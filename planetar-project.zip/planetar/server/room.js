// Кімната гри в реальному часі (Durable Object, безкоштовний варіант із SQLite).
// Одна кімната = один код. Перший, хто зайшов, — ведучий: він задає гру,
// кількість гравців (2–12), ботів на вільні місця й починає гру.
// Сервер лише впорядковує повідомлення: повний стан гри може слати тільки ведучий,
// а кожен гравець — лише власні ходи. Тексту між гравцями немає, лише емодзі.
export class Room {
  constructor(ctx, env) { this.ctx = ctx; this.env = env; }

  async cfg() { return (await this.ctx.storage.get('cfg')) || { game: 'race', max: 4, bots: true, started: false, seq: 0, host: null, data: null }; }
  async save(c) { await this.ctx.storage.put('cfg', c); }
  open(except) { return this.ctx.getWebSockets().filter((w) => w !== except && w.readyState === 1 && w.deserializeAttachment()); }
  seats(except) { return this.open(except).map((w) => w.deserializeAttachment()); }
  send(ws, m) { try { ws.send(JSON.stringify(m)); } catch (_) { } }
  all(m, except) { for (const w of this.open(except)) this.send(w, m); }

  async lobby(except) {
    const c = await this.cfg(); const seats = this.seats(except);
    if (seats.length && !seats.some((p) => p.seat === c.host)) { c.host = Math.min(...seats.map((p) => p.seat)); await this.save(c); }
    this.all({ t: 'lobby', game: c.game, max: c.max, bots: c.bots, started: c.started, host: c.host, data: c.data, players: seats.map((p) => ({ seat: p.seat, name: p.name })) }, except);
  }

  async fetch(req) {
    const url = new URL(req.url);
    if (url.pathname.endsWith('/info')) {
      const c = await this.cfg();
      if (req.method === 'POST') { const b = await req.json(); Object.assign(c, { game: b.game, max: b.max, bots: b.bots }); await this.save(c); return Response.json({ ok: true }); }
      return Response.json({ ok: true, game: c.game, max: c.max, started: c.started, players: this.seats().length });
    }
    if (req.headers.get('upgrade') !== 'websocket') return new Response('потрібен WebSocket', { status: 426 });
    const c = await this.cfg();
    if (this.seats().length >= c.max) return new Response('кімната заповнена', { status: 409 });
    const pair = new WebSocketPair();
    this.ctx.acceptWebSocket(pair[1]);
    return new Response(null, { status: 101, webSocket: pair[0] });
  }

  async webSocketMessage(ws, raw) {
    if (typeof raw !== 'string' || raw.length > 8000) return;
    let m; try { m = JSON.parse(raw); } catch (_) { return; }
    const c = await this.cfg();
    let me = ws.deserializeAttachment();
    if (m.t === 'hello') {
      if (me) return;
      const used = new Set(this.seats().map((p) => p.seat));
      let seat = 0; while (used.has(seat)) seat++;
      me = { seat, name: String(m.name || 'Гравець').replace(/[<>]/g, '').slice(0, 16) || 'Гравець' };
      ws.serializeAttachment(me);
      if (c.host === null || !this.seats(ws).some((p) => p.seat === c.host)) { c.host = seat; await this.save(c); }
      this.send(ws, { t: 'you', seat });
      if (c.started) this.send(ws, { t: 'start', game: c.game, data: c.data, late: true });
      return this.lobby();
    }
    if (!me) return;
    const host = me.seat === c.host;
    if (m.t === 'max' && host && !c.started) { c.max = Math.max(Math.max(2, this.seats().length), Math.min(12, Number(m.n) || 2)); await this.save(c); return this.lobby(); }
    if (m.t === 'bots' && host && !c.started) { c.bots = !!m.on; await this.save(c); return this.lobby(); }
    if (m.t === 'game' && host && !c.started) { c.game = String(m.game || 'race').slice(0, 20); c.data = m.data || null; await this.save(c); return this.lobby(); }
    if (m.t === 'start' && host && !c.started) { c.started = true; c.seq = 0; c.data = m.data || c.data; await this.save(c); this.all({ t: 'start', game: c.game, data: c.data, max: c.max, bots: c.bots }); return this.lobby(); }
    if (m.t === 'reset' && host) { c.started = false; c.data = null; await this.save(c); this.all({ t: 'reset' }); return this.lobby(); }
    if (m.t === 'move' || m.t === 'state') {
      if (m.t === 'state' && !host) return; // повний стан гри розсилає лише ведучий
      if (m.data && m.data.bot !== undefined && !host) return; // за ботів ходить лише ведучий
      c.seq++; await this.save(c);
      return this.all({ t: m.t, from: me.seat, seq: c.seq, data: m.data });
    }
    if (m.t === 'emote') return this.all({ t: 'emote', from: me.seat, e: String(m.e || '').slice(0, 4) });
  }
  async webSocketClose(ws) { try { ws.close(); } catch (_) { } await this.lobby(ws); }
  async webSocketError(ws) { await this.lobby(ws); }
}
