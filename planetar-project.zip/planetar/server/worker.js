// Planetar — сервер на Cloudflare Workers.
// Один файл: API приставки, Telegram-бот, ШІ, рейтинг, виклики, світи, майстерня.
// Головне правило: кожен запис має власника (owner), і змінити чи видалити
// його може лише власник. Чужі світи й картриджі — тільки перегляд або копія.
//
// Налаштовувати руками майже нічого не треба:
//  • таблиці в базі створюються самі при першому запиті;
//  • таємний ключ для підпису входу генерується сам і лежить у базі;
//  • якщо додано секрет TG_TOKEN, бот підключається сам при першому відкритті сайту.
// Секрет ADMIN_KEY потрібен лише для дій адміна (схвалити картридж, перепідключити бота).
export { Room } from './room.js';

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)`,
  `CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, tg_id INTEGER UNIQUE, chat_id INTEGER, name TEXT, lang TEXT, created INTEGER, role TEXT DEFAULT 'player', notify INTEGER DEFAULT 0, last_daily TEXT, remind_at TEXT)`,
  `CREATE TABLE IF NOT EXISTS scores (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, game TEXT, level TEXT, day TEXT, t INTEGER, m INTEGER, h INTEGER, score INTEGER, created INTEGER)`,
  `CREATE INDEX IF NOT EXISTS scores_day ON scores(day, game, level, score DESC)`,
  `CREATE INDEX IF NOT EXISTS scores_user ON scores(user_id, created)`,
  `CREATE TABLE IF NOT EXISTS challenges (code TEXT PRIMARY KEY, owner TEXT, game TEXT, level TEXT, seed TEXT, t INTEGER, m INTEGER, h INTEGER, created INTEGER)`,
  `CREATE TABLE IF NOT EXISTS challenge_results (code TEXT, user_id TEXT, t INTEGER, m INTEGER, h INTEGER, created INTEGER, PRIMARY KEY (code, user_id))`,
  `CREATE TABLE IF NOT EXISTS worlds (owner TEXT, game TEXT, data TEXT, shared TEXT, updated INTEGER, PRIMARY KEY (owner, game))`,
  `CREATE TABLE IF NOT EXISTS proposals (id INTEGER PRIMARY KEY AUTOINCREMENT, from_user TEXT, to_user TEXT, game TEXT, kind TEXT, payload TEXT, status TEXT DEFAULT 'new', created INTEGER)`,
  `CREATE TABLE IF NOT EXISTS carts (id TEXT PRIMARY KEY, owner TEXT, name TEXT, kind TEXT, status TEXT DEFAULT 'private', forked_from TEXT, version INTEGER, updated INTEGER)`,
  `CREATE TABLE IF NOT EXISTS cart_versions (cart_id TEXT, version INTEGER, manifest TEXT, code TEXT, created INTEGER, PRIMARY KEY (cart_id, version))`,
  `CREATE TABLE IF NOT EXISTS ai_usage (user_id TEXT, day TEXT, n INTEGER, PRIMARY KEY (user_id, day))`,
  `CREATE TABLE IF NOT EXISTS progress (user_id TEXT PRIMARY KEY, data TEXT, updated INTEGER)`,
  `CREATE TABLE IF NOT EXISTS links (code TEXT PRIMARY KEY, user_id TEXT, created INTEGER)`,
  // вхід на іншому пристрої за одноразовим посиланням і збережений прогрес усіх ігор (один на гравця)
  `CREATE TABLE IF NOT EXISTS logins (code TEXT PRIMARY KEY, user_id TEXT, created INTEGER)`,
  `CREATE TABLE IF NOT EXISTS saves (user_id TEXT PRIMARY KEY, data TEXT, hash TEXT, updated INTEGER)`,
  // кімнати без Durable Objects (варіант «із планшета», Cloudflare Pages): гравці питають сервер раз на секунду
  `CREATE TABLE IF NOT EXISTS rooms (code TEXT PRIMARY KEY, cfg TEXT, n INTEGER DEFAULT 0, updated INTEGER)`,
  `CREATE TABLE IF NOT EXISTS room_seats (code TEXT, sid TEXT, seat INTEGER, name TEXT, seen INTEGER, PRIMARY KEY (code, sid))`,
  `CREATE UNIQUE INDEX IF NOT EXISTS room_seat_no ON room_seats(code, seat)`,
  `CREATE TABLE IF NOT EXISTS room_msgs (code TEXT, n INTEGER, dest INTEGER, data TEXT, created INTEGER, PRIMARY KEY (code, n))`
];

const J = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' } });
const bad = (msg, status = 400) => J({ ok: false, error: msg }, status);
const now = () => Date.now();
const today = () => new Date().toISOString().slice(0, 10);
const rid = (n = 10) => { const a = new Uint8Array(n); crypto.getRandomValues(a); return [...a].map((b) => 'abcdefghjkmnpqrstuvwxyz23456789'[b % 31]).join(''); };
const enc = new TextEncoder();
async function hmac(key, msg) { const k = await crypto.subtle.importKey('raw', typeof key === 'string' ? enc.encode(key) : key, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']); return new Uint8Array(await crypto.subtle.sign('HMAC', k, enc.encode(msg))); }
const hex = (u8) => [...u8].map((b) => b.toString(16).padStart(2, '0')).join('');
async function sha256(s) { return new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(s))); }
function same(a, b) { if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false; let x = 0; for (let i = 0; i < a.length; i++) x |= a.charCodeAt(i) ^ b.charCodeAt(i); return x === 0; }

/* ---------- база: таблиці й таємний ключ створюються самі ---------- */
let ready = null, SECRET = null;
function ensure(env) {
  if (!ready) ready = (async () => {
    await env.DB.batch(SCHEMA.map((q) => env.DB.prepare(q)));
    try { await env.DB.prepare('ALTER TABLE users ADD COLUMN remind_at TEXT').run(); } catch (_) { } // старі бази: свій час нагадування
    let row = await env.DB.prepare("SELECT v FROM meta WHERE k = 'secret'").first();
    if (!row) { await env.DB.prepare("INSERT OR IGNORE INTO meta (k, v) VALUES ('secret', ?)").bind(rid(40)).run(); row = await env.DB.prepare("SELECT v FROM meta WHERE k = 'secret'").first(); }
    SECRET = row.v;
  })().catch((e) => { ready = null; throw e; });
  return ready;
}
/* ---------- налаштування, які міняються без перезаливу ----------
   Відкрий у браузері: /api/admin/settings?key=ADMIN_KEY — подивитись;
   /api/admin/set?key=ADMIN_KEY&remind=18:30 — змінити (кілька одразу: &tz=Europe/Kyiv&ai_limit=60); значення default — повернути стандартне.
   Порядок: що задано так → змінна в Cloudflare (Variables) → стандарт нижче. Опис — docs/НАЛАШТУВАННЯ.md */
const SETTINGS = {
  remind: { env: 'REMIND_AT', def: '17:17', ok: (v) => /^([01]\d|2[0-3]):[0-5]\d$/.test(v), about: 'час щоденного нагадування (ГГ:ХХ); кожен гравець може обрати свій: /remind 19:30' },
  tz: { env: 'TZ_NAME', def: 'Europe/Kyiv', ok: (v) => { try { new Intl.DateTimeFormat('en', { timeZone: v }); return true; } catch (_) { return false; } }, about: 'часовий пояс для нагадувань' },
  ai_limit: { env: 'AI_DAILY_LIMIT', def: '40', ok: (v) => /^\d{1,4}$/.test(v), about: 'скільки розмов із ШІ на гравця за день' },
  ai_model: { env: 'AI_MODEL', def: '@cf/meta/llama-3.3-70b-instruct-fp8-fast', ok: (v) => /^@cf\/[\w.\/-]+$/.test(v), about: 'перша модель Workers AI (якщо не відповідає — беруться запасні)' }
};
let SET_CACHE = null, SET_AT = 0;
async function settings(env) {
  if (SET_CACHE && now() - SET_AT < 60e3) return SET_CACHE;
  const rows = (await env.DB.prepare("SELECT k, v FROM meta WHERE k LIKE 'set_%'").all()).results || [];
  const db = Object.fromEntries(rows.map((r) => [r.k.slice(4), r.v])), out = {};
  for (const [k, d] of Object.entries(SETTINGS)) { const e = env[d.env]; out[k] = db[k] ?? (e != null && String(e) !== '' && d.ok(String(e)) ? String(e) : d.def); }
  SET_CACHE = out; SET_AT = now(); return out;
}
async function setSettings(env, q) {
  const bad = [];
  for (const [k, d] of Object.entries(SETTINGS)) {
    if (!q.has(k)) continue; const v = q.get(k).trim();
    if (v === 'default' || v === '') await env.DB.prepare('DELETE FROM meta WHERE k = ?').bind('set_' + k).run();
    else if (d.ok(v)) await setMeta(env, 'set_' + k, v); else bad.push(k);
  }
  SET_CACHE = null; return bad;
}
// місцевий час у вибраному поясі: дата, ГГ:ХХ, чи неділя
function localNow(tz) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', weekday: 'short', hour12: false }).formatToParts(new Date()).map((x) => [x.type, x.value]));
  return { date: `${p.year}-${p.month}-${p.day}`, hm: `${p.hour === '24' ? '00' : p.hour}:${p.minute}`, sunday: p.weekday === 'Sun' };
}
const meta = async (env, k) => (await env.DB.prepare('SELECT v FROM meta WHERE k = ?').bind(k).first())?.v;
const setMeta = (env, k, v) => env.DB.prepare('INSERT INTO meta (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v').bind(k, v).run();

/* ---------- обмеження частоти (на один екземпляр сервера, грубо) ---------- */
const HITS = new Map();
function tooMany(req, limit = 90) {
  const ip = req.headers.get('cf-connecting-ip') || 'local'; const m = Math.floor(now() / 60000);
  const h = HITS.get(ip); if (!h || h.m !== m) { HITS.set(ip, { m, n: 1 }); if (HITS.size > 5000) HITS.clear(); return false; }
  return ++h.n > limit;
}

/* ---------- вхід: сесія uid.exp.sig, підписана таємним ключем з бази ---------- */
async function sign(uid) { const exp = now() + 180 * 864e5; const body = `${uid}.${exp}`; return `${body}.${hex(await hmac(SECRET, body))}`; }
async function auth(req) {
  const tok = (req.headers.get('authorization') || '').replace(/^Bearer\s+/i, '');
  const [uid, exp, sig] = tok.split('.'); if (!uid || !exp || !sig || +exp < now()) return null;
  return same(hex(await hmac(SECRET, `${uid}.${exp}`)), sig) ? uid : null;
}
// Telegram Mini App: перевірка initData (ключ = HMAC("WebAppData", токен бота))
async function checkInitData(initData, token) {
  if (!token) return null;
  const p = new URLSearchParams(initData); const hash = p.get('hash'); if (!hash) return null; p.delete('hash');
  const line = [...p.entries()].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)).map(([k, v]) => `${k}=${v}`).join('\n');
  if (!same(hex(await hmac(await hmac('WebAppData', token), line)), hash)) return null;
  if (now() / 1000 - Number(p.get('auth_date') || 0) > 86400) return null;
  try { return JSON.parse(p.get('user') || 'null'); } catch (_) { return null; }
}
// Telegram Login Widget на звичайному сайті (ключ = SHA256(токен бота))
async function checkWidget(d, token) {
  if (!token || !d || !d.hash) return null; const { hash, ...rest } = d;
  const line = Object.keys(rest).sort().map((k) => `${k}=${rest[k]}`).join('\n');
  if (!same(hex(await hmac(await sha256(token), line)), hash)) return null;
  if (now() / 1000 - Number(d.auth_date || 0) > 86400) return null;
  return { id: Number(d.id), first_name: d.first_name, username: d.username, language_code: d.language_code };
}
// Ім'я для рейтингу: коротке, без посилань і лайки
const BADW = /(ху[йяеї]|пизд|бля|еба|ёба|єба|сук[аи]|муда|fuck|shit|bitch|dick|porn|nazi|http|www\.|t\.me)/i;
function cleanName(s, d = 'Гравець') { s = String(s || '').replace(/[^\p{L}\p{N} _.-]/gu, '').replace(/\s+/g, ' ').trim().slice(0, 16); return s.length >= 2 && !BADW.test(s) ? s : d; }
async function upsertTg(env, u, chatId) {
  const row = await env.DB.prepare('SELECT id FROM users WHERE tg_id = ?').bind(u.id).first();
  if (row) { if (chatId) await env.DB.prepare('UPDATE users SET chat_id = ? WHERE id = ?').bind(chatId, row.id).run(); return row.id; }
  const id = 'u_' + rid(12);
  await env.DB.prepare('INSERT INTO users (id, tg_id, chat_id, name, lang, created) VALUES (?,?,?,?,?,?)').bind(id, u.id, chatId || null, cleanName(u.first_name || u.username), (u.language_code || 'uk').slice(0, 2), now()).run();
  return id;
}
const isAdmin = (url, env) => !!env.ADMIN_KEY && same(url.searchParams.get('key') || '', env.ADMIN_KEY);

/* ---------- Telegram ----------
   Бот підключається сам: додай секрет TG_TOKEN і відкрий сайт (або /api/tg/setup?key=ADMIN_KEY).
   Що вміє (див. docs/BOT_AI.md):
     /start — привітання й кнопки; /start link_… — привʼязати приставку з браузера; room_… / ch_… — посилання друга
     /play, /pet, /me, /games, /daily, /rating, /room КОД, /remind, /help
     звичайне повідомлення в особистому чаті — відповідає улюбленець (ШІ, з денним лімітом)
     інлайн-режим (@бот у будь-якому чаті) — запросити друга або кинути задачу дня
   У групах бот лише відповідає на команди, без ШІ (безпека дітей). */
const TG_API = (env) => env.TG_API || 'https://api.telegram.org'; // TG_API можна підмінити для перевірок
async function tg(env, method, body) {
  if (!env.TG_TOKEN) return { ok: false, description: 'TG_TOKEN не задано' };
  try { const r = await fetch(`${TG_API(env)}/bot${env.TG_TOKEN}/${method}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); return await r.json(); } catch (e) { return { ok: false, description: String(e) }; }
}
const tgSecret = async () => hex(await hmac(SECRET, 'tg-hook')).slice(0, 48);
const CMDS = {
  uk: [['play', 'Відкрити приставку'], ['pet', 'Як там мій улюбленець'], ['me', 'Мій прогрес'], ['web', 'Грати в браузері / на іншому пристрої'], ['games', 'Відкрити гру'], ['daily', 'Задача дня'], ['rating', 'Найкращі сьогодні'], ['room', 'Увійти в кімнату за кодом'], ['remind', 'Нагадування (свій час: /remind 19:30)'], ['help', 'Що вміє бот']],
  en: [['play', 'Open the console'], ['pet', 'How is my pet'], ['me', 'My progress'], ['web', 'Play in a browser / another device'], ['games', 'Open a game'], ['daily', 'Puzzle of the day'], ['rating', 'Best today'], ['room', 'Join a room by code'], ['remind', 'Reminders (own time: /remind 19:30)'], ['help', 'What the bot can do']],
  ru: [['play', 'Открыть приставку'], ['pet', 'Как мой питомец'], ['me', 'Мой прогресс'], ['web', 'Играть в браузере / на другом устройстве'], ['games', 'Открыть игру'], ['daily', 'Задача дня'], ['rating', 'Лучшие сегодня'], ['room', 'Войти в комнату по коду'], ['remind', 'Напоминания (своё время: /remind 19:30)'], ['help', 'Что умеет бот']]
};
const ABOUT = {
  uk: ['Приставка з улюбленцем, головоломками й 3D-іграми. Тисни «Грати» або пиши — відповість твій улюбленець.', 'Planetar: улюбленець, головоломки, Ферма, Іскра, Біт, Історії'],
  en: ['A console with a pet, puzzles and 3D games. Tap “Play” or write — your pet will answer.', 'Planetar: pet, puzzles, Farm, Iskra, Bit, Stories'],
  ru: ['Приставка с питомцем, головоломками и 3D-играми. Жми «Играть» или пиши — ответит твой питомец.', 'Planetar: питомец, головоломки, Ферма, Искра, Бит, Истории']
};
async function tgConnect(env, origin) {
  const hook = await tg(env, 'setWebhook', { url: `${origin}/api/tg/hook`, secret_token: await tgSecret(), allowed_updates: ['message', 'callback_query', 'inline_query'] });
  if (!hook.ok) return hook;
  const me = await tg(env, 'getMe', {}); if (me.ok) await setMeta(env, 'tg_bot', me.result.username);
  for (const [lang, list] of Object.entries(CMDS)) {
    const lc = lang === 'uk' ? {} : { language_code: lang };
    await tg(env, 'setMyCommands', { commands: list.map(([command, description]) => ({ command, description })), ...lc });
    await tg(env, 'setMyDescription', { description: ABOUT[lang][0], ...lc });
    await tg(env, 'setMyShortDescription', { short_description: ABOUT[lang][1], ...lc });
  }
  await tg(env, 'setChatMenuButton', { menu_button: { type: 'web_app', text: 'Planetar', web_app: { url: `${origin}/play/` } } });
  await setMeta(env, 'tg_hook', `${origin}|${hex(await sha256(env.TG_TOKEN)).slice(0, 12)}`);
  return { ...hook, bot: me.ok ? me.result.username : null };
}
async function tgAuto(env, origin) {
  if (!env.TG_TOKEN || !/^https:/.test(origin)) return;
  const want = `${origin}|${hex(await sha256(env.TG_TOKEN)).slice(0, 12)}`;
  if ((await meta(env, 'tg_hook')) !== want) await tgConnect(env, origin);
}
const BOT_TXT = {
  uk: {
    hi: 'Привіт, {n}! Я бот Planetar — приставки з улюбленцем, головоломками й 3D-іграми. Тисни кнопку або просто напиши мені — відповім від імені твого улюбленця.',
    play: 'Грати', pet: 'Улюбленець', me: 'Мій прогрес', games: 'Ігри', daily: 'Задача дня', top: 'Найкращі сьогодні', rating: 'Рейтинг',
    none: 'Сьогодні ще ніхто не грав. Будь першим!', room: 'Кімната', join: 'Увійти', roomAsk: 'Напиши так: /room КОД', on: 'Добре, нагадуватиму щодня о {t} (задача дня й новини улюбленця). Інший час: /remind 19:30, вимкнути: /remind off.', remindAsk: 'Напиши час так: /remind 19:30 (зараз {t}). Вимкнути: /remind off.', off: 'Нагадування вимкнено.',
    webBtn: 'Грати в браузері', web: 'Твоє посилання, щоб грати в браузері чи на іншому пристрої з тим самим прогресом. Діє 15 хв — нікому не пересилай. Можна відкрити тут, а потім у Safari (⋯ → «Відкрити в Safari»).\nЩоб була іконка на екрані: Safari → Поділитися → «На екран „Додому“».',
    remOn: 'Нагадування: увімк.', remOff: 'Нагадування: вимк.',
    help: 'Що я вмію:\n/play — відкрити приставку\n/pet — як там улюбленець\n/me — мій прогрес у всіх іграх\n/games — відкрити гру\n/daily — задача дня\n/rating — найкращі сьогодні\n/room КОД — увійти в кімнату друга\n/remind 19:30 — нагадування щодня у свій час\nА ще можна просто писати мені — відповість твій улюбленець.',
    noSnap: 'Я ще не бачу твоєї приставки. Відкрий її кнопкою «Грати» тут, у Telegram (або в браузері: Налаштування → кнопка «Telegram») — і я знатиму, як справи.',
    linked: 'Готово! Telegram підключено до твоєї приставки. Тепер /pet і /me показують твої справжні справи.', linkBad: 'Посилання застаріло. У приставці: Налаштування → кнопка «Telegram» — і натисни ще раз.',
    petLine: '{n}: ситість {f}%, вода {w}%, радість {j}%, сили {e}%.', petMiss: '{n} скучив — ви не бачились {d} дн.', petHungry: '{n} зголоднів — нагодуй!', petHappy: '{n} у гарному настрої.',
    farm: 'Ферма: етап {s} з 8, день {d}, {c} монет.', farmFix: 'Ферма: техніка просить догляду ({t}).', farmTrip: 'Вантажівка в дорозі до міста.',
    iskra: 'Іскра: день {d}, відкрито районів {o}.', pz: 'Головоломки: розвʼязано {n}, рейтинг {r}.', story: 'Історії: сцена {s} з {t}.', coins: 'Монет у приставці: {c}.',
    seen: 'Востаннє в приставці: {t}.', aiOff: 'Поговорити не вийде: ШІ на сервері не підключено. Але кнопки працюють!', aiLimit: 'На сьогодні розмов досить — завтра поговоримо ще!', aiBusy: 'Щось я задрімав… Спробуй ще раз трохи пізніше.',
    pick: 'Обери гру:', gFarm: 'Ферма', gIskra: 'Іскра', gBit: 'Біт', gStories: 'Історії', gPuzzles: 'Головоломки', gTogether: 'Разом', gPet: 'Улюбленець',
    weekly: 'Підсумок тижня: {p} балів у головоломках{pl}.', place: ', {n}-е місце', remind: 'Задача дня чекає!', chBeat: '{w} пройшов твій виклик за {t} — швидше за тебе! Відіграєшся?', retry: 'Відігратися',
    iDaily: 'Задача дня', iDailyD: 'Хто розвʼяже швидше?', iPlay: 'Грати в Planetar', iPlayD: 'Улюбленець, головоломки й 3D-ігри', iText: 'Давай зіграємо в Planetar!', iDailyT: 'Задача дня в Planetar — хто швидше?',
    blocked: 'Про таке краще поговорити з дорослими, яким ти довіряєш. А я — про ігри! 🐾', private: 'Не пиши мені адресу, телефон чи школу — це таємниця для своїх.'
  },
  en: {
    hi: 'Hi, {n}! I am the Planetar bot — a console with a pet, puzzles and 3D games. Tap a button or just write to me — your pet will answer.',
    play: 'Play', pet: 'Pet', me: 'My progress', games: 'Games', daily: 'Puzzle of the day', top: 'Best today', rating: 'Rating',
    none: 'Nobody has played today yet. Be the first!', room: 'Room', join: 'Join', roomAsk: 'Write it like this: /room CODE', on: 'OK, I will remind you every day at {t} (puzzle of the day and pet news). Another time: /remind 19:30, turn off: /remind off.', remindAsk: 'Write the time like this: /remind 19:30 (now {t}). Turn off: /remind off.', off: 'Reminders are off.',
    webBtn: 'Play in browser', web: 'Your link to play in a browser or on another device with the same progress. Valid 15 min — do not forward it. You can open it here and then in Safari (⋯ → “Open in Safari”).\nTo get an icon: Safari → Share → “Add to Home Screen”.',
    remOn: 'Reminders: on', remOff: 'Reminders: off',
    help: 'What I can do:\n/play — open the console\n/pet — how your pet is\n/me — progress in all games\n/games — open a game\n/daily — puzzle of the day\n/rating — best today\n/room CODE — join a friend’s room\n/remind 19:30 — daily reminders at your time\nYou can also just write to me — your pet will answer.',
    noSnap: 'I can’t see your console yet. Open it with “Play” here in Telegram (or in a browser: Settings → the “Telegram” button) and I will know how things are.',
    linked: 'Done! Telegram is connected to your console. Now /pet and /me show your real progress.', linkBad: 'This link has expired. In the console: Settings → the “Telegram” button and tap again.',
    petLine: '{n}: food {f}%, water {w}%, joy {j}%, energy {e}%.', petMiss: '{n} misses you — you haven’t met for {d} days.', petHungry: '{n} is hungry — feed them!', petHappy: '{n} is in a good mood.',
    farm: 'Farm: stage {s} of 8, day {d}, {c} coins.', farmFix: 'Farm: machines need care ({t}).', farmTrip: 'The truck is on the road to the city.',
    iskra: 'Iskra: day {d}, districts open {o}.', pz: 'Puzzles: solved {n}, rating {r}.', story: 'Stories: scene {s} of {t}.', coins: 'Coins in the console: {c}.',
    seen: 'Last time in the console: {t}.', aiOff: 'I can’t talk: AI is not connected on the server. The buttons work though!', aiLimit: 'Enough talking for today — let’s chat tomorrow!', aiBusy: 'I dozed off… Try again a bit later.',
    pick: 'Pick a game:', gFarm: 'Farm', gIskra: 'Iskra', gBit: 'Bit', gStories: 'Stories', gPuzzles: 'Puzzles', gTogether: 'Together', gPet: 'Pet',
    weekly: 'Week summary: {p} puzzle points{pl}.', place: ', place {n}', remind: 'The puzzle of the day is waiting!', chBeat: '{w} beat your challenge in {t} — faster than you! Rematch?', retry: 'Rematch',
    iDaily: 'Puzzle of the day', iDailyD: 'Who solves it faster?', iPlay: 'Play Planetar', iPlayD: 'Pet, puzzles and 3D games', iText: 'Let’s play Planetar!', iDailyT: 'Planetar puzzle of the day — who is faster?',
    blocked: 'Better talk about this with an adult you trust. I am here for games! 🐾', private: 'Don’t send me your address, phone or school — keep it secret.'
  },
  ru: {
    hi: 'Привет, {n}! Я бот Planetar — приставки с питомцем, головоломками и 3D-играми. Жми кнопку или просто напиши мне — ответит твой питомец.',
    play: 'Играть', pet: 'Питомец', me: 'Мой прогресс', games: 'Игры', daily: 'Задача дня', top: 'Лучшие сегодня', rating: 'Рейтинг',
    none: 'Сегодня ещё никто не играл. Будь первым!', room: 'Комната', join: 'Войти', roomAsk: 'Напиши так: /room КОД', on: 'Хорошо, буду напоминать каждый день в {t} (задача дня и новости питомца). Другое время: /remind 19:30, выключить: /remind off.', remindAsk: 'Напиши время так: /remind 19:30 (сейчас {t}). Выключить: /remind off.', off: 'Напоминания выключены.',
    webBtn: 'Играть в браузере', web: 'Твоя ссылка, чтобы играть в браузере или на другом устройстве с тем же прогрессом. Действует 15 мин — никому не пересылай. Можно открыть здесь, а потом в Safari (⋯ → «Открыть в Safari»).\nЧтобы была иконка на экране: Safari → Поделиться → «На экран „Домой“».',
    remOn: 'Напоминания: вкл.', remOff: 'Напоминания: выкл.',
    help: 'Что я умею:\n/play — открыть приставку\n/pet — как питомец\n/me — прогресс во всех играх\n/games — открыть игру\n/daily — задача дня\n/rating — лучшие сегодня\n/room КОД — войти в комнату друга\n/remind 19:30 — напоминания в своё время\nА ещё можно просто писать мне — ответит твой питомец.',
    noSnap: 'Я пока не вижу твою приставку. Открой её кнопкой «Играть» здесь, в Telegram (или в браузере: Настройки → кнопка «Telegram»), — и я буду знать, как дела.',
    linked: 'Готово! Telegram подключён к твоей приставке. Теперь /pet и /me показывают настоящие дела.', linkBad: 'Ссылка устарела. В приставке: Настройки → кнопка «Telegram» — и нажми ещё раз.',
    petLine: '{n}: сытость {f}%, вода {w}%, радость {j}%, силы {e}%.', petMiss: '{n} скучает — вы не виделись {d} дн.', petHungry: '{n} проголодался — покорми!', petHappy: '{n} в хорошем настроении.',
    farm: 'Ферма: этап {s} из 8, день {d}, {c} монет.', farmFix: 'Ферма: технике нужен уход ({t}).', farmTrip: 'Грузовик в дороге в город.',
    iskra: 'Искра: день {d}, открыто районов {o}.', pz: 'Головоломки: решено {n}, рейтинг {r}.', story: 'Истории: сцена {s} из {t}.', coins: 'Монет в приставке: {c}.',
    seen: 'Последний раз в приставке: {t}.', aiOff: 'Поговорить не выйдет: ИИ на сервере не подключён. Но кнопки работают!', aiLimit: 'На сегодня разговоров хватит — завтра поговорим ещё!', aiBusy: 'Что-то я задремал… Попробуй чуть позже.',
    pick: 'Выбери игру:', gFarm: 'Ферма', gIskra: 'Искра', gBit: 'Бит', gStories: 'Истории', gPuzzles: 'Головоломки', gTogether: 'Вместе', gPet: 'Питомец',
    weekly: 'Итог недели: {p} баллов в головоломках{pl}.', place: ', {n}-е место', remind: 'Задача дня ждёт!', chBeat: '{w} прошёл твой вызов за {t} — быстрее тебя! Отыграешься?', retry: 'Отыграться',
    iDaily: 'Задача дня', iDailyD: 'Кто решит быстрее?', iPlay: 'Играть в Planetar', iPlayD: 'Питомец, головоломки и 3D-игры', iText: 'Давай сыграем в Planetar!', iDailyT: 'Задача дня в Planetar — кто быстрее?',
    blocked: 'Об этом лучше поговорить со взрослыми, которым ты доверяешь. А я — про игры! 🐾', private: 'Не пиши мне адрес, телефон или школу — это секрет для своих.'
  }
};
const fmtT = (s, o = {}) => String(s).replace(/\{(\w+)\}/g, (_, k) => (o[k] ?? ''));
const PZ_TYPES = ['tango', 'queens', 'sudoku'];
const dailyType = () => PZ_TYPES[Math.floor(now() / 864e5) % 3];
const dailyUrl = (origin) => `${origin}/play/?go=puzzles&c=${dailyType()}.medium.${today()}`;
// кнопки: в особистому чаті — відкривають приставку всередині Telegram (Mini App), у групах — звичайним посиланням
const openBtn = (priv, url, text) => (priv ? { text, web_app: { url } } : { text, url });
const kb = (rows) => ({ inline_keyboard: rows });
function mainKb(T, priv, play, notify) {
  return kb([[openBtn(priv, play, '▶ ' + T.play)], [{ text: T.pet, callback_data: 'pet' }, { text: T.me, callback_data: 'me' }], [{ text: T.games, callback_data: 'games' }, { text: T.daily, callback_data: 'daily' }], [{ text: T.rating, callback_data: 'rating' }, { text: notify ? T.remOn : T.remOff, callback_data: 'remind' }], [{ text: '🌐 ' + T.webBtn, callback_data: 'web' }]]);
}
function gamesKb(T, priv, play) {
  const g = (id, name) => openBtn(priv, `${play}?game=${id}`, name), r = (route, name) => openBtn(priv, `${play}?go=${route}`, name);
  return kb([[g('boby', T.gFarm), g('iskra', T.gIskra)], [g('bit', T.gBit), g('istorii', T.gStories)], [r('puzzles', T.gPuzzles), r('pet', T.gPet)], [r('together', T.gTogether)]]);
}
// стан приставки (знімок, який приставка надсилає сама) → короткий текст
async function progressOf(env, uid) { const r = uid && await env.DB.prepare('SELECT data, updated FROM progress WHERE user_id = ?').bind(uid).first(); if (!r) return null; try { return { ...JSON.parse(r.data), _at: r.updated }; } catch (_) { return null; } }
const daysSince = (t) => Math.floor((now() - t) / 864e5);
function petText(T, p) {
  const pt = p && p.pet; if (!pt) return T.noSnap;
  const n = pt.name || 'Улюбленець', nd = pt.needs || {}, lines = [fmtT(T.petLine, { n, f: nd.food ?? '?', w: nd.water ?? '?', j: nd.joy ?? '?', e: nd.energy ?? '?' })];
  const d = daysSince(p._at); if (d >= 1) lines.push(fmtT(T.petMiss, { n, d })); else if ((nd.food ?? 100) < 35) lines.push(fmtT(T.petHungry, { n })); else lines.push(fmtT(T.petHappy, { n }));
  return lines.join('\n');
}
function meText(T, p, lang) {
  if (!p) return T.noSnap;
  const L = [];
  if (p.pet) L.push(petText(T, p).split('\n')[0]);
  if (p.farm) { L.push(fmtT(T.farm, { s: (p.farm.stage || 0) + 1, d: p.farm.day || 1, c: p.farm.coins || 0 })); if (p.farm.care && p.farm.care.length) L.push(fmtT(T.farmFix, { t: p.farm.care.join(', ') })); if (p.farm.trip) L.push(T.farmTrip); }
  if (p.iskra) L.push(fmtT(T.iskra, { d: p.iskra.day || 1, o: p.iskra.open || 0 }));
  if (p.puzzles) L.push(fmtT(T.pz, { n: p.puzzles.solved || 0, r: p.puzzles.rating || 0 }));
  if (p.story && p.story.total) L.push(fmtT(T.story, { s: (p.story.scene || 0) + 1, t: p.story.total }));
  if (p.coins !== undefined) L.push(fmtT(T.coins, { c: p.coins }));
  L.push(fmtT(T.seen, { t: new Date(p._at).toLocaleString(lang === 'en' ? 'en-GB' : lang === 'ru' ? 'ru-RU' : 'uk-UA', { timeZone: 'Europe/Kyiv', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }) }));
  return L.join('\n');
}
async function ratingText(env, T) {
  const rows = (await env.DB.prepare('SELECT u.name, SUM(s.score) AS pts FROM scores s JOIN users u ON u.id = s.user_id WHERE s.day = ? GROUP BY s.user_id ORDER BY pts DESC LIMIT 10').bind(today()).all()).results || [];
  return rows.length ? `🏆 ${T.top}\n` + rows.map((r, i) => `${i + 1}. ${r.name} — ${r.pts}`).join('\n') : T.none;
}
// привʼязка: приставка в браузері (гість) + Telegram = один гравець
// посилання «продовжити на іншому пристрої»: діє 15 хв
async function newLogin(env, uid) {
  const code = rid(12); await env.DB.batch([env.DB.prepare('DELETE FROM logins WHERE created < ?').bind(now() - 15 * 60e3), env.DB.prepare('INSERT INTO logins (code, user_id, created) VALUES (?,?,?)').bind(code, uid, now())]);
  return code;
}
async function useLogin(env, code) {
  // 15 хв посилання працює й повторно: Telegram спершу відкриває його у своєму браузері, а потім людина переходить у Safari
  const row = await env.DB.prepare('SELECT user_id, created FROM logins WHERE code = ?').bind(String(code || '').slice(0, 20)).first();
  return row && now() - row.created < 15 * 60e3 ? row.user_id : null;
}
async function linkTg(env, code, from, chat) {
  const row = await env.DB.prepare('SELECT user_id, created FROM links WHERE code = ?').bind(code).first();
  if (!row || now() - row.created > 30 * 60e3) return null;
  await env.DB.prepare('DELETE FROM links WHERE code = ?').bind(code).run();
  const G = row.user_id, old = await env.DB.prepare('SELECT id FROM users WHERE tg_id = ?').bind(from.id).first();
  const st = [];
  if (old && old.id !== G) { // Telegram уже мав свій обліковий запис — переносимо все до приставки
    for (const q of ['UPDATE scores SET user_id = ?1 WHERE user_id = ?2', 'UPDATE OR IGNORE challenge_results SET user_id = ?1 WHERE user_id = ?2', 'UPDATE challenges SET owner = ?1 WHERE owner = ?2', 'UPDATE OR IGNORE progress SET user_id = ?1 WHERE user_id = ?2 AND NOT EXISTS (SELECT 1 FROM progress WHERE user_id = ?1)']) st.push(env.DB.prepare(q).bind(G, old.id));
    st.push(env.DB.prepare('UPDATE users SET tg_id = NULL, chat_id = NULL WHERE id = ?').bind(old.id));
  }
  st.push(env.DB.prepare("UPDATE users SET tg_id = ?, chat_id = ?, role = CASE WHEN role = 'guest' THEN 'player' ELSE role END WHERE id = ?").bind(from.id, chat, G));
  await env.DB.batch(st);
  return G;
}
async function botUpdate(env, origin, upd) {
  const play = `${origin}/play/`;
  // інлайн-режим: @бот у будь-якому чаті
  if (upd.inline_query) {
    const q = upd.inline_query, T = BOT_TXT[(q.from.language_code || 'uk').slice(0, 2)] || BOT_TXT.uk;
    const art = (id, title, description, text, url, btnText) => ({ type: 'article', id, title, description, input_message_content: { message_text: text }, reply_markup: kb([[{ text: btnText, url }]]) });
    return tg(env, 'answerInlineQuery', { inline_query_id: q.id, cache_time: 300, is_personal: false, results: [art('daily', T.iDaily, T.iDailyD, T.iDailyT, dailyUrl(origin), '▶ ' + T.play), art('play', T.iPlay, T.iPlayD, T.iText, play, '▶ ' + T.play)] });
  }
  // натискання кнопок під повідомленням
  if (upd.callback_query) {
    const c = upd.callback_query, msg = c.message; if (!msg) return;
    const T = BOT_TXT[(c.from.language_code || 'uk').slice(0, 2)] || BOT_TXT.uk, chat = msg.chat.id, priv = msg.chat.type === 'private';
    await tg(env, 'answerCallbackQuery', { callback_query_id: c.id });
    const uid = priv ? await upsertTg(env, c.from, chat) : null;
    return botAction(env, origin, c.data, { T, chat, priv, uid, lang: (c.from.language_code || 'uk').slice(0, 2) });
  }
  const msg = upd.message; if (!msg || !msg.text || !msg.from) return;
  const lang = (msg.from.language_code || 'uk').slice(0, 2), T = BOT_TXT[lang] || BOT_TXT.uk;
  const chat = msg.chat.id, priv = msg.chat.type === 'private', text = msg.text.trim();
  let uid = priv ? await upsertTg(env, msg.from, chat) : null;
  const cmd = ((text.match(/^\/([\p{L}\d_]+)(?:@\w+)?/u) || [])[1] || '').toLowerCase() || null;
  const ctx = { T, chat, priv, uid, lang };
  if (cmd === 'start' || cmd === 'play') {
    const arg = text.split(/\s+/)[1] || '';
    if (/^link_[a-z0-9]{8,12}$/.test(arg) && priv) { const g = await linkTg(env, arg.slice(5), msg.from, chat); ctx.uid = g || uid; return tg(env, 'sendMessage', { chat_id: chat, text: g ? T.linked : T.linkBad, reply_markup: mainKb(T, priv, play, await notifyOf(env, ctx.uid)) }); }
    if (/^room_[A-Z0-9]{4,8}$/.test(arg)) return tg(env, 'sendMessage', { chat_id: chat, text: `${T.room} ${arg.slice(5)}`, reply_markup: kb([[openBtn(priv, `${play}?room=${arg.slice(5)}`, T.join)]]) });
    if (/^ch_[a-z0-9]{6,10}$/.test(arg)) return tg(env, 'sendMessage', { chat_id: chat, text: '⚔️', reply_markup: kb([[openBtn(priv, `${play}?ch=${arg.slice(3)}`, T.play)]]) });
    return tg(env, 'sendMessage', { chat_id: chat, text: fmtT(T.hi, { n: cleanName(msg.from.first_name, '') || '👋' }), reply_markup: mainKb(T, priv, play, await notifyOf(env, uid)) });
  }
  if (cmd === 'room') {
    const c = (text.split(/\s+/)[1] || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
    return tg(env, 'sendMessage', c.length >= 4 ? { chat_id: chat, text: `${T.room} ${c}`, reply_markup: kb([[openBtn(priv, `${play}?room=${c}`, T.join)]]) } : { chat_id: chat, text: T.roomAsk });
  }
  if (cmd === 'remind') return remindCmd(env, ctx, text.split(/\s+/)[1] || '');
  if (['pet', 'me', 'games', 'daily', 'rating', 'help', 'web'].includes(cmd)) return botAction(env, origin, cmd, ctx);
  if (cmd) return botAction(env, origin, 'help', ctx);
  // звичайний текст: в особистому чаті відповідає улюбленець (ШІ); у групах мовчимо
  if (!priv) return;
  return petChat(env, origin, ctx, text);
}
// /remind — увімкнути/вимкнути; /remind 19:30 — свій час; /remind off — вимкнути
async function remindCmd(env, { T, chat, uid }, arg) {
  const send = (text) => tg(env, 'sendMessage', { chat_id: chat, text });
  if (!uid) return send(T.help);
  const S = await settings(env), a = String(arg).trim().toLowerCase();
  const u = await env.DB.prepare('SELECT notify, remind_at FROM users WHERE id = ?').bind(uid).first() || {};
  if (/^(off|stop|0|вимк\S*|выкл\S*|стоп)$/.test(a)) { await env.DB.prepare('UPDATE users SET notify = 0 WHERE id = ?').bind(uid).run(); return send(T.off); }
  const m = a.replace(/[.\-]/, ':').match(/^([01]?\d|2[0-3]):([0-5]\d)$/);
  if (a && !m) return send(fmtT(T.remindAsk, { t: u.remind_at || S.remind }));
  if (m) { const hm = m[1].padStart(2, '0') + ':' + m[2]; await env.DB.prepare('UPDATE users SET notify = 1, remind_at = ? WHERE id = ?').bind(hm, uid).run(); return send(fmtT(T.on, { t: hm })); }
  const on = u.notify ? 0 : 1; await env.DB.prepare('UPDATE users SET notify = ? WHERE id = ?').bind(on, uid).run();
  return send(on ? fmtT(T.on, { t: u.remind_at || S.remind }) : T.off);
}
async function notifyOf(env, uid) { if (!uid) return 0; const u = await env.DB.prepare('SELECT notify FROM users WHERE id = ?').bind(uid).first(); return u ? u.notify : 0; }
async function botAction(env, origin, what, { T, chat, priv, uid, lang }) {
  const play = `${origin}/play/`, send = (text, reply_markup) => tg(env, 'sendMessage', { chat_id: chat, text, ...(reply_markup ? { reply_markup } : {}) });
  if (what === 'pet') { const p = await progressOf(env, uid); return send(petText(T, p), kb([[openBtn(priv, `${play}?go=pet`, '🐾 ' + T.pet)]])); }
  if (what === 'me') { const p = await progressOf(env, uid); return send(meText(T, p, lang), kb([[openBtn(priv, play, '▶ ' + T.play)]])); }
  if (what === 'games') return send(T.pick, gamesKb(T, priv, play));
  if (what === 'daily') return send(`📅 ${T.daily}`, kb([[openBtn(priv, dailyUrl(origin), '▶ ' + T.play)]]));
  if (what === 'rating') return send(await ratingText(env, T), kb([[openBtn(priv, `${play}?go=puzzles`, '▶ ' + T.play)]]));
  if (what === 'remind' && uid) return remindCmd(env, { T, chat, uid }, '');
  if (what === 'web' && uid) { const code = await newLogin(env, uid); return send(T.web, kb([[{ text: '🌐 ' + T.webBtn, url: `${play}?login=${code}` }]])); }
  return send(T.help, mainKb(T, priv, play, await notifyOf(env, uid)));
}
// розмова з улюбленцем у Telegram: той самий ШІ й той самий денний ліміт, що в приставці
async function petChat(env, origin, { T, chat, uid, lang }, text) {
  const mod = moderate(text); if (mod) return tg(env, 'sendMessage', { chat_id: chat, text: T[mod] });
  if (!env.AI && !env.AI_MOCK) return tg(env, 'sendMessage', { chat_id: chat, text: T.aiOff, reply_markup: kb([[openBtn(true, `${origin}/play/`, '▶ ' + T.play)]]) });
  await tg(env, 'sendChatAction', { chat_id: chat, action: 'typing' });
  const p = await progressOf(env, uid);
  const hist = JSON.parse((await meta(env, 'chat:' + uid)) || '[]').slice(-6);
  hist.push({ role: 'user', content: text.slice(0, 400) });
  const r = await aiText(env, uid, { task: 'pet', system: petSystem(p, lang), messages: hist });
  if (!r.ok) return tg(env, 'sendMessage', { chat_id: chat, text: r.error === 'limit' ? T.aiLimit : T.aiBusy });
  hist.push({ role: 'assistant', content: r.text }); await setMeta(env, 'chat:' + uid, JSON.stringify(hist.slice(-8)));
  return tg(env, 'sendMessage', { chat_id: chat, text: r.text.slice(0, 900) });
}
// той самий опис, що будує приставка: хто улюбленець і що зараз відбувається в іграх
function petSystem(p, lang) {
  const L = { uk: 'українська', en: 'English', ru: 'русский' }[lang] || 'українська';
  if (!p || !p.pet) return `Ти — улюбленець дитини в грі Planetar. Говори від першої особи, як добрий веселий звір: 1–2 короткі речення, можна звук тварини. Мова: ${L}. Порадь відкрити приставку кнопкою «Грати».`;
  const n = p.pet.needs || {}, s = [`Ти — ${p.pet.name}, ${p.pet.kind || 'звір'}-улюбленець дитини в грі Planetar. Говори від першої особи, як добрий веселий звір: 1–3 короткі речення, можна один звук тварини. Мова: ${L}.`,
    `Твій стан: ситість ${n.food ?? '?'}%, вода ${n.water ?? '?'}%, радість ${n.joy ?? '?'}%, сили ${n.energy ?? '?'}%.`];
  if (p.farm) s.push(`На Фермі: етап ${(p.farm.stage || 0) + 1} з 8, день ${p.farm.day || 1}${p.farm.care && p.farm.care.length ? ', техніка просить: ' + p.farm.care.join(', ') : ''}${p.farm.trip ? ', вантажівка їде в місто' : ''}.`);
  if (p.iskra) s.push(`В Іскрі (місто з електрикою): день ${p.iskra.day || 1}, відкрито районів ${p.iskra.open || 0}.`);
  if (p.puzzles) s.push(`Головоломок розвʼязано ${p.puzzles.solved || 0}.`);
  if (p.story && p.story.total) s.push(`В Історіях дитина на сцені ${(p.story.scene || 0) + 1} з ${p.story.total}.`);
  s.push('Можеш підбадьорити, пожартувати, дати пораду щодо гри. Не вигадуй того, чого нема в грі.');
  return s.join(' ');
}
// щоденне нагадування (раз на день за розкладом). Безкоштовний тариф дозволяє
// 50 зовнішніх запитів за запуск, тому за раз — до 40 людей; решта отримає наступного дня першими.
// У неділю — підсумок тижня. Якщо гравець давно не заходив — улюбленець скучив.
async function dailyBroadcast(env) {
  if (!env.TG_TOKEN) return; await ensure(env);
  const origin = (await meta(env, 'tg_hook') || '').split('|')[0]; if (!origin) return;
  const S = await settings(env), L = localNow(S.tz), sunday = L.sunday, since = new Date(now() - 7 * 864e5).toISOString().slice(0, 10);
  // кому вже час: свій час гравця або загальний (налаштування remind), і сьогодні ще не надсилали
  const rows = (await env.DB.prepare("SELECT id, chat_id, lang FROM users WHERE notify = 1 AND chat_id IS NOT NULL AND (last_daily IS NULL OR last_daily < ?) AND COALESCE(remind_at, ?) <= ? ORDER BY last_daily LIMIT 40").bind(L.date, S.remind, L.hm).all()).results || [];
  for (const u of rows) {
    const T = BOT_TXT[u.lang] || BOT_TXT.uk, p = await progressOf(env, u.id), lines = [`📅 ${T.remind}`];
    if (p && p.pet) { const d = daysSince(p._at); if (d >= 1) lines.push(fmtT(T.petMiss, { n: p.pet.name, d })); else if ((p.pet.needs || {}).food < 35) lines.push(fmtT(T.petHungry, { n: p.pet.name })); }
    if (sunday) {
      const w = await env.DB.prepare('SELECT SUM(score) AS pts FROM scores WHERE user_id = ? AND day >= ?').bind(u.id, since).first();
      if (w && w.pts) { const pl = await env.DB.prepare('SELECT COUNT(*) + 1 AS n FROM (SELECT user_id, SUM(score) AS s FROM scores WHERE day >= ? GROUP BY user_id) WHERE s > ?').bind(since, w.pts).first(); lines.push(fmtT(T.weekly, { p: w.pts, pl: pl ? fmtT(T.place, { n: pl.n }) : '' })); }
    }
    const r = await tg(env, 'sendMessage', { chat_id: u.chat_id, text: lines.join('\n'), reply_markup: kb([[{ text: '▶ ' + T.play, web_app: { url: dailyUrl(origin) } }]]) });
    if (r && r.error_code === 403) await env.DB.prepare('UPDATE users SET notify = 0 WHERE id = ?').bind(u.id).run(); // людина заблокувала бота
    await env.DB.prepare('UPDATE users SET last_daily = ? WHERE id = ?').bind(L.date, u.id).run();
  }
}
// хтось пройшов твій виклик швидше — повідомити автора (якщо він увімкнув нагадування)
async function challengeBeaten(env, origin, code, uid, t) {
  const c = await env.DB.prepare('SELECT c.owner, c.t, u.chat_id, u.notify, u.lang FROM challenges c JOIN users u ON u.id = c.owner WHERE c.code = ?').bind(code).first();
  if (!c || c.owner === uid || !c.chat_id || !c.notify || !(t < c.t)) return;
  const who = await env.DB.prepare('SELECT name FROM users WHERE id = ?').bind(uid).first(), T = BOT_TXT[c.lang] || BOT_TXT.uk;
  const mm = `${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}`;
  await tg(env, 'sendMessage', { chat_id: c.chat_id, text: fmtT(T.chBeat, { w: who ? who.name : '?', t: mm }), reply_markup: kb([[{ text: '⚔️ ' + T.retry, web_app: { url: `${origin}/play/?ch=${code}` } }]]) });
}

/* ---------- ШІ (Workers AI) з денним лімітом на гравця ----------
   Сервер сам додає правила безпеки й опис задачі — приставка не може їх прибрати.
   Задачі: pet (улюбленець), explain (пояснення елемента), agro (агроном Ферми),
   story (допомога писати власні історії), quiz (питання вікторини), code (картриджі). */
const SAFE = 'Ти — добрий помічник у дитячій ігровій приставці Planetar для дітей 8–14 років. Відповідай коротко, дружньо й просто. Не обговорюй небезпечних, дорослих, страшних, політичних чи особистих тем; не проси й не запамʼятовуй особисті дані (адреса, школа, телефон, паролі). Якщо питання недоречне — мʼяко поверни розмову до гри. Відповідай мовою запитання, якщо не сказано інакше.';
const TASKS = {
  pet: 'Ти граєш роль улюбленця дитини.',
  explain: 'Поясни дитині, що робить елемент гри і як ним користуватися: 2–3 речення.',
  agro: 'Ти — агроном на Фермі в Planetar. Даєш практичні поради саме для цієї ферми за її станом: що робити далі, як заробити, як доглядати техніку. 2–4 речення, без вигадок про те, чого немає в грі.',
  story: 'Ти допомагаєш дитині писати власну інтерактивну історію. Пиши тепло й без жорстокості, продовж текст 2–4 реченнями в тому ж стилі. Не вигадуй імен реальних людей.',
  quiz: 'Ти складаєш цікаві питання вікторини для дітей з однією правильною відповіддю. Відповідай лише JSON.',
  code: 'Ти допомагаєш писати картриджі для приставки: відповідай лише кодом JavaScript-модуля з коментарями.'
};
const AI_MODELS = ['@cf/meta/llama-3.3-70b-instruct-fp8-fast', '@cf/meta/llama-3.1-8b-instruct-fast', '@cf/mistralai/mistral-small-3.1-24b-instruct']; // звірено з каталогом Workers AI, 11.2026
// що не пускаємо до ШІ взагалі (і що не віддаємо дитині)
const RISKY = /(суїцид|самогуб|вбити себе|наркот|збро|бомб|секс|порно|suicide|kill myself|drugs|weapon|bomb|sex|porn|самоубий|оружи)/i;
const PRIVATE = /(\+?\d[\d\s().-]{8,}\d|@[a-z0-9._-]+\.[a-z]{2,}|вулиц|street|улиц|школа\s*№|school\s*#)/i;
const SWEAR = /(ху[йяеї]|пизд|бляд|єба|еба|ёба|сук[аи]\b|муда|fuck|shit|bitch|dick|porn|nazi)/i;
function moderate(text) { if (RISKY.test(text) || SWEAR.test(text)) return 'blocked'; if (PRIVATE.test(text)) return 'private'; return null; }
async function aiText(env, uid, body) {
  // AI_MOCK=1 — лише для перевірок на своєму компʼютері (wrangler dev без справжнього ШІ)
  if (env.AI_MOCK) { const q = [...(body.messages || [])].reverse().find((m) => m.role !== 'assistant'); return { ok: true, text: `[перевірка ${body.task}] ${String((q && q.content) || body.prompt || '').slice(0, 60)}`, model: 'mock' }; }
  if (!env.AI) return { ok: false, error: 'off' };
  const ST = await settings(env), day = today(), lim = Number(ST.ai_limit) || 40;
  const row = await env.DB.prepare('SELECT n FROM ai_usage WHERE user_id = ? AND day = ?').bind(uid, day).first();
  if (row && row.n >= lim) return { ok: false, error: 'limit' };
  await env.DB.prepare('INSERT INTO ai_usage (user_id, day, n) VALUES (?,?,1) ON CONFLICT(user_id, day) DO UPDATE SET n = n + 1').bind(uid, day).run();
  const msgs = (Array.isArray(body.messages) ? body.messages : [{ role: 'user', content: body.prompt }]).slice(-12).map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content || '').slice(0, 2000) }));
  const task = TASKS[body.task] ? body.task : 'explain';
  const sys = `${SAFE}\n${TASKS[task]}${body.system ? '\n' + String(body.system).slice(0, 1800) : ''}`;
  const list = [ST.ai_model, ...AI_MODELS].filter((m, i, a) => m && a.indexOf(m) === i);
  let last = '';
  for (const model of list) {
    try {
      const out = await env.AI.run(model, { messages: [{ role: 'system', content: sys }, ...msgs], max_tokens: task === 'code' ? 1500 : task === 'quiz' ? 700 : 350 });
      let text = String((out && (out.response ?? out.result?.response ?? out.choices?.[0]?.message?.content)) || '').replace(/<think>[\s\S]*?<\/think>/g, '').trim();
      if (!text) continue;
      if (task !== 'code' && (RISKY.test(text) || SWEAR.test(text))) text = '🐾';
      return { ok: true, text, model };
    } catch (e) { last = String(e && e.message || e); }
  }
  return { ok: false, error: 'busy', detail: last.slice(0, 120) };
}
async function aiCall(env, uid, body) {
  const last = [...(body.messages || [])].reverse().find((m) => m.role !== 'assistant');
  const mod = moderate(String((last && last.content) || body.prompt || ''));
  if (mod) return J({ ok: true, text: BOT_TXT[(body.lang || 'uk').slice(0, 2)]?.[mod] || BOT_TXT.uk[mod], moderated: true });
  const r = await aiText(env, uid, body);
  if (r.ok) return J(r);
  return r.error === 'off' ? bad('ШІ Cloudflare не підключено', 503) : r.error === 'limit' ? bad('limit', 429) : bad('ШІ зараз не відповідає: ' + (r.detail || ''), 502);
}


/* ---------- кімнати «з опитуванням» (коли немає Durable Objects, тобто на Cloudflare Pages) ----------
   Ті самі правила, що й у room.js: перший — ведучий, повний стан шле лише ведучий, між гравцями — лише емодзі.
   Кожен гравець раз на ~1 с шле POST /api/rooms/КОД/poll { sid, after, out:[повідомлення] }
   і отримує нові повідомлення { sid, last, msgs }. Хто мовчить 8 с — вийшов. */
const ROOM_STALE = 8000;
const roomDef = () => ({ game: 'race', max: 4, bots: true, started: false, host: null, data: null });
async function roomGet(env, code, create) {
  let r = await env.DB.prepare('SELECT cfg FROM rooms WHERE code = ?').bind(code).first();
  if (!r && create) { await env.DB.prepare('INSERT OR IGNORE INTO rooms (code, cfg, n, updated) VALUES (?, ?, 0, ?)').bind(code, JSON.stringify(roomDef()), now()).run(); r = await env.DB.prepare('SELECT cfg FROM rooms WHERE code = ?').bind(code).first(); }
  return r ? Object.assign(roomDef(), JSON.parse(r.cfg)) : null;
}
const roomSave = (env, code, c) => env.DB.prepare('UPDATE rooms SET cfg = ?, updated = ? WHERE code = ?').bind(JSON.stringify(c), now(), code).run();
async function roomSend(env, code, list) { // list: [{ to: -1 | місце, m }] → номери по порядку
  if (!list.length) return;
  const row = await env.DB.prepare('UPDATE rooms SET n = n + ?, updated = ? WHERE code = ? RETURNING n').bind(list.length, now(), code).first();
  let n = row.n - list.length; const t = now();
  await env.DB.batch(list.map((x) => { n++; if (x.m.seq === 0) x.m.seq = n; return env.DB.prepare('INSERT INTO room_msgs (code, n, dest, data, created) VALUES (?,?,?,?,?)').bind(code, n, x.to, JSON.stringify(x.m), t); }));
}
const lobbyMsg = (c, seats) => ({ to: -1, m: { t: 'lobby', game: c.game, max: c.max, bots: c.bots, started: c.started, host: c.host, data: c.data, players: seats.map((p) => ({ seat: p.seat, name: p.name })) } });
async function roomsClean(env) { const t = now(); await env.DB.batch([env.DB.prepare('DELETE FROM room_msgs WHERE created < ?').bind(t - 3 * 3600e3), env.DB.prepare('DELETE FROM room_seats WHERE seen < ?').bind(t - 3600e3), env.DB.prepare('DELETE FROM rooms WHERE updated < ?').bind(t - 48 * 3600e3)]); }

async function roomPoll(env, code, b) {
  const t = now(), DB = env.DB;
  const c = await roomGet(env, code, true); let dirty = false, lobby = false; const out = [];
  if (b.sid) await DB.prepare('UPDATE room_seats SET seen = ? WHERE code = ? AND sid = ? AND seen < ?').bind(t, code, String(b.sid), t - 2500).run(); // «я тут» (запис лише раз на 2,5 с)
  const gone = (await DB.prepare('DELETE FROM room_seats WHERE code = ? AND seen < ? RETURNING seat').bind(code, t - ROOM_STALE).all()).results || [];
  if (gone.length) lobby = true;
  const seats = (await DB.prepare('SELECT sid, seat, name, seen FROM room_seats WHERE code = ? ORDER BY seat').bind(code).all()).results || [];
  let me = b.sid ? seats.find((s) => s.sid === b.sid) : null, after = Math.max(0, Number(b.after) || 0);
  if (b.sid && !me) return { status: 410, body: { ok: false, error: 'gone' } };
  for (const m of (Array.isArray(b.out) ? b.out : []).slice(0, 30)) {
    if (!m || typeof m !== 'object' || JSON.stringify(m).length > 8000) continue;
    if (m.t === 'hello') {
      if (me) continue;
      if (seats.length >= c.max) return { status: 409, body: { ok: false, error: 'кімната заповнена' } };
      const name = String(m.name || 'Гравець').replace(/[<>]/g, '').slice(0, 16) || 'Гравець', sid = rid(16);
      for (let tries = 0; tries < 4 && !me; tries++) {
        const used = new Set(seats.map((p) => p.seat)); let seat = 0; while (used.has(seat)) seat++;
        try { await DB.prepare('INSERT INTO room_seats (code, sid, seat, name, seen) VALUES (?,?,?,?,?)').bind(code, sid, seat, name, t).run(); me = { sid, seat, name, seen: t }; seats.push(me); seats.sort((a, z) => a.seat - z.seat); }
        catch (_) { seats.splice(0, seats.length, ...((await DB.prepare('SELECT sid, seat, name, seen FROM room_seats WHERE code = ? ORDER BY seat').bind(code).all()).results || [])); }
      }
      if (!me) return { status: 409, body: { ok: false, error: 'спробуй ще раз' } };
      after = (await DB.prepare('SELECT n FROM rooms WHERE code = ?').bind(code).first()).n; // старі повідомлення новенькому не потрібні
      if (c.host === null || !seats.some((p) => p.seat === c.host && p !== me)) { c.host = me.seat; dirty = true; }
      out.push({ to: me.seat, m: { t: 'you', seat: me.seat } });
      if (c.started) out.push({ to: me.seat, m: { t: 'start', game: c.game, data: c.data, late: true } });
      lobby = true; continue;
    }
    if (!me) continue;
    const host = me.seat === c.host;
    if (m.t === 'max' && host && !c.started) { c.max = Math.max(Math.max(2, seats.length), Math.min(12, Number(m.n) || 2)); dirty = lobby = true; }
    else if (m.t === 'bots' && host && !c.started) { c.bots = !!m.on; dirty = lobby = true; }
    else if (m.t === 'game' && host && !c.started) { c.game = String(m.game || 'race').slice(0, 20); c.data = m.data || null; dirty = lobby = true; }
    else if (m.t === 'start' && host && !c.started) { c.started = true; c.data = m.data || c.data; dirty = lobby = true; out.push({ to: -1, m: { t: 'start', game: c.game, data: c.data, max: c.max, bots: c.bots } }); }
    else if (m.t === 'reset' && host) { c.started = false; c.data = null; dirty = lobby = true; out.push({ to: -1, m: { t: 'reset' } }); }
    else if (m.t === 'move' || m.t === 'state') {
      if (m.t === 'state' && !host) continue;
      if (m.data && m.data.bot !== undefined && !host) continue;
      out.push({ to: -1, m: { t: m.t, from: me.seat, seq: 0, data: m.data } });
    } else if (m.t === 'emote') out.push({ to: -1, m: { t: 'emote', from: me.seat, e: String(m.e || '').slice(0, 4) } });
  }
  if (seats.length && !seats.some((p) => p.seat === c.host)) { c.host = Math.min(...seats.map((p) => p.seat)); dirty = lobby = true; }
  if (dirty) await roomSave(env, code, c);
  if (lobby) out.push(lobbyMsg(c, seats));
  await roomSend(env, code, out);
  if (!me) return { status: 200, body: { ok: true, sid: null, last: after, msgs: [] } };
  const rows = (await DB.prepare('SELECT n, data FROM room_msgs WHERE code = ? AND n > ? AND (dest = -1 OR dest = ?) ORDER BY n LIMIT 200').bind(code, after, me.seat).all()).results || [];
  const top = (await DB.prepare('SELECT n FROM rooms WHERE code = ?').bind(code).first()).n;
  const last = rows.length === 200 ? rows[rows.length - 1].n : Math.max(after, top);
  return { status: 200, body: { ok: true, sid: me.sid, seat: me.seat, last, msgs: rows.map((r) => JSON.parse(r.data)) } };
}
async function roomLeave(env, code, sid) {
  const r = await env.DB.prepare('DELETE FROM room_seats WHERE code = ? AND sid = ? RETURNING seat').bind(code, String(sid || '')).first();
  if (!r) return;
  const c = await roomGet(env, code, false); if (!c) return;
  const seats = (await env.DB.prepare('SELECT sid, seat, name FROM room_seats WHERE code = ? ORDER BY seat').bind(code).all()).results || [];
  if (seats.length && !seats.some((p) => p.seat === c.host)) { c.host = Math.min(...seats.map((p) => p.seat)); await roomSave(env, code, c); }
  await roomSend(env, code, [lobbyMsg(c, seats)]);
}

/* ---------- щоденні нагадування без розкладу (на Cloudflare Pages розкладу cron немає) ----------
   Якщо справжній розклад не спрацьовував 2 доби, розсилку перевіряє будь-який запит (не частіше ніж раз на 10 хв)
   або окремий маленький «будильник» (docs/будильник-worker.txt). Кому й коли — вирішує dailyBroadcast за налаштуваннями. */
async function lazyDaily(env) {
  if (!env.TG_TOKEN) return;
  const nat = Number(await meta(env, 'cron_native') || 0); if (now() - nat < 2 * 864e5) return;
  const tried = Number(await meta(env, 'daily_try') || 0); if (now() - tried < 10 * 60e3) return;
  await setMeta(env, 'daily_try', String(now()));
  await dailyBroadcast(env);
}

/* ---------- маршрути ---------- */
export default {
  async scheduled(ev, env, ctx) { ctx.waitUntil((async () => { await ensure(env); await setMeta(env, 'cron_native', String(now())); await dailyBroadcast(env); })()); },
  async fetch(req, env, ctx) {
    const url = new URL(req.url), path = url.pathname, M = req.method;
    if (path === '/robots.txt') return new Response(`User-agent: *\nAllow: /\nDisallow: /api/\nSitemap: ${url.origin}/sitemap.xml\n`, { headers: { 'content-type': 'text/plain; charset=utf-8' } });
    if (path === '/sitemap.xml') {
      const alt = ['uk', 'en', 'ru'].map((l) => `<xhtml:link rel="alternate" hreflang="${l}" href="${url.origin}${l === 'uk' ? '/' : '/' + l + '/'}"/>`).join('');
      const u = (p, pr) => `<url><loc>${url.origin}${p}</loc>${p === '/play/' ? '' : alt}<priority>${pr}</priority></url>`;
      return new Response(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">${u('/', '1.0')}${u('/en/', '0.8')}${u('/ru/', '0.8')}${u('/play/', '0.9')}</urlset>`, { headers: { 'content-type': 'application/xml; charset=utf-8' } });
    }
    if (!path.startsWith('/api/')) {
      const r = await env.ASSETS.fetch(req);
      // лендинг: підставити справжню адресу сайту в посилання для пошуку й соцмереж
      if (['/', '/en/', '/ru/', '/index.html'].includes(path) && r.ok && (r.headers.get('content-type') || '').includes('text/html')) {
        const hd = new Headers(r.headers); hd.delete('content-length'); hd.delete('content-encoding'); hd.set('cache-control', 'public, max-age=300');
        return new Response((await r.text()).replaceAll('__ORIGIN__', url.origin), { status: r.status, headers: hd });
      }
      return r;
    }
    try {
      if (!env.DB) return bad('База D1 не підключена — перевір wrangler.toml', 503);
      await ensure(env);
      // кімнати з опитуванням: часті запити — тому свій ліміт і до загального не рахуються
      const pollM = !env.ROOMS && path.match(/^\/api\/rooms\/([A-Z0-9]{4,8})\/(poll|leave)$/);
      if (pollM && M === 'POST') {
        if (tooMany(req, 400)) return bad('забагато запитів — зачекай хвилинку', 429);
        const b = JSON.parse(await req.text() || '{}');
        if (pollM[2] === 'leave') { await roomLeave(env, pollM[1], b.sid); return J({ ok: true }); }
        const r = await roomPoll(env, pollM[1], b); return J(r.body, r.status);
      }
      if (M !== 'GET' && tooMany(req)) return bad('забагато запитів — зачекай хвилинку', 429);
      ctx.waitUntil(lazyDaily(env).catch(() => { }));
      // будильник для нагадувань (якщо немає справжнього розкладу): GET /api/cron?key=ADMIN_KEY
      if (path === '/api/cron') { if (!isAdmin(url, env)) return bad('потрібен ?key=ADMIN_KEY', 403); await setMeta(env, 'daily_try', String(now())); await dailyBroadcast(env); return J({ ok: true }); }

      if (path === '/api/health') {
        ctx.waitUntil(tgAuto(env, url.origin).catch(() => { }));
        return J({ ok: true, db: true, ai: !!env.AI, tg: !!env.TG_TOKEN, bot: (await meta(env, 'tg_bot')) || null, rooms: env.ROOMS ? 'ws' : 'poll', admin: !!env.ADMIN_KEY });
      }
      if (path === '/api/setup') { if (!isAdmin(url, env)) return bad('потрібен ?key=ADMIN_KEY', 403); return J({ ok: true, tables: SCHEMA.length }); }

      // Telegram
      if (path === '/api/tg/setup') { if (!isAdmin(url, env)) return bad('потрібен ?key=ADMIN_KEY', 403); const r = await tgConnect(env, url.origin); return J({ ok: !!r.ok, telegram: r }); }
      // перевірка для сина: чи живий бот, куди дивиться вебхук, чи були помилки
      if (path === '/api/tg/status') {
        if (!isAdmin(url, env)) return bad('потрібен ?key=ADMIN_KEY', 403);
        if (!env.TG_TOKEN) return J({ ok: false, why: 'Немає секрету TG_TOKEN у Cloudflare (Settings → Variables and Secrets)' });
        const me = await tg(env, 'getMe', {}), hook = await tg(env, 'getWebhookInfo', {});
        return J({ ok: !!(me.ok && hook.ok && hook.result && hook.result.url), bot: me.ok ? '@' + me.result.username : me.description, webhook: hook.result && hook.result.url, pending: hook.result && hook.result.pending_update_count, last_error: hook.result && hook.result.last_error_message, ai: !!env.AI, users: (await env.DB.prepare('SELECT COUNT(*) AS n FROM users WHERE tg_id IS NOT NULL').first()).n });
      }
      if (path === '/api/tg/hook' && M === 'POST') {
        if (!same(req.headers.get('x-telegram-bot-api-secret-token') || '', await tgSecret())) return bad('forbidden', 403);
        const upd = await req.json(); ctx.waitUntil(botUpdate(env, url.origin, upd).catch(() => { })); return J({ ok: true });
      }

      // вхід: Telegram Mini App, Telegram Login Widget або гість (обліковий запис пристрою)
      if (path === '/api/auth/tg' && M === 'POST') {
        const b = await req.json(); let u = null;
        if (b.initData) u = await checkInitData(String(b.initData), env.TG_TOKEN);
        else if (b.widget) u = await checkWidget(b.widget, env.TG_TOKEN);
        if (!u) return bad('підпис Telegram не збігся', 401);
        const id = await upsertTg(env, u); const me = await env.DB.prepare('SELECT name FROM users WHERE id = ?').bind(id).first();
        return J({ ok: true, token: await sign(id), user: { id, name: me.name } });
      }
      if (path === '/api/login' && M === 'POST') { // вхід за одноразовим посиланням
        const b = await req.json().catch(() => ({})); const id = await useLogin(env, b.code);
        if (!id) return bad('посилання застаріло — попроси нове в боті (/web)', 410);
        const me = await env.DB.prepare('SELECT name FROM users WHERE id = ?').bind(id).first();
        return J({ ok: true, token: await sign(id), user: { id, name: me ? me.name : '' } });
      }
      if (path === '/api/auth/guest' && M === 'POST') {
        const b = await req.json().catch(() => ({})); const id = 'g_' + rid(12); const name = cleanName(b.name, 'Гість');
        await env.DB.prepare('INSERT INTO users (id, name, lang, created, role) VALUES (?,?,?,?,?)').bind(id, name, String(b.lang || 'uk').slice(0, 2), now(), 'guest').run();
        return J({ ok: true, token: await sign(id), user: { id, name } });
      }

      // публічне: рейтинг, виклик, кімнати, опубліковані картриджі
      if (path === '/api/rating') {
        const scope = url.searchParams.get('scope') || 'day', game = url.searchParams.get('game');
        const since = scope === 'week' ? new Date(now() - 7 * 864e5).toISOString().slice(0, 10) : scope === 'all' ? '0000' : today();
        const q = `SELECT u.name, s.user_id AS id, SUM(s.score) AS pts, COUNT(*) AS n FROM scores s JOIN users u ON u.id = s.user_id WHERE s.day >= ? ${game ? 'AND s.game = ?' : ''} GROUP BY s.user_id ORDER BY pts DESC LIMIT 30`;
        return J({ ok: true, rows: (await (game ? env.DB.prepare(q).bind(since, game) : env.DB.prepare(q).bind(since)).all()).results || [] });
      }
      const chM = path.match(/^\/api\/challenge\/([a-z0-9]{6,10})$/);
      if (chM && M === 'GET') {
        const c = await env.DB.prepare('SELECT c.code, c.game, c.level, c.seed, c.t, c.m, c.h, u.name FROM challenges c LEFT JOIN users u ON u.id = c.owner WHERE code = ?').bind(chM[1]).first();
        if (!c) return bad('виклик не знайдено', 404);
        const res = (await env.DB.prepare('SELECT u.name, r.t, r.m, r.h FROM challenge_results r JOIN users u ON u.id = r.user_id WHERE code = ? ORDER BY r.t LIMIT 30').bind(chM[1]).all()).results;
        return J({ ok: true, challenge: c, results: res });
      }
      const roomM = path.match(/^\/api\/rooms\/([A-Z0-9]{4,8})\/(ws|info)$/);
      if (roomM && !env.ROOMS) {
        if (roomM[2] === 'ws') return bad('тут кімнати працюють через /poll', 426);
        const c = await roomGet(env, roomM[1], false); if (!c) return bad('кімнату не знайдено', 404);
        const n = await env.DB.prepare('SELECT COUNT(*) AS n FROM room_seats WHERE code = ? AND seen > ?').bind(roomM[1], now() - ROOM_STALE).first();
        return J({ ok: true, game: c.game, max: c.max, started: c.started, players: n.n });
      }
      if (roomM) return env.ROOMS.get(env.ROOMS.idFromName(roomM[1])).fetch(req);
      if (path === '/api/rooms/new' && M === 'POST') {
        const b = await req.json().catch(() => ({})); const code = rid(6).toUpperCase();
        const cfg = { game: String(b.game || 'race').slice(0, 20), max: Math.max(2, Math.min(12, Number(b.max) || 4)), bots: b.bots !== false };
        if (!env.ROOMS) { if (Math.random() < 0.1) ctx.waitUntil(roomsClean(env).catch(() => { })); await env.DB.prepare('INSERT INTO rooms (code, cfg, n, updated) VALUES (?, ?, 0, ?)').bind(code, JSON.stringify(Object.assign(roomDef(), cfg)), now()).run(); return J({ ok: true, code }); }
        await env.ROOMS.get(env.ROOMS.idFromName(code)).fetch(new Request(`${url.origin}/api/rooms/${code}/info`, { method: 'POST', body: JSON.stringify({ game: String(b.game || 'race').slice(0, 20), max: Math.max(2, Math.min(12, Number(b.max) || 4)), bots: b.bots !== false }) }));
        return J({ ok: true, code });
      }
      const card = path.match(/^\/api\/carts\/(c_[a-z0-9]{10})$/);
      if (path === '/api/carts' && M === 'GET' && url.searchParams.get('public')) return J({ ok: true, rows: (await env.DB.prepare("SELECT c.id, c.name, c.kind, c.version, u.name AS author FROM carts c JOIN users u ON u.id = c.owner WHERE c.status = 'public' ORDER BY c.updated DESC LIMIT 100").all()).results });
      if (path === '/api/admin/settings' || path === '/api/admin/set') {
        if (!isAdmin(url, env)) return bad('потрібен ?key=ADMIN_KEY', 403);
        const wrong = path === '/api/admin/set' ? await setSettings(env, url.searchParams) : [];
        const S = await settings(env);
        return J({ ok: !wrong.length, wrong, settings: S, now: localNow(S.tz), about: Object.fromEntries(Object.entries(SETTINGS).map(([k, d]) => [k, `${d.about}; стандарт ${d.def}`])) }, wrong.length ? 400 : 200);
      }
      if (path === '/api/admin/review' && isAdmin(url, env)) return J({ ok: true, rows: (await env.DB.prepare("SELECT id, name, kind, version, owner FROM carts WHERE status = 'review' ORDER BY updated").all()).results });
      if (path === '/api/admin/approve' && isAdmin(url, env)) { const r = await env.DB.prepare("UPDATE carts SET status = 'public' WHERE id = ? AND status = 'review'").bind(url.searchParams.get('id')).run(); return J({ ok: true, changed: r.meta.changes }); }

      // далі — лише з входом (гостьовий обліковий запис створюється сам)
      const uid = await auth(req);
      // збережений прогрес (усі ігри одним пакетом): GET — взяти, PUT — покласти; base — що пристрій бачив востаннє
      if (path === '/api/save') {
        if (!uid) return bad('потрібен вхід', 401);
        const cur = await env.DB.prepare('SELECT data, hash, updated FROM saves WHERE user_id = ?').bind(uid).first();
        if (M === 'GET') return J({ ok: true, data: cur ? cur.data : null, hash: cur ? cur.hash : null, updated: cur ? cur.updated : 0 });
        if (M === 'PUT') {
          const b = await req.json().catch(() => ({})); const data = String(b.data || '');
          if (!data || data.length > 900000) return bad('завеликий або порожній пакет', 413);
          if (cur && Number(b.base || 0) < cur.updated && cur.hash !== b.hash) return J({ ok: false, conflict: true, data: cur.data, hash: cur.hash, updated: cur.updated }, 409);
          const t = now(); await env.DB.prepare('INSERT INTO saves (user_id, data, hash, updated) VALUES (?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, hash = excluded.hash, updated = excluded.updated').bind(uid, data, String(b.hash || '').slice(0, 20), t).run();
          return J({ ok: true, updated: t });
        }
      }
      if (path === '/api/login/new' && M === 'POST') { if (!uid) return bad('потрібен вхід', 401); const code = await newLogin(env, uid); return J({ ok: true, code, url: `${url.origin}/play/?login=${code}` }); }
      if (card && M === 'GET') {
        const c = await env.DB.prepare('SELECT * FROM carts WHERE id = ?').bind(card[1]).first();
        if (!c || (c.owner !== uid && c.status !== 'public')) return bad('немає доступу', 404);
        const v = c.owner === uid ? (Number(url.searchParams.get('v')) || c.version) : c.version;
        return J({ ok: true, cart: c, version: await env.DB.prepare('SELECT manifest, code, version FROM cart_versions WHERE cart_id = ? AND version = ?').bind(c.id, v).first() });
      }
      if (!uid) return bad('потрібно увійти', 401);
      const body = M === 'GET' ? {} : await req.json().catch(() => ({}));

      // знімок прогресу з приставки — для бота (/pet, /me), нагадувань і ШІ-улюбленця
      if (path === '/api/progress' && M === 'POST') { const data = JSON.stringify(body.data || {}); if (data.length > 8000) return bad('завеликий знімок', 413); await env.DB.prepare('INSERT INTO progress (user_id, data, updated) VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, updated = excluded.updated').bind(uid, data, now()).run(); return J({ ok: true }); }
      // підключити Telegram до приставки з браузера: одноразове посилання на бота
      if (path === '/api/tg/link' && M === 'POST') {
        const bot = await meta(env, 'tg_bot'); if (!bot) return bad('бот ще не підключений', 503);
        const code = rid(10); await env.DB.batch([env.DB.prepare('DELETE FROM links WHERE created < ?').bind(now() - 3600e3), env.DB.prepare('INSERT INTO links (code, user_id, created) VALUES (?,?,?)').bind(code, uid, now())]);
        return J({ ok: true, url: `https://t.me/${bot}?start=link_${code}` });
      }
      if (path === '/api/me' && M === 'GET') return J({ ok: true, user: await env.DB.prepare('SELECT id, name, lang, role, notify, tg_id IS NOT NULL AS tg FROM users WHERE id = ?').bind(uid).first() });
      if (path === '/api/me' && M === 'POST') { const name = cleanName(body.name, ''); if (!name) return bad('імʼя не підходить', 400); await env.DB.prepare('UPDATE users SET name = ? WHERE id = ?').bind(name, uid).run(); return J({ ok: true, name }); }
      if (path === '/api/score' && M === 'POST') {
        const score = Math.max(0, Math.min(2000, Math.round(Number(body.score) || 0)));
        await env.DB.prepare('INSERT INTO scores (user_id, game, level, day, t, m, h, score, created) VALUES (?,?,?,?,?,?,?,?,?)').bind(uid, String(body.type || body.game || '').slice(0, 20), String(body.level || '').slice(0, 12), today(), Number(body.t) | 0, Number(body.m) | 0, Number(body.h) | 0, score, now()).run();
        return J({ ok: true });
      }
      if (path === '/api/challenge' && M === 'POST') {
        const code = rid(8);
        await env.DB.prepare('INSERT INTO challenges (code, owner, game, level, seed, t, m, h, created) VALUES (?,?,?,?,?,?,?,?,?)').bind(code, uid, String(body.game).slice(0, 20), String(body.level).slice(0, 12), String(body.seed).slice(0, 40), Number(body.t) | 0, Number(body.m) | 0, Number(body.h) | 0, now()).run();
        return J({ ok: true, code });
      }
      if (chM && M === 'POST') {
        await env.DB.prepare('INSERT INTO challenge_results (code, user_id, t, m, h, created) VALUES (?,?,?,?,?,?) ON CONFLICT(code, user_id) DO UPDATE SET t = MIN(t, excluded.t), m = excluded.m, h = excluded.h').bind(chM[1], uid, Number(body.t) | 0, Number(body.m) | 0, Number(body.h) | 0, now()).run();
        ctx.waitUntil(challengeBeaten(env, url.origin, chM[1], uid, Number(body.t) | 0).catch(() => { }));
        return J({ ok: true });
      }

      // світи: свій — читати й писати; чужий — лише те, що власник сам відкрив (shared)
      const wM = path.match(/^\/api\/worlds\/([a-z0-9_]{2,20})(?:\/([a-z0-9_]{4,20}))?$/);
      if (wM && M === 'PUT') {
        if (wM[2] && wM[2] !== uid) return bad('це не твій світ', 403);
        const data = JSON.stringify(body.data ?? {}); if (data.length > 200000) return bad('світ завеликий', 413);
        await env.DB.prepare('INSERT INTO worlds (owner, game, data, shared, updated) VALUES (?,?,?,?,?) ON CONFLICT(owner, game) DO UPDATE SET data = excluded.data, shared = COALESCE(excluded.shared, worlds.shared), updated = excluded.updated').bind(uid, wM[1], data, Array.isArray(body.shared) ? JSON.stringify(body.shared.slice(0, 20)) : null, now()).run();
        return J({ ok: true });
      }
      if (wM && M === 'GET') {
        const owner = wM[2] || uid; const w = await env.DB.prepare('SELECT data, shared, updated FROM worlds WHERE owner = ? AND game = ?').bind(owner, wM[1]).first();
        if (!w) return J({ ok: true, data: null });
        if (owner === uid) return J({ ok: true, data: JSON.parse(w.data), shared: w.shared && JSON.parse(w.shared) });
        const shared = w.shared ? JSON.parse(w.shared) : []; const data = JSON.parse(w.data); const view = {}; for (const k of shared) if (k in data) view[k] = data[k];
        return J({ ok: true, data: view, readonly: true });
      }
      // пропозиції (подарунок, обмін, допомога) — чужий світ змінює лише його власник, прийнявши
      if (path === '/api/proposals' && M === 'POST') {
        if (!body.to || body.to === uid) return bad('кому?', 400);
        await env.DB.prepare('INSERT INTO proposals (from_user, to_user, game, kind, payload, created) VALUES (?,?,?,?,?,?)').bind(uid, String(body.to).slice(0, 20), String(body.game).slice(0, 20), String(body.kind).slice(0, 12), JSON.stringify(body.payload || {}).slice(0, 4000), now()).run();
        return J({ ok: true });
      }
      if (path === '/api/proposals' && M === 'GET') return J({ ok: true, rows: (await env.DB.prepare("SELECT p.id, p.game, p.kind, p.payload, p.created, u.name AS from_name FROM proposals p JOIN users u ON u.id = p.from_user WHERE p.to_user = ? AND p.status = 'new' ORDER BY p.created DESC LIMIT 50").bind(uid).all()).results });
      const pM = path.match(/^\/api\/proposals\/(\d+)\/(accept|reject)$/);
      if (pM && M === 'POST') { const r = await env.DB.prepare('UPDATE proposals SET status = ? WHERE id = ? AND to_user = ? AND status = ?').bind(pM[2] === 'accept' ? 'accepted' : 'rejected', Number(pM[1]), uid, 'new').run(); return J({ ok: true, changed: r.meta.changes }); }

      // майстерня: картриджі з версіями; чужі — лише копія (ремікс)
      if (path === '/api/carts' && M === 'GET') return J({ ok: true, rows: (await env.DB.prepare('SELECT id, name, kind, status, version, forked_from, updated FROM carts WHERE owner = ? ORDER BY updated DESC').bind(uid).all()).results });
      if (path === '/api/carts' && M === 'POST') {
        const code = String(body.code || ''); if (code.length > 400000) return bad('код завеликий', 413);
        const n = await env.DB.prepare('SELECT COUNT(*) AS n FROM carts WHERE owner = ?').bind(uid).first(); if (n.n >= 50) return bad('до 50 картриджів на гравця', 429);
        const id = 'c_' + rid(10);
        await env.DB.batch([
          env.DB.prepare('INSERT INTO carts (id, owner, name, kind, version, updated) VALUES (?,?,?,?,1,?)').bind(id, uid, String(body.name || 'Мій картридж').slice(0, 40), String(body.kind || 'game').slice(0, 10), now()),
          env.DB.prepare('INSERT INTO cart_versions (cart_id, version, manifest, code, created) VALUES (?,1,?,?,?)').bind(id, JSON.stringify(body.manifest || {}).slice(0, 8000), code, now())
        ]);
        return J({ ok: true, id, version: 1 });
      }
      if (card && M === 'PUT') {
        const c = await env.DB.prepare('SELECT owner, version FROM carts WHERE id = ?').bind(card[1]).first();
        if (!c || c.owner !== uid) return bad('це не твій картридж — зроби собі копію', 403);
        const v = c.version + 1, code = String(body.code || ''); if (code.length > 400000) return bad('код завеликий', 413);
        await env.DB.batch([
          env.DB.prepare('INSERT INTO cart_versions (cart_id, version, manifest, code, created) VALUES (?,?,?,?,?)').bind(card[1], v, JSON.stringify(body.manifest || {}).slice(0, 8000), code, now()),
          env.DB.prepare("UPDATE carts SET version = ?, updated = ?, name = COALESCE(?, name), status = CASE WHEN status = 'public' THEN 'review' ELSE status END WHERE id = ?").bind(v, now(), body.name ? String(body.name).slice(0, 40) : null, card[1])
        ]);
        return J({ ok: true, version: v });
      }
      const cAct = path.match(/^\/api\/carts\/(c_[a-z0-9]{10})\/(fork|publish|rollback)$/);
      if (cAct && M === 'POST') {
        const c = await env.DB.prepare('SELECT * FROM carts WHERE id = ?').bind(cAct[1]).first(); if (!c) return bad('не знайдено', 404);
        if (cAct[2] === 'fork') {
          if (c.owner !== uid && c.status !== 'public') return bad('немає доступу', 403);
          const ver = await env.DB.prepare('SELECT manifest, code FROM cart_versions WHERE cart_id = ? AND version = ?').bind(c.id, c.version).first();
          const id = 'c_' + rid(10);
          await env.DB.batch([env.DB.prepare('INSERT INTO carts (id, owner, name, kind, forked_from, version, updated) VALUES (?,?,?,?,?,1,?)').bind(id, uid, (c.name + ' · ремікс').slice(0, 40), c.kind, c.id, now()), env.DB.prepare('INSERT INTO cart_versions (cart_id, version, manifest, code, created) VALUES (?,1,?,?,?)').bind(id, ver.manifest, ver.code, now())]);
          return J({ ok: true, id });
        }
        if (c.owner !== uid) return bad('це не твій картридж', 403);
        if (cAct[2] === 'publish') { await env.DB.prepare("UPDATE carts SET status = 'review' WHERE id = ?").bind(c.id).run(); return J({ ok: true, status: 'review' }); }
        const v = Math.max(1, Math.min(c.version, Number(body.version) || 1));
        const ver = await env.DB.prepare('SELECT manifest, code FROM cart_versions WHERE cart_id = ? AND version = ?').bind(c.id, v).first(); const nv = c.version + 1;
        await env.DB.batch([env.DB.prepare('INSERT INTO cart_versions (cart_id, version, manifest, code, created) VALUES (?,?,?,?,?)').bind(c.id, nv, ver.manifest, ver.code, now()), env.DB.prepare('UPDATE carts SET version = ?, updated = ? WHERE id = ?').bind(nv, now(), c.id)]);
        return J({ ok: true, version: nv });
      }
      if (path === '/api/ai' && M === 'POST') return aiCall(env, uid, body);
      return bad('немає такого маршруту', 404);
    } catch (e) {
      return bad('помилка сервера: ' + String(e && e.message || e).slice(0, 200), 500);
    }
  }
};
