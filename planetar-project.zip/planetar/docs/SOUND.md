# Звук у Pristavka

Усе синтезується в браузері (`console/js/sound.js`) — без файлів, тому працює офлайн.

## Правила міксу
1. Важливе звучить у смузі **300 Гц – 5 кГц**. Динамік телефона нижче ~250 Гц майже не грає.
2. Жодних голих «пищалок»: у звуку є атака (клац, шурхіт), тіло й хвіст; мелодійне — «молоточком» (маримба).
3. Групи гучності: `ui` (кнопки, тихо), `fx` (дії у світі), `amb` (фон, найтихіше), `voice` (тварини).
4. Вимикач діє миттєво (`window.__planetarMute` + `soundSync()`), у фоновій вкладці звук на паузі.
5. Звук із місця у світі: `spatial(W)` — панорама за екраном, гучність за відстанню.

## Як користуватися в грі
```js
import { sfx as SFX, soundScope, spatial } from '../sound.js';
const SND = soundScope(), sp3 = spatial(W, 18);
SFX('clunk', sp3(position));                 // разовий звук із місця
const eng = SND.loop('engine', { size: 'tractor' }); eng.set({ rpm: 0.6, load: 0.8, vol: 1, pan: 0 });
SND.amb.set('birds', 0.8); SND.amb.tick(dt);  // фон: birds, crickets, wind, rain, city, room, pad, water
// у destroy(): SND.stop();
```
Список звуків — `LIB` у `sound.js` (інтерфейс, метал, рідини, ферма, електрика, лікарня, Біт, тварини).
Новий звук: додай у `LIB`, перевір `tools/tests/sound_check.py` (пік < −1 dBFS, смуга, частка басу < 35%, різкість < 30%).
