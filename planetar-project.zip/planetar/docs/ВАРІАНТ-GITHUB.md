# Варіант із GitHub — з планшета або з компʼютера

Є два способи викласти Pristavka. Код однаковий, різниця — як файли потрапляють у Cloudflare.

| | Без GitHub (zip → Cloudflare Pages) | **З GitHub** (→ Cloudflare Workers) |
|---|---|---|
| Як оновити сайт | `planetar-site.zip` → Cloudflare → Create deployment | `planetar-project.zip` → GitHub → Cloudflare збирає й викладає сам |
| Кімнати з друзями | працюють, хід доходить за ~1 с | миттєві |
| Нагадування | після першого візиту або «будильник» | точно вчасно, саме |
| Історія змін | старі zip у «Файлах» + Rollback у Cloudflare | кожна зміна в GitHub + Rollback |
| Claude Code (якщо є в плані) | — | може сам змінювати файли в GitHub |
| Складність | найпростіше | ще один акаунт (GitHub), один раз налаштувати |

**Порада:** якщо хочеш миттєві кімнати й точні нагадування — GitHub. Якщо треба запуститися найшвидше — без GitHub (`docs/ІНСТРУКЦІЯ.md`).
Перейти пізніше можна без втрат: база `planetar-db` та сама (крок 6).

Секрети, бот і ШІ — однакові для обох способів: `docs/ІНСТРУКЦІЯ.md`, частини 3.2, 4 і 6. Налаштування — `docs/НАЛАШТУВАННЯ.md`.

---

## З планшета (iPad, Safari + «Файли») — ~30 хв
Хитрість: у GitHub лежить **один архів** `planetar-project.zip` (а не сотні файлів у папках, які з iPad завантажувати незручно).
Cloudflare сам розпаковує його під час кожного збирання.

### 1. Підготувати 3 файли
Розпакуй `planetar-project.zip` у «Файлах» (торкнутися архіву). З папки `planetar` візьми два файли: **`wrangler.toml`** і **`prepare.mjs`**.
Третій — сам **`planetar-project.zip`** (не розпакований). Поклади всі три в одну папку, наприклад `Pristavka/github`.

### 2. Репозиторій
1. github.com → **Sign up** (акаунт — татові) → **+** → **New repository**.
2. Назва `planetar`, **Private** → **Create repository**.
3. **uploading an existing file** (або **Add file → Upload files**) → **choose your files** → «Файли» → `Pristavka/github` →
   **Вибрати** → познач усі три файли → **Відкрити**.
4. Внизу **Commit changes**. У репозиторії мають бути рівно ці 3 файли.

### 3. Cloudflare
1. dash.cloudflare.com → **Workers & Pages** → **Create application** → **Import a repository** → **Connect GitHub**
   (дозволь доступ **лише** до `planetar`) → обери `planetar` → **Deploy** (налаштування не міняй).
2. Зачекай 2–4 хв. Адреса — `https://planetar.ІМʼЯ.workers.dev`. Перевір `/api/health`: має бути `"db":true` і `"rooms":"ws"`.
3. Далі — секрети `ADMIN_KEY`, `TG_TOKEN`, бот і ШІ, як у `docs/ІНСТРУКЦІЯ.md` (частини 3.2 і 4). Тут: Workers → `planetar` →
   **Settings** → **Variables and Secrets**. Звʼязки (база, ШІ) вже є — їх додавати не треба. Перевикладати після секретів не треба.

### 4. Як оновлювати з iPad
1. Новий `planetar-project.zip` від свого Claude (`docs/ЯК-ПРАЦЮВАТИ-З-CLAUDE.md`).
2. GitHub → репозиторій → **Add file → Upload files** → обери новий `planetar-project.zip` (з тією самою назвою) → **Commit changes**.
3. Cloudflare сам перебере й викладе за 2–4 хв (видно в Workers → `planetar` → **Deployments**). Зламалось — там **Rollback**.

---

## З компʼютера — ~20 хв
Так само, як із планшета (3 файли — найпростіше), **або** всі файли проєкту як є — тоді в GitHub видно кожну зміну рядок за рядком,
і з проєктом може працювати Claude Code.
1. Розпакуй `planetar-project.zip` → папка `planetar`.
2. Новий репозиторій `planetar` (Private) → **uploading an existing file** → **перетягни вміст папки `planetar`** у вікно
   (папки зберігаються; за раз — до 100 файлів, тож спершу `console/models`, потім решту; після кожного — **Commit changes**).
   Або програма GitHub Desktop: **Add local repository** → папка `planetar` → **Publish repository**.
3. Cloudflare — як у кроці 3 вище.
4. Оновлення: міняєш файли в GitHub (олівцем, GitHub Desktop або через Claude Code) → Cloudflare викладає сам.

---

## 5. Якщо щось не так
| Що бачиш | Що зробити |
|---|---|
| Збирання впало: «немає ні planetar-project.zip, ні файлів проєкту» | У репозиторії бракує архіву. Завантаж `planetar-project.zip`. |
| Збирання впало через `database_id` / базу | Cloudflare → **D1** → **Create** `planetar-db` (якщо ще немає) → скопіюй **ID** → у GitHub відкрий `wrangler.toml` → олівець → під `database_name = "planetar-db"` допиши `database_id = "ID"` → **Commit**. |
| `"rooms":"poll"` замість `"ws"` | Це сайт без GitHub (Pages). Відкрий адресу `…workers.dev`, а не `…pages.dev`. |
| Зламалось після зміни | Cloudflare → Deployments → **Rollback**, або GitHub → **Commits** → **Revert**. |

## 6. Перейти з «без GitHub» на GitHub, не загубивши гравців
1. Cloudflare → **D1** → `planetar-db` → скопіюй **Database ID**.
2. У `wrangler.toml` (у GitHub, олівцем) під `database_name = "planetar-db"` допиши `database_id = "СКОПІЙОВАНИЙ-ID"` → **Commit**.
   Тепер новий сайт бачить тих самих гравців, рейтинг і прогрес.
3. Секрети `ADMIN_KEY` і `TG_TOKEN` додай і в новий проєкт. Відкрий новий сайт (`/play/`) — бот сам переключиться на нову адресу
   (напевно: `/api/tg/setup?key=…`). Старий проєкт Pages можна видалити.
