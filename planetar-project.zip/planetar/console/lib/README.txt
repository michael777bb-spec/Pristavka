three.js (r187) у цій папці ОБРОБЛЕНИЙ, не оригінальний. Не підміняй його «чистим» файлом з GitHub/CDN!

Чому: у чистій збірці є `static { }` у класах (Vector2, Vector3, Matrix4…). Це синтаксис 2022 року —
iPhone з iOS < 16.4 (напр. iPhone SE 1 покоління), старі iPad і Android-браузери < Chrome 94 не можуть
навіть розібрати файл, і приставка лишається білим екраном (без жодного повідомлення).

Що зроблено (esbuild, один раз; Node.js потрібен лише для цього):
  npx esbuild three.core.js   --target=es2019 --format=esm --minify-whitespace --minify-syntax --legal-comments=inline --outfile=lib/three.core.js
  npx esbuild three.module.js --target=es2019 --format=esm --minify-whitespace --minify-syntax --legal-comments=inline --outfile=lib/three.module.js
(Заодно файли стали втричі менші: 2,1 МБ → 1,0 МБ — швидше стартує на слабких телефонах.)
Імена класів і функцій не змінюються (без --minify-identifiers).

Імпорти «three» у js/ і в lib/addons/ — ВІДНОСНІ (../lib/three.module.js), а не через importmap:
importmap не працює на iOS < 16.4 і Chrome < 89.

Оновлюєш three.js? Візьми нові three.core.js / three.module.js, прожени ті самі команди,
заміни імпорти `from 'three'` у lib/addons/** на `from '../../three.module.js'`. Збирання (build.mjs)
само зупиниться й скаже, якщо `static { }` або «голий» імпорт лишились.
