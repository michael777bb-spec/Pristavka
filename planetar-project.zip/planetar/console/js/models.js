// Завантаження 3D-моделей приставки.
// Моделі лежать як JS-модулі (GLB у base64), бо так їх віддає хостинг.
// Усі моделі — CC0 (Quaternius, Kenney), див. models/NOTICE.txt.
import * as THREE from '../lib/three.module.js';
import { GLTFLoader } from '../lib/addons/loaders/GLTFLoader.js';
import { clone as skClone } from '../lib/addons/utils/SkeletonUtils.js';

const loader = new GLTFLoader();
const cache = {};

export function urlOf(name) { return name.includes('/') ? name : `models/${name}.glb.js`; }

export function gltf(name) {
  const url = urlOf(name);
  if (!cache[url]) {
    cache[url] = (async () => {
      const b64 = (await import(new URL('../' + url, import.meta.url).href)).default;
      const bin = atob(b64);
      const u8 = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      return loader.parseAsync(u8.buffer, '');
    })();
    cache[url].catch(() => { delete cache[url]; });
  }
  return cache[url];
}

export function parse(buf) { return loader.parseAsync(buf, ''); }

// Копія моделі (зі скелетом), нормалізована до потрібної висоти, стоїть на y=0
export async function inst(name, height = 1, o = {}) {
  const g = await gltf(name);
  const obj = skClone(g.scene);
  prep(obj, o);
  const root = new THREE.Group();
  root.add(obj);
  fit(obj, height, o.by);
  root.userData.clips = g.animations || [];
  return root;
}

export function prep(obj, o = {}) {
  obj.traverse((m) => {
    if (m.isMesh) {
      m.castShadow = o.shadow !== false;
      m.receiveShadow = !!o.receive;
      if (o.tint || o.emissive) {
        m.material = m.material.clone();
        if (o.tint && m.material.map) {
          // перефарбувати текстуру: зберегти малюнок (смуги, очі), змінити колір
          const tint = new THREE.Color(o.tint);
          m.material.onBeforeCompile = (sh) => {
            sh.uniforms.uTint = { value: tint };
            sh.fragmentShader = 'uniform vec3 uTint;\n' + sh.fragmentShader.replace('#include <map_fragment>', `#ifdef USE_MAP
              vec4 sdc = texture2D( map, vMapUv );
              float l = dot( sdc.rgb, vec3( 0.2126, 0.7152, 0.0722 ) );
              sdc.rgb = clamp( uTint * pow( l / 0.22, 0.85 ), 0.0, 1.6 );
              diffuseColor *= sdc;
            #endif`);
          };
          m.material.customProgramCacheKey = () => 'tint' + tint.getHexString();
        } else if (o.tint) m.material.color.multiply(new THREE.Color(o.tint));
        if (o.emissive) { m.material.emissive = new THREE.Color(o.emissive); m.material.emissiveIntensity = o.ei || 1; }
      }
      if (m.material && m.material.map) m.material.map.anisotropy = 8;
    }
  });
}

export function fit(obj, height, by = 'y') {
  obj.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(obj);
  const size = box.getSize(new THREE.Vector3());
  const ref = by === 'max' ? Math.max(size.x, size.y, size.z) : by === 'xz' ? Math.max(size.x, size.z) : size.y;
  const k = height / (ref || 1);
  obj.scale.multiplyScalar(k);
  obj.updateMatrixWorld(true);
  const b2 = new THREE.Box3().setFromObject(obj);
  const c = b2.getCenter(new THREE.Vector3());
  obj.position.x -= c.x; obj.position.z -= c.z; obj.position.y -= b2.min.y;
  return b2.getSize(new THREE.Vector3());
}

const short = (n) => n.split('|').pop();
// Знайти анімацію за списком шаблонів (перший збіг виграє)
export function clip(clips, ...res) {
  for (const re of res) {
    const c = clips.find((cl) => re.test(short(cl.name)));
    if (c) return c;
  }
  return null;
}

// Простий аніматор: плавні переходи між кліпами
export function animator(root, clips) {
  const mixer = new THREE.AnimationMixer(root);
  let cur = null;
  const acts = new Map();
  const get = (c) => { if (!acts.has(c)) acts.set(c, mixer.clipAction(c)); return acts.get(c); };
  return {
    mixer,
    play(c, { once = false, fade = 0.25, speed = 1, then } = {}) {
      if (!c) return;
      const a = get(c);
      a.timeScale = speed;
      if (cur === a && !once) return;
      a.reset();
      a.setLoop(once ? THREE.LoopOnce : THREE.LoopRepeat, Infinity);
      a.clampWhenFinished = once;
      a.fadeIn(fade).play();
      if (cur && cur !== a) cur.fadeOut(fade);
      cur = a;
      if (once && then) {
        const f = (e) => { if (e.action === a) { mixer.removeEventListener('finished', f); then(); } };
        mixer.addEventListener('finished', f);
      }
    },
    speed(s) { if (cur) cur.timeScale = s; },
    update(dt) { mixer.update(dt); }
  };
}
