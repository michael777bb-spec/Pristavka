// Зв'язок приставки із сервером Cloudflare (/api).
// Якщо сервера немає (наприклад, локальний перегляд) — усе тихо працює на пристрої.
const LS = 'planetar:';
const get = (k, d) => { try { const v = localStorage.getItem(LS + k); return v === null ? d : JSON.parse(v); } catch (_) { return d; } };
const set = (k, v) => { try { localStorage.setItem(LS + k, JSON.stringify(v)); } catch (_) { } };

export const net = {
  online: false, user: null, token: get('token', null),
  async init(lang) {
    try {
      const r = await fetch('/api/health', { cache: 'no-store' });
      if (!r.ok) return false; const j = await r.json(); this.online = !!j.ok; this.caps = j;
    } catch (_) { this.online = false; return false; }
    // одноразове посилання з бота або з налаштувань (?login=…): цей пристрій входить у той самий обліковий запис
    const q = new URLSearchParams(location.search), login = q.get('login');
    // код лишається в адресі: Telegram відкриває посилання у своєму браузері, а «Відкрити в Safari» бере саме поточну адресу
    if (login && get('loginUsed') !== login) {
      const j = await this.post('/api/login', { code: login }, true);
      if (j.ok) { this.token = j.token; set('token', j.token); set('loginUsed', login); this.loggedIn = true; } else this.loginErr = j.error || 'login';
    }
    // усередині Telegram — вхід без пароля через підпис Telegram
    const tg = window.Telegram && window.Telegram.WebApp;
    if (!this.token && tg && tg.initData) { const j = await this.post('/api/auth/tg', { initData: tg.initData }, true); if (j.ok) { this.token = j.token; set('token', j.token); } try { tg.ready(); tg.expand(); } catch (_) { } }
    if (!this.token) { const j = await this.post('/api/auth/guest', { name: get('name', 'Гість'), lang }, true); if (j.ok) { this.token = j.token; set('token', j.token); } }
    let me = await this.getj('/api/me'); if (me.ok) this.user = me.user;
    // у Telegram завжди той обліковий запис, що й у бота (раніше міг лишитися гостьовий)
    if (tg && tg.initData && (!me.ok || !me.user || !me.user.tg)) {
      const j = await this.post('/api/auth/tg', { initData: tg.initData }, true);
      if (j.ok) { this.token = j.token; set('token', j.token); me = await this.getj('/api/me'); if (me.ok) this.user = me.user; }
    }
    return this.online;
  },
  hdr() { return this.token ? { authorization: 'Bearer ' + this.token } : {}; },
  async post(path, body, noAuth) { if (!this.online) return { ok: false, offline: true }; try { const r = await fetch(path, { method: 'POST', headers: { 'content-type': 'application/json', ...(noAuth ? {} : this.hdr()) }, body: JSON.stringify(body || {}) }); return await r.json(); } catch (e) { return { ok: false, error: String(e) }; } },
  async put(path, body) { if (!this.online) return { ok: false, offline: true }; try { const r = await fetch(path, { method: 'PUT', headers: { 'content-type': 'application/json', ...this.hdr() }, body: JSON.stringify(body || {}) }); return await r.json(); } catch (e) { return { ok: false, error: String(e) }; } },
  async getj(path) { if (!this.online) return { ok: false, offline: true }; try { const r = await fetch(path, { headers: this.hdr() }); return await r.json(); } catch (e) { return { ok: false, error: String(e) }; } },
  score(r) { return this.post('/api/score', r); },
  rating(scope = 'day', game) { return this.getj(`/api/rating?scope=${scope}${game ? '&game=' + game : ''}`); },
  challenge(game, level, seed, t, m, h) { return this.post('/api/challenge', { game, level, seed, t, m, h }); },
  challengeGet(code) { return this.getj(`/api/challenge/${code}`); },
  challengeDone(code, r) { return this.post(`/api/challenge/${code}`, r); },
  setName(name) { return this.post('/api/me', { name }); },
  ai(o) { return this.post('/api/ai', { system: o.system, messages: o.messages || [{ role: 'user', content: o.prompt || '' }], task: o.task, lang: document.documentElement.lang }); },
  progress(data) { return this.post('/api/progress', { data }); },
  saveWorld(game, data, shared) { return this.put(`/api/worlds/${game}`, { data, shared }); },
  loadWorld(game, owner) { return this.getj(`/api/worlds/${game}${owner ? '/' + owner : ''}`); },
  carts: {
    mine: () => net.getj('/api/carts'),
    public: () => net.getj('/api/carts?public=1'),
    get: (id, v) => net.getj(`/api/carts/${id}${v ? '?v=' + v : ''}`),
    create: (c) => net.post('/api/carts', c),
    update: (id, c) => net.put(`/api/carts/${id}`, c),
    fork: (id) => net.post(`/api/carts/${id}/fork`),
    publish: (id) => net.post(`/api/carts/${id}/publish`),
    rollback: (id, version) => net.post(`/api/carts/${id}/rollback`, { version })
  },
  // кімнати: лобі, кількість гравців, старт, ходи
  async newRoom(game, max, bots) { return this.post('/api/rooms/new', { game, max, bots }); },
  joinRoom(code, name, on) {
    if (!this.online) return null;
    if (!this.caps || this.caps.rooms !== 'ws') return this.pollRoom(code, name, on);
    const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/api/rooms/${code}/ws`);
    ws.onopen = () => ws.send(JSON.stringify({ t: 'hello', name }));
    ws.onmessage = (e) => { try { on(JSON.parse(e.data)); } catch (_) { } };
    let opened = false; ws.addEventListener('open', () => { opened = true; });
    ws.onclose = () => on({ t: 'closed', early: !opened });
    return { send: (m) => { try { ws.send(JSON.stringify(m)); } catch (_) { } }, close: () => ws.close() };
  },
  // кімнати без WebSocket (сайт на Cloudflare Pages): раз на секунду питаємо сервер, ходи шлемо одразу
  pollRoom(code, name, on) {
    let sid = null, after = 0, out = [{ t: 'hello', name }], alive = true, busy = false, timer = 0, fails = 0, opened = false;
    const url = (p) => `/api/rooms/${code}/${p}`;
    const stop = (early) => { if (!alive) return; alive = false; clearTimeout(timer); on({ t: 'closed', early }); };
    const tick = async () => {
      if (!alive || busy) return; busy = true; clearTimeout(timer);
      const batch = out; out = [];
      try {
        const r = await fetch(url('poll'), { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ sid, after, out: batch }) });
        if (r.status === 409 || r.status === 410 || r.status === 404) { busy = false; return stop(!opened); }
        const j = await r.json(); if (!r.ok || !j.ok) throw new Error(j.error || r.status);
        fails = 0; opened = true; sid = j.sid; after = j.last;
        for (const m of j.msgs) { if (!alive) break; on(m); }
      } catch (_) {
        out = batch.concat(out);
        if (++fails >= 8) { busy = false; return stop(!opened); }
      }
      busy = false;
      if (alive) timer = setTimeout(tick, out.length ? 60 : document.hidden ? 3000 : fails ? 2000 : 1000);
    };
    tick();
    return {
      send: (m) => { if (!alive) return; out.push(m); if (!busy) { clearTimeout(timer); timer = setTimeout(tick, 60); } },
      close: () => {
        if (!alive) return; alive = false; clearTimeout(timer);
        if (sid) { const body = JSON.stringify({ sid }); if (!(navigator.sendBeacon && navigator.sendBeacon(url('leave'), body))) fetch(url('leave'), { method: 'POST', body, keepalive: true }).catch(() => { }); }
      }
    };
  }
};
