// Голоси тварин і звуки догляду — синтез із формантами (без файлів, працює офлайн).
// Кожен звук має «тіло» (основний тон через фільтри голосних) і подих (шум),
// тому нявкання звучить як «мі-яу», а не як писк.
import { audioCtx, noiseBuf, bus, setVoiceHook } from './sound.js';

const muted = () => !!window.__planetarMute;
function out() { return bus('voice'); } // через спільний мікс: вимикач і компресор діють і на голоси
// голосна → форманти (F1, F2, F3)
const VOW = { i: [300, 2300, 3000], e: [500, 1900, 2600], a: [800, 1250, 2600], o: [500, 900, 2400], u: [350, 750, 2300], m: [280, 1100, 2200] };
// voice(): основний тон f0[] по часу, голосні vow[] по часу, гучність env[]
function voice({ dur, f0, vow, env = [[0, 0], [0.08, 1], [0.75, 0.8], [1, 0]], type = 'sawtooth', vib = 0, vibF = 6, breath = 0.12, gain = 0.32, delay = 0, rough = 0 }) {
  const a = audioCtx(), t0 = a.currentTime + 0.01 + delay, o = a.createOscillator(); o.type = type;
  f0.forEach(([k, f], i) => i ? o.frequency.exponentialRampToValueAtTime(f, t0 + k * dur) : o.frequency.setValueAtTime(f, t0));
  if (vib) { const l = a.createOscillator(), lg = a.createGain(); l.frequency.value = vibF; lg.gain.value = vib; l.connect(lg); lg.connect(o.frequency); l.start(t0); l.stop(t0 + dur + 0.05); }
  const src = a.createGain(); o.connect(src);
  if (rough) { const n = a.createBufferSource(); n.buffer = noiseBuf(); const ng = a.createGain(); ng.gain.value = rough; n.connect(ng); ng.connect(src); n.start(t0); n.stop(t0 + dur + 0.05); }
  const sum = a.createGain();
  [0, 1, 2].forEach((fi) => {
    const f = a.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = fi ? 9 : 5;
    vow.forEach(([k, v], i) => { const hz = VOW[v][fi]; i ? f.frequency.linearRampToValueAtTime(hz, t0 + k * dur) : f.frequency.setValueAtTime(hz, t0); });
    const fg = a.createGain(); fg.gain.value = [1, 0.55, 0.22][fi]; src.connect(f); f.connect(fg); fg.connect(sum);
  });
  if (breath) { const n = a.createBufferSource(); n.buffer = noiseBuf(); const nf = a.createBiquadFilter(); nf.type = 'highpass'; nf.frequency.value = 1800; const ng = a.createGain(); ng.gain.value = breath; n.connect(nf); nf.connect(ng); ng.connect(sum); n.start(t0); n.stop(t0 + dur + 0.05); }
  const g = a.createGain(); g.gain.setValueAtTime(0.0001, t0);
  env.forEach(([k, v]) => g.gain.linearRampToValueAtTime(Math.max(0.0001, v * gain), t0 + k * dur));
  sum.connect(g); g.connect(out()); o.start(t0); o.stop(t0 + dur + 0.05);
}
function burst({ dur, freq, q = 1, type = 'bandpass', gain = 0.3, delay = 0, f1 }) {
  const a = audioCtx(), t0 = a.currentTime + 0.01 + delay, n = a.createBufferSource(); n.buffer = noiseBuf();
  const f = a.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(freq, t0); if (f1) f.frequency.exponentialRampToValueAtTime(f1, t0 + dur); f.Q.value = q;
  const g = a.createGain(); g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(gain, t0 + Math.min(0.012, dur / 4)); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  n.connect(f); f.connect(g); g.connect(out()); n.start(t0, Math.random()); n.stop(t0 + dur + 0.02);
}
function thump(f0, f1, dur, gain = 0.4, delay = 0) { const a = audioCtx(), t0 = a.currentTime + 0.01 + delay, o = a.createOscillator(), g = a.createGain(); o.frequency.setValueAtTime(f0, t0); o.frequency.exponentialRampToValueAtTime(f1, t0 + dur); g.gain.setValueAtTime(gain, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur); o.connect(g); g.connect(out()); o.start(t0); o.stop(t0 + dur + 0.02); }
const R = (a, b) => a + Math.random() * (b - a);

// pitch: 1 — звичайний, >1 — менша тварина (мопс, кошеня), <1 — більша
export const VOICES = {
  meow(p = 1) { const b = R(0.95, 1.08) * p; voice({ dur: R(0.55, 0.75), f0: [[0, 480 * b], [0.35, 760 * b], [1, 420 * b]], vow: [[0, 'i'], [0.4, 'a'], [1, 'u']], vib: 12, breath: 0.08, gain: 0.3 }); },
  mew(p = 1) { voice({ dur: 0.28, f0: [[0, 700 * p], [1, 900 * p]], vow: [[0, 'i'], [1, 'e']], gain: 0.22 }); },
  purr() { // мурчання: низький шум, що пульсує ~25 разів на секунду, у два подихи
    const a = audioCtx(), t0 = a.currentTime + 0.01, dur = 2.2, n = a.createBufferSource(); n.buffer = noiseBuf(); n.loop = true;
    const f = a.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 320;
    const am = a.createGain(); am.gain.value = 0; const lfo = a.createOscillator(); lfo.type = 'square'; lfo.frequency.value = 26; const lg = a.createGain(); lg.gain.value = 0.5; lfo.connect(lg); lg.connect(am.gain);
    const g = a.createGain(); g.gain.setValueAtTime(0.0001, t0); [[0.15, 0.5], [0.95, 0.3], [1.15, 0.55], [2.0, 0.3], [2.2, 0.0001]].forEach(([k, v]) => g.gain.linearRampToValueAtTime(v, t0 + k));
    n.connect(f); f.connect(am); am.connect(g); g.connect(out()); n.start(t0); lfo.start(t0); n.stop(t0 + dur); lfo.stop(t0 + dur);
  },
  bark(p = 1) { const b = R(0.9, 1.1) * p; voice({ dur: 0.16, f0: [[0, 330 * b], [0.3, 420 * b], [1, 210 * b]], vow: [[0, 'a'], [1, 'o']], rough: 0.25, breath: 0.25, gain: 0.42, env: [[0, 0], [0.06, 1], [0.5, 0.7], [1, 0]] }); burst({ dur: 0.08, freq: 1400, q: 0.8, gain: 0.12 }); },
  bark2(p = 1) { VOICES.bark(p); setTimeout(() => VOICES.bark(p * 1.04), 190); },
  yip(p = 1) { voice({ dur: 0.18, f0: [[0, 900 * p], [0.4, 1250 * p], [1, 700 * p]], vow: [[0, 'e'], [1, 'a']], breath: 0.15, gain: 0.3 }); },
  howl(p = 1) { voice({ dur: 1.6, f0: [[0, 330 * p], [0.3, 560 * p], [0.8, 520 * p], [1, 380 * p]], vow: [[0, 'u'], [0.4, 'o'], [1, 'u']], vib: 9, vibF: 5, breath: 0.06, gain: 0.3, type: 'triangle', env: [[0, 0], [0.2, 0.8], [0.8, 1], [1, 0]] }); },
  whine(p = 1) { voice({ dur: 0.5, f0: [[0, 900 * p], [1, 1100 * p]], vow: [[0, 'i'], [1, 'i']], type: 'triangle', vib: 30, vibF: 9, gain: 0.18 }); },
  pant() { for (let i = 0; i < 4; i++) burst({ dur: 0.12, freq: 1800, q: 0.7, gain: 0.08, delay: i * 0.2 }); },
  ribbit(p = 1) { [0, 0.16].forEach((d, i) => { for (let k = 0; k < 5; k++) voice({ dur: 0.03, f0: [[0, (i ? 380 : 300) * p], [1, (i ? 320 : 260) * p]], vow: [[0, 'o'], [1, 'u']], gain: 0.35, delay: d + k * 0.022, breath: 0 }); }); },
  bleat(p = 1) { voice({ dur: 0.6, f0: [[0, 520 * p], [0.3, 600 * p], [1, 480 * p]], vow: [[0, 'e'], [1, 'e']], vib: 45, vibF: 8, gain: 0.26 }); },
  growl(p = 1) { voice({ dur: 0.9, f0: [[0, 95 * p], [0.5, 120 * p], [1, 80 * p]], vow: [[0, 'o'], [1, 'u']], rough: 0.6, breath: 0.2, gain: 0.45, type: 'sawtooth', vib: 8, vibF: 18 }); },
  roar(p = 1) { voice({ dur: 1.1, f0: [[0, 120 * p], [0.3, 180 * p], [1, 90 * p]], vow: [[0, 'a'], [0.5, 'o'], [1, 'u']], rough: 0.8, breath: 0.35, gain: 0.5, vib: 10, vibF: 22 }); },
  chirp(p = 1) { voice({ dur: 0.14, f0: [[0, 1400 * p], [1, 2000 * p]], vow: [[0, 'i'], [1, 'i']], type: 'triangle', gain: 0.2 }); },
  sniff() { for (let i = 0; i < 3; i++) burst({ dur: 0.07, freq: 2600, q: 1.2, gain: 0.12, delay: i * 0.11 }); },
  snore() { burst({ dur: 1.0, freq: 220, q: 2, type: 'lowpass', gain: 0.18 }); },
  // догляд і гра
  lap() { burst({ dur: 0.05, freq: R(2200, 3000), q: 3, gain: 0.16 }); thump(900, 500, 0.04, 0.05, 0.01); },
  crunch() { for (let i = 0; i < 3; i++) burst({ dur: 0.035, freq: R(1800, 4200), q: 1.5, gain: 0.2, delay: i * 0.03 }); },
  pour() { burst({ dur: 0.6, freq: 1400, q: 0.6, gain: 0.12, f1: 2400 }); },
  kibble() { for (let i = 0; i < 7; i++) burst({ dur: 0.03, freq: R(2500, 5000), q: 2, gain: 0.12, delay: i * R(0.03, 0.06) }); },
  bounce(v = 1) { thump(160, 70, 0.14, 0.3 * Math.min(1, v)); },
  throwIt() { burst({ dur: 0.25, freq: 900, q: 0.7, gain: 0.1, f1: 300 }); },
  squeak() { voice({ dur: 0.18, f0: [[0, 1300], [0.5, 1900], [1, 1500]], vow: [[0, 'i'], [1, 'i']], type: 'square', gain: 0.12, breath: 0 }); },
  catchIt() { thump(300, 120, 0.08, 0.25); },
  cup() { thump(220, 160, 0.1, 0.25); burst({ dur: 0.05, freq: 3000, q: 2, gain: 0.08 }); },
  shuffle() { burst({ dur: 0.18, freq: 1200, q: 0.8, gain: 0.08 }); },
  treat() { VOICES.crunch(); },
  wear() { burst({ dur: 0.16, freq: 1600, q: 0.6, gain: 0.08, f1: 900 }); voice({ dur: 0.12, f0: [[0, 900], [1, 1400]], vow: [[0, 'i'], [1, 'i']], type: 'sine', gain: 0.12, breath: 0, delay: 0.1 }); },
  tap() { thump(700, 520, 0.05, 0.12); },
  ok() { voice({ dur: 0.12, f0: [[0, 880], [1, 880]], vow: [[0, 'i'], [1, 'i']], type: 'triangle', gain: 0.14, breath: 0 }); voice({ dur: 0.2, f0: [[0, 1320], [1, 1320]], vow: [[0, 'i'], [1, 'i']], type: 'triangle', gain: 0.14, breath: 0, delay: 0.1 }); },
  growlPlay(p = 1) { voice({ dur: 0.5, f0: [[0, 150 * p], [0.5, 190 * p], [1, 140 * p]], vow: [[0, 'o'], [1, 'u']], rough: 0.45, breath: 0.15, gain: 0.3, vib: 10, vibF: 20 }); },
  laser() { voice({ dur: 0.12, f0: [[0, 2400], [1, 2600]], vow: [[0, 'i'], [1, 'i']], type: 'sine', gain: 0.05, breath: 0 }); }
};
// що каже кожен вид у різних ситуаціях
const SPV = {
  cat: { hello: 'meow', happy: 'mew', pet: 'purr', ask: 'meow', no: 'mew', play: 'mew', tug: 'mew', p: 1 },
  dog: { hello: 'bark', happy: 'bark2', pet: 'pant', ask: 'whine', no: 'whine', play: 'bark', tug: 'growlPlay', p: 1 },
  fox: { hello: 'yip', happy: 'yip', pet: 'chirp', ask: 'whine', no: 'yip', play: 'yip', tug: 'growlPlay', p: 1.25 },
  wolf: { hello: 'howl', happy: 'bark', pet: 'pant', ask: 'whine', no: 'growl', play: 'bark', tug: 'growlPlay', p: 0.9 },
  frog: { hello: 'ribbit', happy: 'ribbit', pet: 'ribbit', ask: 'ribbit', no: 'ribbit', play: 'ribbit', p: 1 },
  deer: { hello: 'bleat', happy: 'bleat', pet: 'sniff', ask: 'bleat', no: 'bleat', play: 'bleat', p: 1.1 },
  dino: { hello: 'roar', happy: 'growl', pet: 'growl', ask: 'growl', no: 'growl', play: 'roar', p: 1.2 },
  trike: { hello: 'growl', happy: 'growl', pet: 'growl', ask: 'growl', no: 'growl', play: 'roar', p: 0.9 },
  dragon: { hello: 'roar', happy: 'chirp', pet: 'purr', ask: 'growl', no: 'growl', play: 'roar', p: 1.4 }
};
export function petVoice(species, what, size = 1) {
  if (muted()) return;
  try { const v = SPV[species] || SPV.dog; const k = v[what] || what; const fn = VOICES[k]; if (fn) fn(v.p * (species === 'dog' ? 1 / Math.max(0.7, Math.min(1.4, size)) : 1)); } catch (_) { }
}
export function careSound(kind, arg) { if (muted()) return; try { const fn = VOICES[kind]; if (fn) fn(arg); } catch (_) { } }

// звуки тварин з ігор (sfx('meow') тощо) — тими самими голосами
setVoiceHook((k) => { if (muted()) return; const fn = VOICES[k]; if (fn) try { fn(); } catch (_) { } });
