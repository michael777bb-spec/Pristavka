// Спільний 3D-рушій для всіх картриджів приставки.
// Один стиль на всі ігри: «живий мініатюрний світ» — справжні матеріали,
// м'яке світло, тіні, сяйво (bloom) і легке розмиття країв кадру, як у макету.
import * as THREE from '../lib/three.module.js';
import { RoomEnvironment } from '../lib/addons/environments/RoomEnvironment.js';
import { EffectComposer } from '../lib/addons/postprocessing/EffectComposer.js';
import { RenderPass } from '../lib/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from '../lib/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from '../lib/addons/postprocessing/ShaderPass.js';
import { OutputPass } from '../lib/addons/postprocessing/OutputPass.js';
import { RoundedBoxGeometry } from '../lib/addons/geometries/RoundedBoxGeometry.js';
import { profile, limiter } from './perf.js';
export { THREE, RoundedBoxGeometry };

const TiltShift = {
  uniforms: { tDiffuse: { value: null }, uDir: { value: new THREE.Vector2(1, 0) }, uFocus: { value: 0.5 }, uRange: { value: 0.2 }, uAmt: { value: 1 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
  fragmentShader: `uniform sampler2D tDiffuse; uniform vec2 uDir; uniform float uFocus, uRange, uAmt; varying vec2 vUv;
  void main(){
    float d = max(0.0, abs(vUv.y - uFocus) - uRange);
    float r = clamp(d * 3.2, 0.0, 1.0) * uAmt;
    vec2 o1 = uDir * 1.3846 * r, o2 = uDir * 3.2308 * r;
    vec4 c = texture2D(tDiffuse, vUv) * 0.2270;
    c += (texture2D(tDiffuse, vUv + o1) + texture2D(tDiffuse, vUv - o1)) * 0.3162;
    c += (texture2D(tDiffuse, vUv + o2) + texture2D(tDiffuse, vUv - o2)) * 0.0703;
    gl_FragColor = c;
  }`
};

export const ease = {
  out: (t) => 1 - Math.pow(1 - t, 3),
  inOut: (t) => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2,
  back: (t) => { const c = 1.70158; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); },
  lin: (t) => t
};

export function world(root, o = {}) {
  const q = o.quality || 'high';
  const hi = q === 'high';
  const PFG = profile(q === 'off' ? 'eco' : q); // «Без 3D» стосується лише фону; сама гра — найлегшою
  const canvas = document.createElement('canvas');
  canvas.className = 'cart-canvas';
  root.appendChild(canvas);
  const hud = document.createElement('div');
  hud.className = 'hud';
  root.appendChild(hud);

  let running = true;
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'default' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, PFG.gameDpr));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = o.exposure || 1;
  // тіні — найдорожче в грі (кожен предмет малюється двічі, плюс окремі шейдери); у «eco» і на старих телефонах — без них
  renderer.shadowMap.enabled = !!PFG.gameShadows;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  // телефон «загубив» 3D (забракло памʼяті) — приставка покаже пояснення й кнопку «Спробувати легше»
  canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); if (running) root.dispatchEvent(new CustomEvent('cart-lost', { bubbles: true })); });
  // чи вміє відеокарта малювати в півточні (half-float) текстури: без цього світло-оточення й свічення не працюють
  const halfOk = renderer.extensions.has('EXT_color_buffer_float') || renderer.extensions.has('EXT_color_buffer_half_float');

  const scene = new THREE.Scene();
  if (o.bg !== undefined) scene.background = new THREE.Color(o.bg);
  if (halfOk) {
    const pm = new THREE.PMREMGenerator(renderer);
    scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environmentIntensity = o.envI ?? 0.6;
    pm.dispose();
  } else {
    // запасне світло замість оточення (старі Android): сцена не буде темною
    scene.add(new THREE.HemisphereLight(0xffffff, 0x3a4250, 1.4 * (o.envI ?? 0.6) + 0.4));
  }

  const camera = new THREE.PerspectiveCamera(o.fov || 35, 1, 0.1, 400);

  const rt = new THREE.WebGLRenderTarget(4, 4, { type: halfOk ? THREE.HalfFloatType : THREE.UnsignedByteType, samples: hi && halfOk ? 4 : 0 });
  const composer = new EffectComposer(renderer, rt);
  composer.addPass(new RenderPass(scene, camera));
  const bloom = new UnrealBloomPass(new THREE.Vector2(4, 4), o.bloom ?? 0.55, 0.6, o.bloomTh ?? 0.82);
  bloom.enabled = PFG.bloom && halfOk;
  composer.addPass(bloom);
  const tsH = new ShaderPass(TiltShift), tsV = new ShaderPass(TiltShift);
  const tilt = o.tilt ?? 1;
  if (tilt && PFG.tilt) { composer.addPass(tsH); composer.addPass(tsV); }
  composer.addPass(new OutputPass());
  // у «eco» без свічення й розмиття послідовність проходів зайва: малюємо сцену одразу на екран (удвічі менше роботи)
  const direct = !bloom.enabled && !PFG.tilt;

  let W = 1, H = 1;
  function resize() {
    const r = root.getBoundingClientRect();
    W = Math.max(1, r.width); H = Math.max(1, r.height);
    renderer.setSize(W, H, false);
    composer.setSize(W, H);
    bloom.resolution.set(W / 2, H / 2);
    camera.aspect = W / H;
    if (api.onResize) api.onResize(W, H); else camera.updateProjectionMatrix();
    const k = hi ? 2.4 : 1.8;
    tsH.uniforms.uDir.value.set(k / W, 0); tsV.uniforms.uDir.value.set(0, k / H);
    tsH.uniforms.uAmt.value = tsV.uniforms.uAmt.value = tilt;
  }
  const ro = new ResizeObserver(resize);
  ro.observe(root);

  const frames = new Set();
  const tweens = [];
  const clock = { last: performance.now(), elapsedTime: 0, getDelta() { const n = performance.now(); const d = (n - this.last) / 1000; this.last = n; this.elapsedTime += Math.min(d, 0.05); return d; } };
  const allow = limiter(() => PFG.gameFps);   // 30 к/с в «eco»: для дитячих ігор досить, а телефон не гріється
  function loop(now) {
    if (!allow(now || performance.now())) return;
    const dt = Math.min(clock.getDelta(), 0.05);
    const tm = clock.elapsedTime;
    for (let i = tweens.length - 1; i >= 0; i--) {
      const tw = tweens[i];
      tw.t += dt / tw.dur;
      const k = tw.ease(Math.min(1, Math.max(0, tw.t)));
      if (tw.t > 0) for (const key in tw.to) tw.obj[key] = tw.from[key] + (tw.to[key] - tw.from[key]) * k;
      if (tw.t >= 1) { tweens.splice(i, 1); if (tw.done) tw.done(); }
    }
    for (const f of frames) f(dt, tm);
    if (direct) renderer.render(scene, camera); else composer.render(dt);
  }
  renderer.setAnimationLoop(loop);
  const onVis = () => { if (document.hidden) renderer.setAnimationLoop(null); else if (running) { clock.getDelta(); renderer.setAnimationLoop(loop); } };
  document.addEventListener('visibilitychange', onVis);

  function tween(obj, to, dur = 0.4, ez = ease.out, done, delay = 0) {
    const from = {};
    for (const k in to) from[k] = obj[k];
    // скасувати попередній твін того самого об'єкта по тих самих ключах
    for (let i = tweens.length - 1; i >= 0; i--) if (tweens[i].obj === obj && Object.keys(to).some((k) => k in tweens[i].to)) tweens.splice(i, 1);
    tweens.push({ obj, from, to, t: -delay / dur, dur, ease: ez, done });
  }
  const wait = (s) => new Promise((r) => tween({ v: 0 }, { v: 1 }, s, ease.lin, r));

  const ray = new THREE.Raycaster();
  const ndc = new THREE.Vector2();
  function toNdc(ev) {
    const r = canvas.getBoundingClientRect();
    ndc.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
    return ndc;
  }
  function pick(ev, list) {
    ray.setFromCamera(toNdc(ev), camera);
    const hits = ray.intersectObjects(list, true);
    for (const h of hits) {
      let o2 = h.object;
      while (o2 && !o2.userData.pick) o2 = o2.parent;
      if (o2) return { obj: o2, point: h.point, hit: h };
    }
    return null;
  }
  const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
  function ground(ev, y = 0) {
    ray.setFromCamera(toNdc(ev), camera);
    plane.constant = -y;
    const p = new THREE.Vector3();
    return ray.ray.intersectPlane(plane, p) ? p : null;
  }
  function screen(v3) {
    const v = v3.clone().project(camera);
    return { x: (v.x + 1) / 2 * W, y: (1 - v.y) / 2 * H, behind: v.z > 1 };
  }

  const disposables = [];
  function destroy() {
    running = false;
    renderer.setAnimationLoop(null);
    document.removeEventListener('visibilitychange', onVis);
    ro.disconnect();
    scene.traverse((ob) => {
      if (ob.geometry) ob.geometry.dispose();
      if (ob.material) (Array.isArray(ob.material) ? ob.material : [ob.material]).forEach((m) => { if (!m || !m.isMaterial) return; for (const k in m) if (m[k] && m[k].isTexture) m[k].dispose(); m.dispose(); });
    });
    disposables.forEach((d) => { try { d(); } catch (_) { } });
    composer.dispose && composer.dispose();
    renderer.dispose();
    // звільнити сам WebGL-контекст одразу, а не «колись»: інакше після кількох ігор старий iPhone вичерпує памʼять
    try { renderer.forceContextLoss(); } catch (_) { }
    canvas.width = canvas.height = 1;
    root.innerHTML = '';
  }

  const api = {
    THREE, renderer, scene, camera, canvas, hud, composer, bloom, tilt: (v, focus, range) => {
      tsH.uniforms.uAmt.value = tsV.uniforms.uAmt.value = v;
      if (focus !== undefined) tsH.uniforms.uFocus.value = tsV.uniforms.uFocus.value = focus;
      if (range !== undefined) tsH.uniforms.uRange.value = tsV.uniforms.uRange.value = range;
    },
    onFrame: (f) => { frames.add(f); return () => frames.delete(f); },
    tween, wait, pick, ground, screen, toNdc, ray, destroy, resize,
    size: () => ({ W, H }),
    onDispose: (f) => disposables.push(f),
    onResize: null
  };
  requestAnimationFrame(resize);
  if (/[?&]dbg/.test(location.search)) window.__W = api; // для автоматичних перевірок
  return api;
}

/* ---------- матеріали й текстури ---------- */
export function canvasTex(size, draw, opt = {}) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d');
  draw(g, size);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = opt.linear ? THREE.NoColorSpace : THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 4;
  if (opt.repeat) t.repeat.set(opt.repeat, opt.repeat);
  return t;
}

// Детермінований шум для текстур
export function rnd(seed = 1) {
  let a = seed >>> 0;
  return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}

export function speckle(base, spots, size = 256, n = 2400, seed = 7, r = [0.6, 2.2]) {
  const R = rnd(seed);
  return canvasTex(size, (g, s) => {
    g.fillStyle = base; g.fillRect(0, 0, s, s);
    for (let i = 0; i < n; i++) {
      g.fillStyle = spots[(R() * spots.length) | 0];
      g.globalAlpha = 0.25 + R() * 0.6;
      g.beginPath(); g.arc(R() * s, R() * s, r[0] + R() * (r[1] - r[0]), 0, 7); g.fill();
    }
    g.globalAlpha = 1;
  });
}

export function std(color, rough = 0.6, metal = 0, extra = {}) {
  return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal, ...extra });
}
export function glass(tint = 0xffffff, extra = {}) {
  return new THREE.MeshPhysicalMaterial({ color: tint, roughness: 0.05, metalness: 0, transmission: 1, thickness: 0.4, ior: 1.45, transparent: true, ...extra });
}
export function glow(color, intensity = 2) {
  return new THREE.MeshStandardMaterial({ color: 0x111111, emissive: color, emissiveIntensity: intensity, roughness: 0.4 });
}

// М'яка контактна тінь під об'єктом (дешевий AO)
let _blobTex = null;
export function blob(w = 1, d = 1, op = 0.45) {
  if (!_blobTex) _blobTex = canvasTex(128, (g, s) => {
    const gr = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
    gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, 0, s, s);
  });
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshBasicMaterial({ map: _blobTex, transparent: true, opacity: op, depthWrite: false }));
  m.rotation.x = -Math.PI / 2;
  m.position.y = 0.005;
  m.renderOrder = 1;
  return m;
}

export function label(text, o = {}) {
  const fs = o.size || 44, pad = 18;
  const c = document.createElement('canvas'), g = c.getContext('2d');
  g.font = `${o.weight || 700} ${fs}px Onest, system-ui, sans-serif`;
  const w = Math.ceil(g.measureText(text).width) + pad * 2, h = fs + pad * 1.4;
  c.width = w; c.height = h;
  g.font = `${o.weight || 700} ${fs}px Onest, system-ui, sans-serif`;
  if (o.bg !== false) { g.fillStyle = o.bg || 'rgba(12,14,20,.72)'; const r = h / 2; g.beginPath(); g.roundRect(0, 0, w, h, r); g.fill(); }
  g.fillStyle = o.color || '#fff'; g.textBaseline = 'middle'; g.fillText(text, pad, h / 2 + 2);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, depthTest: o.depth ?? false, transparent: true }));
  const k = (o.scale || 0.5) / h;
  s.scale.set(w * k, h * k, 1);
  s.renderOrder = 10;
  return s;
}

// табличка з іконкою (SVG) і, за бажанням, текстом — для 3D-сцени
export function tagSprite(svg, text = '', o = {}) {
  const fs = o.size || 44, pad = 16, ic = Math.round(fs * 1.25);
  const c = document.createElement('canvas'), g = c.getContext('2d');
  g.font = `${o.weight || 700} ${fs}px Onest, system-ui, sans-serif`;
  const tw = text ? Math.ceil(g.measureText(text).width) + 10 : 0;
  const w = pad * 2 + ic + tw, hh = ic + pad;
  c.width = w; c.height = hh;
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const draw = (img) => {
    g.clearRect(0, 0, w, hh);
    if (o.bg !== false) { g.fillStyle = o.bg || 'rgba(12,14,20,.72)'; g.beginPath(); g.roundRect(0, 0, w, hh, hh / 2); g.fill(); }
    if (img) g.drawImage(img, pad, pad / 2, ic, ic);
    if (text) { g.font = `${o.weight || 700} ${fs}px Onest, system-ui, sans-serif`; g.fillStyle = o.color || '#fff'; g.textBaseline = 'middle'; g.fillText(text, pad + ic + 8, hh / 2 + 2); }
    t.needsUpdate = true;
  };
  draw(null);
  const img = new Image(); img.onload = () => draw(img); img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, depthTest: o.depth ?? false, transparent: true }));
  const k = (o.scale || 0.5) / hh; s.scale.set(w * k, hh * k, 1); s.renderOrder = 10;
  return s;
}

/* ---------- частинки ---------- */
export function particles(w, max = 400) {
  const { THREE: T, scene } = w;
  const geo = new T.BufferGeometry();
  const pos = new Float32Array(max * 3), col = new Float32Array(max * 3);
  geo.setAttribute('position', new T.BufferAttribute(pos, 3));
  geo.setAttribute('color', new T.BufferAttribute(col, 3));
  const tex = canvasTex(64, (g, s) => { const gr = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.4, 'rgba(255,255,255,.5)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, s, s); });
  const mat = new T.PointsMaterial({ size: 0.16, map: tex, vertexColors: true, transparent: true, depthWrite: false, blending: T.AdditiveBlending });
  const pts = new T.Points(geo, mat);
  pts.frustumCulled = false;
  scene.add(pts);
  const P = [];
  const c = new T.Color();
  w.onFrame((dt) => {
    for (let i = P.length - 1; i >= 0; i--) {
      const p = P[i];
      p.life -= dt;
      if (p.life <= 0) { P.splice(i, 1); continue; }
      p.v.y -= (p.g ?? 6) * dt;
      p.p.addScaledVector(p.v, dt);
    }
    for (let i = 0; i < max; i++) {
      const p = P[i];
      if (p) { pos[i * 3] = p.p.x; pos[i * 3 + 1] = p.p.y; pos[i * 3 + 2] = p.p.z; const f = Math.min(1, p.life / p.max * 2); col[i * 3] = p.c.r * f; col[i * 3 + 1] = p.c.g * f; col[i * 3 + 2] = p.c.b * f; }
      else { pos[i * 3 + 1] = -999; }
    }
    geo.attributes.position.needsUpdate = true; geo.attributes.color.needsUpdate = true;
  });
  return {
    burst(at, color = 0xffd36b, n = 24, speed = 2.2, life = 0.9, g = 6) {
      c.set(color);
      for (let i = 0; i < n && P.length < max; i++) {
        const v = new T.Vector3(Math.random() - 0.5, Math.random() * 0.9 + 0.3, Math.random() - 0.5).normalize().multiplyScalar(speed * (0.4 + Math.random() * 0.8));
        P.push({ p: at.clone(), v, life: life * (0.6 + Math.random() * 0.6), max: life, c: c.clone(), g });
      }
    },
    mat
  };
}

/* ---------- HUD (DOM поверх 3D) ---------- */
export function h(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
}
export function esc(s) { return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]); }

// Перетягування з порогом: відрізняє тап від свайпу
export function gesture(el, h2) {
  let st = null;
  el.addEventListener('pointerdown', (e) => {
    st = { x: e.clientX, y: e.clientY, t: performance.now(), moved: false, id: e.pointerId, lx: e.clientX, ly: e.clientY, vx: 0, vy: 0 };
    if (h2.down) h2.down(e, st);
  });
  el.addEventListener('pointermove', (e) => {
    if (!st || e.pointerId !== st.id) { if (h2.hover) h2.hover(e); return; }
    const now = performance.now();
    st.vx = (e.clientX - st.lx) / Math.max(1, now - (st.lt || st.t)); st.vy = (e.clientY - st.ly) / Math.max(1, now - (st.lt || st.t));
    st.lx = e.clientX; st.ly = e.clientY; st.lt = now;
    if (!st.moved && Math.hypot(e.clientX - st.x, e.clientY - st.y) > 8) { st.moved = true; try { el.setPointerCapture(e.pointerId); } catch (_) { } if (h2.start) h2.start(e, st); }
    if (st.moved && h2.move) h2.move(e, st);
  });
  const up = (e) => {
    if (!st || e.pointerId !== st.id) return;
    const s = st; st = null;
    if (s.moved) { if (h2.end) h2.end(e, s); } else if (h2.tap) h2.tap(e, s);
  };
  el.addEventListener('pointerup', up);
  el.addEventListener('pointercancel', (e) => { if (st && h2.end) h2.end(e, st); st = null; });
}

// Звук — у sound.js (шини, вимикач, петлі, фон); тут лише повторний експорт для старих імпортів
export { sfx, audioCtx, noiseBuf } from './sound.js';

/* ---------- камера-«руки»: тягни, щипай, крути, тицяй, затискай ----------
   1 палець / ліва миша — рух мапою; 2 пальці — щипок (масштаб) і поворот;
   права миша або Shift — поворот і нахил; коліщатко — масштаб.
   Тап — onTap(e), затискання 0,45 с — onHold(e). Ігри можуть «забрати»
   дотик собі (наприклад, кота) через rig.grab(e) у onDown. */
export function rig(W, o = {}) {
  const { camera, canvas } = W;
  const T = new THREE.Vector3().copy(o.target || new THREE.Vector3());
  const st = { dist: o.dist || 14, yaw: o.yaw || 0, pitch: o.pitch || 0.95 };
  const want = { t: T.clone(), dist: st.dist, yaw: st.yaw, pitch: st.pitch };
  const lim = Object.assign({ min: 4, max: 40, pmin: 0.45, pmax: 1.35, box: 20 }, o.limits || {});
  const pts = new Map();
  let mode = null, grabbed = null, holdT = null, start = null, last2 = null, moved = false;
  const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), ray = new THREE.Raycaster(), v2 = new THREE.Vector2();
  const ground = (x, y) => { const r = canvas.getBoundingClientRect(); v2.set(((x - r.left) / r.width) * 2 - 1, -((y - r.top) / r.height) * 2 + 1); ray.setFromCamera(v2, camera); const p = new THREE.Vector3(); return ray.ray.intersectPlane(plane, p) ? p : null; };
  const api = {
    target: want.t, onTap: null, onHold: null, onDown: null, onMove: null, onUp: null, enabled: true,
    grab(e) { grabbed = e.pointerId; clearTimeout(holdT); },
    flyTo(p, dist) { want.t.copy(p); if (dist) want.dist = dist; },
    set(o2) { if (o2.dist) want.dist = o2.dist; if (o2.yaw !== undefined) want.yaw = o2.yaw; if (o2.pitch !== undefined) want.pitch = o2.pitch; },
    get dist() { return st.dist; },
    update(dt) {
      const k = Math.min(1, dt * 7);
      st.dist += (want.dist - st.dist) * k; st.yaw += (want.yaw - st.yaw) * k; st.pitch += (want.pitch - st.pitch) * k;
      T.lerp(want.t, k);
      const cp = Math.cos(st.pitch), sp = Math.sin(st.pitch);
      camera.position.set(T.x + Math.sin(st.yaw) * cp * st.dist, T.y + sp * st.dist, T.z + Math.cos(st.yaw) * cp * st.dist);
      camera.lookAt(T);
    },
    ground
  };
  const clamp = () => { want.dist = THREE.MathUtils.clamp(want.dist, lim.min, lim.max); want.pitch = THREE.MathUtils.clamp(want.pitch, lim.pmin, lim.pmax); want.t.x = THREE.MathUtils.clamp(want.t.x, -lim.box, lim.box); want.t.z = THREE.MathUtils.clamp(want.t.z, -lim.box, lim.box); };
  canvas.style.touchAction = 'none';
  canvas.addEventListener('contextmenu', (e) => e.preventDefault());
  canvas.addEventListener('pointerdown', (e) => {
    if (!api.enabled) return;
    try { canvas.setPointerCapture(e.pointerId); } catch (_) { }
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.size === 1) {
      moved = false; grabbed = null; start = { x: e.clientX, y: e.clientY, g: ground(e.clientX, e.clientY), t: want.t.clone(), yaw: want.yaw, pitch: want.pitch };
      mode = (e.button === 2 || e.shiftKey) ? 'rot' : 'pan';
      if (api.onDown) api.onDown(e);
      if (grabbed === null) holdT = setTimeout(() => { if (!moved && pts.size === 1 && api.onHold) { api.onHold(e); grabbed = -1; } }, 450);
    } else { clearTimeout(holdT); mode = 'two'; last2 = null; }
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!pts.has(e.pointerId)) { if (api.onHover) api.onHover(e); return; }
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (grabbed === e.pointerId) { if (api.onMove) api.onMove(e); return; }
    if (grabbed === -1) return;
    if (mode === 'two' && pts.size >= 2) {
      const [a, b] = [...pts.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y), ang = Math.atan2(b.y - a.y, b.x - a.x), cy = (a.y + b.y) / 2;
      if (last2) { want.dist *= last2.d / Math.max(1, d); want.yaw -= (ang - last2.ang); want.pitch += (cy - last2.cy) * 0.004; clamp(); }
      last2 = { d, ang, cy }; moved = true; return;
    }
    const dx = e.clientX - start.x, dy = e.clientY - start.y;
    if (!moved && Math.hypot(dx, dy) > 8) { moved = true; clearTimeout(holdT); }
    if (!moved) return;
    if (mode === 'rot') { want.yaw = start.yaw - dx * 0.006; want.pitch = start.pitch + dy * 0.004; clamp(); return; }
    // панорамування: точка землі під пальцем лишається під пальцем
    const g = ground(e.clientX, e.clientY);
    if (g && start.g) { const d2 = start.g.clone().sub(g); want.t.add(d2.multiplyScalar(0.5)); start.g = ground(e.clientX, e.clientY); clamp(); }
  });
  const end = (e) => {
    if (!pts.has(e.pointerId)) return;
    pts.delete(e.pointerId); clearTimeout(holdT);
    if (grabbed === e.pointerId) { grabbed = null; if (api.onUp) api.onUp(e); return; }
    if (pts.size === 0) { if (!moved && grabbed !== -1 && mode !== 'two' && api.onTap) api.onTap(e); grabbed = null; mode = null; }
  };
  canvas.addEventListener('pointerup', end); canvas.addEventListener('pointercancel', end);
  canvas.addEventListener('wheel', (e) => { e.preventDefault(); want.dist *= Math.exp(e.deltaY * 0.0012); clamp(); }, { passive: false });
  W.onFrame((dt) => api.update(dt));
  return api;
}

/* ---------- дахи: справжня геометрія під прямокутний будинок ----------
   hipRoof — чотирисхилий (вальмовий): схили з усіх боків, коник по довшій стороні.
   gableRoof — двосхилий: два схили, трикутні фронтони з матеріалу стін, коник зверху.
   w — ширина (X), d — глибина (Z), h — висота від карниза до коника, over — напуск. */
function roofGeo(pts, tris) {
  const g = new THREE.BufferGeometry(), pos = [];
  for (const [a, b, c] of tris) pos.push(...pts[a], ...pts[b], ...pts[c]);
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.computeVertexNormals();
  // UV за світовими X/Z — щоб текстура черепиці лягала рівно
  const uv = []; for (let i = 0; i < pos.length; i += 3) uv.push(pos[i] + pos[i + 1] * 0.3, pos[i + 2] + pos[i + 1] * 0.8); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  return g;
}
export function hipRoof(w, d, h, o = {}) {
  const over = o.over ?? 0.1, g = new THREE.Group(), W = w / 2 + over, D = d / 2 + over;
  const mat = o.mat || new THREE.MeshStandardMaterial({ color: o.color ?? 0x8a3b2c, roughness: 0.75 }); mat.side = THREE.DoubleSide;
  const along = w >= d, r = along ? Math.max(0, W - D) : Math.max(0, D - W);
  const pts = [[-W, 0, -D], [W, 0, -D], [W, 0, D], [-W, 0, D], along ? [-r, h, 0] : [0, h, -r], along ? [r, h, 0] : [0, h, r]];
  const tris = along ? [[3, 2, 5], [3, 5, 4], [1, 0, 4], [1, 4, 5], [2, 1, 5], [0, 3, 4]] : [[3, 2, 5], [0, 3, 4], [3, 5, 4], [2, 1, 4], [2, 4, 5], [1, 0, 4]];
  const m = new THREE.Mesh(roofGeo(pts, tris), mat); m.castShadow = true; m.receiveShadow = true; g.add(m);
  // карниз (товщина краю) — щоб дах не виглядав паперовим
  const th = o.th ?? Math.min(0.08, h * 0.12), em = o.edge || mat;
  for (const [sx, sz, lx, lz] of [[0, D, W * 2, 0.04], [0, -D, W * 2, 0.04], [W, 0, 0.04, D * 2], [-W, 0, 0.04, D * 2]]) { const e = new THREE.Mesh(new THREE.BoxGeometry(lx + 0.04, th, lz + 0.04), em); e.position.set(sx, -th / 2, sz); e.castShadow = true; g.add(e); }
  if (r > 0.01) { const rid = new THREE.Mesh(new THREE.BoxGeometry(along ? r * 2 + 0.06 : 0.07, 0.05, along ? 0.07 : r * 2 + 0.06), o.ridge || em); rid.position.y = h + 0.01; g.add(rid); }
  return g;
}
export function gableRoof(w, d, h, o = {}) {
  // коник уздовж X; фронтони — на торцях ±X; схили — плити з товщиною
  const over = o.over ?? 0.1, g = new THREE.Group(), W = w / 2 + over, D = d / 2 + over, dz = d / 2, k = h / dz, th = o.th ?? 0.07;
  const mat = o.mat || new THREE.MeshStandardMaterial({ color: o.color ?? 0x8a3b2c, roughness: 0.75 });
  const yE = -over * k, a = Math.atan2(h - yE, D), L = Math.hypot(D, h - yE);
  for (const s of [-1, 1]) {
    const slab = new THREE.Mesh(new THREE.BoxGeometry(W * 2, th, L + th * 0.5), mat);
    slab.rotation.x = s * a; slab.position.set(0, (h + yE) / 2 + th / 2 * Math.cos(a), s * D / 2 + s * th / 2 * Math.sin(a));
    slab.castShadow = true; slab.receiveShadow = true; g.add(slab);
  }
  if (o.wall) { const tri = new THREE.Shape([new THREE.Vector2(-dz, 0), new THREE.Vector2(dz, 0), new THREE.Vector2(0, h)]); for (const s of [-1, 1]) { const f = new THREE.Mesh(new THREE.ShapeGeometry(tri), o.wall); f.rotation.y = s * Math.PI / 2; f.position.x = s * w / 2; f.castShadow = true; f.receiveShadow = true; g.add(f); } }
  const rid = new THREE.Mesh(new THREE.BoxGeometry(W * 2 + 0.04, 0.07, 0.12), o.ridge || mat); rid.position.y = h + th * 0.9; rid.castShadow = true; g.add(rid);
  return g;
}
