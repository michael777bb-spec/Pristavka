// Один прогрес на всіх пристроях: Telegram, браузер, іконка на екрані (PWA).
// Усі збереження приставки (planetar:…) — одним пакетом на сервері, прив'язаним до облікового запису.
// Що лишається лише на цьому пристрої: вхід, якість графіки, звук, мова, ключі ШІ.
import { net } from './net.js';

const P = 'planetar:';
const LOCAL_ONLY = /^(token|loginUsed|quality|mute|lang|offlineReady|sync:|ai:|aiKeys|seen)/;
export let reloading = false; // під час заміни прогресу з хмари ігри не повинні перезаписати його старим

function collect() {
  const o = {};
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith(P) && !LOCAL_ONLY.test(k.slice(P.length))) o[k.slice(P.length)] = localStorage.getItem(k);
  }
  return o;
}
const ser = (o) => JSON.stringify(Object.keys(o).sort().reduce((a, k) => ((a[k] = o[k]), a), {}));
const hash = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36) + s.length.toString(36); };
const meta = () => { try { return JSON.parse(localStorage.getItem(P + 'sync:meta')) || {}; } catch (_) { return {}; } };
const setMeta = (m) => { try { localStorage.setItem(P + 'sync:meta', JSON.stringify(m)); } catch (_) { } };
// «порожній» пристрій: ще не грали — тоді прогрес із хмари береться без питань
const fresh = (o) => !Object.keys(o).some((k) => k.startsWith('cart:') || k === 'pzResults' || k === 'petAll');

function apply(data) {
  const o = JSON.parse(data);
  for (const k of Object.keys(collect())) if (!(k in o)) localStorage.removeItem(P + k);
  for (const [k, v] of Object.entries(o)) localStorage.setItem(P + k, v);
}
async function push(data, h, base) {
  const r = await net.put('/api/save', { data, hash: h, base });
  if (r.ok) setMeta({ hash: h, at: r.updated });
  else if (r.conflict) setMeta({ ...meta(), at: 0 }); // хтось записав раніше — наступна перевірка спитає
  return r;
}

let busy = false, again = null; // попросили синхронізувати, поки йшла попередня — повторимо одразу після неї
// ui.ask() → true, якщо взяти прогрес з іншого пристрою; ui.done() — після заміни (перезавантажити)
export async function syncNow(ui) {
  if (busy) { again = ui; return; }
  if (reloading || !net.online || !net.token) return;
  busy = true;
  try {
    const loc = collect(), data = ser(loc), h = hash(data), m = meta();
    if (ui.onlyIfChanged && m.hash === h) return; // нічого не змінилось — навіть не питаємо сервер
    const s = await net.getj('/api/save'); if (!s.ok) return;
    if (!s.data) { if (!fresh(loc)) await push(data, h, 0); return; }
    if (s.hash === h) { setMeta({ hash: h, at: s.updated }); return; }
    const localChanged = m.hash !== h, serverChanged = (m.at || 0) < s.updated;
    if (!serverChanged) { if (localChanged) await push(data, h, m.at || 0); return; }
    if (!localChanged || fresh(loc) || (ui.ask && await ui.ask())) {
      reloading = true; apply(s.data); setMeta({ hash: hash(ser(collect())), at: s.updated }); ui.done && ui.done(); return;
    }
    await push(data, h, s.updated); // лишаємо прогрес цього пристрою — він і стає спільним
  } catch (_) { /* без мережі — спробуємо пізніше */ } finally { busy = false; if (again && !reloading) { const u = again; again = null; setTimeout(() => syncNow(u), 50); } }
}
