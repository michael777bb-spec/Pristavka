/* ============================================================
   PLANETAR — приставка (прототип).
   Один екран для телефона, планшета й комп'ютера.
   ============================================================ */
import { createStage } from './stage.js';
import { PetStage } from './pet.js';
import { T, LANGS, GAMES, BREEDS } from './i18n.js';
import { HATS, COMMANDS, toysFor } from './pet.js';
import { sfx } from './kit.js';
import { soundSync } from './sound.js';
import { petVoice } from './voice.js';
import * as PZ from './puzzles.js';
import { net } from './net.js';
import { createAI, PROVIDERS } from './ai.js';
import { gi, iconDefs } from './icons.js';

const $ = (s, r) => (r || document).querySelector(s);
const store = {
  get(k, d) { try { const v = localStorage.getItem('planetar:' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('planetar:' + k, JSON.stringify(v)); } catch (e) { } }
};

const S = {
  lang: store.get('lang', 'uk'),
  quality: store.get('quality', window.matchMedia('(pointer:coarse)').matches ? 'normal' : 'high'),
  route: 'home', corpus: false, coins: store.get('coins', 120),
  breed: store.get('breed', 'fox'), petAll: store.get('petAll', true), models: {},
  pzType: 'tango', pzLevel: 'medium', pz: null, showErrors: true,
  online: false, me: null, name: store.get('name', ''),
  tg: { mode: 'online', phase: 'menu', code: '', seat: -1, host: -1, players: [], max: 4, bots: true, type: 'tango', level: 'easy', race: null, local: null, n: 2 },
  aiRes: null, aiBusy: false, rateScope: 'day', pencil: store.get('pencil', false),
  game_open: null, speech: 'petIdle'
};
const t = (k) => (T[S.lang] && T[S.lang][k]) || T.uk[k] || k;
const L = (o) => (o && (o[S.lang] || o.uk)) || '';
const esc = (s) => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* ---------- іконки ---------- */
const IC = {
  home: '<svg viewBox="0 0 22 22" aria-hidden="true"><rect x="2.5" y="5" width="17" height="12" rx="4" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M7 9v4M5 11h4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><circle cx="14.5" cy="10" r="1.1" fill="currentColor"/><circle cx="16" cy="12.5" r="1.1" fill="currentColor"/></svg>',
  games: '<svg viewBox="0 0 22 22" aria-hidden="true"><rect x="5" y="2.5" width="12" height="17" rx="2.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8 2.5v3h6v-3M8 16h6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><rect x="8" y="8" width="6" height="5" rx="1" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>',
  puzzles: '<svg viewBox="0 0 22 22" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="12" y="3" width="7" height="7" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="3" y="12" width="7" height="7" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="12" y="12" width="7" height="7" rx="2" fill="currentColor" opacity=".55"/></svg>',
  pet: '<svg viewBox="0 0 22 22" aria-hidden="true"><ellipse cx="11" cy="14.5" rx="4.6" ry="3.8" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="5" cy="9.5" r="1.9" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="8.5" cy="5.5" r="1.9" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="13.5" cy="5.5" r="1.9" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="17" cy="9.5" r="1.9" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>',
  together: '<svg viewBox="0 0 22 22" aria-hidden="true"><circle cx="8" cy="8" r="3.3" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="15.5" cy="9" r="2.7" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M2.5 18c.7-3.3 2.8-5 5.5-5s4.8 1.7 5.5 5M13 13.3c2.7-.4 5.4.8 6.3 4.2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
  ai: '<svg viewBox="0 0 22 22" aria-hidden="true"><rect x="5" y="5" width="12" height="12" rx="3" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8 2v3M14 2v3M8 17v3M14 17v3M2 8h3M2 14h3M17 8h3M17 14h3" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><path d="M11 8.2l.9 1.9 1.9.9-1.9.9-.9 1.9-.9-1.9-1.9-.9 1.9-.9z" fill="currentColor"/></svg>',
  settings: '<svg viewBox="0 0 22 22" aria-hidden="true"><circle cx="11" cy="11" r="3" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M11 2.5V5M11 17v2.5M2.5 11H5M17 11h2.5M5 5l1.8 1.8M15.2 15.2 17 17M5 17l1.8-1.8M15.2 6.8 17 5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
  sun: '<svg viewBox="0 0 30 30" aria-hidden="true"><circle cx="15" cy="15" r="6.5" fill="#FFC067"/><path d="M15 3v3.5M15 23.5V27M3 15h3.5M23.5 15H27M6.5 6.5l2.5 2.5M21 21l2.5 2.5M6.5 23.5 9 21M21 9l2.5-2.5" stroke="#FFC067" stroke-width="2" stroke-linecap="round"/></svg>',
  moon: '<svg viewBox="0 0 28 28" aria-hidden="true"><path d="M19.5 20.5A9 9 0 0 1 11 5.2 9.5 9.5 0 1 0 22.8 17a8.9 8.9 0 0 1-3.3 3.5z" fill="#9BEAFF"/></svg>',
  queen: '<svg viewBox="0 0 30 30" aria-hidden="true"><path d="M5 22 3.5 10l6.5 5L15 6l5 9 6.5-5L25 22z" fill="#1b1206" stroke="#1b1206" stroke-width="1.2" stroke-linejoin="round"/><rect x="5" y="23.5" width="20" height="3" rx="1.5" fill="#1b1206"/></svg>'
};
for (const k of ['home', 'games', 'puzzles', 'pet', 'together', 'ai', 'settings']) IC[k] = gi(k, 24);
const MEDAL = (i, sz = 18) => i < 3 ? gi('m' + (i + 1), sz) : `<b class="mn">${i + 1}</b>`;
const NAV = ['home', 'games', 'puzzles', 'pet', 'together', 'ai', 'settings'];
const DOCK = ['home', 'games', 'puzzles', 'pet', 'together'];
const MODOF = { home: 'core', games: 'sand2', puzzles: 'core', pet: 'pet', together: 'net', ai: 'ai', settings: 'mem' };

/* ---------- сцена й улюбленець ---------- */
let stage = null;
function startStage() {
  if (S.quality === 'off') { document.body.classList.add('noglass'); return; }
  try {
    stage = createStage($('#stage'), { quality: S.quality });
    document.body.classList.remove('noglass');
  } catch (e) { stage = null; document.body.classList.add('noglass'); }
}
const pet = new PetStage();
pet.onTap = () => { if (S.route === 'puzzles' && S.pz && !S.pz.solved && !S.game_open) { hint(); return; } say('petTap'); pulse('pet', petAct); };
pet.onHappy = (k) => { hearts(); say(k === 'feed' ? 'petWin' : 'petTap'); pulse('pet', petAct); };
window.__planetarMute = store.get('mute', false);
pet.onSound = (k) => sfx(k);
// підказки ігор улюбленця («Знайди ласощі») — у рядку над кнопками
pet.onHint = (k, n) => { S.petHint = k ? [k, n] : null; const e = $('#petStateNote'); if (!e) return; e.textContent = breedNote(); e.classList.toggle('game', !!k); };
// жест розпізнано — коротка позначка внизу сцени
pet.onGesture = (cmd, ok) => {
  const e = $('#gToast'); if (!e) return;
  e.innerHTML = `${gi({ sit: 'sit', lie: 'lie', paw: 'pawA', jump: 'jump', spin: 'spin', voice: 'voice' }[cmd], 22)}<b>${esc(t('cmd_' + cmd))}</b>${ok ? '' : `<em>${esc(t('say_confused'))}</em>`}`;
  e.classList.remove('on'); void e.offsetWidth; e.classList.add('on');
};
pet.skills = store.get('skills', {});
pet.onTrain = (sk) => { store.set('skills', sk); if (S.route === 'pet' && S.petTab === 'cmd') render(); };
pet.onSay = (k) => { const e = document.getElementById('petSay'); if (!e) return; e.textContent = t('say_' + k); e.classList.remove('on'); void e.offsetWidth; e.classList.add('on'); };
(function initNeeds() {
  const n = store.get('needs', null), at = store.get('needsAt', 0);
  if (n) { const mins = Math.max(0, (Date.now() - at) / 60000); n.food = Math.max(40, n.food - mins * 0.5); n.joy = Math.max(40, n.joy - mins * 0.4); n.energy = Math.min(100, n.energy + mins); pet.setNeeds(n); }
  pet.setHat(store.get('hat', 'none'));
})();
pet.onNeeds = (n) => {
  ['food', 'water', 'joy', 'energy'].forEach(k => { const e = document.querySelector(`[data-need="${k}"] i`); if (e) e.style.width = Math.round(n[k]) + '%'; });
  if ((pet._saveT = (pet._saveT || 0) + 1) % 10 === 0) { store.set('needs', n); store.set('needsAt', Date.now()); }
};
pet.onState = (s) => { const n = $('#petStateNote'); if (n) n.textContent = s === 'loading' ? t('petLoading') : s === 'error' ? t('petError') : breedNote(); };
function breedRow(id) { for (const g of Object.values(BREEDS)) for (const b of g) if (b[0] === id) return b; return null; }
function breedUrl(id) { if (S.models[id]) return S.models[id]; const b = breedRow(id); return b ? b[2] : null; }
function breedName(id) { for (const g of Object.values(BREEDS)) for (const b of g) if (b[0] === id) return L(b[1]); return id; }
function breedNote() { const tb = S.petTab || 'who'; return tb === 'who' ? t('ph_who2') : tb === 'play' ? (pet.toyKind === 'cups' && S.petHint ? t(S.petHint[0]).replace('{n}', S.petHint[1] ?? '') : pet.toyKind ? t('toyhint_' + pet.toyKind) : t('ph_play')) : tb === 'cmd' ? t('ph_cmd2') : t('ph_' + tb); }
function loadPet() {
  if (!breedRow(S.breed)) S.breed = 'fox';
  const b = breedRow(S.breed);
  const pr = S.models[S.breed] ? pet.load(pet.cache[S.models[S.breed]] ? S.models[S.breed] : b[2], S.breed) : pet.load(b[2], S.breed, b[3]);
  pr.then(() => { if (!pet.toyKind || !toysFor(pet.sp).includes(pet.toyKind)) pet.setToy(toysFor(pet.sp)[0]); if (S.route === 'pet') render(); });
}
function setHat(k) { pet.setHat(k); store.set('hat', k); render(); }
function petTab(k) { S.petTab = k; pet.gestures = k === 'cmd'; if (k !== 'play' && pet.toyKind === 'cups') pet.setToy(null); render(); }
function toggleSound() { window.__planetarMute = !window.__planetarMute; store.set('mute', window.__planetarMute); soundSync(); if (!window.__planetarMute) sfx('ok'); syncChrome(); }
function setToy(k) { pet.setToy(pet.toyKind === k ? null : k); render(); }
function petCmd(c) { pet.command(c); }
function petReward() { pet.reward(); }

/* ---------- механізм: імпульс і код ---------- */
function pulse(mod, fn) {
  if (!stage) return;
  stage.pulse(mod || 'core');
  if (fn) stage.highlight(String(fn).split('\n'));
}

/* ============================================================
   ДІЇ. Їхній код показує капсула «затисни — спитай».
   ============================================================ */
function go(route) {
  if (!NAV.includes(route)) route = 'home';
  S.route = route;
  try { if (location.hash !== '#' + route) history.replaceState(null, '', '#' + route); } catch (e) { }
  render();
  $('#main').scrollTo({ top: 0, behavior: 'instant' });
}
function toggleCorpus() {
  S.corpus = !S.corpus;
  if (stage) stage.setCorpus(S.corpus);
  syncChrome();
}
let cart = null;
function cartApi(id) {
  return {
    lang: S.lang, quality: S.quality, t, L,
    coins(n) { S.coins += n; store.set('coins', S.coins); syncChrome(); },
    pet(kind) { pet.react(kind); },
    toast, sfx,
    store: { get: (k, d) => store.get(`cart:${id}:${k}`, d), set: (k, v) => store.set(`cart:${id}:${k}`, v) },
    exit: closeGame,
    petName: breedName(S.breed),
    petModel: (breedRow(S.breed) || breedRow('fox'))[2], petTint: (breedRow(S.breed) || [])[3] || null, petHat: pet.hatKind,
    // ШІ для гри: повертає текст або '' (тоді гра відповідає сама, за правилами)
    async ask(task, system, question) { if (!aiAny()) return ''; const r = await ai.ask({ task, system, messages: [{ role: 'user', content: String(question).slice(0, 400) }], max: 260 }).catch(() => ({})); return r.moderated ? t('ai_' + r.moderated) : (r.text || ''); }
  };
}
async function openGame(id) {
  closeSheet();
  const g = GAMES[id]; if (!g) return;
  S.game_open = id;
  $('#playerTitle').textContent = L(g.name);
  $('#playerBadge').textContent = '';
  $('#player').classList.remove('hidden');
  if (stage) stage.stop();
  placePet();
  const root = $('#cartRoot');
  root.innerHTML = `<div class="cart-loading"><span class="spin"></span>${esc(t('cartLoading'))}</div>`;
  try {
    const mod = await import(`./carts/${id}.js`);
    if (S.game_open !== id) return;
    root.innerHTML = '';
    cart = mod.mount(root, cartApi(id));
  } catch (e) {
    console.error(e);
    root.innerHTML = `<div class="cart-loading">${esc(t('cartError'))}</div>`;
  }
}
function closeGame() {
  setTimeout(syncProgress, 300);
  if (cart) { try { cart.destroy(); } catch (e) { console.error(e); } cart = null; }
  $('#cartRoot').innerHTML = '';
  S.game_open = null;
  $('#player').classList.add('hidden');
  if (stage && S.quality !== 'off') stage.start();
  render();
}
function petAct(kind) {
  pet.react(kind);
  say(kind === 'feed' ? 'petWin' : 'petTap');
  hearts();
}
function petWho() {
  const grp = (k) => `<b class="bw-h">${esc(t(k))}</b><div class="bw-grid">${BREEDS[k].map(([id, name]) => `<button class="bw ${S.breed === id ? 'on' : ''}" data-act="pickBreed" data-arg="${id}" data-mod="pet" data-x="breed"><img src="assets/pets/${id}.webp" alt=""><span>${esc(L(name))}</span></button>`).join('')}${k === 'others' ? `<label class="bw">${gi('plus', 30)}<span>${esc(t('pet_own'))}</span><input type="file" accept=".glb,.gltf,model/gltf-binary" id="glbInput" style="display:none"></label>` : ''}</div>`;
  openSheet(`<div class="bw-sheet"><b class="disp" style="font-size:20px">${esc(t('ph_who'))}</b>${grp('cats')}${grp('dogs')}${grp('others')}</div>`);
  const inp = $('#glbInput');
  if (inp) inp.addEventListener('change', async () => { const f = inp.files && inp.files[0]; if (!f) return; closeSheet(); const url = await pet.loadFile(f, S.breed); S.models[S.breed] = url; render(); });
}
function pickBreed(id) {
  closeSheet();
  S.breed = id; store.set('breed', id);
  if (breedUrl(id)) loadPet();
  render();
}
function togglePetAll() { S.petAll = !S.petAll; store.set('petAll', S.petAll); render(); }
function setPuzzleType(type) { S.pzType = type; newPuzzle('daily'); }
function setLevel(level) { S.pzLevel = level; newPuzzle('daily'); }
function newPuzzle(kind) {
  const day = new Date().toISOString().slice(0, 10);
  const seed = kind === 'daily' ? PZ.hashSeed(day + S.pzType + S.pzLevel) : (Math.random() * 1e9) >>> 0;
  const data = PZ.generate(S.pzType, seed, S.pzLevel);
  S.pz = mkPz(data, kind, seed);
  if (S.route !== 'puzzles') go('puzzles'); else render();
}
function cellTap(i) {
  i = Number(i); // з розмітки приходить рядок — без цього вибрана клітинка судоку не підсвічувалась
  const p = S.pz; if (!p || p.solved) return;
  const d = p.data;
  const before = errCount(p);
  if (d.type === 'sudoku') { p.sel = p.sel === i && !p.cells[i] && !d.puzzle[i] ? i : i; p.focus = 0; sfx('tap'); }
  else if (d.type === 'tango') { if (d.puzzle[i]) return; p.cells[i] = (p.cells[i] + 1) % 3; sfx(p.cells[i] ? 'place' : 'erase'); }
  else if (d.type === 'queens') { p.cells[i] = (p.cells[i] + 1) % 3; sfx(p.cells[i] === 2 ? 'place' : p.cells[i] === 1 ? 'pencil' : 'erase'); }
  if (errCount(p) > before) { p.mistakes++; sfx('bad'); }
  checkWin(); renderBoard(); raceTick();
}
function sdPeers(d, i) { const n = d.size, r = (i / n) | 0, c = i % n, out = []; for (let k = 0; k < n * n; k++) { const r2 = (k / n) | 0, c2 = k % n; if (k !== i && (r2 === r || c2 === c || (((r2 / d.br) | 0) === ((r / d.br) | 0) && ((c2 / d.bc) | 0) === ((c / d.bc) | 0)))) out.push(k); } return out; }
function numTap(v) {
  const p = S.pz; if (!p || p.solved || p.data.type !== 'sudoku') return;
  v = Number(v) || 0;
  // цифра без вибраної клітинки — підсвітити всі такі цифри на полі
  if (p.sel < 0 || p.data.puzzle[p.sel]) { p.focus = p.focus === v ? 0 : v; sfx('tap'); renderBoard(); return; }
  p.notes = p.notes || new Array(p.cells.length).fill(0);
  if (S.pencil && v && !p.cells[p.sel]) { p.notes[p.sel] ^= (1 << v); p.last = -1; sfx('pencil'); renderBoard(); return; }
  const before = errCount(p);
  p.cells[p.sel] = v; p.last = p.sel; p.focus = 0; sfx(v ? 'place' : 'erase');
  if (v) { p.notes[p.sel] = 0; for (const k of sdPeers(p.data, p.sel)) p.notes[k] &= ~(1 << v); }
  if (errCount(p) > before) { p.mistakes++; sfx('bad'); }
  checkWin(); renderBoard(); raceTick();
}
function togglePencil() { S.pencil = !S.pencil; store.set('pencil', S.pencil); sfx('toggle'); renderBoard(); }
const HINTWHY = { sudoku: 'hint_sudoku', tango: 'hint_tango', queens: 'hint_queens' };
// Підказка м'яка, у три кроки: 1) де шукати (рядок/квадрат/колір), 2) яка клітинка, 3) відповідь
function hintTarget(p) {
  const d = p.data, n = d.size;
  if (d.type === 'sudoku') {
    const wrong = p.cells.findIndex((v, k) => v && v !== d.solution[k]);
    if (wrong >= 0) return { i: wrong, area: rowOf(wrong, n) };
    let best = -1, bcand = n + 1;
    for (let k = 0; k < n * n; k++) { if (p.cells[k]) continue; const used = new Set(sdPeers(d, k).map((j) => p.cells[j]).filter(Boolean)); const cand = n - used.size; if (cand < bcand) { bcand = cand; best = k; } }
    if (best < 0) return null; const r = (best / n) | 0, c = best % n, r0 = r - r % d.br, c0 = c - c % d.bc;
    const area = []; for (let y = 0; y < d.br; y++) for (let x = 0; x < d.bc; x++) area.push((r0 + y) * n + c0 + x); return { i: best, area };
  }
  if (d.type === 'tango') {
    const wrong = p.cells.findIndex((v, k) => v && v !== d.solution[k]); if (wrong >= 0) return { i: wrong, area: rowOf(wrong, n) };
    const empty = p.cells.map((v, k) => !v ? k : -1).filter(k => k >= 0); if (!empty.length) return null;
    // вимушений хід: два однакові поруч або знак =/× біля заповненої
    const forced = empty.find(k => { const r = (k / n) | 0, c = k % n, v = (i) => p.cells[i] || 0; const pairs = [[k - 1, k - 2, c >= 2], [k + 1, k + 2, c <= n - 3], [k - n, k - 2 * n, r >= 2], [k + n, k + 2 * n, r <= n - 3], [k - 1, k + 1, c >= 1 && c <= n - 2], [k - n, k + n, r >= 1 && r <= n - 2]]; if (pairs.some(([a2, b2, ok]) => ok && v(a2) && v(a2) === v(b2))) return true; return d.cons.some(q => (q.a === k && v(q.b)) || (q.b === k && v(q.a))); });
    const k = forced ?? empty[0]; return { i: k, area: rowOf(k, n) };
  }
  const truth = new Set(d.solution.map((c, r) => r * n + c));
  const wrongQ = p.cells.findIndex((v, k) => v === 2 && !truth.has(k)); if (wrongQ >= 0) return { i: wrongQ, area: d.regions.map((g, k) => g === d.regions[wrongQ] ? k : -1).filter(k => k >= 0), remove: true };
  const miss = [...truth].filter(k => p.cells[k] !== 2); if (!miss.length) return null;
  miss.sort((a2, b2) => d.regions.filter(g => g === d.regions[a2]).length - d.regions.filter(g => g === d.regions[b2]).length);
  const k = miss[0]; return { i: k, area: d.regions.map((g, j) => g === d.regions[k] ? j : -1).filter(j => j >= 0) };
}
const rowOf = (k, n) => { const r = (k / n) | 0; return Array.from({ length: n }, (_, j) => r * n + j); };
function hint() {
  const p = S.pz; if (!p || p.solved) return;
  const d = p.data;
  const valid = p.hl && (d.type === 'queens' ? (p.hl.remove ? p.cells[p.hl.i] === 2 : p.cells[p.hl.i] !== 2) : p.cells[p.hl.i] !== d.solution[p.hl.i]);
  if (!valid) { const tg = hintTarget(p); if (!tg) return; p.hl = { ...tg, level: 0 }; }
  p.hl.level++; p.hints++;
  sfx('pop');
  if (p.hl.level === 1) toast(t(HINTWHY[d.type]));
  if (p.hl.level >= 3) {
    const i = p.hl.i;
    if (d.type === 'queens') p.cells[i] = p.hl.remove ? 0 : 2; else { p.cells[i] = d.solution[i]; if (d.type === 'sudoku') p.sel = i; }
    p.hint = i; p.hl = null;
    setTimeout(() => { if (S.pz === p) { p.hint = -1; renderBoard(); } }, 1600);
    checkWin();
  }
  renderBoard(); raceTick();
}
const LVBASE = { easy: 100, medium: 200, hard: 350, expert: 500 };
const TTARGET = { sudoku: [60, 180, 600, 1000], tango: [90, 150, 240, 360], queens: [60, 120, 180, 300] };
function scoreOf(p) { const lv = PZ.LEVELS.indexOf(S.pzLevel); const tgt = TTARGET[p.data.type][lv]; const k = Math.max(0.4, Math.min(1.5, tgt / Math.max(10, p.time))); return Math.max(10, Math.round(LVBASE[S.pzLevel] * k - p.mistakes * 15 - p.hints * 25)); }
function recordResult(p) {
  const r = { type: p.data.type, level: S.pzLevel, t: p.time, m: p.mistakes, h: p.hints, daily: p.kind === 'daily', at: Date.now(), score: scoreOf(p) };
  if (p.kind === 'local') return r; // гра по черзі на одному пристрої — не в особистий рейтинг власника
  const all = store.get('pzResults', []); all.push(r); store.set('pzResults', all.slice(-300));
  store.set('pzRating', store.get('pzRating', 0) + r.score);
  const key = 'best:' + r.type + ':' + r.level; const best = store.get(key, null);
  r.best = !best || r.t < best.t; if (r.best) store.set(key, { t: r.t, m: r.m, h: r.h });
  r.prevBest = best;
  net.score(r);
  return r;
}
function checkWin() {
  const p = S.pz, d = p.data;
  let won = false;
  if (d.type === 'sudoku') won = p.cells.every((v, i) => v === d.solution[i]);
  if (d.type === 'tango') won = p.cells.every(v => v > 0) && PZ.tangoErrors(p.cells, d.cons).size === 0;
  if (d.type === 'queens') { const q = PZ.queensErrors(d.size, d.regions, p.cells); won = q.count === d.size && q.bad.size === 0; }
  if (won && !p.solved) {
    p.solved = true; p.time = Math.round((Date.now() - p.start) / 1000); p.result = recordResult(p); sfx('win');
    S.coins += 10; store.set('coins', S.coins); syncChrome();
    pet.react('happy'); say('petWin'); hearts();
    pulse('mem', checkWin);
    onSolved(p);
  }
}
function setLang(l) {
  S.lang = l; store.set('lang', l);
  document.documentElement.lang = l;
  if (stage) stage.setLabels(modLabels());
  render();
}
function setQuality(q) {
  S.quality = q; store.set('quality', q);
  if (q === 'off') { if (stage) stage.stop(); document.body.classList.add('noglass'); }
  else { document.body.classList.remove('noglass'); if (!stage) { startStage(); if (stage) stage.setLabels(modLabels()); } else { stage.setQuality(q); stage.start(); } }
  render();
}
function closeSheet() { $('#sheetRoot').innerHTML = ''; }
function goLive() { S.tg.mode = 'near'; go('together'); }

/* ============================================================
   ШІ: Cloudflare на сервері + власні ключі на пристрої
   ============================================================ */
const ai = createAI({ store, server: (o) => net.online ? net.ai(o) : Promise.resolve({ ok: false, offline: true }) });
const aiAny = () => ai.st.order.some((id) => ai.ready(id) && (id !== 'cf' || net.online));
function aiToggle(id) { ai.enable(id, !ai.st.order.includes(id)); S.aiRes = null; render(); }
function aiUp(id) { ai.up(id); render(); }
async function aiTest() { S.aiBusy = true; S.aiRes = null; render(); S.aiRes = await ai.test(); S.aiBusy = false; if (S.route === 'ai') render(); }
function aiErr(why) { return t({ none: 'ai_err_none', key: 'ai_err_key', limit: 'ai_err_limit', net: 'ai_err_net', time: 'ai_err_time', nokey: 'ai_err_nokey', offline: 'ai_err_offline' }[why] || 'ai_err_all'); }
document.addEventListener('change', (e) => {
  const el = e.target;
  if (el.dataset.aikey) { ai.setKey(el.dataset.aikey, el.value); S.aiRes = null; }
  if (el.hasAttribute('data-aiurl')) { ai.st.custom.url = el.value.trim(); ai.save(); }
  if (el.hasAttribute('data-aifmt')) { ai.st.custom.fmt = el.value; ai.save(); }
  if (el.hasAttribute('data-aimodel')) { ai.st.custom.model = el.value.trim(); ai.save(); }
  if (el.id === 'nameIn') saveName();
});
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  if (e.target.id === 'talkIn') { e.preventDefault(); petTalk(); }
  if (e.target.id === 'roomCodeIn') { e.preventDefault(); tgJoinCode(); }
  if (e.target.id === 'nameIn') { e.preventDefault(); e.target.blur(); }
});
function saveName() {
  const el = $('#nameIn'); if (!el) return;
  const v = el.value.replace(/[^\p{L}\p{N} _.-]/gu, '').replace(/\s+/g, ' ').trim().slice(0, 16);
  if (v.length < 2) return;
  S.name = v; store.set('name', v); toast(t('name_ok'));
  if (net.online) net.setName(v);
}

/* ---------- розмова з улюбленцем ---------- */
const PETSOUND = { cat: 'meow', dog: 'bark', fox: 'yip', wolf: 'howl', frog: 'ribbit', dragon: 'roar', dino: 'roar' };
const PETWORD = { cat: ['кіт', 'cat', 'кот'], dog: ['пес', 'dog', 'пёс'], fox: ['лис', 'fox', 'лис'], wolf: ['вовк', 'wolf', 'волк'], frog: ['жабка', 'frog', 'лягушка'], dragon: ['драконя', 'baby dragon', 'дракончик'], dino: ['динозаврик', 'dinosaur', 'динозаврик'], deer: ['оленя', 'fawn', 'оленёнок'] };
function petBubble(text, long) {
  const e = $('#petSay') || document.querySelector('.pet-say'); if (!e) { toast(text); return; }
  e.textContent = text; e.classList.remove('on', 'long'); void e.offsetWidth; e.classList.add('on'); if (long) e.classList.add('long');
}
function offlineTalk() {
  const n = pet.needs || {};
  if ((n.food ?? 100) < 35) return t('talk_hungry');
  if ((n.energy ?? 100) < 25) return t('talk_sleepy');
  const a = t('talk_off'); return Array.isArray(a) ? a[(Math.random() * a.length) | 0] : String(a);
}
async function petTalk(q) {
  const inp = $('#talkIn');
  if (q === 'rand') q = ['talk_q1', 'talk_q2', 'talk_q3'][(Math.random() * 3) | 0];
  const text = (q ? t(q) : (inp && inp.value) || '').trim().slice(0, 200); if (!text) return;
  if (inp) inp.value = '';
  const sp = pet.sp || 'fox';
  petBubble('…'); pet.react && pet.react('happy');
  S.talk = (S.talk || []).slice(-6); S.talk.push({ role: 'user', content: text });
  let ans = '';
  if (aiAny()) {
    const li = { uk: 0, en: 1, ru: 2 }[S.lang] || 0;
    const r = await ai.ask({ task: 'pet', system: petSystem(snapshot(), li), messages: S.talk, max: 140 });
    ans = r.moderated ? t('ai_' + r.moderated) : r.text;
  }
  if (ans) S.talk.push({ role: 'assistant', content: ans }); else ans = offlineTalk();
  petBubble(ans.slice(0, 220), true); petVoice(sp, 'hello', pet.size);
}

/* ---------- знімок прогресу: для бота (/pet, /me), нагадувань і ШІ-улюбленця ----------
   Лише короткі числа зі збережень на пристрої; приставка надсилає його сама, коли є сервер. */
const CARE = { uk: { tractor: 'трактор', combine: 'комбайн', truck: 'вантажівка', broken: 'поломка', fuel: 'пальне', oil: 'мастило', dirt: 'миття' }, en: { tractor: 'tractor', combine: 'combine', truck: 'truck', broken: 'repair', fuel: 'fuel', oil: 'oil', dirt: 'wash' }, ru: { tractor: 'трактор', combine: 'комбайн', truck: 'грузовик', broken: 'поломка', fuel: 'топливо', oil: 'масло', dirt: 'мойка' } };
function snapshot() {
  const r = (v) => Math.round(v ?? 0), n = pet.needs || {}, sp = pet.sp || 'fox', li = { uk: 0, en: 1, ru: 2 }[S.lang] || 0, W = CARE[S.lang] || CARE.uk;
  const out = { lang: S.lang, coins: r(S.coins), pet: { name: breedName(S.breed), kind: (PETWORD[sp] || PETWORD.fox)[li], needs: { food: r(n.food), water: r(n.water), joy: r(n.joy), energy: r(n.energy) }, hat: pet.hatKind || 'none' } };
  const res = store.get('pzResults', []); out.puzzles = { solved: res.length, today: res.filter((x) => new Date(x.at).toDateString() === new Date().toDateString()).length, rating: store.get('pzRating', 0) };
  const f = store.get('cart:boby:state3', null);
  if (f && f.m) { const care = []; for (const id of ['tractor', 'combine', 'truck']) { const m = f.m[id]; if (!m) continue; const w = []; if (m.broken) w.push(W.broken); if (m.fuel !== undefined && m.fuel < 8) w.push(W.fuel); if (m.oil !== undefined && m.oil < 25) w.push(W.oil); if (m.dirt > 0.6) w.push(W.dirt); if (w.length) care.push(`${W[id]} — ${w.join(', ')}`); } out.farm = { stage: f.stage | 0, day: f.day | 0, coins: r(f.coins), fields: (f.fields || []).filter((x) => x.own).length, ripe: (f.fields || []).filter((x) => x.st === 'ripe').length, care, trip: !!f.trip }; }
  const k = store.get('cart:iskra:v2', null); if (k) out.iskra = { day: k.day | 0, coins: r(k.coins), open: Object.values(k.open || {}).filter(Boolean).length, gens: (k.gens || []).length };
  const sp2 = store.get('cart:istorii:pos', null); if (sp2) out.story = { scene: sp2.s | 0, total: store.get('cart:istorii:total', 0) };
  return out;
}
// той самий опис улюбленця, що й на сервері для бота (див. worker.js → petSystem)
function petSystem(p, li) {
  const n = p.pet.needs, s = [`Ти — ${p.pet.name}, ${p.pet.kind}-улюбленець дитини в грі Planetar. Говори від першої особи, як добрий веселий звір: 1–3 короткі речення, можна один звук тварини. Мова: ${['українська', 'English', 'русский'][li]}.`, `Твій стан: ситість ${n.food}%, вода ${n.water}%, радість ${n.joy}%, сили ${n.energy}%.`];
  if (p.farm) s.push(`На Фермі: етап ${p.farm.stage + 1} з 8, день ${p.farm.day}${p.farm.care.length ? ', техніка просить: ' + p.farm.care.join('; ') : ''}${p.farm.trip ? ', вантажівка їде в місто' : ''}.`);
  if (p.iskra) s.push(`В Іскрі (місто з електрикою): день ${p.iskra.day}, відкрито районів ${p.iskra.open}.`);
  if (p.puzzles.solved) s.push(`Головоломок розвʼязано ${p.puzzles.solved}, сьогодні ${p.puzzles.today}.`);
  if (p.story && p.story.total) s.push(`В Історіях — сцена ${p.story.scene + 1} з ${p.story.total}.`);
  s.push('Можеш підбадьорити, пожартувати, дати пораду щодо гри. Не вигадуй того, чого нема в грі.');
  return s.join(' ');
}
let lastSync = '';
function syncProgress() { if (!S.online) return; const d = snapshot(), j = JSON.stringify(d); if (j === lastSync) return; lastSync = j; net.progress(d); }
setInterval(syncProgress, 5 * 60e3);
document.addEventListener('visibilitychange', () => { if (document.hidden) syncProgress(); });

/* ---------- Telegram: підключити приставку з браузера до бота ---------- */
function tgLine() {
  if (window.Telegram && window.Telegram.WebApp && window.Telegram.WebApp.initData) return { txt: t('tgb_inside') };
  if (!S.online) return { txt: t('tgb_noserver') };
  if (!net.caps || !net.caps.bot) return { txt: t('tgb_nobot') };
  if (S.me && S.me.tg) return { txt: t('tgb_linked'), btn: ['tgOpenBot', t('tgb_open')] };
  return { txt: t('tgb_how'), btn: ['tgLinkBot', t('tgb_link')] };
}
async function tgLinkBot() { const j = await net.post('/api/tg/link', {}); if (j.ok && j.url) { try { window.open(j.url, '_blank') || (location.href = j.url); } catch (_) { location.href = j.url; } setTimeout(async () => { const me = await net.getj('/api/me'); if (me.ok) { S.me = me.user; if (S.route === 'settings') render(); } }, 15000); } else toast(t('tgb_fail')); }
function tgOpenBot() { if (net.caps && net.caps.bot) window.open(`https://t.me/${net.caps.bot}`, '_blank'); }

/* ---------- рейтинг ---------- */
async function openRating(scope) {
  if (scope) S.rateScope = scope;
  const tabs = ['day', 'week', 'all'].map((k) => `<button class="chip sm ${S.rateScope === k ? 'on' : ''}" data-act="openRating" data-arg="${k}" data-mod="net" data-x="rating">${esc(t('rate_' + k))}</button>`).join('');
  openSheet(`<b class="disp" style="font-size:20px;display:flex;align-items:center;gap:8px">${gi('trophy', 26)} ${esc(t('rate_title'))}</b><div class="chips">${tabs}</div><div class="rate-list" id="rateList">${net.online ? '<span class="spin"></span>' : esc(t('rate_off'))}</div><span class="muted" style="font-size:13px">${esc(t('rate_mine'))}: ${store.get('pzRating', 0)}</span>`);
  if (!net.online) return;
  const r = await net.rating(S.rateScope); const el = $('#rateList'); if (!el) return;
  el.innerHTML = r.ok && r.rows.length ? r.rows.map((x, i) => `<div class="lead ${S.me && x.id === S.me.id ? 'me' : ''}"><span>${MEDAL(i)} ${esc(x.name)}</span><span class="mono">${x.pts}</span></div>`).join('') : esc(t('rate_empty'));
}

/* ---------- виклик від друга за кодом (?ch=...) ---------- */
async function loadChallenge(code) {
  const r = await net.challengeGet(code); if (!r.ok || !r.challenge) { toast(r.error || '—'); return; }
  const c = r.challenge; if (!['tango', 'queens', 'sudoku'].includes(c.game)) return;
  S.pzType = c.game; S.pzLevel = PZ.LEVELS.includes(c.level) ? c.level : 'medium';
  const seed = Number(c.seed) >>> 0;
  S.pz = mkPz(PZ.generate(c.game, seed, S.pzLevel), 'challenge', seed);
  S.pz.ch = { code, name: c.name || '?', t: c.t, m: c.m, h: c.h };
  go('puzzles');
}
function onSolved(p) {
  if (p.kind === 'race' && RX.conn) RX.conn.send({ t: 'move', data: { done: true, t: p.time, m: p.mistakes, h: p.hints } });
  if (p.kind === 'local' && S.tg.local) { const LC = S.tg.local; LC.res.push({ name: LC.names[LC.turn], t: p.time, m: p.mistakes, h: p.hints, score: p.result.score }); }
  if (p.kind === 'challenge' && p.ch) net.challengeDone(p.ch.code, { t: p.time, m: p.mistakes, h: p.hints });
}

/* ============================================================
   РАЗОМ: кімнати (онлайн і поруч), перегони головоломок, один пристрій
   Кількість гравців задає ведучий у самій кімнаті (2–12), вільні місця — боти.
   ============================================================ */
const RX = { conn: null, lastSend: 0, lastP: -1, botT: null, tickT: null };
const myName = () => S.name || (net.user && net.user.name) || t('tg_player');
const isHost = () => S.tg.seat >= 0 && S.tg.seat === S.tg.host;
const fmtCode = (c) => (c.length > 4 ? c.slice(0, 3) + '-' + c.slice(3) : c);
const SEATC = ['#7FE3FF', '#FFC067', '#FF8FA8', '#A8E6A1', '#C9A2FF', '#FFE08A', '#9FB4FF', '#86E0D0', '#FFB27A', '#D0B48C', '#F5F5F5', '#B4F08C'];
function tgMode(m) { S.tg.mode = m; render(); }
function tgSet(k) {
  const [a, b] = String(k).split(':'); if (!['type', 'level'].includes(a)) return; S.tg[a] = b;
  if (S.tg.phase === 'lobby' && RX.conn && isHost()) RX.conn.send({ t: 'game', game: 'race', data: { type: S.tg.type, level: S.tg.level } });
  render();
}
function tgMax(d) {
  if (S.tg.mode === 'local' && S.tg.phase === 'menu') { S.tg.n = Math.max(2, Math.min(8, S.tg.n + Number(d))); render(); return; }
  S.tg.max = Math.max(Math.max(2, S.tg.players.length), Math.min(12, S.tg.max + Number(d)));
  if (RX.conn && isHost()) RX.conn.send({ t: 'max', n: S.tg.max });
  render();
}
function tgBots() { S.tg.bots = !S.tg.bots; if (RX.conn && isHost()) RX.conn.send({ t: 'bots', on: S.tg.bots }); render(); }
async function tgCreate() {
  if (!net.online) { toast(t('tg_needServer')); return; }
  const r = await net.newRoom('race', S.tg.max, S.tg.bots);
  if (!r.ok) { toast(t('tg_lost')); return; }
  tgJoin(r.code, true);
}
function tgJoinCode() { const c = (($('#roomCodeIn') || {}).value || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); if (c.length >= 4) tgJoin(c); }
function tgJoin(code, created) {
  if (RX.conn) { const old = RX.conn; RX.conn = null; old.close(); }
  stopBots();
  Object.assign(S.tg, { code, phase: 'lobby', seat: -1, host: -1, players: [], race: null });
  RX.created = !!created; RX.sentCfg = false;
  const c = net.joinRoom(code, myName(), (m) => { if (RX.conn === c) onRoomMsg(m); });
  RX.conn = c;
  if (S.route !== 'together') go('together'); else render();
}
function tgLeave() {
  const c = RX.conn; RX.conn = null; if (c) c.close();
  stopBots(); Object.assign(S.tg, { phase: 'menu', code: '', race: null, seat: -1, local: null });
  if (S.pz && (S.pz.kind === 'race' || S.pz.kind === 'local')) S.pz = null;
  go('together');
}
function tgShare() { shareText(`${t('tg_inviteText')} ${fmtCode(S.tg.code)}\n${location.origin}${location.pathname}?room=${S.tg.code}`); }
function tgStart() {
  if (S.tg.mode === 'local' && !RX.conn) return localStart();
  if (!RX.conn || !isHost()) return;
  RX.conn.send({ t: 'start', data: { type: S.tg.type, level: S.tg.level, seed: (Math.random() * 1e9) >>> 0 } });
}
function tgAgain() { if (RX.conn && isHost()) RX.conn.send({ t: 'reset' }); }
function tgEmote(e) { if (RX.conn) RX.conn.send({ t: 'emote', e }); }
function onRoomMsg(m) {
  const tg = S.tg;
  if (m.t === 'you') tg.seat = m.seat;
  else if (m.t === 'lobby') {
    Object.assign(tg, { players: m.players || [], host: m.host, max: m.max, bots: m.bots });
    if (m.data && m.data.type) { tg.type = m.data.type; tg.level = m.data.level; }
    if (RX.created && isHost() && !m.started && !RX.sentCfg) { RX.sentCfg = true; RX.conn.send({ t: 'game', game: 'race', data: { type: tg.type, level: tg.level } }); }
    if (tg.race) raceStrip(); else if (S.route === 'together') render();
  }
  else if (m.t === 'start') raceBegin(m.data, m.late);
  else if (m.t === 'move') raceMove(m.from, m.data);
  else if (m.t === 'reset') { stopBots(); tg.race = null; tg.phase = 'lobby'; if (S.pz && S.pz.kind === 'race') S.pz = null; go('together'); }
  else if (m.t === 'emote') floatEmote(m.e);
  else if (m.t === 'closed') { RX.conn = null; stopBots(); toast(t('tg_lost')); tg.phase = 'menu'; tg.race = null; if (S.route === 'together') render(); }
}
function floatEmote(e) {
  const host = $('#boardCard') || $('#view'); if (!host || !/^[\p{Emoji}‍️]{1,4}$/u.test(e || '')) return;
  const s = document.createElement('span'); s.className = 'emote'; s.textContent = e; s.style.left = (15 + Math.random() * 70) + '%';
  host.appendChild(s); setTimeout(() => s.remove(), 1800);
}
function raceBegin(d, late) {
  if (!d || !['tango', 'queens', 'sudoku'].includes(d.type)) return;
  const tg = S.tg; tg.phase = 'race';
  tg.race = { type: d.type, level: d.level, seed: d.seed >>> 0, start: Date.now(), prog: {}, done: {}, names: {} };
  S.pzType = d.type; S.pzLevel = PZ.LEVELS.includes(d.level) ? d.level : 'easy';
  S.pz = mkPz(PZ.generate(d.type, d.seed >>> 0, S.pzLevel), 'race', d.seed >>> 0);
  RX.lastP = -1; sfx('whoosh');
  go('puzzles');
  if (isHost() && tg.bots && !late) startBots();
}
function raceMove(from, d) {
  const r = S.tg.race; if (!r || !d) return;
  const key = d.bot !== undefined ? 'b' + d.bot : 's' + from;
  if (d.name) r.names[key] = String(d.name).slice(0, 18);
  if (d.done) { if (!r.done[key]) { r.done[key] = { t: d.t | 0, m: d.m | 0, h: d.h | 0, at: Date.now() }; r.prog[key] = 1; if (key !== 's' + S.tg.seat) sfx('coin'); } }
  else r.prog[key] = Math.max(r.prog[key] || 0, Math.min(0.99, Number(d.p) || 0));
  raceStrip();
  if (S.pz && S.pz.solved && S.route === 'puzzles') renderBoard();
}
function progressOf(p) {
  const d = p.data;
  if (d.type === 'queens') { let ok = 0; for (let r = 0; r < d.size; r++) if (p.cells[r * d.size + d.solution[r]] === 2) ok++; return ok / d.size; }
  let tot = 0, ok = 0; for (let i = 0; i < p.cells.length; i++) { if (d.puzzle[i]) continue; tot++; if (p.cells[i] === d.solution[i]) ok++; }
  return tot ? ok / tot : 0;
}
function raceTick() {
  const p = S.pz; if (!p || p.kind !== 'race' || !RX.conn || p.solved) return;
  const v = Math.round(progressOf(p) * 20) / 20;
  clearTimeout(RX.tickT);
  RX.tickT = setTimeout(() => { if (v !== RX.lastP && RX.conn && !p.solved) { RX.lastP = v; RX.lastSend = Date.now(); RX.conn.send({ t: 'move', data: { p: v } }); } }, Math.max(0, 700 - (Date.now() - RX.lastSend)));
}
const BOTN = ['Біп', 'Буп', 'Зум', 'Кліп', 'Тік', 'Пікс', 'Робі', 'Дзинь', 'Гвинтик', 'Шестерня'];
function startBots() {
  stopBots();
  const r = S.tg.race, n = Math.max(0, S.tg.max - S.tg.players.length); if (!n) return;
  const tgt = TTARGET[r.type][Math.max(0, PZ.LEVELS.indexOf(r.level))];
  const bots = Array.from({ length: n }, (_, i) => ({ i, name: BOTN[i % BOTN.length], T: tgt * (0.7 + Math.random() * 1.0), p: 0 }));
  RX.botT = setInterval(() => {
    if (!RX.conn || !S.tg.race) return stopBots();
    const el = (Date.now() - r.start) / 1000;
    for (const b of bots) {
      if (b.done) continue;
      const p = Math.min(1, el / b.T);
      if (p >= 1) { b.done = true; RX.conn.send({ t: 'move', data: { bot: b.i, name: b.name, done: true, t: Math.round(el), m: Math.random() < 0.3 ? 1 : 0, h: 0 } }); }
      else if (p - b.p >= 0.1) { b.p = p; RX.conn.send({ t: 'move', data: { bot: b.i, name: b.name, p: Math.round(p * 20) / 20 } }); }
    }
    if (bots.every((b) => b.done)) stopBots();
  }, 2000);
}
function stopBots() { clearInterval(RX.botT); RX.botT = null; }
function raceEntries() {
  const r = S.tg.race; if (!r) return [];
  const list = S.tg.players.map((p) => ({ key: 's' + p.seat, seat: p.seat, name: p.name, me: p.seat === S.tg.seat }));
  for (const k of Object.keys(r.names)) if (k[0] === 'b') list.push({ key: k, seat: 6 + Number(k.slice(1)), name: r.names[k], bot: true });
  for (const k of Object.keys(r.done)) if (!list.some((e) => e.key === k)) list.push({ key: k, seat: Number(k.slice(1)), name: '—' }); // вийшов, але встиг фінішувати
  return list.map((e) => ({ ...e, p: r.prog[e.key] || 0, done: r.done[e.key] }));
}
const ranked = (es) => es.filter((e) => e.done).sort((a, b) => a.done.t - b.done.t || a.done.at - b.done.at);
function raceTrack() {
  const es = raceEntries(), fin = ranked(es);
  return `<div class="track" id="raceStrip" data-x="room" aria-label="${esc(t('tg_race'))}"><i class="lane"></i>${es.map((e, i) => { const pl = fin.indexOf(e); const x = e.done ? 100 : e.p * 100; return `<span class="runner ${e.me ? 'me' : ''} ${e.bot ? 'bot' : ''}" style="left:calc(${x}% * .86 + 4%);top:${6 + (i % 3) * 30}%;--c:${SEATC[e.seat % SEATC.length]}" title="${esc(e.name)}">${pl >= 0 && pl < 3 ? MEDAL(pl, 22) : e.bot ? gi('bot', 18) : esc([...String(e.name)][0] || '?')}</span>`; }).join('')}<span class="flag">${gi('flag', 22)}</span></div>`;
}
function raceStrip() { const el = $('#raceStrip'); if (el) el.outerHTML = raceTrack(); }
function raceResults() {
  const es = raceEntries(), fin = ranked(es), me = fin.findIndex((e) => e.me);
  const rows = fin.map((e, i) => `<div class="lead ${e.me ? 'me' : ''}"><span>${MEDAL(i)} ${esc(e.name)}</span><span class="mono">${fmt(e.done.t)} · ✖${e.done.m} · ${gi('bulb', 14)}${e.done.h}</span></div>`).join('');
  return `<div class="race-res"><b>${me >= 0 ? `${me + 1} ${esc(t('tg_place'))} / ${es.length}` : ''}</b>${rows}</div>`;
}
/* ---------- один пристрій: по черзі ---------- */
function localStart() {
  const n = S.tg.n, seed = (Math.random() * 1e9) >>> 0;
  S.tg.local = { n, seed, type: S.tg.type, level: S.tg.level, turn: 0, res: [], names: Array.from({ length: n }, (_, i) => `${t('tg_player')} ${i + 1}`) };
  S.tg.phase = 'pass'; render();
}
function localGo() {
  const LC = S.tg.local; if (!LC) return;
  S.pzType = LC.type; S.pzLevel = LC.level;
  S.pz = mkPz(PZ.generate(LC.type, LC.seed, LC.level), 'local', LC.seed);
  S.tg.phase = 'local'; go('puzzles');
}
function localNext() { const LC = S.tg.local; if (!LC) return; LC.turn++; S.tg.phase = LC.turn >= LC.n ? 'localDone' : 'pass'; if (S.tg.phase === 'localDone') sfx('win'); go('together'); }
let qrcode = null; import('../lib/qrcode.mjs').then((m) => { qrcode = m.qrcode; }).catch(() => { });
function qrSvg(text) { if (!qrcode) return ''; try { const q = qrcode(0, 'M'); q.addData(text); q.make(); return q.createSvgTag({ cellSize: 4, margin: 2, scalable: true }); } catch (_) { return ''; } }

function gamePick(editable) {
  const a = (k, v) => editable ? `data-act="tgSet" data-arg="${k}:${v}" data-mod="net" data-x="room"` : 'disabled';
  const types = ['tango', 'queens', 'sudoku'].map((tp) => `<button class="chip sm ${S.tg.type === tp ? 'on' : ''}" ${a('type', tp)}>${esc(t('pz_' + tp))}</button>`).join('');
  const lv = PZ.LEVELS.map((l) => `<button class="chip sm ${S.tg.level === l ? 'on' : ''}" ${a('level', l)}>${esc(t('lv_' + l))}</button>`).join('');
  const soon = ['g_sea', 'g_quiz', 'g_mafia'].map((k) => `<span class="chip sm soon">${esc(t(k))} · ${esc(t('tg_soon'))}</span>`).join('');
  return `<div class="tg-game"><b>${gi('energy', 18)} ${esc(t('tg_race'))}</b><span class="muted">${esc(t('tg_raceSub'))}</span><div class="chips">${types}</div><div class="chips">${lv}</div></div>`; void soon;
}
function stepper(n, label) { return `<div class="stepper"><span>${esc(label)}</span><button class="btn ghost" data-act="tgMax" data-arg="-1" data-mod="net" data-x="room">−</button><b>${n}</b><button class="btn ghost" data-act="tgMax" data-arg="1" data-mod="net" data-x="room">+</button></div>`; }
function botsRow() { return `<div class="toggle-row"><span>${esc(t('bots'))}</span><button data-act="tgBots" data-mod="net" data-x="room" aria-pressed="${S.tg.bots}" aria-label="${esc(t('bots'))}"><span class="sw ${S.tg.bots ? 'on' : ''}"><i></i></span></button></div>`; }
function nameRow() { return `<label class="name-row"><span>${esc(t('name_lbl'))}</span><input id="nameIn" class="inp" maxlength="16" autocomplete="nickname" value="${esc(S.name)}" placeholder="${esc(t('name_ph'))}"></label>`; }
function vTogether() {
  const tg = S.tg;
  const modes = ['online', 'near', 'local'].map((m) => `<button class="${tg.mode === m ? 'on' : ''}" data-act="tgMode" data-arg="${m}" data-mod="net" data-x="room">${gi({ online: 'globe', near: 'near', local: 'device' }[m], 20)}${esc(t('tg_' + m))}</button>`).join('');
  let body;
  if (tg.phase === 'pass' && tg.local) {
    const LC = tg.local;
    body = `<button class="pass-card" data-glass data-act="localGo" data-mod="net" data-x="room"><span class="big">${esc(t('tg_turn').replace('{n}', LC.names[LC.turn]))}</span><span>${esc(t('tg_pass'))}</span><span class="muted">${esc(t('pz_' + LC.type))} · ${esc(t('lv_' + LC.level))} · ${LC.turn + 1}/${LC.n}</span></button>
      <div class="pz-bar"><button class="chip" data-act="tgLeave" data-mod="net" data-x="room">${esc(t('tg_leave'))}</button></div>`;
  } else if (tg.phase === 'localDone' && tg.local) {
    const res = tg.local.res.slice().sort((a, b) => b.score - a.score);
    body = `<div class="card" data-glass style="max-width:560px;display:flex;flex-direction:column;gap:10px"><b class="disp" style="font-size:22px;display:flex;align-items:center;gap:8px">${gi('trophy', 30)} ${esc(t('tg_winner').replace('{n}', res[0] ? res[0].name : '—'))}</b>${res.map((r, i) => `<div class="lead"><span>${MEDAL(i)} ${esc(r.name)}</span><span class="mono">${r.score} · ${fmt(r.t)} · ✖${r.m} · ${gi('bulb', 14)}${r.h}</span></div>`).join('')}
      <div class="pz-bar"><button class="chip on" data-act="localStart" data-mod="net" data-x="room">${gi('again', 18)} ${esc(t('tg_again'))}</button><button class="chip" data-act="tgLeave" data-mod="net" data-x="room">${esc(t('tg_leave'))}</button></div></div>`;
  } else if (tg.phase === 'lobby') {
    const host = isHost(), url = `${location.origin}${location.pathname}?room=${tg.code}`;
    const free = Math.max(0, tg.max - tg.players.length);
    const seats = tg.players.map((p) => `<span class="pl ${p.seat === tg.seat ? 'me' : ''}" style="--c:${SEATC[p.seat % SEATC.length]}">${p.seat === tg.host ? gi('crown', 16) + ' ' : ''}${esc(p.name)}${p.seat === tg.seat ? ' · ' + esc(t('tg_you')) : ''}</span>`).join('') + Array.from({ length: free }, () => `<span class="pl empty">${tg.bots ? gi('bot', 18) : '·'}</span>`).join('');
    const canStart = tg.players.length >= 2 || (tg.bots && free > 0);
    body = `<div class="lobby" data-glass>
      <div class="lobby-code">${tg.mode === 'near' || isDesk() ? `<div class="qr">${qrSvg(url)}</div>` : ''}<div><span class="muted" style="font-size:12px">${esc(t('roomCode'))}</span><span class="code">${esc(fmtCode(tg.code))}</span>${tg.mode === 'near' ? `<span class="muted" style="font-size:12px">${esc(t('tg_scan'))}</span>` : ''}<button class="chip" data-act="tgShare" data-mod="net" data-x="room">${gi('share', 18)} ${esc(t('tg_share'))}</button></div></div>
      <div class="seats">${seats}</div>
      ${gamePick(host)}
      ${host ? stepper(tg.max, t('players')) + botsRow() + `<button class="btn prim" ${canStart ? '' : 'disabled'} data-act="tgStart" data-mod="net" data-x="room">${gi('play', 20)} ${esc(t('start'))}</button>` : `<p class="muted" style="margin:0;text-align:center">${esc(t('tg_wait'))}</p>`}
      <button class="chip" style="align-self:center" data-act="tgLeave" data-mod="net" data-x="room">${esc(t('tg_leave'))}</button></div>`;
  } else if (tg.mode === 'local') {
    body = `<div class="lobby" data-glass>${gamePick(true)}<span class="muted" style="font-size:13px">${esc(t('tg_localSub'))}</span>${stepper(tg.n, t('players'))}<button class="btn prim" data-act="localStart" data-mod="net" data-x="room">${gi('play', 20)} ${esc(t('start'))}</button></div>`;
  } else if (!net.online) {
    body = `<div class="card" data-glass="dark" style="max-width:560px;display:flex;flex-direction:column;gap:12px;font-size:14.5px;line-height:1.5"><span style="display:flex;gap:10px;align-items:flex-start">${gi('globe', 28)}<span>${esc(t('tg_needServer'))}</span></span><button class="btn prim" data-act="tgMode" data-arg="local" data-mod="net" data-x="room">${esc(t('tg_local'))}</button></div>`;
  } else {
    body = `<div class="lobby" data-glass>${nameRow()}${gamePick(true)}${stepper(tg.max, t('players'))}${botsRow()}<button class="btn prim" data-act="tgCreate" data-mod="net" data-x="room">${esc(t('tg_create'))}</button>
      <div class="join-row"><input id="roomCodeIn" class="inp" maxlength="8" autocapitalize="characters" autocomplete="off" placeholder="${esc(t('tg_codePh'))}"><button class="btn ghost" data-act="tgJoinCode" data-mod="net" data-x="room">${esc(t('tg_join'))}</button></div></div>`;
  }
  return head(t('togetherTitle'), '') + (tg.phase === 'menu' ? `<div class="seg" data-glass style="margin:8px 0 12px">${modes}</div>` : '') + body;
}

const ACT = { petWho, go, goLive, toggleCorpus, toggleSound, pzRules, shareResult, openGame, closeGame, setHat, hint, petTab, setToy, petCmd, petReward, petAct, pickBreed, togglePetAll, setPuzzleType, setLevel, newPuzzle, cellTap, numTap, setLang, setQuality, closeSheet };
Object.assign(ACT, { tgLinkBot, tgOpenBot, togglePencil, pickLevel, setLevelClose, aiToggle, aiUp, aiTest, saveName, petTalk, openRating, tgMode, tgSet, tgMax, tgBots, tgCreate, tgJoinCode, tgLeave, tgShare, tgStart, tgAgain, tgEmote, localStart, localGo, localNext });

/* ---------- дрібниці інтерфейсу ---------- */
function say(key) { S.speech = key; document.querySelectorAll('[data-speech]').forEach(e => e.textContent = t(key)); }
function hearts() {
  const slot = pet.canvas.parentNode; if (!slot) return;
  for (let i = 0; i < 5; i++) {
    const h = document.createElement('span');
    h.className = 'heart';
    h.style.left = (35 + Math.random() * 30) + '%';
    h.style.animationDelay = (i * 0.12) + 's';
    h.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M12 21s-7.5-4.6-9.6-9.3C.9 8.1 3 4.5 6.6 4.5c2.2 0 3.7 1.3 5.4 3.3 1.7-2 3.2-3.3 5.4-3.3 3.6 0 5.7 3.6 4.2 7.2C19.5 16.4 12 21 12 21z" fill="#FF8FA8"/></svg>';
    slot.appendChild(h); setTimeout(() => h.remove(), 1800);
  }
}
function toast(text) {
  const r = $('#toastRoot');
  r.innerHTML = `<div class="toast solid">${esc(text)}</div>`;
  clearTimeout(toast.t); toast.t = setTimeout(() => r.innerHTML = '', 2200);
}
function openSheet(html) {
  $('#sheetRoot').innerHTML = `<div class="sheet-back" data-act="closeSheet"></div><div class="sheet solid">${html}</div>`;
}
function modLabels() { const o = {}; ['core', 'ai', 'sand1', 'sand2', 'sand3', 'mem', 'net', 'pet'].forEach(m => o[m] = t('mod_' + m)); return o; }
function syncChrome() {
  $('#brandSub').textContent = t('brandSub');
  $('#corpusLbl').textContent = t('corpus');
  $('#corpusSw').classList.toggle('on', S.corpus);
  $('#corpusBtn').setAttribute('aria-pressed', String(S.corpus));
  $('#coinsN').textContent = S.coins;
  { const sb = $('#soundBtn'); if (sb) { document.querySelectorAll('.sico').forEach(e => e.innerHTML = gi(window.__planetarMute ? 'mute' : 'sound', 22)); sb.setAttribute('aria-pressed', String(!window.__planetarMute)); sb.setAttribute('aria-label', t('sound')); } }
  $('#gearBtn').setAttribute('aria-label', t('nav_settings'));
  $('#playerBackT').textContent = t('back');
  const nb = (r, extra) => `<button class="nb ${S.route === r ? 'on' : ''}${extra || ''}" data-act="go" data-arg="${r}" data-mod="${MODOF[r]}" data-x="nav" ${S.route === r ? 'data-glass="on"' : ''} aria-current="${S.route === r ? 'page' : 'false'}">${IC[r]}<span>${esc(t('nav_' + r))}</span></button>`;
  $('#sidebar').innerHTML = NAV.map(r => nb(r)).join('');
  $('#dock').innerHTML = DOCK.map(r => nb(r)).join('');
  $('#compName').textContent = breedName(S.breed);
  $('#compSpeech').textContent = t(S.speech); $('#compSpeech').setAttribute('data-speech', '');
  $('#compActs').innerHTML = `<span class="tagline">${esc(t('petHint'))}</span>`;
}

const isDesk = () => window.matchMedia('(min-width:1200px)').matches;
function placePet() {
  const mini = $('#miniPet');
  let slot = null;
  if (S.game_open) { $('#playerPet').classList.toggle('off', !S.petAll); slot = S.petAll ? $('#playerSlot') : null; }
  else if (S.route === 'pet') slot = $('#petStageSlot');
  else if (isDesk()) slot = $('#companionSlot');
  else if (S.route === 'home') slot = $('#heroSlot');
  else if (S.petAll) slot = $('#perchSlot');
  mini.classList.add('hidden');
  if (slot) pet.mount(slot, (slot.id === 'petStageSlot' || slot.id === 'heroSlot' || slot.id === 'companionSlot') ? 'full' : 'mini');
  else if (pet.canvas.parentNode) pet.canvas.parentNode.removeChild(pet.canvas);
}

/* ============================================================
   ЕКРАНИ
   ============================================================ */
function vHome() {
  const pz = ['tango', 'queens', 'sudoku'].map((tp) => `<button class="tile" data-glass data-act="setPuzzleType" data-arg="${tp}" data-mod="core" data-x="pzLevel"><span class="ti">${tp === 'sudoku' ? '<b class="disp">9</b>' : tp === 'tango' ? IC.sun : '<span class="qb">' + IC.queen + '</span>'}</span><b>${esc(t('pz_' + tp))}</b></button>`).join('');
  const gm = Object.entries(GAMES).filter(([id]) => READY.has(id)).map(([id, g]) => `<button class="tile gt" data-glass data-act="openGame" data-arg="${id}" data-mod="sand2" data-x="game"><img src="assets/covers/${g.cover}.jpg" alt="" loading="lazy"><b>${esc(L(g.name))}</b></button>`).join('');
  return `<div class="home">
    <section class="hero dup" data-glass data-act="go" data-arg="pet" data-mod="pet" data-x="nav">
      <div class="pet-slot" id="heroSlot"></div>
      <div class="hero-body"><span class="pet-name">${esc(breedName(S.breed))}</span><span class="speech" data-speech>${esc(t(S.speech))}</span></div>
    </section>
    <div class="row-t">${esc(t('today'))}</div><div class="tiles t3">${pz}</div>
    <div class="row-t">${esc(t('gamesTitle'))}</div><div class="tiles t4">${gm}</div>
  </div>`;
}
function head(title, sub) {
  return `<div class="vhead"><div style="min-width:0"><h1>${esc(title)}</h1>${sub ? `<p class="sub">${esc(sub)}</p>` : ''}</div><div class="perch"><div class="pet-slot" id="perchSlot"></div></div></div>`;
}
const READY = new Set(['boby', 'iskra', 'bit', 'istorii']);
function cartList(wrap) {
  return `<div class="carts ${wrap ? 'wrap' : ''}">` + Object.entries(GAMES).filter(([id]) => READY.has(id)).map(([id, g], i) => `
    <article class="cart" data-glass>
      <div class="cover"><img src="assets/covers/${g.cover}.jpg" alt="${esc(L(g.name))}" loading="lazy"><span class="badge">3D</span></div>
      <div class="meta"><b>${esc(L(g.name))}</b><span>${esc(L(g.genre))}</span><p class="pitch">${esc(L(g.pitch))}</p></div>
      <div class="acts"><button class="btn prim" data-act="openGame" data-arg="${id}" data-mod="sand${1 + i % 3}" data-x="game">${esc(t('play'))}</button></div>
    </article>`).join('') + '</div>';
}
function vGames() {
  const list = Object.entries(GAMES).filter(([id]) => READY.has(id));
  return `<div class="games-fit">` + list.map(([id, g], k) => `
    <button class="gcard" data-glass data-act="openGame" data-arg="${id}" data-mod="sand${1 + k % 3}" data-x="game" aria-label="${esc(t('play'))}: ${esc(L(g.name))}">
      <span class="gimg"><img src="assets/covers/${g.cover}.jpg" alt="" style="animation-delay:${-k * 3}s"></span>
      <span class="gplay">▶</span>
      <span class="gmeta"><b>${esc(L(g.name))}</b><span>${esc(L(g.genre))}</span></span>
    </button>`).join('') + `</div>`;
}
function vPuzzles() {
  if (!S.pz || S.pz.data.type !== S.pzType) { const d = new Date().toISOString().slice(0, 10); const seed = PZ.hashSeed(d + S.pzType + S.pzLevel); S.pz = mkPz(PZ.generate(S.pzType, seed, S.pzLevel), 'daily', seed); }
  const tabs = ['tango', 'queens', 'sudoku'].map(tp => `<button class="${S.pzType === tp ? 'on' : ''}" data-act="setPuzzleType" data-arg="${tp}" data-mod="core" data-x="pzLevel">${esc(t('pz_' + tp))}</button>`).join('');
  const R = store.get('pzRating', 0), p = S.pz, kind = p.kind;
  const rate = `<button class="rating" data-act="openRating" data-mod="net" data-x="rating" aria-label="${esc(t('rating'))}">🏆 ${R}</button>`;
  const perch = `<div class="perch"><div class="pet-slot" id="perchSlot"></div></div>`;
  if (kind === 'race' || kind === 'local') {
    const LC = S.tg.local;
    const title = kind === 'race' ? `${gi('energy', 18)} ${esc(t('tg_race'))} · ${esc(fmtCode(S.tg.code))}` : `${gi('together', 18)} ${esc(t('tg_turn').replace('{n}', LC ? LC.names[LC.turn] : ''))}`;
    const emotes = kind === 'race' ? ['👍', '😮', '😂', '🔥'].map((e) => `<button class="chip sm" data-act="tgEmote" data-arg="${e}" data-mod="net" data-x="room">${e}</button>`).join('') : '';
    return `<div class="pz-fit">
      <div class="pz-top"><div class="pz-tabs" data-glass><span class="chip on">${title}</span></div>${perch}</div>
      ${kind === 'race' ? raceTrack() : `<div class="pz-levels"><span class="chip sm on">${esc(t('pz_' + S.pzType))} · ${esc(t('lv_' + S.pzLevel))}</span>${LC ? LC.res.map((r) => `<span class="chip sm">${esc(r.name)} · ${fmt(r.t)}</span>`).join('') : ''}</div>`}
      <div class="board-card" data-glass id="boardCard"></div>
      <div class="pz-bar">${emotes}<button class="chip" data-act="tgLeave" data-mod="net" data-x="room">${esc(t('tg_leave'))}</button></div>
    </div>`;
  }
  const chBanner = kind === 'challenge' && p.ch ? `<div class="ch-banner">${gi('energy', 16)} ${esc(t('ch_from').replace('{n}', p.ch.name))}: ${fmt(p.ch.t)} · ✖${p.ch.m} · ${gi('bulb', 14)}${p.ch.h}</div>` : '';
  return `<div class="pz-fit">
    <div class="pz-top"><div class="seg pz-seg" data-glass>${tabs}</div>${perch}</div>
    ${chBanner}
    <div class="board-card" data-glass id="boardCard"></div>
    <div class="pz-bar">
      <button class="ib" data-act="newPuzzle" data-arg="daily" data-mod="core" data-x="pzLevel">${gi('cal')}${esc(t('daily'))}</button>
      <button class="ib" data-act="newPuzzle" data-arg="fresh" data-mod="core" data-x="pzLevel">${gi('dice')}${esc(t('fresh'))}</button>
      <button class="ib ${S.showErrors ? 'on' : ''}" data-act="toggleErrors" data-mod="core" data-x="pzLevel" aria-pressed="${S.showErrors}" aria-label="${esc(t('showErrors'))}">${gi('eye')}${esc(t('errorsShort'))}</button>
      ${rate.replace('class="rating"', 'class="ib"').replace('🏆 ' + R, gi('trophy') + R)}
      <button class="ib" data-act="pzRules" data-mod="core" data-x="pzLevel" aria-label="${esc(t('rules'))}">${gi('help')}${esc(t('rules'))}</button>
    </div>
  </div>`;
}
function pickLevel() {
  openSheet(`<b class="disp" style="font-size:19px">${esc(t('pz_' + S.pzType))}</b><div class="lv-pick">${PZ.LEVELS.map((lv, k) => `<button class="${S.pzLevel === lv ? 'on' : ''}" data-act="setLevelClose" data-arg="${lv}" data-mod="core" data-x="pzLevel"><b>${'●'.repeat(k + 1)}${'○'.repeat(3 - k)}</b>${esc(t('lv_' + lv))}${S.pzType === 'sudoku' ? `<small>${PZ.SUDOKU_SIZE[lv]}×${PZ.SUDOKU_SIZE[lv]}</small>` : ''}</button>`).join('')}</div>`);
}
function setLevelClose(lv) { closeSheet(); setLevel(lv); }
function mkPz(data, kind, seed) { return { data, kind, seed, sel: -1, start: Date.now(), solved: false, mistakes: 0, hints: 0, hl: null, cells: data.type === 'queens' ? new Array(data.size * data.size).fill(0) : data.puzzle.slice() }; }
function pzRules() { toast(t('rules_' + S.pzType)); }
async function shareResult() {
  const p = S.pz; if (!p || !p.result) return;
  const day = new Date().toISOString().slice(0, 10);
  const txt = `${t('challengeText')} ${t('pz_' + p.data.type)} · ${t('lv_' + S.pzLevel)}: ${fmt(p.time)}, ✖${p.mistakes}, 💡${p.hints}`;
  const base = location.origin + location.pathname;
  let url = `${base}?go=puzzles&c=${p.data.type}.${S.pzLevel}.${p.kind === 'daily' ? day : 'x'}`;
  if (net.online && p.seed != null) { const r = await net.challenge(p.data.type, S.pzLevel, String(p.seed), p.time, p.mistakes, p.hints); if (r.ok) url = `${base}?ch=${r.code}`; }
  shareText(`${txt}\n${url}`, t('ch_made'));
}
function shareText(full, okMsg) {
  try { if (navigator.share) { navigator.share({ text: full }).catch(() => { }); return; } } catch (_) { }
  try { navigator.clipboard.writeText(full).then(() => toast(okMsg || t('copied')), () => toast(full)); } catch (_) { toast(full); }
}
function errCount(p) { const d = p.data; return d.type === 'sudoku' ? PZ.sudokuConflicts(p.cells, d.size).size : d.type === 'tango' ? PZ.tangoErrors(p.cells, d.cons).size : PZ.queensErrors(d.size, d.regions, p.cells).bad.size; }
ACT.toggleErrors = function toggleErrors() { S.showErrors = !S.showErrors; render(); };
const QCOL = ['rgba(201,162,255,.5)', 'rgba(255,178,122,.5)', 'rgba(143,214,255,.5)', 'rgba(168,230,161,.5)', 'rgba(255,159,180,.5)', 'rgba(255,224,138,.5)', 'rgba(159,180,255,.5)', 'rgba(134,224,208,.5)', 'rgba(208,180,140,.5)'];
function renderBoard() {
  const host = $('#boardCard'); if (!host) return;
  const p = S.pz, d = p.data, n = d.size;
  let cells = '', extra = '';
  if (d.type === 'sudoku') {
    const bad = S.showErrors ? PZ.sudokuConflicts(p.cells, n) : new Set();
    const sr = p.sel >= 0 ? (p.sel / n) | 0 : -1, sc = p.sel >= 0 ? p.sel % n : -1;
    const sbox = p.sel >= 0 ? ((sr / d.br) | 0) * 10 + ((sc / d.bc) | 0) : -1;
    const focus = p.sel >= 0 && p.cells[p.sel] ? p.cells[p.sel] : p.focus || 0;
    const notes = p.notes || [];
    for (let i = 0; i < n * n; i++) {
      const r = (i / n) | 0, c = i % n, v = p.cells[i], given = !!d.puzzle[i];
      const peer = p.sel >= 0 && (r === sr || c === sc || ((r / d.br) | 0) * 10 + ((c / d.bc) | 0) === sbox);
      const same = focus && v === focus && i !== p.sel;
      let inner = v || '';
      if (!v && notes[i]) { inner = `<span class="notes" style="--nc:${d.bc}">${[...Array(n)].map((_, k) => `<i class="${focus === k + 1 ? 'f' : ''}">${notes[i] & (1 << (k + 1)) ? k + 1 : ''}</i>`).join('')}</span>`; }
      cells += `<button class="cell ${given ? 'given' : v ? 'user' : ''} ${(c + 1) % d.bc === 0 && c < n - 1 ? 'br' : ''} ${(r + 1) % d.br === 0 && r < n - 1 ? 'bb' : ''} ${p.sel === i ? 'sel' : peer ? 'peer' : ''} ${same ? 'same' : ''} ${bad.has(i) ? 'bad' : ''} ${p.last === i ? 'pop' : ''} ${hlc(p, i)}" data-act="cellTap" data-arg="${i}" data-mod="core" data-x="pzCell" aria-label="${r + 1}:${c + 1}">${inner}</button>`;
    }
    const left = (v) => n - p.cells.filter(x => x === v).length;
    extra = `<div class="numpad n${n} ${S.pencil ? 'pencil' : ''}" style="--nn:${n}">${[...Array(n)].map((_, k) => k + 1).map(v => `<button data-act="numTap" data-arg="${v}" data-mod="core" data-x="pzCell" class="${left(v) <= 0 ? 'done' : ''} ${focus === v ? 'cur' : ''}">${v}<small>${Math.max(0, left(v)) || '✓'}</small></button>`).join('')}</div>`;
  } else if (d.type === 'tango') {
    const bad = S.showErrors ? PZ.tangoErrors(p.cells, d.cons) : new Set();
    for (let i = 0; i < n * n; i++) {
      const v = p.cells[i], given = !!d.puzzle[i];
      cells += `<button class="cell ${given ? 'given' : ''} ${bad.has(i) ? 'bad' : ''} ${hlc(p, i)}" data-act="cellTap" data-arg="${i}" data-mod="core" data-x="pzCell" aria-label="${((i / n) | 0) + 1}:${i % n + 1}">${v === 1 ? IC.sun : v === 2 ? IC.moon : ''}</button>`;
    }
    for (const q of d.cons) {
      const ra = (q.a / n) | 0, ca = q.a % n, rb = (q.b / n) | 0, cb = q.b % n;
      const x = ((ca + cb) / 2 + 0.5) / n * 100, y = ((ra + rb) / 2 + 0.5) / n * 100;
      cells += `<span class="con" style="left:${x}%;top:${y}%">${q.t === '=' ? '=' : '×'}</span>`;
    }
  } else if (d.type === 'queens') {
    const qe = PZ.queensErrors(n, d.regions, p.cells), bad = S.showErrors ? qe.bad : new Set();
    const auto = new Set();
    p.cells.forEach((v, k) => { if (v !== 2) return; const qr = (k / n) | 0, qc = k % n; for (let j = 0; j < n * n; j++) { if (j === k) continue; const jr = (j / n) | 0, jc = j % n; if (jr === qr || jc === qc || d.regions[j] === d.regions[k] || (Math.abs(jr - qr) <= 1 && Math.abs(jc - qc) <= 1)) auto.add(j); } });
    for (let i = 0; i < n * n; i++) {
      const r = (i / n) | 0, c = i % n, g = d.regions[i], v = p.cells[i];
      const sh = [];
      if (c === 0 || d.regions[i - 1] !== g) sh.push('inset 2px 0 0 rgba(6,8,11,.75)');
      if (r === 0 || d.regions[i - n] !== g) sh.push('inset 0 2px 0 rgba(6,8,11,.75)');
      if (c === n - 1 || d.regions[i + 1] !== g) sh.push('inset -2px 0 0 rgba(6,8,11,.75)');
      if (r === n - 1 || d.regions[i + n] !== g) sh.push('inset 0 -2px 0 rgba(6,8,11,.75)');
      sh.push('inset -1px -1px 0 rgba(6,8,11,.28)');
      if (bad.has(i)) sh.push('inset 0 0 0 3px rgba(255,142,122,.95)');
      cells += `<button class="cell q ${hlc(p, i)}" style="border-radius:0;background:${QCOL[g % QCOL.length]};box-shadow:${sh.join(',') || 'none'}" data-act="cellTap" data-arg="${i}" data-mod="core" data-x="pzCell" aria-label="${r + 1}:${c + 1}">${v === 1 ? '<span class="qx">×</span>' : v === 2 ? IC.queen : auto.has(i) ? '<span class="qx auto">×</span>' : ''}</button>`;
    }
  }
  const time = p.solved ? p.time : Math.round((Date.now() - p.start) / 1000);
  host.innerHTML = `
    <div class="pz-head">${['race', 'local', 'challenge'].includes(p.kind) ? `<span class="lvchip static">${esc(t('lv_' + S.pzLevel))}</span>` : `<button class="lvchip" data-act="pickLevel" data-mod="core" data-x="pzLevel">${esc(t('lv_' + S.pzLevel))}${d.type === 'sudoku' ? ' · ' + n + '×' + n : ''} ▾</button>`}<span class="mist" title="${esc(t('mistakes'))}">✖ ${p.mistakes}</span><span class="timer" id="pzTimer">${fmt(time)}</span>${d.type === 'sudoku' ? `<button class="pen-btn ${S.pencil ? 'on' : ''}" data-act="togglePencil" data-mod="core" data-x="pzCell" aria-pressed="${!!S.pencil}" aria-label="${esc(t('pencil'))}">${gi('pencil', 22)}<small>${esc(t('pencil'))}</small></button><button class="er-btn" data-act="numTap" data-arg="0" data-mod="core" data-x="pzCell" aria-label="${esc(t('erase'))}">${gi('erase', 22)}</button>` : ''}<button class="hint-btn" data-act="hint" data-mod="ai" data-x="pzCell" aria-label="${esc(t('hint'))}">${gi('bulb', 24)}${p.hints ? '<small>' + p.hints + '</small>' : ''}</button></div>
    <div class="board ${d.type}" style="--n:${n};${d.type === 'queens' ? 'gap:0;border-radius:16px;overflow:hidden' : ''}">${cells}</div>
    ${extra}
    ${p.solved && p.result && p.kind === 'race' ? `<div class="won"><b>${esc(t('solvedIn'))} ${fmt(p.time)}</b>${raceResults()}<span style="display:flex;gap:6px;margin-top:4px">${isHost() ? `<button class="chip" data-act="tgAgain" data-mod="net" data-x="room">${gi('again', 18)} ${esc(t('tg_again'))}</button>` : ''}<button class="chip" data-act="tgLeave" data-mod="net" data-x="room">${esc(t('tg_leave'))}</button></span></div>` : ''}
    ${p.solved && p.result && p.kind === 'local' ? `<div class="won"><b>${esc(S.tg.local.names[S.tg.local.turn])}: ${fmt(p.time)} · ✖${p.mistakes} · ${gi('bulb', 14)}${p.hints} · ${p.result.score}</b><span style="display:flex;gap:6px;margin-top:4px"><button class="chip on" data-act="localNext" data-mod="net" data-x="room">${S.tg.local.turn + 1 < S.tg.local.n ? gi('play', 18) + ' ' + esc(t('tg_next').replace('{n}', S.tg.local.names[S.tg.local.turn + 1])) : gi('trophy', 18) + ' ' + esc(t('tg_results'))}</button></span></div>` : ''}
    ${p.solved && p.result && p.kind === 'challenge' && p.ch ? `<div class="won"><b>${p.time <= p.ch.t ? gi('party', 20) + ' ' + esc(t('ch_win')) : esc(t('ch_lose').replace('{n}', p.ch.name).replace('{d}', fmt(p.time - p.ch.t)))}</b><span>${fmt(p.time)} · ✖${p.mistakes} · ${gi('bulb', 14)}${p.hints} · ${gi('trophy', 14)} +${p.result.score}</span><span style="display:flex;gap:6px;margin-top:4px"><button class="chip" data-act="shareResult" data-mod="net" data-x="room">${gi('share', 18)} ${esc(t('challenge'))}</button><button class="chip" data-act="newPuzzle" data-arg="daily" data-mod="core" data-x="pzLevel">${gi('cal', 18)} ${esc(t('daily'))}</button></span></div>` : ''}
    ${p.solved && p.result && !['race', 'local', 'challenge'].includes(p.kind) ? `<div class="won"><b>${esc(t('solvedIn'))} ${fmt(p.time)}</b><span>✖ ${p.mistakes} · ${gi('bulb', 14)} ${p.hints} · ${gi('trophy', 14)} +${p.result.score}${p.result.best ? ' · ' + esc(t('newBest')) : p.result.prevBest ? ' · ' + esc(t('best')) + ' ' + fmt(p.result.prevBest.t) : ''}</span><span style="display:flex;gap:6px;margin-top:4px"><button class="chip" data-act="newPuzzle" data-arg="fresh" data-mod="core" data-x="pzLevel">${gi('dice', 18)} ${esc(t('fresh'))}</button><button class="chip" data-act="shareResult" data-mod="net" data-x="room">${gi('share', 18)} ${esc(t('challenge'))}</button></span></div>` : ''}`;
  fitBoard();
  p.last = -1;
}
function fitBoard() {
  const card = $('#boardCard'), b = card && card.querySelector('.board'); if (!b) return;
  const fit = card.parentElement, cs = getComputedStyle(card), gap = parseFloat(cs.rowGap) || 8, fgap = parseFloat(getComputedStyle(fit).rowGap) || 8;
  // місце = уся колонка мінус інші блоки екрана; картка обіймає поле, без порожнечі
  let outside = 0; for (const ch of fit.children) if (ch !== card) outside += ch.offsetHeight + fgap;
  let inner = 0, n = 0; for (const ch of card.children) { if (ch === b || getComputedStyle(ch).position === 'absolute') continue; inner += ch.offsetHeight; n++; }
  const availH = fit.clientHeight - outside - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom) - inner - n * gap - 2;
  const availW = card.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
  const w = Math.floor(Math.max(180, Math.min(availW, availH, 640)));
  b.style.width = b.style.height = w + 'px'; b.style.setProperty('--cs', (w / (S.pz ? S.pz.data.size : 9)) + 'px');
  card.querySelectorAll('.numpad,.pz-head').forEach((e) => e.style.width = Math.max(w, Math.min(availW, 420)) + 'px');
}
window.addEventListener('resize', () => { if (S.route === 'puzzles') fitBoard(); });
function hlc(p, i) { if (p.hint === i) return 'hint'; const h = p.hl; if (!h) return ''; if (h.level >= 2 && h.i === i) return 'hcell'; return h.area && h.area.includes(i) ? 'harea' : ''; }
const fmt = (s) => String(Math.floor(s / 60)).padStart(1, '0') + ':' + String(s % 60).padStart(2, '0');
setInterval(() => { const e = $('#pzTimer'); if (e && S.pz && !S.pz.solved) e.textContent = fmt(Math.round((Date.now() - S.pz.start) / 1000)); }, 1000);

function vPet() {
  const tab = S.petTab || 'who';
  pet.gestures = tab === 'cmd';
  // одна смуга керування: значок + підпис; сцена лишається відкритою
  const B = (act, arg, icon, label, on, mod = 'pet') => `<button class="pbtn ${on ? 'on' : ''}" data-act="${act}" ${arg != null ? `data-arg="${arg}"` : ''} data-mod="${mod}" data-x="petAct" aria-label="${esc(label)}">${gi(icon, 26)}<span>${esc(label)}</span></button>`;
  let row = '';
  if (tab === 'who') row = `<button class="pwho" data-act="petWho" data-mod="pet" data-x="breed"><img src="assets/pets/${esc(S.breed)}.webp" alt="" onerror="this.style.visibility='hidden'"><span><b>${esc(breedName(S.breed))}</b><em>${esc(t('pet_change'))}</em></span>${gi('play', 20)}</button>`;
  else if (tab === 'play') row = toysFor(pet.sp).map(k => B('setToy', k, k, t('toy_' + k), pet.toyKind === k)).join('') + B('petReward', null, 'cookie', t('treat'), false);
  else if (tab === 'cmd') {
    const G = { sit: 'g_hold', lie: 'g_down', paw: 'g_side', jump: 'g_up', spin: 'g_circle', voice: 'g_dbl' };
    row = COMMANDS.map(c => { const sk = Math.floor(pet.skills[c] || 0); return `<button class="pbtn cmd" data-act="petCmd" data-arg="${c}" data-mod="pet" data-x="petAct" aria-label="${esc(t('cmd_' + c))}"><i class="gx">${gi(G[c], 14)}</i>${gi({ sit: 'sit', lie: 'lie', paw: 'pawA', jump: 'jump', spin: 'spin', voice: 'voice' }[c], 24)}<span>${esc(t('cmd_' + c))}</span><b class="dots">${[0, 1, 2, 3, 4].map(i => `<i class="${i < sk ? 'f' : ''}"></i>`).join('')}</b></button>`; }).join('') + B('petReward', null, 'cookie', t('treat'), false);
  }
  else if (tab === 'talk') row = `<div class="talk"><input id="talkIn" class="inp" maxlength="200" enterkeyhint="send" autocomplete="off" placeholder="${esc(t('talk_ph'))}"><button class="pbtn sq" data-act="petTalk" data-mod="ai" data-x="petAct" aria-label="${esc(t('talk_send'))}">${gi('send', 24)}</button><button class="pbtn sq" data-act="petTalk" data-arg="rand" data-mod="ai" data-x="petAct" aria-label="${esc(t('talk_rand'))}">${gi('dice', 24)}</button></div>`;
  else row = HATS.map(h => B('setHat', h, h === 'none' ? 'none' : h, t('hat_' + h), pet.hatKind === h)).join('');
  const need = (k, ico) => `<div class="need" data-need="${k}" title="${esc(t('need_' + k))}"><span>${ico}</span><b><i style="width:${Math.round(pet.needs[k] ?? 50)}%"></i></b></div>`;
  const tabs = ['who', 'play', 'cmd', 'talk', 'wear'].map(k => `<button class="ptab ${tab === k ? 'on' : ''}" data-act="petTab" data-arg="${k}" data-mod="pet" data-x="petAct">${gi({ who: 'paw', play: 'ball', cmd: 'cap', talk: 'chat', wear: 'hat' }[k], 22)}<span>${esc(t('pt_' + k))}</span></button>`).join('');
  return `<section class="pet-stage big fit" data-glass>
      <div class="pet-slot" id="petStageSlot"></div>
      <div class="needs">${need('food', gi('food', 16))}${need('water', gi('water', 16))}${need('joy', gi('joy', 16))}${need('energy', gi('energy', 16))}</div>
      <div class="pet-say" id="petSay"></div>
      <div class="gtoast" id="gToast"></div>
      <div class="pet-dock">
        <span class="pet-note" id="petStateNote">${esc(breedNote())}</span>
        <div class="prow ${tab}">${row}</div>
        <div class="ptabs">${tabs}</div>
      </div>
    </section>`;
}
function vAi() {
  const ids = ['cf', 'gemini', 'groq', 'openrouter', 'openai', 'anthropic', 'custom'];
  const order = ai.st.order;
  const row = (id) => {
    const P = PROVIDERS[id], on = order.includes(id), q = order.indexOf(id) + 1;
    const res = S.aiRes && S.aiRes.find((x) => x.id === id);
    const status = res ? (res.ok ? `<em class="ok">✓ ${res.ms} ms</em>` : `<em class="bad">✗ ${esc(res.id === 'cf' && !net.online ? t('ai_err_offline') : aiErr(res.why))}</em>`) : '';
    let body = '';
    if (on && id === 'custom') body = `<div class="ai-keys"><input class="inp" data-aiurl inputmode="url" spellcheck="false" placeholder="${esc(t('ai_url'))}" value="${esc(ai.st.custom.url)}"><select class="inp" data-aifmt>${['openai', 'anthropic', 'gemini'].map((f) => `<option value="${f}" ${ai.st.custom.fmt === f ? 'selected' : ''}>${f}</option>`).join('')}</select><input class="inp" data-aimodel spellcheck="false" placeholder="${esc(t('ai_model'))}" value="${esc(ai.st.custom.model)}"><input class="inp" type="password" autocomplete="off" data-aikey="custom" placeholder="${esc(t('ai_keyPh'))}" value="${esc(ai.st.keys.custom || '')}"></div>`;
    else if (on && id !== 'cf') body = `<div class="ai-keys"><input class="inp" type="password" autocomplete="off" spellcheck="false" data-aikey="${id}" placeholder="${esc(t('ai_keyPh'))}" value="${esc(ai.st.keys[id] || '')}"><a href="${P.key}" target="_blank" rel="noopener">${gi('key', 16)} ${esc(t('ai_getKey'))}</a></div>`;
    return `<div class="ai-row ${on ? '' : 'off'}"><span class="q">${on ? q : '·'}</span><div class="t"><b>${esc(id === 'custom' ? t('customAgent') : P.name)} ${status}</b><span>${esc(t('ai_' + id))}</span>${body}</div>${on && q > 1 ? `<button class="up" data-act="aiUp" data-arg="${id}" data-mod="ai" data-x="ai" aria-label="${esc(t('ai_up'))}">↑</button>` : ''}<button data-act="aiToggle" data-arg="${id}" data-mod="ai" data-x="ai" aria-pressed="${on}" aria-label="${esc(P.name)}"><span class="sw ${on ? 'on' : ''}"><i></i></span></button></div>`;
  };
  return head(t('aiTitle'), t('aiSub')) + `
    <div class="card" data-glass style="max-width:640px;padding:6px 18px">${ids.map(row).join('')}</div>
    <div style="max-width:640px;margin-top:10px"><button class="btn prim" style="width:100%" ${S.aiBusy ? 'disabled' : ''} data-act="aiTest" data-mod="ai" data-x="ai">${esc(S.aiBusy ? t('aiTesting') : t('aiTest'))}</button></div>
    <p class="muted fine">${gi('key', 14)} ${esc(t('aiKeyNote'))}</p>`;
}
function vSettings() {
  const langs = LANGS.map(([id, name]) => `<button class="chip ${S.lang === id ? 'on' : ''}" data-act="setLang" data-arg="${id}" data-mod="mem" data-x="lang">${esc(name)}</button>`).join('');
  const qs = ['high', 'normal', 'off'].map(q => `<button class="chip ${S.quality === q ? 'on' : ''}" data-act="setQuality" data-arg="${q}" data-mod="core" data-x="generic">${esc(t('q_' + q))}</button>`).join('');
  return head(t('settingsTitle'), '') + `
    <div class="card" data-glass style="max-width:640px;display:flex;flex-direction:column;gap:12px">
      ${nameRow()}<span class="muted" style="font-size:12px;margin-top:-6px">${esc(t('name_note'))}</span>
      <b>${esc(t('language'))}</b><div class="chips">${langs}</div>
      <b style="margin-top:8px">${esc(t('quality'))}</b><div class="chips">${qs}</div>
      <b style="margin-top:8px">${esc(t('offline_t'))}</b><span class="muted" id="offState" style="font-size:13px;display:flex;align-items:center;gap:6px">${offlineLine()}</span>
      ${(() => { const L = tgLine(); return `<span class="muted" style="font-size:12.5px;margin-top:4px">${gi('send', 14)} Telegram: ${esc(L.txt)}</span>`; })()}
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><button class="btn ghost" style="justify-content:flex-start" data-act="go" data-arg="ai" data-mod="ai" data-x="nav">${IC.ai.replace('<svg', '<svg width="20" height="20"')} ${esc(t('nav_ai'))}</button>${(() => { const L = tgLine(); return L.btn ? `<button class="btn ghost" style="justify-content:flex-start" data-act="${L.btn[0]}" data-mod="net" data-x="generic">${gi('send', 20)} ${esc(L.btn[1])}</button>` : ''; })()}</div>
    </div>
    <p class="muted fine">${esc(t('holdHint'))}</p>`;
}

function render() {
  if (S.route === 'settings' && navigator.serviceWorker && navigator.serviceWorker.controller) navigator.serviceWorker.controller.postMessage('count');
  closeCapsule();
  const V = { home: vHome, games: vGames, puzzles: vPuzzles, pet: vPet, together: vTogether, ai: vAi, settings: vSettings }[S.route] || vHome;
  document.body.dataset.route = S.route;
  $('#view').innerHTML = V();
  if (S.route === 'puzzles') renderBoard();

  syncChrome();
  placePet();
}

/* ============================================================
   НАТИСКАННЯ, «ЗАТИСНИ — СПИТАЙ»
   ============================================================ */
let suppress = false;
document.addEventListener('click', (e) => {
  if (suppress) { e.preventDefault(); e.stopPropagation(); suppress = false; return; }
  const cap = $('#capsule');
  if (!cap.classList.contains('hidden') && !e.target.closest('#capsule')) { closeCapsule(); }
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const fn = ACT[el.dataset.act];
  if (!fn) return;
  fn(el.dataset.arg);
  pulse(el.dataset.mod || 'core', fn);
}, true);

let hold = null;
document.addEventListener('pointerdown', (e) => {
  if (e.button !== 0) return;
  if (e.target.closest('input,textarea,#capsule,iframe,.pet-canvas')) return;
  const el = e.target.closest('[data-x],[data-act],.cart,.board-card,.hero,.card,.pet-stage');
  if (!el) return;
  holdRing.style.left = e.clientX + 'px'; holdRing.style.top = e.clientY + 'px';
  holdRing.classList.remove('on'); void holdRing.offsetWidth; holdRing.classList.add('on');
  hold = { el, x: e.clientX, y: e.clientY, tm: setTimeout(() => { holdRing.classList.remove('on'); openCapsule(el); suppress = true; hold = null; try { navigator.vibrate && navigator.vibrate(10); } catch (_) { } }, 450) };
});
const holdRing = document.createElement('div'); holdRing.className = 'hold-ring'; document.body.appendChild(holdRing);
const cancelHold = () => { holdRing.classList.remove('on'); if (hold) { clearTimeout(hold.tm); hold = null; } };
document.addEventListener('pointermove', (e) => { if (hold && Math.hypot(e.clientX - hold.x, e.clientY - hold.y) > 10) cancelHold(); }, { passive: true });
document.addEventListener('pointerup', cancelHold);
document.addEventListener('pointercancel', cancelHold);
$('#main').addEventListener('scroll', cancelHold, { passive: true });
document.addEventListener('contextmenu', (e) => {
  const el = e.target.closest('[data-x],[data-act]');
  if (e.target.closest('input,textarea,iframe')) return;
  e.preventDefault();
  if (el) openCapsule(el);
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeCapsule(); closeSheet(); } });

function highlightCode(src) {
  const lines = src.split('\n').slice(0, 18).map(l => l.replace(/^ {0,2}/, ''));
  return esc(lines.join('\n'))
    .replace(/(\/\*[\s\S]*?\*\/|\/\/[^\n]*)/g, '<span class="cm">$1</span>')
    .replace(/('[^'\n]*'|`[^`\n]*`)/g, '<span class="st">$1</span>')
    .replace(/\b(function|const|let|if|else|return|for|of|new|true|false|null)\b/g, '<span class="kw">$1</span>');
}
function codeFor(el) {
  const a = el.dataset.act;
  if (a === 'cellTap' || a === 'numTap') {
    const tp = S.pz && S.pz.data.type;
    return tp === 'sudoku' ? PZ.sudokuConflicts : tp === 'queens' ? PZ.queensErrors : PZ.tangoErrors;
  }
  return ACT[a] || null;
}
function openCapsule(el) {
  const cap = $('#capsule');
  document.querySelectorAll('.held').forEach(x => x.classList.remove('held'));
  el.classList.add('held');
  const key = el.dataset.x || 'generic';
  const fn = codeFor(el);
  const label = (el.getAttribute('aria-label') || el.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 60);
  cap.innerHTML = `
    <span class="ct">${esc(t('x_' + key))}${label ? ' · ' + esc(label) : ''}</span>
    <span class="cd">${esc(t('x_' + key + '_d'))}</span>
    ${fn ? `<span class="ck">${esc(t('cap_code')).toUpperCase()}</span><pre>${highlightCode(String(fn))}</pre>` : ''}
    <div class="cacts">
      <button class="btn ghost" data-cap="ask">${esc(t('cap_ask'))}</button>
      <button class="btn ghost" data-cap="show">${esc(t('cap_show'))}</button>
      ${fn ? `<button class="btn ghost" data-cap="copy">${esc(t('cap_copy'))}</button>` : ''}
    </div>
    <div id="capReply"></div>`;
  cap.classList.add('solid');
  cap.classList.remove('hidden');
  const r = el.getBoundingClientRect(), cw = cap.offsetWidth, ch = cap.offsetHeight;
  let x = Math.min(Math.max(10, r.left + r.width / 2 - cw / 2), window.innerWidth - cw - 10);
  let y = r.top - ch - 12;
  if (y < 70) y = Math.min(r.bottom + 12, window.innerHeight - ch - 10);
  cap.style.left = x + 'px'; cap.style.top = Math.max(10, y) + 'px';
  cap.onclick = async (ev) => {
    const b = ev.target.closest('[data-cap]'); if (!b) return;
    ev.stopPropagation();
    if (b.dataset.cap === 'ask') {
      const box = $('#capReply');
      if (!aiAny()) { box.innerHTML = `<div class="reply">${esc(t('ai_err_none'))}</div>`; return; }
      box.innerHTML = `<div class="reply">${esc(t('cap_thinking'))}</div>`;
      const what = `${t('x_' + (el.dataset.x || 'generic'))}: ${t('x_' + (el.dataset.x || 'generic') + '_d')}. ${(el.getAttribute('aria-label') || el.textContent || '').trim().slice(0, 80)}`;
      const r = await ai.ask({ task: 'explain', system: `Поясни дитині 10–11 років простими словами, що робить цей елемент гри і як ним користуватися. 2–3 речення. Мова: ${{ uk: 'українська', en: 'English', ru: 'русский' }[S.lang]}.`, prompt: what, max: 200 });
      if ($('#capReply') === box) box.innerHTML = `<div class="reply">${esc(r.moderated ? t('ai_' + r.moderated) : r.text || aiErr(r.error))}</div>`;
    }
    if (b.dataset.cap === 'show') { if (!S.corpus) toggleCorpus(); pulse(el.dataset.mod || 'core', fn); closeCapsule(); }
    if (b.dataset.cap === 'copy') { try { await navigator.clipboard.writeText(String(fn)); toast(t('copied')); } catch (_) { } }
  };
}
function closeCapsule() { $('#capsule').classList.add('hidden'); document.querySelectorAll('.held').forEach(x => x.classList.remove('held')); }

// картки нахиляються за пальцем / мишкою
document.addEventListener('pointermove', (e) => {
  const c = e.target.closest && e.target.closest('.cart'); 
  document.querySelectorAll('.cart.tilt').forEach(x => { if (x !== c) { x.classList.remove('tilt'); x.style.transform = ''; } });
  if (!c) return;
  const r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
  c.classList.add('tilt'); c.style.transform = `perspective(700px) rotateY(${x * 10}deg) rotateX(${-y * 8}deg) translateZ(6px)`;
}, { passive: true });
// виклик від друга: ?c=queens.hard.2026-11-14 — та сама задача дня
try { const c = new URLSearchParams(location.search).get('c'); if (c) { const [tp, lv] = c.split('.'); if (['tango', 'queens', 'sudoku'].includes(tp)) { S.pzType = tp; if (PZ.LEVELS.includes(lv)) S.pzLevel = lv; S.pz = null; if (!location.hash) location.hash = '#puzzles'; } } } catch (_) { }
/* ---------- старт ---------- */
document.addEventListener('visibilitychange', () => { if (!stage || S.quality === 'off') return; if (document.hidden) stage.stop(); else if (!S.game_open) stage.start(); });
document.documentElement.lang = S.lang;
document.body.insertAdjacentHTML('afterbegin', iconDefs());
{ const cs = document.querySelector('#coins svg'); if (cs) cs.outerHTML = gi('coin', 20); const gs = document.querySelector('#gearBtn svg'); if (gs) gs.outerHTML = gi('settings', 22); }
startStage();
window.addEventListener('hashchange', () => { const r = location.hash.slice(1); if (r && r !== S.route) go(r); });
window.addEventListener('resize', () => placePet());
const QS = new URLSearchParams(location.search);
if (QS.has('dbg')) window.__pet = pet; // для автоматичних перевірок
const first = QS.get('go') || location.hash.slice(1);
S.route = NAV.includes(first) ? first : 'home';
render();
loadPet();
{ const gq = QS.get('game'); if (gq && READY.has(gq)) setTimeout(() => openGame(gq), 300); }
net.init(S.lang).then((ok) => {
  S.online = ok; S.me = net.user; setTimeout(syncProgress, 4000);
  if (S.route === 'settings') render();
  if (ok && S.name && net.user && net.user.name !== S.name) net.setName(S.name);
  const room = (QS.get('room') || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (room.length >= 4) { if (ok) tgJoin(room); else { go('together'); toast(t('tg_needServer')); } }
  const ch = (QS.get('ch') || '').replace(/[^a-z0-9]/g, '');
  if (ch && ok) loadChallenge(ch);
  if (!room && !ch && ['together', 'ai'].includes(S.route)) render();
});
// офлайн: сервіс-воркер завантажує всю приставку; коли готово — кажемо один раз
if (swOk()) {
  navigator.serviceWorker.register('sw.js').catch(() => { });
  navigator.serviceWorker.addEventListener('message', (e) => {
    const d = e.data || {};
    if (d.t === 'sw-ready' && !store.get('offlineReady', false)) { store.set('offlineReady', true); toast(t('offline_ready')); }
    if (d.t === 'sw-count') { S.offline = d; const el = $('#offState'); if (el) el.innerHTML = offlineLine(); }
  });
}
function swOk() { return 'serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost') && /\/play\/(index\.html)?$/.test(location.pathname); }
function offlineLine() {
  const o = S.offline; if (!swOk()) return esc(t('offline_na'));
  if (!o) return esc(t('offline_check'));
  return o.have >= o.total ? `${gi('flag', 16)} ${esc(t('offline_ok'))}` : esc(t('offline_load').replace('{a}', o.have).replace('{b}', o.total));
}
document.fonts && document.fonts.ready.then(() => { if (stage) stage.setLabels(modLabels()); });
Promise.all(['js/app.js', 'js/puzzles.js', 'js/stage.js', 'js/pet.js'].map(u => fetch(u).then(r => r.text()).catch(() => ''))).then(a => { if (stage) stage.setCode(a.join('\n')); });
