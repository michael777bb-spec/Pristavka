// ІСКРА 3D v2 — керування руками, без панелей.
// Від гри сина: коти-електрики в касках (його талісман), 13 районів з його
// назвами, станція з генераторами, щитки, бурі, відключення, репутація, інспекція.
// Як грати — все на мапі:
//   • тягни мапу, щипай — масштаб, два пальці — поворот;
//   • тицьни район — камера підлітає; затисни — бачиш нутрощі й цифри;
//   • кота-електрика бери пальцем і неси на іскристий щиток чи генератор;
//   • рубильник на щитку — тиць: планове відключення / увімкнути;
//   • монети над районами — тиць, щоб зібрати; на них відкривай райони,
//     будуй генератори й наймай котів (табличка «+» прямо на мапі).
import { world, rig, THREE, RoundedBoxGeometry, speckle, std, glow, blob, label, particles, h, esc, canvasTex, ease } from '../kit.js';
import { inst, clip, animator } from '../models.js';
import { gi, giSvg } from '../icons.js';
import { tagSprite, hipRoof, gableRoof } from '../kit.js';
import { sfx as SFX, soundScope, spatial } from '../sound.js';
import { makeCat } from '../catcrew.js';

const TX = {
  uk: { start: 'Тицьни, щоб почати', goal: 'Тримай світло в місті', coach: 'Тягни кота на іскристий щиток', coins: 'Бракує монет', insp: 'Інспекція!', pass: 'Інспекцію пройдено', fail: 'Інспекція незадоволена', closed: 'Компанію закрито', again: 'Ще раз', day: 'День', storm: 'буря', demand: 'Попит', rep: 'Репутація', ok: 'світло є', off: 'вимкнено за графіком', dark: 'перевантаження — темно', broken: 'щиток зламано', health: 'Стан', out: 'Дає', idle: 'чекає роботу', walk: 'йде на виклик', repair: 'лагодить', carried: 'у тебе в лапах', newGen: 'генератор', newCat: 'кіт', open: 'відкрити',
    d: { center: 'Центр', sleep: 'Спальний район', uni: 'Університетське', industry: 'Промзона', old: 'Старе місто', port: 'Порт', village: 'Заміські села', resort: 'Курортна зона', tech: 'Технопарк', grove: 'Гаї', dacha: 'Дачі', orchard: 'Сади', ravine: 'Яри' }, station: 'Станція', depot: 'Депо котів', hall: 'Мерія' },
  en: { start: 'Tap to start', goal: 'Keep the city lit', coach: 'Drag a cat onto the sparking switchboard', coins: 'Not enough coins', insp: 'Inspection!', pass: 'Inspection passed', fail: 'The inspector is unhappy', closed: 'The company is closed', again: 'Again', day: 'Day', storm: 'storm', demand: 'Demand', rep: 'Reputation', ok: 'lights on', off: 'scheduled outage', dark: 'overload — dark', broken: 'switchboard broken', health: 'Condition', out: 'Output', idle: 'waiting for a job', walk: 'on the way', repair: 'repairing', carried: 'in your paws', newGen: 'generator', newCat: 'cat', open: 'open',
    d: { center: 'Centre', sleep: 'Sleepy Quarter', uni: 'University', industry: 'Industrial Zone', old: 'Old Town', port: 'Port', village: 'Villages', resort: 'Resort', tech: 'Tech Park', grove: 'Groves', dacha: 'Dachas', orchard: 'Orchards', ravine: 'Ravines' }, station: 'Station', depot: 'Cat depot', hall: 'City Hall' },
  ru: { start: 'Тапни, чтобы начать', goal: 'Держи свет в городе', coach: 'Тащи кота на искрящий щиток', coins: 'Не хватает монет', insp: 'Инспекция!', pass: 'Инспекция пройдена', fail: 'Инспекция недовольна', closed: 'Компанию закрыли', again: 'Ещё раз', day: 'День', storm: 'буря', demand: 'Спрос', rep: 'Репутация', ok: 'свет есть', off: 'отключено по графику', dark: 'перегрузка — темно', broken: 'щиток сломан', health: 'Состояние', out: 'Даёт', idle: 'ждёт работу', walk: 'идёт на вызов', repair: 'чинит', carried: 'у тебя в лапах', newGen: 'генератор', newCat: 'кот', open: 'открыть',
    d: { center: 'Центр', sleep: 'Спальный район', uni: 'Университетский', industry: 'Промзона', old: 'Старый город', port: 'Порт', village: 'Загородные сёла', resort: 'Курортная зона', tech: 'Технопарк', grove: 'Рощи', dacha: 'Дачи', orchard: 'Сады', ravine: 'Овраги' }, station: 'Станция', depot: 'Депо котов', hall: 'Мэрия' }
};
const P = 6.4, LOT = 5.0, DAYLEN = 160;
const lotPos = (c, r) => new THREE.Vector3((c - 1.5) * P, 0, (r - 1.5) * P);
const LOTS = [
  [0, 0, 'grove'], [1, 0, 'orchard'], [2, 0, 'dacha'], [3, 0, 'ravine'],
  [0, 1, 'village'], [1, 1, 'old'], [2, 1, 'uni'], [3, 1, 'tech'],
  [0, 2, 'sleep'], [1, 2, 'center'], [2, 2, 'industry'], [3, 2, 'STATION'],
  [0, 3, 'port'], [1, 3, 'resort'], [2, 3, 'DEPOT'], [3, 3, 'HALL']
];
const DEM = { center: 30, sleep: 22, uni: 18, old: 16, industry: 28, tech: 24, village: 10, dacha: 8, orchard: 9, grove: 6, ravine: 7, port: 20, resort: 14 };
const INC = { center: 3, sleep: 2, uni: 2, old: 2, industry: 3, tech: 3, village: 1, dacha: 1, orchard: 1, grove: 1, ravine: 1, port: 2.5, resort: 2 };
const START_OPEN = ['center', 'sleep', 'uni', 'old'];
const ROADS = [-2, -1, 0, 1, 2].map((k) => k * P);
const nearRoad = (v) => ROADS.reduce((a, b) => Math.abs(b - v) < Math.abs(a - v) ? b : a);
const gauss = (x, m, s) => Math.exp(-((x - m) ** 2) / (2 * s * s));

export function mount(root, api) {
  const lang = TX[api.lang] ? api.lang : 'uk';
  const T = TX[lang];
  const W = world(root, { quality: api.quality, bg: 0x0d1420, envI: 0.4, bloom: 0.2, bloomTh: 0.93, tilt: 0.12 });
  const { scene, camera, hud } = W;
  const fx = particles(W, 900);
  const cam = rig(W, { target: new THREE.Vector3(0, 0, 0), dist: 34, pitch: 0.95, yaw: 0.35, limits: { min: 7, max: 52, box: 15 } });
  // звук: місто, генератори, іскри, грім — з місця у світі
  const SND = soundScope(), sp3 = spatial(W, 20);
  const snd = (k, p, x = 1, d = 0) => SFX(k, p ? { ...sp3(p, x), delay: d } : { delay: d });

  /* ---------- стан ---------- */
  const kinds = LOTS.map((l) => l[2]).filter((k) => DEM[k]);
  const fresh = () => ({ coins: 60, day: 1, t: 0.05, rep: Object.fromEntries(kinds.map((k) => [k, 65])), open: Object.fromEntries(kinds.map((k) => [k, START_OPEN.includes(k)])), broken: { sleep: true }, off: {}, gens: [{ h: 92 }, { h: 74 }], cats: 2, storm: false, stormNext: true, fails: 0, coach: false, lost: false, unlocked: 0 });
  let S = api.store.get('v2', null) || fresh();
  const save = () => api.store.set('v2', S);
  const hour = () => (7 + S.t * 24) % 24;

  /* ---------- світло й небо ---------- */
  const hemi = new THREE.HemisphereLight(0xcfe3ff, 0x2c2a26, 0.9); scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xffefd8, 2.6); sun.castShadow = true;
  sun.shadow.mapSize.set(api.quality === 'high' ? 2048 : 1024, api.quality === 'high' ? 2048 : 1024);
  Object.assign(sun.shadow.camera, { left: -18, right: 18, top: 18, bottom: -18, near: 1, far: 70 }); sun.shadow.bias = -0.0005; sun.shadow.normalBias = 0.03;
  scene.add(sun, sun.target);
  // зорі й вуличні ліхтарі на перехрестях (світяться лише вночі)
  const stars = (() => { const n = 240, g = new THREE.BufferGeometry(), a2 = new Float32Array(n * 3); for (let i = 0; i < n; i++) { const u = Math.random() * Math.PI * 2, v = 0.1 + Math.random() * 0.5; a2.set([Math.cos(u) * Math.cos(v) * 130, Math.sin(v) * 130, Math.sin(u) * Math.cos(v) * 130], i * 3); } g.setAttribute('position', new THREE.BufferAttribute(a2, 3)); const p = new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffffff, size: 0.9, sizeAttenuation: false, transparent: true, opacity: 0, fog: false })); scene.add(p); return p; })();
  const lampBulb = new THREE.MeshStandardMaterial({ color: 0xfff2d0, emissive: new THREE.Color(0xffc56b), emissiveIntensity: 0 });
  scene.fog = new THREE.Fog(0x3a5170, 45, 110);
  const bgCv = document.createElement('canvas'); bgCv.width = 4; bgCv.height = 256;
  const bgTex = new THREE.CanvasTexture(bgCv); bgTex.colorSpace = THREE.SRGBColorSpace; scene.background = bgTex;
  let lastSky = '';
  function sky(top, mid) { const k = top + mid; if (k === lastSky) return; lastSky = k; const g = bgCv.getContext('2d'), gr = g.createLinearGradient(0, 0, 0, 256); gr.addColorStop(0, top); gr.addColorStop(0.55, mid); gr.addColorStop(1, '#0a0e15'); g.fillStyle = gr; g.fillRect(0, 0, 4, 256); bgTex.needsUpdate = true; }

  /* ---------- земля, дороги, вода ---------- */
  const world3 = new THREE.Group(); scene.add(world3);
  const grass = speckle('#5d8a45', ['#527d3c', '#6a9850', '#4a7236', '#76a55a'], 512, 12000, 31, [0.6, 2.2]); grass.repeat.set(8, 8);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), std(0xffffff, 0.95, 0, { map: grass })); ground.rotation.x = -Math.PI / 2; ground.position.y = -0.02; ground.receiveShadow = true; world3.add(ground);
  const asphalt = speckle('#2d3138', ['#25282e', '#353941', '#3c4048'], 256, 4000, 33, [0.5, 1.4]); asphalt.repeat.set(1, 12);
  const roadM = std(0xffffff, 0.85, 0, { map: asphalt });
  const SPAN = P * 4 + 1.4;
  for (const x of ROADS) { const r = new THREE.Mesh(new THREE.PlaneGeometry(1.25, SPAN), roadM); r.rotation.x = -Math.PI / 2; r.position.set(x, 0.005, 0); r.receiveShadow = true; world3.add(r); }
  for (const z of ROADS) { const r = new THREE.Mesh(new THREE.PlaneGeometry(SPAN, 1.25), roadM); r.rotation.x = -Math.PI / 2; r.position.set(0, 0.006, z); r.receiveShadow = true; world3.add(r); }
  const dash = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.4, 0.06), new THREE.MeshBasicMaterial({ color: 0xd9d4c0 }), 400); let dn = 0; const m4 = new THREE.Matrix4();
  for (const x of ROADS) for (let z = -SPAN / 2; z < SPAN / 2; z += 0.9) { m4.makeRotationX(-Math.PI / 2).premultiply(new THREE.Matrix4().makeRotationY(Math.PI / 2)).setPosition(x, 0.012, z); dash.setMatrixAt(dn++, m4); }
  for (const z of ROADS) for (let x = -SPAN / 2; x < SPAN / 2; x += 0.9) { m4.makeRotationX(-Math.PI / 2).setPosition(x, 0.013, z); dash.setMatrixAt(dn++, m4); }
  dash.count = dn; world3.add(dash);
  const waterM = new THREE.MeshPhysicalMaterial({ color: 0x1d5f86, roughness: 0.08, metalness: 0.1, transmission: 0, clearcoat: 1, transparent: true, opacity: 0.92 });
  const water = new THREE.Mesh(new THREE.PlaneGeometry(60, 14, 1, 1), waterM); water.rotation.x = -Math.PI / 2; water.position.set(0, 0.01, 1.5 * P + LOT / 2 + 7.6); world3.add(water);
  const sand = new THREE.Mesh(new THREE.PlaneGeometry(60, 1.4), std(0xd8c290, 1)); sand.rotation.x = -Math.PI / 2; sand.position.set(0, 0.008, 1.5 * P + LOT / 2 + 0.5); sand.receiveShadow = true; world3.add(sand);
  // ліхтарі
  const poleM = std(0x2a2d33, 0.5, 0.8);
  const poles = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.03, 0.04, 1.1, 6), poleM, 60), bulbs = new THREE.InstancedMesh(new THREE.SphereGeometry(0.08, 10, 8), new THREE.MeshBasicMaterial({ color: 0x333333 }), 60);
  let pn = 0; for (const x of ROADS) for (const z of ROADS) { m4.makeTranslation(x + 0.75, 0.55, z + 0.75); poles.setMatrixAt(pn, m4); m4.makeTranslation(x + 0.75, 1.12, z + 0.75); bulbs.setMatrixAt(pn, m4); pn++; }
  poles.count = bulbs.count = pn; poles.castShadow = true; world3.add(poles, bulbs);

  /* ---------- райони ---------- */
  const D = {}; // kind -> district
  const pickables = [];
  const wallM = (c) => std(c, 0.85);
  function house(g, x, z, w, d, hh, wall, roof) {
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, hh, d), wallM(wall)); b.position.set(x, hh / 2, z); b.castShadow = true; b.receiveShadow = true; b.userData.bld = true; g.add(b);
    // вальмовий дах точно під прямокутник будинку, з напуском і карнизом
    const r = hipRoof(w, d, Math.min(w, d) * 0.42, { over: Math.min(w, d) * 0.1, mat: std(roof, 0.75) }); r.position.set(x, hh, z); g.add(r);
    return b;
  }
  function factory(g, x, z) {
    const b = new THREE.Mesh(new RoundedBoxGeometry(1.8, 1.0, 1.4, 2, 0.04), std(0x8d8f94, 0.8, 0.2)); b.position.set(x, 0.5, z); b.castShadow = true; b.receiveShadow = true; b.userData.bld = true; g.add(b);
    for (let i = 0; i < 3; i++) { const t = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.25, 1.4), std(0x6f7278, 0.7)); t.position.set(x - 0.6 + i * 0.6, 1.1, z); t.rotation.z = 0.35; t.castShadow = true; g.add(t); }
    const ch = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 1.8, 14), std(0xb6b9bf, 0.6)); ch.position.set(x + 0.7, 0.9, z - 0.5); ch.castShadow = true; g.add(ch);
    return ch;
  }
  function crane(g, x, z) {
    const m = std(0xe8a02c, 0.5, 0.3);
    const t = new THREE.Mesh(new THREE.BoxGeometry(0.18, 2.6, 0.18), m); t.position.set(x, 1.3, z); t.castShadow = true; g.add(t);
    const a = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.14, 0.14), m); a.position.set(x + 0.8, 2.55, z); a.castShadow = true; g.add(a);
    const c = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 1.2, 4), std(0x222222, 0.5)); c.position.set(x + 1.8, 1.95, z); g.add(c);
  }
  function umbrella(g, x, z, col) {
    const p = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.8, 6), std(0xffffff, 0.5)); p.position.set(x, 0.4, z); g.add(p);
    const top = new THREE.Mesh(new THREE.ConeGeometry(0.45, 0.22, 10), std(col, 0.7)); top.position.set(x, 0.85, z); top.castShadow = true; g.add(top);
  }
  const TREES = ['tree_oak', 'tree_autumn', 'tree_pine', 'tree_fat', 'tree_pine_tall'];
  function trees(g, n, area, list = TREES, hh = [0.9, 1.6]) {
    for (let i = 0; i < n; i++) { const name = list[(Math.random() * list.length) | 0]; const x = (Math.random() - 0.5) * area, z = (Math.random() - 0.5) * area; inst(name, hh[0] + Math.random() * (hh[1] - hh[0])).then((m) => { m.position.set(x, 0, z); m.rotation.y = Math.random() * 6; g.add(m); }).catch(() => { }); }
  }
  function cabinet(g) {
    const c = new THREE.Group(); c.position.set(LOT / 2 - 0.35, 0, LOT / 2 - 0.35); g.add(c);
    const box = new THREE.Mesh(new RoundedBoxGeometry(0.5, 0.75, 0.32, 2, 0.04), std(0x9aa3ad, 0.4, 0.7)); box.position.y = 0.38; box.castShadow = true; c.add(box);
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.18), new THREE.MeshBasicMaterial({ map: canvasTex(64, (x, s) => { x.fillStyle = '#ffd400'; x.beginPath(); x.moveTo(s / 2, 4); x.lineTo(s - 4, s - 6); x.lineTo(4, s - 6); x.closePath(); x.fill(); x.fillStyle = '#111'; x.fillStyle = '#111'; x.beginPath(); x.moveTo(s * 0.55, s * 0.3); x.lineTo(s * 0.38, s * 0.62); x.lineTo(s * 0.5, s * 0.62); x.lineTo(s * 0.44, s * 0.86); x.lineTo(s * 0.63, s * 0.52); x.lineTo(s * 0.51, s * 0.52); x.closePath(); x.fill(); }) , transparent: true }));
    sign.position.set(0, 0.5, 0.165); c.add(sign);
    const pivot = new THREE.Group(); pivot.position.set(0.27, 0.42, 0); c.add(pivot);
    const lever = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.3, 8), std(0x222222, 0.4, 0.6)); lever.position.y = 0.13; pivot.add(lever);
    const knob = new THREE.Mesh(new THREE.SphereGeometry(0.05, 12, 8), std(0xd8463b, 0.4)); knob.position.y = 0.28; pivot.add(knob);
    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.05, 12, 8), new THREE.MeshBasicMaterial({ color: 0x00ff66 })); lamp.position.set(-0.12, 0.8, 0); c.add(lamp);
    const hit = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.4, 1.0), new THREE.MeshBasicMaterial({ visible: false })); hit.position.y = 0.6; c.add(hit);
    return { c, pivot, lamp };
  }
  function windows(d) {
    const panes = [];
    d.g.updateMatrixWorld(true);
    const inv = d.g.matrixWorld.clone().invert();
    d.g.traverse((m) => {
      if (!m.isMesh || !m.userData.bld) return;
      const bb = new THREE.Box3().setFromObject(m).applyMatrix4(inv);
      const sz = bb.getSize(new THREE.Vector3()), c = bb.getCenter(new THREE.Vector3());
      const fl = Math.max(1, Math.floor((sz.y - 0.15) / 0.24));
      for (const [nx, nz] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) {
        const wdt = nx ? sz.z : sz.x, cols = Math.max(1, Math.floor((wdt - 0.12) / 0.22));
        for (let f = 0; f < fl; f++) for (let k = 0; k < cols; k++) {
          if (Math.random() < 0.3) continue;
          const off = (k - (cols - 1) / 2) * 0.22, y = bb.min.y + 0.2 + f * 0.24;
          panes.push({ p: new THREE.Vector3(nx ? c.x + nx * (sz.x / 2 + 0.008) : c.x + off, y, nz ? c.z + nz * (sz.z / 2 + 0.008) : c.z + off), ry: nx ? Math.PI / 2 : 0 });
        }
      }
    });
    if (d.panes) d.g.remove(d.panes);
    if (!panes.length) return;
    const im = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.11, 0.13), d.winM, panes.length);
    const col = new THREE.Color();
    panes.forEach((pn2, k) => { m4.makeRotationY(pn2.ry).setPosition(pn2.p); im.setMatrixAt(k, m4); im.setColorAt(k, col.setHSL(0.09 + Math.random() * 0.05, 0.6, 0.45 + Math.random() * 0.45)); });
    im.material.side = THREE.DoubleSide; d.panes = im; d.g.add(im);
  }
  const BLD = ['building_a', 'building_b', 'building_c', 'building_d', 'building_e', 'building_f', 'building_g', 'building_h'];
  function buildLot(d) {
    const g = d.content, k = d.kind, jobs = [];
    const model = (n, hh, x, z, by = 'xz', o2 = {}) => jobs.push(inst(n, hh, { by, ...o2 }).then((m) => { m.position.set(x, 0, z); m.rotation.y = [0, Math.PI / 2, Math.PI, -Math.PI / 2][(Math.random() * 4) | 0]; m.traverse((x2) => { if (x2.isMesh) { x2.userData.bld = true; x2.material = x2.material.clone(); } }); g.add(m); return m; }).catch(() => null));
    if (k === 'center') { model('skyscraper_a', 1.5, -1.1, -1.1); model('skyscraper_b', 1.5, 1.1, -1.1); model('skyscraper_c', 1.5, -1.1, 1.0); model('building_c', 1.5, 1.1, 1.0); }
    else if (k === 'sleep') { [[-1.1, -1.1], [1.1, -1.1], [-1.1, 1.0], [1.1, 1.0]].forEach(([x, z], i) => model(BLD[(i * 3) % 8], 1.6, x, z)); }
    else if (k === 'uni') { const b = new THREE.Mesh(new RoundedBoxGeometry(3.4, 0.9, 1.4, 2, 0.05), std(0xe9e1cf, 0.8)); b.position.set(0, 0.45, -0.8); b.castShadow = true; b.receiveShadow = true; b.userData.bld = true; g.add(b); for (let i = 0; i < 6; i++) { const col = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.8, 10), std(0xffffff, 0.6)); col.position.set(-1.25 + i * 0.5, 0.4, -0.05); col.castShadow = true; g.add(col); } const roof = gableRoof(3.4, 1.4, 0.42, { over: 0.12, mat: std(0x8a4a3a, 0.72), wall: std(0xe9e1cf, 0.8) }); roof.position.set(0, 0.9, -0.8); g.add(roof); const ped = gableRoof(0.75, 3.0, 0.32, { over: 0.06, mat: std(0x8a4a3a, 0.72), wall: std(0xf4efe4, 0.6) }); ped.rotation.y = Math.PI / 2; ped.position.set(0, 0.87, -0.05); g.add(ped); const ent = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.07, 0.75), std(0xf4efe4, 0.6)); ent.position.set(0, 0.83, -0.05); ent.castShadow = true; g.add(ent); trees(g, 5, 4, ['tree_oak', 'tree_fat'], [0.8, 1.2]); }
    else if (k === 'old') { [[-1.2, -1.2], [0.2, -1.3], [1.4, -1.0], [-1.0, 0.9], [0.9, 1.1]].forEach(([x, z], i) => house(g, x, z, 0.9, 0.9, 0.8 + (i % 2) * 0.3, ['#d9b48c', '#c98f6a', '#e3cfa5'][i % 3], ['#8a4a3a', '#6e3b2e'][i % 2])); trees(g, 3, 4, ['tree_oak'], [0.8, 1.1]); }
    else if (k === 'tech') { model('skyscraper_b', 1.6, -0.9, -0.9, 'xz', { tint: '#9fd0ff' }); model('skyscraper_a', 1.4, 1.2, 0.6, 'xz', { tint: '#b0e0ff' }); model('satellite_dish', 0.9, 1.3, -1.4, 'y'); }
    else if (k === 'industry') { d.chimneys = [factory(g, -0.9, -0.9), factory(g, 1.0, 0.9)]; }
    else if (k === 'village' || k === 'dacha') { const n = k === 'village' ? 6 : 8; for (let i = 0; i < n; i++) house(g, ((i % 3) - 1) * 1.45 + (Math.random() - 0.5) * 0.3, (((i / 3) | 0) - 1) * 1.4, k === 'dacha' ? 0.6 : 0.8, k === 'dacha' ? 0.6 : 0.8, k === 'dacha' ? 0.5 : 0.65, ['#f2e6d0', '#e9d3b3', '#d6e2cf', '#efd9c8'][i % 4], ['#7a3b2e', '#4a5a6a', '#8a5a2a'][i % 3]); trees(g, 4, 4.4, ['tree_fat', 'tree_oak'], [0.6, 1.0]); }
    else if (k === 'grove') { trees(g, 16, 4.4, ['tree_oak', 'tree_autumn', 'tree_fat'], [1.0, 1.8]); house(g, 1.4, 1.5, 0.7, 0.7, 0.6, '#d6c3a5', '#6e3b2e'); }
    else if (k === 'orchard') { for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) inst('tree_fat', 0.75, {}).then((m) => { m.position.set(-1.6 + i * 1.05, 0, -1.6 + j * 1.05); g.add(m); }).catch(() => { }); house(g, 1.7, 1.7, 0.6, 0.6, 0.55, '#efe0c0', '#7a3b2e'); }
    else if (k === 'ravine') { const dip = new THREE.Mesh(new THREE.CircleGeometry(1.8, 32), std(0x3d5a2e, 1)); dip.rotation.x = -Math.PI / 2; dip.position.y = 0.01; g.add(dip); trees(g, 12, 4.4, ['tree_pine', 'tree_pine_tall'], [1.0, 2.0]); house(g, -1.5, 1.6, 0.6, 0.6, 0.55, '#d9c8a8', '#4a5a6a'); }
    else if (k === 'port') { crane(g, -1.6, 1.4); crane(g, 0.6, 1.7); model('cargo_ship', 3.4, 0.4, 4.0, 'xz'); for (let i = 0; i < 6; i++) model('crate', 0.45, -1.4 + (i % 3) * 0.55, -1.0 + ((i / 3) | 0) * 0.55, 'xz'); const wh = new THREE.Mesh(new RoundedBoxGeometry(1.8, 0.9, 1.0, 2, 0.04), std(0x6f8796, 0.8, 0.2)); wh.position.set(1.0, 0.45, -1.0); wh.castShadow = true; wh.userData.bld = true; g.add(wh); }
    else if (k === 'resort') { const sandL = new THREE.Mesh(new THREE.PlaneGeometry(LOT, LOT), std(0xe1cc98, 1)); sandL.rotation.x = -Math.PI / 2; sandL.position.y = 0.02; sandL.receiveShadow = true; g.add(sandL); for (let i = 0; i < 4; i++) umbrella(g, -1.5 + i * 1.0, 1.4, ['#ff6b6b', '#ffd36b', '#6bd0ff', '#9fe39a'][i]); for (let i = 0; i < 5; i++) inst('tree_palm', 1.4 + Math.random() * 0.5).then((m) => { m.position.set(-1.8 + i * 0.9, 0, -0.2 + (i % 2) * 0.5); g.add(m); }).catch(() => { }); house(g, 0.4, -1.4, 2.2, 0.9, 1.1, '#f5efe6', '#3a7aa0'); }
    return Promise.all(jobs).then(() => windows(d));
  }
  // ліхтарі на перехрестях
  { const postM = std(0x3a3f45, 0.5, 0.6), postG = new THREE.CylinderGeometry(0.04, 0.06, 1.5, 8), bulbG = new THREE.SphereGeometry(0.11, 10, 8);
    for (let i = 0; i <= 4; i++) for (let j = 0; j <= 4; j++) { const x = (i - 2) * P + 0.75, z = (j - 2) * P + 0.75; const post = new THREE.Mesh(postG, postM); post.position.set(x, 0.8, z); post.castShadow = true; world3.add(post); const b = new THREE.Mesh(bulbG, lampBulb); b.position.set(x, 1.58, z); world3.add(b); } }
  LOTS.forEach(([c, r, k]) => {
    const g = new THREE.Group(); g.position.copy(lotPos(c, r)); world3.add(g);
    const pad = new THREE.Mesh(new RoundedBoxGeometry(LOT, 0.08, LOT, 2, 0.03), std(0x8f939a, 0.92, 0, { map: speckle('#8f939a', ['#81858c', '#9a9ea5'], 128, 800, 41) })); pad.position.y = 0.03; pad.receiveShadow = true; g.add(pad);
    if (!DEM[k]) { D[k] = { kind: k, g }; return; }
    const content = new THREE.Group(); g.add(content);
    const winM = new THREE.MeshBasicMaterial({ color: 0x0b0d12 });
    const cab = cabinet(g);
    // закритий район — будмайданчик: земля, огорожа, табличка
    const fog = new THREE.Group(); g.add(fog);
    const dirt = new THREE.Mesh(new THREE.PlaneGeometry(LOT - 0.3, LOT - 0.3), new THREE.MeshStandardMaterial({ map: speckle('#6b5236', ['#5a4430', '#7a5e40', '#4a3828'], 128, 1200, 47), roughness: 1, transparent: true })); dirt.rotation.x = -Math.PI / 2; dirt.position.y = 0.075; dirt.receiveShadow = true; fog.add(dirt);
    const fenceM = new THREE.MeshStandardMaterial({ color: 0xc9a46a, roughness: 0.8, transparent: true });
    for (const [x, z, w, d2] of [[0, -LOT / 2 + 0.2, LOT - 0.4, 0.04], [0, LOT / 2 - 0.2, LOT - 0.4, 0.04], [-LOT / 2 + 0.2, 0, 0.04, LOT - 0.4], [LOT / 2 - 0.2, 0, 0.04, LOT - 0.4]]) { const f = new THREE.Mesh(new THREE.BoxGeometry(w, 0.22, d2), fenceM); f.position.set(x, 0.2, z); f.castShadow = true; fog.add(f); }
    fog.material = { opacity: 1 };
    const sign = tagSprite(giSvg('lock'), '', { scale: 0.7 }); sign.position.set(0, 2.2, 0); g.add(sign);
    const face = tagSprite(giSvg('f_happy'), '', { scale: 0.55, bg: false }); face.position.set(0, 3.0, 0); g.add(face);
    const hit = new THREE.Mesh(new THREE.BoxGeometry(LOT, 2.5, LOT), new THREE.MeshBasicMaterial({ visible: false })); hit.position.y = 1.2; g.add(hit);
    g.userData.pick = { kind: 'lot', k };
    cab.c.userData.pick = { kind: 'cab', k };
    const d = { kind: k, g, content, winM, cab, fog, sign, face, lit: 0, target: 0, coins: [], acc: 0, built: false, faceTxt: 'f_happy', wires: null };
    D[k] = d;
    pickables.push(g);
  });
  function ensureBuilt(d) { if (d.built) return; d.built = true; buildLot(d).then(() => { if (d.xr) xray(d, true); }); }
  // підписи районів на дошках (видно при наближенні)
  Object.values(D).forEach((d) => { const name = DEM[d.kind] ? T.d[d.kind] : d.kind === 'STATION' ? T.station : d.kind === 'DEPOT' ? T.depot : T.hall; const tg = label(name, { scale: 0.5 }); tg.position.set(0, 0.35, LOT / 2 - 0.35); d.g.add(tg); d.tag = tg; });

  /* ---------- станція ---------- */
  const st = D.STATION, genSlots = [[-1.2, -1.1], [1.2, -1.1], [-1.2, 1.2], [1.2, 1.2]];
  const gens = [];
  function addGen(i, anim) {
    const g = new THREE.Group(); g.position.set(...[genSlots[i][0], 0, genSlots[i][1]]); st.g.add(g);
    inst(i % 2 ? 'generator' : 'generator_large', 1.5, { by: 'xz' }).then((m) => { g.add(m); }).catch(() => { });
    const ch = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.17, 2.0, 16), std(0xbfc2c8, 0.6, 0.2)); ch.position.set(0.6, 1.0, -0.6); ch.castShadow = true; g.add(ch);
    const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.125, 0.125, 0.16, 16), std(0xd8463b, 0.6)); ring.position.set(0.6, 1.8, -0.6); g.add(ring);
    const hit = new THREE.Mesh(new THREE.BoxGeometry(1.8, 2.2, 1.8), new THREE.MeshBasicMaterial({ visible: false })); hit.position.y = 1.0; g.add(hit);
    g.userData.pick = { kind: 'gen', i };
    pickables.push(g);
    gens[i] = { g, ch };
    if (anim) { g.scale.setScalar(0.01); W.tween(g.scale, { x: 1, y: 1, z: 1 }, 0.9, ease.back); fx.burst(g.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, 0.5, 0)), 0xffd36b, 50, 3); }
  }
  S.gens.forEach((_, i) => addGen(i));
  const genSign = tagSprite(giSvg('settings'), '+150', { scale: 0.5 }); st.g.add(genSign);
  genSign.userData.pick = { kind: 'buyGen' }; pickables.push(genSign);
  const gauge = tagSprite(giSvg('energy'), '', { scale: 0.6 }); gauge.position.set(0, 3.4, 0); st.g.add(gauge);
  /* ---------- депо котів і мерія ---------- */
  const dep = D.DEPOT;
  const garage = new THREE.Mesh(new RoundedBoxGeometry(3.4, 1.2, 1.6, 2, 0.06), std(0x1c2b4d, 0.7)); garage.position.set(0, 0.6, -1.4); garage.castShadow = true; garage.receiveShadow = true; dep.g.add(garage);
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(3.42, 0.14, 1.62), std(0xff8a1f, 0.5)); stripe.position.set(0, 1.0, -1.4); dep.g.add(stripe);
  const logo = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.55), new THREE.MeshBasicMaterial({ map: (() => { const t = new THREE.TextureLoader().load('assets/iskra/mascot.webp'); t.colorSpace = THREE.SRGBColorSpace; return t; })(), transparent: true })); logo.position.set(0, 0.62, -0.59); dep.g.add(logo);
  const catSign = tagSprite(giSvg('paw'), '+80', { scale: 0.5 }); catSign.position.set(1.6, 1.9, 0.6); dep.g.add(catSign); catSign.userData.pick = { kind: 'buyCat' }; pickables.push(catSign);
  const hall = D.HALL;
  const hb = new THREE.Mesh(new RoundedBoxGeometry(2.6, 1.3, 1.8, 2, 0.05), std(0xeee6d8, 0.8)); hb.position.set(0, 0.65, -0.6); hb.castShadow = true; hb.receiveShadow = true; hall.g.add(hb);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.55, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), std(0x7fa7c9, 0.3, 0.6)); dome.position.set(0, 1.3, -0.6); dome.castShadow = true; hall.g.add(dome);
  const flag = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.32), new THREE.MeshStandardMaterial({ map: canvasTex(64, (x, s) => { x.fillStyle = '#2f6fd6'; x.fillRect(0, 0, s, s / 2); x.fillStyle = '#ffd400'; x.fillRect(0, s / 2, s, s / 2); }), side: THREE.DoubleSide })); flag.position.set(0.25, 2.35, -0.6); hall.g.add(flag);
  const fp = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.1, 6), poleM); fp.position.set(0, 2.0, -0.6); hall.g.add(fp);
  trees(dep.g, 2, 4, ['tree_oak'], [0.8, 1.0]); trees(hall.g, 3, 4, ['tree_oak', 'tree_fat'], [0.8, 1.1]);

  /* ---------- коти-електрики ---------- */
  const cats = [];
  const depotSpot = (i) => dep.g.position.clone().add(new THREE.Vector3(-1.4 + i * 0.7, 0, 0.3));
  function addCat(i, walkIn) {
    const o = makeCat(); o.scale.setScalar(1.25);
    o.position.copy(walkIn ? dep.g.position.clone().add(new THREE.Vector3(0, 0, -0.6)) : depotSpot(i)); o.rotation.y = 0.2;
    const hit = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.0, 0.9), new THREE.MeshBasicMaterial({ visible: false })); hit.position.y = 0.4; o.add(hit);
    const sh = blob(0.7, 0.7, 0.4); o.add(sh);
    world3.add(o);
    const c = { o, cat: o.userData.cat, state: 'idle', path: [], job: null, t: 0, i };
    o.userData.pick = { kind: 'cat', c };
    cats.push(c);
    if (walkIn) goTo(c, depotSpot(i), null);
  }
  for (let i = 0; i < S.cats; i++) addCat(i);
  function roadPath(a, b) {
    const ax = nearRoad(a.x), bz = nearRoad(b.z), bx = nearRoad(b.x);
    const pts = [new THREE.Vector3(ax, 0, a.z), new THREE.Vector3(ax, 0, bz), new THREE.Vector3(bx, 0, bz), new THREE.Vector3(b.x, 0, bz), b.clone().setY(0)];
    return pts.filter((p, i) => i === 0 || p.distanceTo(pts[i - 1]) > 0.05);
  }
  function goTo(c, dst, job) { c.path = roadPath(c.o.position, dst); c.job = job; c.state = 'walk'; c.cat.set('walk'); }
  const jobPos = (job) => job.type === 'cab' ? D[job.k].cab.c.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, 0, 0.6)) : gens[job.i].g.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, 0, 1.2));
  function nearestJob(p) {
    let best = null, bd = 2.6;
    kinds.forEach((k) => { if (!S.open[k] || !S.broken[k]) return; const q = D[k].cab.c.getWorldPosition(new THREE.Vector3()); const d = q.distanceTo(p); if (d < bd) { bd = d; best = { type: 'cab', k }; } });
    gens.forEach((g, i) => { if (!g || S.gens[i].h >= 99) return; const q = g.g.getWorldPosition(new THREE.Vector3()); const d = q.distanceTo(p); if (d < bd + 0.5) { bd = d; best = { type: 'gen', i }; } });
    return best;
  }
  // кільце прогресу ремонту
  const ringCv = document.createElement('canvas'); ringCv.width = ringCv.height = 128;
  const ringTex = new THREE.CanvasTexture(ringCv);
  const ringS = new THREE.Sprite(new THREE.SpriteMaterial({ map: ringTex, depthTest: false, transparent: true })); ringS.scale.set(1.0, 1.0, 1); ringS.visible = false; ringS.renderOrder = 12; world3.add(ringS);
  function drawRing(p) { const g = ringCv.getContext('2d'); g.clearRect(0, 0, 128, 128); g.lineWidth = 14; g.strokeStyle = 'rgba(0,0,0,.45)'; g.beginPath(); g.arc(64, 64, 48, 0, 7); g.stroke(); g.strokeStyle = '#ffd36b'; g.lineCap = 'round'; g.beginPath(); g.arc(64, 64, 48, -Math.PI / 2, -Math.PI / 2 + p * Math.PI * 2); g.stroke(); g.fillStyle = '#ffd36b'; [[64, 74, 13], [44, 50, 8], [58, 40, 8], [72, 40, 8], [86, 50, 8]].forEach(([cx, cy, r]) => { g.beginPath(); g.arc(cx, cy, r, 0, 7); g.fill(); }); ringTex.needsUpdate = true; }
  const dropRing = new THREE.Mesh(new THREE.RingGeometry(0.8, 1.0, 40), new THREE.MeshBasicMaterial({ color: new THREE.Color(2, 1.6, 0.4), transparent: true, opacity: 0.9, depthWrite: false })); dropRing.rotation.x = -Math.PI / 2; dropRing.visible = false; world3.add(dropRing);

  /* ---------- улюбленець гуляє містом ---------- */
  // улюбленець — помічник: бігає по монети й приносить їх
  let petO = null, petAnim = null, petClips = [], petPath = [], petWait = 2, petCoin = null, petProc = null;
  const petPlay = (st2) => { if (petProc) petProc.set(st2 === 'happy' ? 'jump' : st2); else if (petAnim) { const c2 = st2 === 'walk' ? clip(petClips, /^walk$/i, /walk/i) : st2 === 'run' ? clip(petClips, /^gallop$/i, /^run$/i, /walk/i) : st2 === 'happy' ? clip(petClips, /^jump_toidle$/i, /^jump$/i, /^yes$/i) : clip(petClips, /^idle$/i, /flying_idle/i, /^idle/i); if (st2 === 'happy') petAnim.play(c2, { once: true, then: () => petPlay('idle') }); else petAnim.play(c2); } };
  const petReady = (m) => { petO = m; m.position.set(-P * 0.5, 0, P * 0.5); world3.add(m); const hit = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.9, 1.2), new THREE.MeshBasicMaterial({ visible: false })); hit.position.y = 0.4; m.add(hit); m.userData.pick = { kind: 'pet' }; petPlay('idle'); };
  if (api.petModel && api.petModel.startsWith('proc:cat')) { const m = makeCat({ coat: api.petModel.split(':')[2] }); m.scale.setScalar(1.35); petProc = m.userData.cat; petReady(m); }
  else if (api.petModel) inst(api.petModel, 0.75, { tint: api.petTint }).then((m) => { petClips = m.userData.clips; petAnim = animator(m, petClips); petReady(m); }).catch(() => { });

  /* ---------- дощ і блискавка ---------- */
  const RN = 1400, rainGeo = new THREE.BufferGeometry(), rp = new Float32Array(RN * 6);
  for (let i = 0; i < RN; i++) { const x = (Math.random() - 0.5) * 40, y = Math.random() * 16, z = (Math.random() - 0.5) * 40; rp.set([x, y, z, x + 0.05, y - 0.45, z], i * 6); }
  rainGeo.setAttribute('position', new THREE.BufferAttribute(rp, 3));
  const rain = new THREE.LineSegments(rainGeo, new THREE.LineBasicMaterial({ color: 0x9fbfff, transparent: true, opacity: 0.35 })); rain.frustumCulled = false; scene.add(rain);
  const boltMat = new THREE.LineBasicMaterial({ color: new THREE.Color(5, 5, 7) }); let bolt = null, flash = 0;
  function strike(at) {
    if (bolt) scene.remove(bolt);
    const pts = []; const top = at.clone().add(new THREE.Vector3((Math.random() - 0.5) * 3, 14, (Math.random() - 0.5) * 3));
    for (let i = 0; i <= 12; i++) pts.push(top.clone().lerp(at, i / 12).add(new THREE.Vector3((Math.random() - 0.5) * 0.7 * (1 - i / 12), 0, (Math.random() - 0.5) * 0.7 * (1 - i / 12))));
    bolt = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), boltMat); scene.add(bolt);
    flash = 1; fx.burst(at.clone().add(new THREE.Vector3(0, 0.6, 0)), 0xbfd8ff, 60, 3.4); snd('zap', at); SFX('thunder', { delay: 0.3 + Math.random() * 0.7, vol: 0.9 });
  }
  // хмари
  const clouds = new THREE.Group(); scene.add(clouds);
  const cloudM = new THREE.MeshStandardMaterial({ color: 0xe8edf2, roughness: 1, transparent: true, opacity: 0.75, depthWrite: false });
  for (let i = 0; i < 9; i++) { const c = new THREE.Group(); for (let j = 0; j < 4; j++) { const s = new THREE.Mesh(new THREE.SphereGeometry(1 + Math.random() * 0.8, 16, 12), cloudM); s.position.set(j * 1.3, Math.random() * 0.4, Math.random() * 0.8); s.scale.y = 0.6; c.add(s); } c.position.set(-30 + i * 7, 24 + Math.random() * 3, -26 + Math.random() * 12); c.scale.setScalar(1.6); clouds.add(c); }

  /* ---------- HUD (мінімум) ---------- */
  hud.innerHTML = `<div class="gg" id="kTop" style="position:absolute;left:10px;top:10px;padding:7px 12px;display:flex;gap:12px;align-items:center;font:600 13px var(--fm)"></div>
    <div id="kBubble" style="position:absolute;pointer-events:none;transform:translate(-50%,-110%);display:none" class="gg"></div>
    <div id="kCoach" style="position:absolute;inset:0;pointer-events:none;display:none"><div id="kHand" style="position:absolute;filter:drop-shadow(0 6px 10px rgba(0,0,0,.5));transform:translate(-30%,-10%)">${gi('paw', 40)}</div><div id="kCoachT" class="gg" style="position:absolute;left:50%;bottom:calc(18px + env(safe-area-inset-bottom));transform:translateX(-50%);padding:10px 16px;font:600 14px var(--fb);white-space:nowrap"></div></div>
    <div id="kSplash" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;padding-bottom:12vh;background:linear-gradient(180deg,rgba(0,0,0,.05),rgba(8,10,16,.75)),url(assets/iskra/splash.jpg) center/cover;cursor:pointer">
      <img src="assets/iskra/mascot.webp" alt="" style="width:min(44vw,220px);filter:drop-shadow(0 18px 30px rgba(0,0,0,.5));animation:floatY 3s ease-in-out infinite">
      <b style="font:800 30px var(--fd);margin-top:8px;text-shadow:0 4px 18px rgba(0,0,0,.6)">${T.goal}</b>
      <span class="gsub" style="margin-top:8px;font-size:14px;animation:pulseO 1.6s ease-in-out infinite">${T.start}</span></div>
    <style>@keyframes floatY{50%{transform:translateY(-10px)}}@keyframes pulseO{50%{opacity:.4}}</style>`;
  const $ = (s) => hud.querySelector(s);
  $('#kSplash').addEventListener('click', () => { $('#kSplash').style.transition = 'opacity .6s'; $('#kSplash').style.opacity = '0'; setTimeout(() => $('#kSplash').remove(), 650); api.sfx('ok'); started = true; if (!S.coach) coachOn = true; });
  let started = false, coachOn = false;
  function float(text, p3, color = '#fff') { const s = W.screen(p3); const e = h('div', 'gfloat', esc(text)); e.style.left = s.x + 'px'; e.style.top = s.y + 'px'; e.style.color = color; hud.appendChild(e); setTimeout(() => e.remove(), 1300); }
  const supply = () => S.gens.reduce((a, g) => a + (g.h > 0 ? 40 * (0.3 + 0.7 * g.h / 100) : 0), 0);
  const curve = () => { const hh = hour(); return 0.35 + 0.25 * gauss(hh, 8, 1.6) + 0.15 * gauss(hh, 13, 3) + 0.65 * gauss(hh, 20, 2.4); };
  let lastHud = '';
  function drawHud(dem, sup, avg) {
    const hh = hour(), night = hh >= 20 || hh < 6;
    const txt = `${gi('coin', 18)} ${Math.floor(S.coins)}|${gi(night ? 'moon' : 'w_sun', 18)} ${String(Math.floor(hh)).padStart(2, '0')}:${String(Math.floor((hh % 1) * 60 / 10) * 10).padStart(2, '0')}${S.storm ? ' ' + gi('storm', 18) : S.stormNext && hh > 14 ? ' ' + gi('w_cloud', 16) + '→' + gi('storm', 16) : ''}|${gi('energy', 18)} ${Math.round(dem)}/${Math.round(sup)}|${gi('star', 18)} ${Math.round(avg)}%|${T.day} ${S.day}`;
    if (txt === lastHud) return; lastHud = txt;
    const [a, b, c2, d2, e2] = txt.split('|');
    $('#kTop').innerHTML = `<span>${a}</span><span>${b}</span><span style="color:${dem > sup ? '#ff8a7a' : '#9fe39a'}">${c2}</span><span>${d2}</span><span class="gsub" style="font-size:11px">${e2}</span>`;
  }
  // вікно-підказка при затисканні (деталі)
  let bubbleT = 0, bubbleAt = null;
  function bubble(p3, html) { const e = $('#kBubble'); e.innerHTML = html; e.style.display = ''; e.style.padding = '10px 14px'; e.style.font = '500 13px var(--fb)'; e.style.lineHeight = '1.45'; bubbleAt = p3.clone(); bubbleT = 3.2; }

  /* ---------- рентген району (затисни) ---------- */
  function xray(d, on) {
    d.xr = on;
    d.content.traverse((m) => { if (m.isMesh && m.material && !m.isInstancedMesh) { m.material.transparent = on; m.material.opacity = on ? 0.22 : 1; m.material.depthWrite = !on; } });
    if (on && !d.wires) {
      const pts = []; const c0 = d.cab.c.position.clone().add(new THREE.Vector3(0, 0.7, 0));
      d.content.children.forEach((ch) => { const p = ch.position.clone(); pts.push(c0.x, c0.y, c0.z, c0.x, 0.15, p.z, c0.x, 0.15, p.z, p.x, 0.15, p.z, p.x, 0.15, p.z, p.x, 1.0, p.z); });
      const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
      d.wires = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: new THREE.Color(3, 2.2, 0.4) })); d.g.add(d.wires);
    }
    if (d.wires) d.wires.visible = on;
  }

  /* ---------- дотики ---------- */
  let carried = null;
  cam.onDown = (e) => {
    if (!started || S.lost) return;
    const hit = W.pick(e, cats.map((c) => c.o));
    if (hit && hit.obj.userData.pick.c && hit.obj.userData.pick.c.state !== 'repair') {
      carried = hit.obj.userData.pick.c; cam.grab(e);
      carried.state = 'carried'; carried.cat.set('carried'); carried.path = []; carried.job = null;
      api.sfx('pop'); coachOn = false; S.coach = true;
    }
  };
  cam.onMove = (e) => {
    if (!carried) return;
    const g = cam.ground(e.clientX, e.clientY); if (!g) return;
    carried.o.position.set(g.x, 1.3, g.z);
    const j = nearestJob(g);
    const lotK = !j && kinds.find((k) => S.open[k] && D[k].coins.length && Math.abs(g.x - D[k].g.position.x) < LOT / 2 && Math.abs(g.z - D[k].g.position.z) < LOT / 2);
    dropRing.visible = !!(j || lotK); if (j) { dropRing.position.copy(jobPos(j)).setY(0.05); dropRing.scale.setScalar(1); } else if (lotK) { dropRing.position.copy(D[lotK].g.position).setY(0.05); dropRing.scale.setScalar(2.6); }
  };
  cam.onUp = (e) => {
    if (!carried) return;
    const c = carried; carried = null; dropRing.visible = false;
    const g = cam.ground(e.clientX, e.clientY) || c.o.position.clone();
    c.o.position.set(g.x, 0, g.z);
    const j = nearestJob(g);
    const lotK = kinds.find((k) => S.open[k] && Math.abs(g.x - D[k].g.position.x) < LOT / 2 + 0.6 && Math.abs(g.z - D[k].g.position.z) < LOT / 2 + 0.6);
    if (j) { goTo(c, jobPos(j), j); api.sfx('ok'); SFX('mew'); }
    else if (lotK && D[lotK].coins.length) { const job = { type: 'collect', k: lotK }; D[lotK].coins.forEach((co) => co.taken = 'cat'); goTo(c, D[lotK].g.position.clone().add(new THREE.Vector3(LOT / 2 + 0.35, 0, 0.4)), job); api.sfx('ok'); }
    else { c.state = 'idle'; c.cat.set('idle'); setTimeout(() => { if (c.state === 'idle') goTo(c, depotSpot(c.i), null); }, 2500); }
  };
  cam.onTap = (e) => {
    if (!started) return;
    if (S.lost) { S = fresh(); S.coach = true; save(); location.hash = location.hash; api.exit(); return; }
    // монети
    const coinHit = W.pick(e, Object.values(D).flatMap((d) => d.coins || []).map((c) => c.o));
    if (coinHit) { const co = coinHit.obj.userData.pick.co; collect(co); return; }
    const hit = W.pick(e, [...pickables, ...(petO ? [petO] : [])]); if (!hit) return;
    const u = hit.obj.userData.pick;
    if (u.kind === 'cab') toggle(u.k);
    else if (u.kind === 'lot') { const d = D[u.k]; if (!S.open[u.k]) unlock(u.k); else { cam.flyTo(d.g.position.clone(), 13); api.sfx('tap'); } }
    else if (u.kind === 'gen') { cam.flyTo(st.g.position.clone(), 12); api.sfx('tap'); }
    else if (u.kind === 'buyGen') buyGen();
    else if (u.kind === 'buyCat') buyCat();
    else if (u.kind === 'pet') { petPlay('happy'); if (petProc) setTimeout(() => petPlay('idle'), 800); api.pet('happy'); api.sfx('pop'); fx.burst(petO.position.clone().add(new THREE.Vector3(0, 1, 0)), 0xff7fa8, 16, 1.4); }
    else if (u.kind === 'cat') { api.sfx('pop'); }
  };
  cam.onHold = (e) => {
    const hit = W.pick(e, [...pickables, ...cats.map((c) => c.o)]); if (!hit) return;
    const u = hit.obj.userData.pick; api.sfx('tap');
    if (u.kind === 'lot' || u.kind === 'cab') {
      const k = u.k, d = D[k]; if (!S.open[k]) return;
      const st2 = S.broken[k] ? T.broken : S.off[k] ? T.off : d.target ? T.ok : T.dark;
      bubble(d.g.position.clone().add(new THREE.Vector3(0, 3.4, 0)), `<b>${T.d[k]}</b><br>${T.demand}: ${Math.round(DEM[k] * curve())} MW<br>${T.rep}: ${Math.round(S.rep[k])}%<br>${st2}`);
      xray(d, true); clearTimeout(d.xrT); d.xrT = setTimeout(() => xray(d, false), 3200);
    } else if (u.kind === 'gen') {
      const g = S.gens[u.i]; bubble(gens[u.i].g.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, 2.6, 0)), `<b>${gi('settings', 16)} #${u.i + 1}</b><br>${T.health}: ${Math.round(g.h)}%<br>${T.out}: ${Math.round(g.h > 0 ? 40 * (0.3 + 0.7 * g.h / 100) : 0)} MW`);
    } else if (u.kind === 'cat') { bubble(u.c.o.position.clone().add(new THREE.Vector3(0, 1.4, 0)), `<b>${gi('paw', 16)} #${u.c.i + 1}</b><br>${T[u.c.state] || T.idle}`); }
  };
  function toggle(k) {
    if (!S.open[k]) return;
    if (S.broken[k]) { float('?', D[k].cab.c.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, 1.2, 0)), '#ffd36b'); api.sfx('bad'); return; }
    S.off[k] = !S.off[k]; snd('switch', D[k].cab.c.getWorldPosition(new THREE.Vector3())); snd(S.off[k] ? 'powerDown' : 'powerUp', D[k].g.position, 0.8, 0.08);
    W.tween(D[k].cab.pivot.rotation, { z: S.off[k] ? -1.1 : 0 }, 0.35, ease.back);
    save();
  }
  function collect(co, by) {
    const d = co.d; if (!d.coins.includes(co)) return; d.coins.splice(d.coins.indexOf(co), 1);
    if (by) { const o = co.o; W.tween(o.position, { x: by.x, y: by.y + 0.6, z: by.z }, 0.35, ease.inOut, () => world3.remove(o)); } else world3.remove(co.o);
    S.coins += co.v; api.sfx('coin'); fx.burst(co.o.position.clone(), 0xffd36b, 18, 2);
    float(`+${co.v}`, co.o.position.clone(), '#ffd36b');
    if (Math.random() < 0.25) api.coins(1);
  }
  const unlockCost = () => 90 + S.unlocked * 40;
  function unlock(k) {
    const cost = unlockCost(), d = D[k];
    if (S.coins < cost) { float(`${T.coins} · ${cost}`, d.g.position.clone().add(new THREE.Vector3(0, 2.6, 0)), '#ff9a8a'); api.sfx('bad'); W.tween(d.sign.position, { y: 2.5 }, 0.15, ease.out, () => W.tween(d.sign.position, { y: 2.2 }, 0.3, ease.back)); return; }
    S.coins -= cost; S.open[k] = true; S.rep[k] = 60; S.unlocked++; save();
    ensureBuilt(d);
    d.content.scale.set(1, 0.01, 1); W.tween(d.content.scale, { y: 1 }, 1.2, ease.back);
    W.tween(d.fog.scale, { x: 0.01, y: 0.01, z: 0.01 }, 0.6, ease.out, () => { d.fog.visible = false; });
    fx.burst(d.g.position.clone().add(new THREE.Vector3(0, 1, 0)), 0xffd36b, 80, 4); snd('build', d.g.position); snd('powerUp', d.g.position, 0.8, 0.75); api.pet('happy');
    cam.flyTo(d.g.position.clone(), 14);
  }
  function buyGen() {
    if (S.gens.length >= 4) return;
    if (S.coins < 150) { float(`${T.coins} · 150`, genSign.getWorldPosition(new THREE.Vector3()), '#ff9a8a'); api.sfx('bad'); return; }
    S.coins -= 150; S.gens.push({ h: 100 }); addGen(S.gens.length - 1, true); snd('build', st.g.position); snd('crank', st.g.position, 1, 0.7); save();
  }
  function buyCat() {
    if (S.cats >= 6) return;
    if (S.coins < 80) { float(`${T.coins} · 80`, catSign.getWorldPosition(new THREE.Vector3()), '#ff9a8a'); api.sfx('bad'); return; }
    S.coins -= 80; S.cats++; addCat(S.cats - 1, true); api.sfx('ok'); SFX('meow'); save();
  }

  /* ---------- інспекція ---------- */
  let inspector = null;
  function inspection() {
    inst('police_car', 1.1, { by: 'xz', tint: '#333333' }).then((m) => {
      inspector = { o: m, path: roadPath(new THREE.Vector3(-14, 0, 14), hall.g.position.clone().add(new THREE.Vector3(0, 0, 1.3))), done: false };
      m.position.set(-14, 0, 14); world3.add(m); float(T.insp, hall.g.position.clone().add(new THREE.Vector3(0, 3, 0)), '#ffd36b');
    }).catch(() => { });
  }

  /* ---------- кадр ---------- */
  let tick = 0, saveT = 0, avgRep = 65, demNow = 0, supNow = 0;
  const v3 = new THREE.Vector3();
  W.onResize = () => { camera.fov = W.size().W / W.size().H < 0.75 ? 42 : 34; camera.updateProjectionMatrix(); };
  // райони, що вже відкриті, будуємо одразу
  kinds.forEach((k) => { if (S.open[k]) { ensureBuilt(D[k]); D[k].fog.visible = false; } });
  W.onFrame((dt, tm) => {
    const run = started && !S.lost;
    if (run) S.t += dt / DAYLEN;
    if (S.t >= 1) {
      S.t -= 1; S.day++; S.storm = S.stormNext; S.stormNext = Math.random() < 0.35;
      float(`${T.day} ${S.day}${S.storm ? ' · ' + T.storm : ''}`, cam.target.clone().add(new THREE.Vector3(0, 3, 0))); snd('bell', hall ? hall.g.position : null, 0.8);
      if (S.day % 2 === 0) inspection();
      save();
    }
    const hh = hour(), night = hh >= 20 || hh < 6, dusk = gauss(hh, 19.5, 1.2) + gauss(hh, 6.5, 0.8);
    const sunA = ((hh - 6) / 12) * Math.PI;
    sun.position.set(Math.cos(sunA) * 20 + cam.target.x, Math.max(2, Math.sin(sunA) * 22), -8 + cam.target.z); sun.target.position.copy(cam.target);
    const dayK = THREE.MathUtils.clamp(Math.sin(sunA) * 1.6, 0, 1);
    const stormK = S.storm && hh > 10 ? 0.5 : 0;
    // день і ніч: уночі світить місяць (холодне світло), небо й навколишнє освітлення темніють, вмикаються ліхтарі
    if (dayK > 0.02) { sun.intensity = 2.4 * dayK * (1 - stormK); sun.color.setRGB(1, 0.86 + 0.14 * dayK, 0.72 + 0.28 * dayK); }
    else { sun.intensity = 0.45; sun.color.setRGB(0.55, 0.65, 1); sun.position.set(cam.target.x - 8, 24, cam.target.z + 4); }
    hemi.intensity = 0.1 + 0.75 * dayK * (1 - stormK * 0.6);
    scene.environmentIntensity = 0.1 + 0.3 * dayK * (1 - stormK * 0.5);
    W.renderer.toneMappingExposure = 0.82 + 0.18 * dayK;
    if (stars) stars.material.opacity = THREE.MathUtils.clamp(1 - dayK * 3, 0, 1) * (stormK ? 0.2 : 0.9);
    lampBulb.emissiveIntensity = THREE.MathUtils.clamp(1 - dayK * 2.5, 0, 1) * 2.6;
    if (scene.fog) scene.fog.color.set(night ? 0x0a1020 : dusk > 0.35 ? 0x3b2f4a : stormK ? 0x2f3640 : 0x3a5170);
    if (night) sky('#0d1730', '#0a1020'); else if (dusk > 0.35) sky('#e08a5a', '#3b2f4a'); else if (stormK) sky('#56606e', '#2f3640'); else sky('#7fb0dc', '#3a5170');
    const nk = THREE.MathUtils.clamp(1 - dayK * 1.4, 0, 1);
    W.bloom.strength = 0.06 + 0.5 * nk;
    // кожні 0,5 с — баланс мережі
    tick += dt;
    if (tick > 0.5 && run) {
      const step = tick; tick = 0;
      const cur = curve(), sup = supply();
      const cand = kinds.filter((k) => S.open[k] && !S.broken[k] && !S.off[k]).sort((a, b) => DEM[b] - DEM[a]);
      let dem = cand.reduce((a, k) => a + DEM[k] * cur, 0); const shed = new Set();
      for (const k of cand) { if (dem <= sup) break; shed.add(k); dem -= DEM[k] * cur; }
      demNow = kinds.filter((k) => S.open[k] && !S.off[k]).reduce((a, k) => a + DEM[k] * cur, 0); supNow = sup;
      let sum = 0, n = 0;
      kinds.forEach((k) => {
        if (!S.open[k]) return; const d = D[k];
        const lit = !S.broken[k] && !S.off[k] && !shed.has(k);
        d.target = lit ? 1 : 0;
        const need = night || dusk > 0.3 ? 1 : 0.4;
        S.rep[k] = THREE.MathUtils.clamp(S.rep[k] + step * (lit ? 0.25 : S.off[k] ? -0.3 * need : S.broken[k] ? -0.7 * need : -1.3 * need), 0, 100);
        if (lit) { d.acc += INC[k] * cur * step; if (d.acc >= 10 && d.coins.length < 3) { d.acc -= 10; spawnCoin(d, 10); } }
        // поломки
        if (!S.broken[k] && Math.random() < step * (S.storm ? 0.012 : 0.0025)) { S.broken[k] = true; if (S.storm) strike(d.cab.c.getWorldPosition(new THREE.Vector3())); }
        sum += S.rep[k]; n++;
      });
      avgRep = n ? sum / n : 0;
      S.gens.forEach((g, i) => { g.h = Math.max(0, g.h - step * 0.05 * (dem / Math.max(1, sup) + 0.3)); if (S.storm && Math.random() < step * 0.006) { g.h = Math.max(0, g.h - 30); strike(gens[i].g.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, 1.5, 0))); } });
    }
    drawHud(demNow, supNow, avgRep);
    saveT += dt; if (saveT > 6) { saveT = 0; save(); }
    // райони: вікна, щитки, обличчя
    kinds.forEach((k) => {
      const d = D[k], open = S.open[k];
      d.sign.visible = !open; if (open && d.fog.scale.x >= 1) d.fog.visible = false;
      if (!open) { d.sign.position.y = 2.2 + Math.sin(tm * 2 + d.g.position.x) * 0.08; return; }
      d.lit += (d.target * (nk > 0.05 ? 1 : 0.3) - d.lit) * Math.min(1, dt * 3);
      const fl = S.broken[k] && Math.random() < 0.06 ? 0.7 : 0;
      const L2 = Math.max(d.lit * nk, fl * nk);
      d.winM.color.setRGB(0.05 + 2.6 * L2, 0.055 + 1.9 * L2, 0.07 + 1.0 * L2);
      if (d.panes) d.panes.visible = nk > 0.05;
      d.cab.lamp.material.color.setRGB(S.broken[k] ? (Math.sin(tm * 10) > 0 ? 3 : 0.3) : S.off[k] ? 2.5 : 0.2, S.broken[k] || S.off[k] ? 0.2 : 2.5, 0.2);
      if (S.broken[k] && Math.random() < dt * 0.9) snd('spark', d.cab.c.getWorldPosition(new THREE.Vector3()), 0.7);
      if (S.broken[k] && Math.random() < dt * 6) fx.burst(d.cab.c.getWorldPosition(v3).add(new THREE.Vector3(0, 0.75, 0.1)), 0xffe08a, 4, 1.6, 0.4, 5);
      const r = S.rep[k], ft = r >= 66 ? 'f_happy' : r >= 40 ? 'f_ok' : 'f_sad';
      if (ft !== d.faceTxt) { d.faceTxt = ft; d.face.material.map.dispose(); const nl = tagSprite(giSvg(ft), '', { scale: 0.55, bg: false }); d.face.material = nl.material; }
      d.face.position.y = 3.0 + Math.sin(tm * 1.5 + d.g.position.z) * 0.06;
      if (d.chimneys && d.target && Math.random() < dt * 4) d.chimneys.forEach((c) => fx.burst(c.getWorldPosition(v3).add(new THREE.Vector3(0, 0.95, 0)), 0x9aa0aa, 1, 0.3, 2.5, -0.5));
      d.coins.forEach((co) => { co.o.rotation.y += dt * 3; co.o.position.y = co.y + Math.sin(tm * 3 + co.y) * 0.1; co.life -= dt; if (co.life <= 0) { d.coins.splice(d.coins.indexOf(co), 1); world3.remove(co.o); } });
    });
    bulbs.material.color.setRGB(0.2 + 2.6 * nk, 0.2 + 2.1 * nk, 0.2 + 1.2 * nk);
    // генератори: дим і стан
    gens.forEach((g, i) => { if (!g) return; const hh2 = S.gens[i].h; if (Math.random() < dt * (hh2 < 40 ? 8 : 3)) fx.burst(g.ch.getWorldPosition(v3).add(new THREE.Vector3(0, 1.05, 0)), hh2 < 40 ? 0x3a3a3a : 0x9aa0aa, 1, 0.3, 2.6, -0.6); if (hh2 < 25 && Math.random() < dt * 4) fx.burst(g.g.getWorldPosition(v3).add(new THREE.Vector3(0, 0.8, 0)), 0xffd06b, 3, 1.4, 0.4, 5); });
    genSign.visible = S.gens.length < 4; if (genSign.visible) { const sl = genSlots[S.gens.length]; genSign.position.set(sl[0], 1.4 + Math.sin(tm * 2) * 0.08, sl[1]); }
    catSign.visible = S.cats < 6;
    // коти
    cats.forEach((c) => {
      c.cat.update(dt);
      if (c.state === 'walk' && c.path.length) {
        const tgt = c.path[0]; const dv = tgt.clone().sub(c.o.position); dv.y = 0; const dist = dv.length();
        if (dist < 0.06) { c.path.shift(); if (!c.path.length) arrive(c); }
        else { const want = Math.atan2(dv.x, dv.z); let df = want - c.o.rotation.y; df = Math.atan2(Math.sin(df), Math.cos(df)); c.o.rotation.y += df * Math.min(1, dt * 10); c.o.position.addScaledVector(dv.normalize(), Math.min(dist, dt * 2.6)); }
      }
      if (c.state === 'repair') {
        c.t += dt; if ((c.rt = (c.rt || 0) - dt) <= 0) { c.rt = 0.9; snd('ratchet', c.o.position, 0.55); } const dur = c.job.type === 'cab' ? 4 : 5; ringS.visible = true; ringS.position.copy(c.o.position).add(new THREE.Vector3(0, 1.7, 0)); drawRing(c.t / dur);
        if (Math.random() < dt * 10) fx.burst(c.o.position.clone().add(new THREE.Vector3(0, 0.6, 0.3).applyAxisAngle(new THREE.Vector3(0, 1, 0), c.o.rotation.y)), 0xfff2a0, 3, 1.8, 0.35, 5);
        if (c.t >= dur) { if (c.job.type === 'cab') { S.broken[c.job.k] = false; } else { S.gens[c.job.i].h = Math.min(100, S.gens[c.job.i].h + 45); } ringS.visible = false; fx.burst(c.o.position.clone().add(new THREE.Vector3(0, 1, 0)), 0x9fe39a, 40, 2.4); api.sfx('ok'); snd('powerUp', c.o.position, 0.8); api.coins(1); goTo(c, depotSpot(c.i), null); save(); }
      }
    });
    if (!cats.some((c) => c.state === 'repair')) ringS.visible = false;
    // улюбленець гуляє дорогами
    if (petO) {
      if (petAnim) petAnim.update(dt); if (petProc) petProc.update(dt);
      if (!petPath.length) {
        petWait -= dt;
        if (petWait <= 0 && run) {
          // найближча монета — туди; інакше прогулянка
          let best = null, bd = 1e9; Object.values(D).forEach((d) => (d.coins || []).forEach((co) => { if (co.taken) return; const q = co.o.position.distanceTo(petO.position); if (q < bd) { bd = q; best = co; } }));
          if (best) { petCoin = best; best.taken = 'pet'; petPath = roadPath(petO.position, best.o.position.clone().setY(0)); petPlay('run'); }
          else { const k = kinds.filter((x) => S.open[x]); const d = D[k[(Math.random() * k.length) | 0]]; petPath = roadPath(petO.position, d.g.position.clone().add(new THREE.Vector3(LOT / 2 + 0.3, 0, 0))); petPlay('walk'); }
        }
      } else {
        const tg = petPath[0], dv = tg.clone().sub(petO.position); dv.y = 0; const dist = dv.length();
        if (dist < 0.08) { petPath.shift(); if (!petPath.length) { petWait = petCoin ? 0.6 : 3 + Math.random() * 3; if (petCoin && petCoin.d.coins.includes(petCoin)) { collect(petCoin, petO.position); petPlay('happy'); } else petPlay('idle'); petCoin = null; } }
        else { const want = Math.atan2(dv.x, dv.z); let df = want - petO.rotation.y; df = Math.atan2(Math.sin(df), Math.cos(df)); petO.rotation.y += df * Math.min(1, dt * 8); petO.position.addScaledVector(dv.normalize(), Math.min(dist, dt * (petCoin ? 3.0 : 1.4))); }
      }
    }
    // інспектор
    if (inspector) {
      const o = inspector.o, tg = inspector.path[0];
      if (tg) { const dv = tg.clone().sub(o.position); dv.y = 0; const dist = dv.length(); if (dist < 0.1) inspector.path.shift(); else { o.rotation.y = Math.atan2(dv.x, dv.z); o.position.addScaledVector(dv.normalize(), Math.min(dist, dt * 4)); } }
      else if (!inspector.done) {
        inspector.done = true; const ok = avgRep >= 50; snd('horn', o.position, 0.8);
        float(ok ? T.pass : T.fail, hall.g.position.clone().add(new THREE.Vector3(0, 3.2, 0)), ok ? '#9fe39a' : '#ff8a7a');
        if (ok) { api.sfx('win', { delay: 0.5 }); S.coins += 100; fx.burst(hall.g.position.clone().add(new THREE.Vector3(0, 2.5, 0)), 0xffd36b, 120, 5); api.pet('happy'); api.coins(5); S.fails = 0; }
        else { S.fails++; api.sfx('bad'); if (S.fails >= 2) { S.lost = true; float(`${T.closed} · ${T.again}`, cam.target.clone().add(new THREE.Vector3(0, 3, 0)), '#ff8a7a'); } }
        setTimeout(() => { if (inspector) { world3.remove(inspector.o); inspector = null; } }, 2500); save();
      }
    }
    // буря
    rain.visible = S.storm && hh > 10; rain.position.set(cam.target.x, 0, cam.target.z);
    if (rain.visible) { const a = rainGeo.attributes.position.array; for (let i = 0; i < RN; i++) { let y = a[i * 6 + 1] - dt * 18; if (y < 0) y += 16; a[i * 6 + 1] = y; a[i * 6 + 4] = y - 0.45; } rainGeo.attributes.position.needsUpdate = true; if (Math.random() < dt * 0.15) flash = 0.6; }
    cloudM.color.setRGB(S.storm ? 0.35 : 0.92, S.storm ? 0.38 : 0.94, S.storm ? 0.42 : 0.96);
    clouds.children.forEach((c, i) => { c.position.x += dt * (0.4 + i * 0.03); if (c.position.x > 34) c.position.x = -34; });
    if (flash > 0) { flash -= dt * 3; hemi.intensity += flash * 3; if (flash <= 0 && bolt) { scene.remove(bolt); bolt = null; } }
    water.material.color.setRGB(0.11 + 0.05 * Math.sin(tm), 0.37, 0.52);
    if ((sndT += dt) > 0.066) { const sdt = sndT; sndT = 0; soundFrame(sdt, dayK, run, !!(S.storm && hh > 10)); }
    // бульбашка з деталями
    if (bubbleT > 0) { bubbleT -= dt; const s = W.screen(bubbleAt); const e = $('#kBubble'); e.style.left = s.x + 'px'; e.style.top = s.y + 'px'; if (bubbleT <= 0) e.style.display = 'none'; }
    // навчання рукою: від кота до зламаного щитка
    const coach = $('#kCoach');
    if (coachOn && cats[0]) {
      const bk = kinds.find((k) => S.open[k] && S.broken[k]);
      if (bk) { coach.style.display = ''; $('#kCoachT').textContent = T.coach; const a = W.screen(cats[0].o.position.clone().add(new THREE.Vector3(0, 0.5, 0))), b = W.screen(D[bk].cab.c.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, 0.5, 0))); const k2 = (tm % 2.2) / 1.6; const q = Math.min(1, k2); $('#kHand').style.left = (a.x + (b.x - a.x) * ease.inOut(q)) + 'px'; $('#kHand').style.top = (a.y + (b.y - a.y) * ease.inOut(q)) + 'px'; $('#kHand').style.opacity = k2 > 1.2 ? 0 : 1; }
      else coach.style.display = 'none';
    } else coach.style.display = 'none';
  });
  /* ---------- звук: генератори, станція, місто ---------- */
  let sndT = 0; const GEN_SND = [];
  const stHum = SND.loop('hum', { vol: 0 });
  function soundFrame(dt, dayK, run, storm) {
    const load = clamp01(demNow / Math.max(1, supNow));
    gens.forEach((g, i) => {
      if (!g || !S.gens[i]) return;
      if (!GEN_SND[i]) GEN_SND[i] = SND.loop('engine', { size: 'gen', rpm: 0, load: 0, vol: 0 });
      const h2 = S.gens[i].h, p = sp3(g.g.getWorldPosition(new THREE.Vector3()), 0.8);
      GEN_SND[i].set({ rpm: 0.3, load: run ? 0.3 + 0.6 * load : 0.1, vol: run && h2 > 0 ? p.vol : 0, pan: p.pan });
      if (run && h2 < 25 && Math.random() < dt * 0.6) snd('stall', g.g.getWorldPosition(new THREE.Vector3()), 0.6); // хворий генератор чхає
    });
    if (stHum) { const p = sp3(st.g.position, 0.7); stHum.set({ vol: run ? p.vol * (0.4 + 0.6 * load) : 0, pan: p.pan }); }
    const nightK = clamp01(1 - dayK * 3);
    SND.amb.set('city', run ? 0.45 + 0.55 * dayK : 0.4);
    SND.amb.set('birds', run ? dayK * (storm ? 0.1 : 0.45) : 0.2);
    SND.amb.set('crickets', run ? nightK * (storm ? 0.2 : 0.6) : 0);
    SND.amb.set('rain', storm ? 1 : 0, { intensity: 0.9 });
    SND.amb.set('wind', storm ? 0.8 : 0.25, { strength: storm ? 0.9 : 0.3 });
    SND.amb.tick(dt);
  }
  const clamp01 = (v) => Math.max(0, Math.min(1, v));
  function spawnCoin(d, v) {
    const o = new THREE.Group(); const p = d.g.position.clone().add(new THREE.Vector3((Math.random() - 0.5) * 2.4, 0, (Math.random() - 0.5) * 2.4));
    o.position.copy(p); const y = 2.2 + Math.random() * 0.6; o.position.y = y; world3.add(o);
    inst('coin', 0.55, { by: 'max' }).then((m) => { m.position.y = -0.27; o.add(m); }).catch(() => { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.05, 20), std(0xffd36b, 0.3, 1)); c.rotation.x = Math.PI / 2; o.add(c); });
    const hit = new THREE.Mesh(new THREE.SphereGeometry(0.6, 8, 6), new THREE.MeshBasicMaterial({ visible: false })); o.add(hit);
    const co = { o, v, y, life: 30, d }; o.userData.pick = { kind: 'coin', co }; d.coins.push(co); api.sfx('coinpop');
  }
  function arrive(c) {
    if (c.job && c.job.type === 'collect') {
      const d = D[c.job.k]; c.cat.set('paw'); let n = 0;
      [...d.coins].forEach((co, i) => setTimeout(() => { collect(co, c.o.position); n++; }, 180 * i));
      setTimeout(() => { c.cat.set('jump'); api.coins(1); setTimeout(() => goTo(c, depotSpot(c.i), null), 700); }, 180 * d.coins.length + 300);
      c.state = 'collect'; return;
    }
    if (c.job) { c.state = 'repair'; c.t = 0; c.cat.set('repair'); const tp = jobPos(c.job); const lookAt = c.job.type === 'cab' ? D[c.job.k].cab.c.getWorldPosition(new THREE.Vector3()) : gens[c.job.i].g.getWorldPosition(new THREE.Vector3()); c.o.rotation.y = Math.atan2(lookAt.x - c.o.position.x, lookAt.z - c.o.position.z); }
    else { c.state = 'idle'; c.cat.set('idle'); c.o.rotation.y = 0.2; }
  }

  root._dbg = { scr: (o) => W.screen(o.getWorldPosition(new THREE.Vector3())), S: () => S, start: () => $('#kSplash') && $('#kSplash').click(), cats, D, cam };
  W.onDispose(() => save());
  return { destroy: () => { SND.stop(); W.destroy(); } };
}
