// ФЕРМА 3D — третя версія: від грядки до заводу, по етапах.
// Ідея сина лишилась (боби, лабораторія мутацій, ворони, ярмарок, що реагує на погоду),
// а навколо виросла справжня ферма:
//  1) город руками → 2) трактор і культиватор → 3) сівалка, комбайн, вагова →
//  4) догляд за технікою (пальне, мастило, мийка, ремонт) → 5) амбар і переробка →
//  6) своя енергія (вітряки, сонячні панелі, біоетанол) → 7) дім і відпочинок → 8) велика ферма.
// Керування — руками на сцені: тягнеш техніку на поле, ящик на грядку, мішок на сівалку;
// утримуєш табличку — купуєш; проводиш пальцем — збираєш, миєш, закидаєш вудку.
import { world, rig, THREE, RoundedBoxGeometry, speckle, std, glass, label, particles, h, esc, canvasTex, ease, tagSprite } from '../kit.js';
import { inst, clip, animator } from '../models.js';
import { makeCat } from '../catcrew.js';
import { sfx as SFX, soundScope, spatial } from '../sound.js';
import { gi, giSvg } from '../icons.js';
import * as D from './farm/data.js';
import * as B from './farm/build.js';
import { texts, fmt } from './farm/text.js';

const V3 = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
const clamp = THREE.MathUtils.clamp;
const IW = 31, ID = 33;
// розкладка ферми (центр острова — 0,0; камера дивиться з +Z)
const P = {
  house: [-10.7, 9.1], stall: [-0.4, 9.7], lab: [4.1, 9.0], hammock: [-5.9, 13.3], pond: [-11.3, 13.8], gazebo: [-1.8, 14.0],
  hangar: [2.0, -1.6], fuel: [6.1, 0.0], wash: [6.0, -2.9], oilcan: [-1.5, 3.0], jerry: [-0.6, 3.0], bucket: [-2.4, 3.0], city: [7.9, 14.6], rack: [2.0, 7.3], fertshed: [5.7, -8.4],
  barn: [-4.7, -2.0], weigh: [-9.6, 1.6], elevator: [-11.8, -2.6], dispatch: [-3.0, -5.4],
  oilmill: [-11.4, -8.6], groatsmill: [-7.0, -8.6], feedmill: [-2.6, -8.6], bioplant: [1.8, -8.6],
  wind: [[-12.6, -14.2], [-9.4, -14.2], [-6.2, -14.2]], solar: [[-1.8, -14.0], [2.8, -14.0]],
  park: { tractor: [0.6, -1.6], combine: [3.4, -1.6], truck: [-8.0, -2.0], jeep: [-13.4, 5.0] },
  att: { cultivator: [-0.9, 5.0], seeder: [1.5, 5.0], sprayer: [3.9, 5.0], irrigator: [6.3, 5.0] },
  fields: [[11.4, 7.1], [11.4, 0.7], [11.4, -5.7], [11.4, -12.1]] // перше поле — найближче до двору
};
const FS = 5.6, FH = FS / 2;
const BEDS = 12, BCOLS = 4;
const bedPos = (i) => V3(-7.7 + (i % BCOLS) * 1.5, 0, 3.3 + ((i / BCOLS) | 0) * 1.5);
const keyOf = (type, mut) => (mut ? `${type}:${mut}` : type);
const split = (k) => { const [type, mut] = k.split(':'); return { type, mut }; };
const beanSvg = (c, s = 16) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" class="gi"><ellipse cx="12" cy="12" rx="6.5" ry="9" transform="rotate(-28 12 12)" fill="${c}" stroke="rgba(0,0,0,.5)" stroke-width="1"/><ellipse cx="10" cy="8.5" rx="2.2" ry="3.4" transform="rotate(-28 10 8.5)" fill="#fff" opacity=".45"/></svg>`;
const WEATHER = { sun: { grow: 1, price: 1, evap: 0.45, wind: 0.6, sunF: 1, sky: 0x9fd2f5 }, rain: { grow: 1.3, price: 0.85, evap: -1.4, wind: 0.9, sunF: 0.25, sky: 0x7d8fa0 }, heat: { grow: 0.8, price: 1.3, evap: 0.9, wind: 0.3, sunF: 1.15, sky: 0xf2c58c }, cloud: { grow: 1, price: 1, evap: 0.25, wind: 1, sunF: 0.55, sky: 0xa9b8c6 } };
const WK = Object.keys(WEATHER);

export function mount(root, api) {
  const { T, N, lang } = texts(api.lang);
  const W = world(root, { quality: api.quality, bg: 0x9fd2f5, envI: 0.45, bloom: 0.12, bloomTh: 0.96, tilt: 0.12, exposure: 1.0 });
  const { scene } = W;
  const fx = particles(W, 900);
  const cam = rig(W, { target: V3(-6.6, 0, 5.2), dist: 24, pitch: 0.98, yaw: 0, limits: { min: 7, max: 46, box: 15.5, pmin: 0.55, pmax: 1.35 } });
  let lastAsp = 0;
  // звук: усе, що звучить у світі, — з його місця (панорама й відстань до камери)
  const SND = soundScope(), sp3 = spatial(W, 18);
  const snd = (k, p, x = 1, d = 0) => SFX(k, p ? { ...sp3(p, x), delay: d } : { delay: d });
  const PETV = ((m) => (m.includes('cat') ? 'meow' : m.includes('fox') ? 'yip' : m.includes('frog') ? 'ribbit' : /dino|dragon|trike/.test(m) ? 'roar' : m.includes('deer') ? 'bleat' : 'bark'))(api.petModel || '');
  function fitCam() { const { W: w, H: hh } = W.size(); const a = w / Math.max(1, hh); if (Math.abs(a - lastAsp) < 0.05) return; lastAsp = a; cam.set({ dist: a < 1 ? clamp(14 / Math.max(0.42, a), 22, 32) : 19 }); }

  /* ================= стан ================= */
  const fresh = () => ({
    v: 3, coins: 80, day: 1, tod: 0.06, weather: 'sun', next: 'cloud', stamina: 100, stage: 0, cnt: {}, stageAt: {},
    inv: { green: 4, red: 2, carrot: 2 }, demand: Object.fromEntries(D.GARDEN.map((k) => [k, 1])),
    beds: Array.from({ length: BEDS }, (_, i) => ({ open: i < 6, k: null, t: 0, wet: 0 })),
    fields: Array.from({ length: D.FIELDS }, (_, i) => ({ own: i === 0, st: 'grass', crop: null, grow: 0, water: 0.6, fert: 0, pests: 0, stress: 1, work: {}, pivot: false })),
    barn: {}, seeds: {}, fertBags: 0,
    b: { house: 1, stall: 1, lab: 1, hammock: 1, hangar: 0, fuel: 0, wash: 0, barn: 0, weigh: 0, elevator: 0, fertshed: 0, oilmill: 0, groatsmill: 0, feedmill: 0, bioplant: 0, wind: 0, solar: 0, pond: 0, gazebo: 0 },
    m: { tractor: null, combine: null, truck: { lvl: 1, fuel: 60, oil: 100, dirt: 0.1, wear: 20, load: 0, crop: null }, att: {} },
    plants: {}, goods: { oil: 0, groats: 0, feed: 0, ethanol: 0 }, eth: { split: 0.5, own: 0 }, order: null, forceBreak: false, fish: 0, maxSt: 100
  });
  let S = api.store.get('state3', null);
  if (!S || S.v !== 3) { const old = api.store.get('state2', null); S = fresh(); if (old) { S.coins = Math.max(S.coins, Math.floor(old.coins || 0)); for (const [k, n] of Object.entries(old.inv || {})) if (n > 0) S.inv[k] = n; } }
  // ремонт старих збережень: зламані числа (NaN) в амбарі, вантажівці й комбайні → 0
  { const fix = (o, ks) => { if (o) for (const k of ks) if (!Number.isFinite(o[k])) o[k] = 0; };
    for (const c of Object.keys(S.barn || {})) if (!Number.isFinite(S.barn[c])) S.barn[c] = 0;
    fix(S.m.truck, ['load']); fix(S.m.combine, ['hopper']); if (S.m.truck && !(S.m.truck.load > 0.01)) { S.m.truck.load = 0; if (!S.m.truck.goods) S.m.truck.crop = null; } }
  const save = () => api.store.set('state3', S);
  const cnt = (k, n = 1) => { S.cnt[k] = (S.cnt[k] || 0) + n; checkStage(); };
  const maxStamina = () => [100, 130, 160][S.b.house - 1] || 100;
  const isNight = () => S.tod > 0.58;
  const hour = () => (6 + S.tod * 24) % 24;
  const gardenPrice = (k) => { const { type, mut } = split(k); return Math.max(1, Math.round(D.CROPS[type].price * WEATHER[S.weather].price * (S.demand[type] || 1) * (mut ? D.MUT[mut].price : 1))); };
  const grainPrice = (c) => Math.round(D.CROPS[c].price * (1 + 0.1 * S.b.elevator));
  const stageOf = () => D.STAGES[S.stage];

  /* ================= світло, небо, туман ================= */
  const hemi = new THREE.HemisphereLight(0xdfefff, 0x5b4a33, 0.85); scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff1d6, 3); sun.castShadow = true;
  const sm = api.quality === 'high' ? 2048 : 1024; sun.shadow.mapSize.set(sm, sm);
  Object.assign(sun.shadow.camera, { left: -16, right: 16, top: 16, bottom: -16, near: 1, far: 70 }); sun.shadow.bias = -0.0005; sun.shadow.normalBias = 0.03;
  scene.add(sun, sun.target);
  const yardLight = new THREE.PointLight(0xffc56b, 0, 14, 1.6); yardLight.position.set(-6, 3.2, 8); scene.add(yardLight);
  scene.fog = new THREE.Fog(0x9fd2f5, 40, 95);
  const skyC = new THREE.Color(0x9fd2f5), skyTop = new THREE.Color();
  const bgCv = document.createElement('canvas'); bgCv.width = 4; bgCv.height = 256;
  const bgTex = new THREE.CanvasTexture(bgCv); bgTex.colorSpace = THREE.SRGBColorSpace; scene.background = bgTex;
  const stars = (() => { const n = 260, g = new THREE.BufferGeometry(), a = new Float32Array(n * 3); for (let i = 0; i < n; i++) { const u = Math.random() * Math.PI * 2, v = Math.random() * 0.45 + 0.08; a.set([Math.cos(u) * Math.cos(v) * 120, Math.sin(v) * 120, Math.sin(u) * Math.cos(v) * 120], i * 3); } g.setAttribute('position', new THREE.BufferAttribute(a, 3)); const p = new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffffff, size: 0.9, sizeAttenuation: false, transparent: true, opacity: 0, fog: false })); scene.add(p); return p; })();
  function paintSky(top, horizon) { const g = bgCv.getContext('2d'), gr = g.createLinearGradient(0, 0, 0, 256); gr.addColorStop(0, '#' + top.getHexString()); gr.addColorStop(0.62, '#' + horizon.getHexString()); gr.addColorStop(1, '#' + horizon.clone().multiplyScalar(0.6).getHexString()); g.fillStyle = gr; g.fillRect(0, 0, 4, 256); bgTex.needsUpdate = true; }

  /* ================= острів і дороги ================= */
  const F = new THREE.Group(); scene.add(F);
  const pickables = [];
  const pick = (o, u) => { o.userData.pick = u; pickables.push(o); return o; };
  const grassTex = speckle('#6fa64a', ['#5f9640', '#7fb456', '#86c05c', '#4f8236'], 512, 9000, 3, [0.6, 2.4]); grassTex.repeat.set(9, 9);
  const dirtTex = speckle('#6b4a2e', ['#5a3d25', '#7a5636', '#4a311d', '#8a6440'], 256, 3000, 5); dirtTex.repeat.set(4, 4);
  const base = new THREE.Mesh(new RoundedBoxGeometry(IW, 1.6, ID, 6, 0.5), std(0xffffff, 0.95, 0, { map: dirtTex })); base.position.y = -0.82; base.receiveShadow = true; F.add(base);
  const lawn = new THREE.Mesh(new RoundedBoxGeometry(IW - 0.08, 0.12, ID - 0.08, 6, 0.06), std(0xffffff, 0.92, 0, { map: grassTex })); lawn.position.y = -0.04; lawn.receiveShadow = true; F.add(lawn);
  const sea = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshStandardMaterial({ color: 0x2f6f9a, roughness: 0.2, metalness: 0.1 })); sea.rotation.x = -Math.PI / 2; sea.position.y = -1.2; scene.add(sea);
  const roadM = std(0xffffff, 0.95, 0, { map: speckle('#8a8478', ['#7a746a', '#9a9488', '#6e685e'], 256, 2600, 11) });
  const road = (x, z, w, d) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), roadM); m.rotation.x = -Math.PI / 2; m.position.set(x, 0.027, z); m.receiveShadow = true; F.add(m); };
  road(7.9, 0, 1.4, ID - 1.2); road(-3.6, 11.2, IW - 8.4, 1.3); road(-3.6, -5.4, IW - 8.4, 1.3); road(-3.6, 1.6, IW - 8.4, 1.3);
  const pathM = std(0xffffff, 1, 0, { map: speckle('#c2a77d', ['#b0956b', '#d4bc94', '#a88c62'], 256, 2500, 11) });
  { const m = new THREE.Mesh(new THREE.PlaneGeometry(9.5, 0.9), pathM); m.rotation.x = -Math.PI / 2; m.position.set(-5.0, 0.026, 7.9); F.add(m); }
  // ліхтарі на подвір'ї (світяться вночі)
  const lampM = new THREE.MeshStandardMaterial({ color: 0xfff2d0, emissive: new THREE.Color(0xffc56b), emissiveIntensity: 0 });
  [[-8.4, 10.6], [-2.6, 10.6], [3.6, 10.6], [-2.6, 2.6], [3.0, 2.6], [-8, -4.7], [1.5, -4.7]].forEach(([x, z]) => { const g = new THREE.Group(); g.position.set(x, 0, z); g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.07, 2.4, 8), std(0x3a3f45, 0.5, 0.6)).translateY(1.2)); g.add(new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 8), lampM).translateY(2.45)); F.add(g); });
  // декор: дерева, кущі, квіти
  const deco = [['tree_oak', -14.2, 5.5, 2.2], ['tree_fat', -14, -0.5, 1.8], ['tree_pine', -14.3, -7.5, 2.4], ['tree_oak', 14.4, 14.6, 2.0], ['tree_fat', 7.0, 14.8, 1.6], ['tree_pine', 14.6, -15.6, 2.3], ['tree_autumn', -6, 15.6, 1.8], ['bush', -9.2, 6.6, 0.6], ['bush', 2.0, 7.4, 0.55], ['flower_red', -6.6, 8.6, 0.35], ['flower_red', -3.4, 8.7, 0.3], ['rock_small', 5.6, 13.2, 0.45], ['mushroom_red', -13.6, 11, 0.35], ['bush', 9.2, 11.0, 0.6], ['tree_pine_tall', -14.4, -12.5, 2.8], ['tree_oak', 6.4, -15.6, 2.0]];
  deco.forEach(([n, x, z, hg]) => inst(n, hg).then((m) => { m.position.set(x, 0, z); m.rotation.y = Math.random() * 6; m.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } }); F.add(m); }).catch(() => { }));
  // паркан навколо городу, колодязь біля лійки, тюки сіна, живопліт уздовж полів
  { const pm = std(0x9a6a40, 0.85), fence = new THREE.Group(); F.add(fence);
    const run = (x0, z0, x1, z1) => { const L = Math.hypot(x1 - x0, z1 - z0), n = Math.max(1, Math.round(L / 1.1)), ang = Math.atan2(x1 - x0, z1 - z0); for (let i = 0; i <= n; i++) { const t = i / n; fence.add(new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.7, 0.1), pm).translateX(x0 + (x1 - x0) * t).translateY(0.35).translateZ(z0 + (z1 - z0) * t)); } for (const y of [0.28, 0.55]) { const r = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.08, L), pm); r.position.set((x0 + x1) / 2, y, (z0 + z1) / 2); r.rotation.y = ang; fence.add(r); } };
    run(-11.2, 2.4, -11.2, 7.6); run(-11.2, 2.4, -2.2, 2.4); run(-2.2, 2.4, -2.2, 4.4); run(-11.2, 7.6, -8.6, 7.6);
    fence.traverse((m) => { if (m.isMesh) m.castShadow = true; });
    const well = new THREE.Group(); well.position.set(-1.0, 0, 7.9); F.add(well);
    well.add(new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.55, 0.7, 16, 1, true), std(0x9aa0a6, 0.9, 0, { side: THREE.DoubleSide, map: speckle('#9aa0a6', ['#7d8287', '#b5bbc0'], 64, 300, 4) })).translateY(0.35));
    well.add(new THREE.Mesh(new THREE.CircleGeometry(0.46, 16), std(0x2f6f9a, 0.1, 0.3)).rotateX(-Math.PI / 2).translateZ(0.5));
    for (const x of [-0.45, 0.45]) well.add(new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.3, 0.08), pm).translateX(x).translateY(0.95));
    well.add(new THREE.Mesh(new THREE.ConeGeometry(0.75, 0.45, 4), std(0x9a3b2c, 0.7)).translateY(1.75).rotateY(Math.PI / 4));
    well.traverse((m) => { if (m.isMesh) m.castShadow = true; });
    const hay = std(0xd9b85a, 0.95, 0, { map: speckle('#d9b85a', ['#c9a44a', '#e8cc7a'], 64, 500, 9) });
    [[-13.6, -5.0], [-14.2, -6.2], [-12.9, -6.0], [9.0, 12.6], [10.2, 13.0]].forEach(([x, z], i) => { const b2 = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.9, 16), hay); b2.rotation.z = Math.PI / 2; b2.rotation.y = i * 0.7; b2.position.set(x, 0.5, z); b2.castShadow = true; F.add(b2); });
    const hedge = std(0x3f7a34, 0.9);
    for (let z = -14.6; z <= 10.2; z += 1.1) { const b3 = new THREE.Mesh(new THREE.IcosahedronGeometry(0.42, 1), hedge); b3.position.set(15.1, 0.32, z); b3.scale.y = 0.8; b3.castShadow = true; F.add(b3); }
    for (let x = -14.6; x <= 14.6; x += 1.15) { if (x > -4 && x < 4.5) continue; const b3 = new THREE.Mesh(new THREE.IcosahedronGeometry(0.42, 1), hedge); b3.position.set(x, 0.32, -16.1); b3.scale.y = 0.8; b3.castShadow = true; F.add(b3); } }

  /* ================= город: грядки, ящики, лійка ================= */
  const woodM = std(0x8a5a34, 0.8, 0, { map: speckle('#8a5a34', ['#7a4c2a', '#9a6a40', '#6a3f22'], 128, 900, 13) });
  const soilTex = speckle('#4a3220', ['#3b2718', '#5a3e28', '#2f1f13', '#6a4a30'], 256, 3500, 9, [0.8, 2.8]);
  const soilM = std(0xffffff, 1, 0, { map: soilTex }), wetM = std(0x2e1d12, 0.55, 0, { map: soilTex });
  const bedGeo = new RoundedBoxGeometry(1.3, 0.22, 1.3, 3, 0.06), soilGeo = new THREE.BoxGeometry(1.12, 0.06, 1.12);
  const signTex = (txt) => canvasTex(256, (g, s) => { g.clearRect(0, 0, s, s); g.fillStyle = '#f4e3c0'; g.beginPath(); g.roundRect(14, 60, s - 28, 136, 22); g.fill(); g.fillStyle = '#5b3a1c'; g.font = '800 64px Onest, system-ui'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(txt, s / 2, s / 2 + 4); });
  const bedCost = () => 40 + S.beds.filter((b) => b.open).length * 12;
  const BO = [];
  for (let i = 0; i < BEDS; i++) {
    const g = new THREE.Group(); g.position.copy(bedPos(i)); F.add(g);
    const bed = new THREE.Mesh(bedGeo, woodM); bed.position.y = 0.11; bed.castShadow = bed.receiveShadow = true;
    const soil = new THREE.Mesh(soilGeo, soilM); soil.position.y = 0.205; soil.receiveShadow = true;
    const plant = new THREE.Group(); plant.position.y = 0.23;
    const lock = new THREE.Group();
    lock.add(new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.8), woodM).translateY(0.4));
    const board = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.9), new THREE.MeshStandardMaterial({ map: signTex('+' + bedCost()), transparent: true, side: THREE.DoubleSide })); board.position.y = 0.85; lock.add(board);
    const hit = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1, 1.4), new THREE.MeshBasicMaterial({ visible: false })); hit.position.y = 0.45;
    g.add(bed, soil, plant, lock, hit); pick(g, { kind: 'bed', i });
    BO.push({ g, bed, soil, plant, lock, board, built: null });
  }
  // моделі городніх рослин
  const leafGeo = new THREE.SphereGeometry(0.15, 12, 8); leafGeo.scale(1, 0.22, 0.55);
  const stemGeo = new THREE.CylinderGeometry(0.022, 0.036, 0.95, 6); stemGeo.translate(0, 0.475, 0);
  const podGeo = new THREE.CapsuleGeometry(0.05, 0.22, 4, 8);
  const leafM = std(0x4f9a35, 0.55, 0, { side: THREE.DoubleSide }), stemM = std(0x5c8f34, 0.7);
  const prodMs = {};
  const prodMat = (k) => { if (!prodMs[k]) { const { type, mut } = split(k); prodMs[k] = std(D.CROPS[type].c, 0.45, 0, { emissive: new THREE.Color(mut ? D.MUT[mut].c : D.CROPS[type].c), emissiveIntensity: 0 }); } return prodMs[k]; };
  function buildPlant(po, k) {
    po.plant.clear(); po.built = k;
    const { type } = split(k), model = D.CROPS[type].model, pm = prodMat(k);
    for (let s = 0; s < 3; s++) {
      const st = new THREE.Group(); st.position.set((s - 1) * 0.3 + (Math.random() - 0.5) * 0.08, 0, (Math.random() - 0.5) * 0.34);
      const prod = new THREE.Group(); prod.name = 'prod';
      if (model === 'bean') {
        st.add(new THREE.Mesh(stemGeo, stemM));
        for (let l = 0; l < 4; l++) { const lf = new THREE.Mesh(leafGeo, leafM); lf.position.set(Math.cos(l * 2.1) * 0.12, 0.25 + l * 0.17, Math.sin(l * 2.1) * 0.12); lf.rotation.set(0.3, l * 2.1, 0.4); st.add(lf); }
        for (let p = 0; p < 3; p++) { const pd = new THREE.Mesh(podGeo, pm); pd.position.set(Math.cos(p * 2.4 + s) * 0.13, 0.42 + p * 0.15, Math.sin(p * 2.4 + s) * 0.13); pd.rotation.z = 0.5; prod.add(pd); }
      } else if (model === 'carrot') {
        for (let l = 0; l < 5; l++) { const lf = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.4, 4), leafM); lf.position.set(Math.cos(l * 1.25) * 0.04, 0.2, Math.sin(l * 1.25) * 0.04); lf.rotation.set(Math.cos(l * 1.25) * 0.35, 0, Math.sin(l * 1.25) * 0.35); st.add(lf); }
        const top = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.22, 10), pm); top.rotation.x = Math.PI; top.position.y = 0.02; prod.add(top);
      } else if (model === 'potato') {
        for (let l = 0; l < 7; l++) { const lf = new THREE.Mesh(leafGeo, leafM); lf.position.set(Math.cos(l * 0.9) * 0.14, 0.12 + (l % 3) * 0.07, Math.sin(l * 0.9) * 0.14); lf.rotation.set(0.4, l * 0.9, 0.2); st.add(lf); }
        for (let p = 0; p < 2; p++) { const pt = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), pm); pt.scale.set(1.3, 0.9, 1); pt.position.set(Math.cos(p * 3) * 0.12, 0.03, Math.sin(p * 3) * 0.12); prod.add(pt); }
      } else { // гарбуз і кавун — плетиво з великим плодом
        for (let l = 0; l < 4; l++) { const lf = new THREE.Mesh(new THREE.SphereGeometry(0.13, 10, 6), leafM); lf.scale.set(1, 0.25, 1); lf.position.set(Math.cos(l * 1.6) * 0.2, 0.06, Math.sin(l * 1.6) * 0.2); st.add(lf); }
        if (s === 1) { const fr = new THREE.Mesh(new THREE.SphereGeometry(0.2, 18, 12), model === 'melon' ? std(0xffffff, 0.45, 0, { map: canvasTex(64, (c, z) => { c.fillStyle = '#3f8f3a'; c.fillRect(0, 0, z, z); c.fillStyle = '#9fd36a'; for (let i = 0; i < 8; i++) c.fillRect(i * z / 8, 0, z / 20, z); }) }) : pm); fr.scale.set(1.15, model === 'melon' ? 0.85 : 0.8, model === 'melon' ? 0.85 : 1.15); fr.position.y = 0.14; prod.add(fr); }
      }
      st.traverse((m) => { if (m.isMesh) m.castShadow = true; });
      st.add(prod); st.rotation.y = Math.random() * 6; po.plant.add(st);
    }
  }
  // ящики з урожаєм — вони ж насіння
  const crateM = std(0xb07a46, 0.75, 0, { map: speckle('#b07a46', ['#9a6638', '#c48a52', '#8a5a30'], 128, 700, 21) });
  const beanGeo = new THREE.CapsuleGeometry(0.055, 0.08, 3, 6);
  const BIN = {};
  const binPos = (j) => V3(-10.35 + (j % 2) * 1.15, 0, 3.0 + ((j / 2) | 0) * 1.15);
  function ensureBin(k) {
    if (BIN[k]) return BIN[k];
    const g = new THREE.Group(); F.add(g);
    const crate = new THREE.Mesh(new RoundedBoxGeometry(0.8, 0.42, 0.8, 2, 0.05), crateM); crate.position.y = 0.21; crate.castShadow = crate.receiveShadow = true; g.add(crate);
    const fill = new THREE.Group(); g.add(fill);
    const { type, mut } = split(k);
    for (let j = 0; j < 14; j++) { const b = new THREE.Mesh(beanGeo, std(D.CROPS[type].c, 0.45, 0, mut ? { emissive: new THREE.Color(D.MUT[mut].c), emissiveIntensity: 0.4 } : {})); b.position.set((Math.random() - 0.5) * 0.55, 0.36 + Math.random() * 0.1, (Math.random() - 0.5) * 0.55); b.rotation.set(Math.random() * 3, Math.random() * 3, 0); fill.add(b); }
    const hit = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.8, 0.95), new THREE.MeshBasicMaterial({ visible: false })); hit.position.y = 0.4; g.add(hit);
    const tag = label('0', { size: 32, scale: 0.24, bg: 'rgba(30,22,10,.78)', color: mut ? D.MUT[mut].c : '#fff' }); tag.position.y = 0.85; g.add(tag);
    pick(g, { kind: 'bin', k });
    BIN[k] = { g, fill, tag, n: -1 };
    layoutBins(); return BIN[k];
  }
  function layoutBins() { Object.keys(BIN).sort().forEach((k, j) => BIN[k].g.position.copy(binPos(j))); }
  function syncBins() {
    for (const k of Object.keys(S.inv)) if (S.inv[k] > 0) ensureBin(k);
    for (const [k, b] of Object.entries(BIN)) {
      const n = S.inv[k] || 0; b.g.visible = n > 0 || !split(k).mut;
      b.fill.children.forEach((c, j) => { c.visible = j < Math.min(14, n * 2); });
      if (b.n !== n) { b.n = n; b.g.remove(b.tag); b.tag = label(String(n), { size: 32, scale: 0.24, bg: 'rgba(30,22,10,.78)', color: split(k).mut ? D.MUT[split(k).mut].c : '#fff' }); b.tag.position.y = 0.85; b.g.add(b.tag); }
    }
  }
  const can = new THREE.Group(); const canHome = V3(-1.9, 0, 7.0); can.position.copy(canHome); F.add(can);
  { const cm = std(0x4f9ad8, 0.35, 0.4); can.add(new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.26, 0.42, 18), cm).translateY(0.21)); const sp = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.05, 0.5, 8), cm); sp.position.set(0.3, 0.35, 0); sp.rotation.z = -0.9; can.add(sp); can.add(new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.03, 6, 14, Math.PI), cm).translateX(-0.05).translateY(0.45)); B.hitBox(can, 0.9, 0.9, 0.9, 0.3); pick(can, { kind: 'can' }); can.traverse((m) => { if (m.isMesh) m.castShadow = true; }); }

  /* ================= ярмарок: продаж городини й насіння ================= */
  const stall = B.stall(); stall.position.set(P.stall[0], 0, P.stall[1]); F.add(stall); pick(stall, { kind: 'stall' });
  const SEED = {};
  D.GARDEN.forEach((type, j) => {
    const g = new THREE.Group(); g.position.set(-1.05 + (j % 4) * 0.7, 0.8, j < 4 ? 0.2 : -0.3); stall.add(g);
    const sk = new THREE.Mesh(new THREE.SphereGeometry(0.2, 14, 10), std(0xd9c49c, 0.9)); sk.scale.set(1, 1.1, 1); sk.position.y = 0.18; sk.castShadow = true; g.add(sk);
    g.add(new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), std(D.CROPS[type].c, 0.4)).translateY(0.38));
    const tag = label(String(D.CROPS[type].seed), { size: 30, scale: 0.22, bg: 'rgba(30,22,10,.75)', color: '#ffd36b' }); tag.position.y = 0.62; g.add(tag);
    B.hitBox(g, 0.55, 0.7, 0.5, 0.3); pick(g, { kind: 'gseed', type }); SEED[type] = { g, sk };
  });
  const priceBoard = new THREE.Mesh(new THREE.PlaneGeometry(2.8, 0.66), new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false })); priceBoard.position.set(0, 2.55, 0.3); stall.add(priceBoard);
  const pbCv = document.createElement('canvas'); pbCv.width = 640; pbCv.height = 150; const pbTex = new THREE.CanvasTexture(pbCv); pbTex.colorSpace = THREE.SRGBColorSpace; priceBoard.material.map = pbTex;
  let lastPrices = {};
  function drawPrices() {
    const g = pbCv.getContext('2d'); g.clearRect(0, 0, 640, 150); g.fillStyle = 'rgba(14,16,22,.8)'; g.beginPath(); g.roundRect(0, 0, 640, 150, 32); g.fill();
    const list = D.GARDEN.filter((k) => (S.inv[k] || 0) > 0 || ['green', 'red', 'carrot'].includes(k)).slice(0, 5);
    list.forEach((type, j) => {
      const x = 22 + j * 124, p = gardenPrice(type), prev = lastPrices[type] ?? p;
      g.fillStyle = D.CROPS[type].c; g.beginPath(); g.ellipse(x + 18, 75, 13, 19, -0.5, 0, Math.PI * 2); g.fill(); g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 2; g.stroke();
      g.fillStyle = '#fff'; g.font = '800 46px Onest, system-ui'; g.textBaseline = 'middle'; g.fillText(String(p), x + 38, 78);
      if (p !== prev) { g.fillStyle = p > prev ? '#8fe08a' : '#ff8a7a'; g.beginPath(); const y = p > prev ? 34 : 116, d = p > prev ? 1 : -1; g.moveTo(x + 104, y + 10 * d); g.lineTo(x + 94, y - 4 * d); g.lineTo(x + 114, y - 4 * d); g.fill(); }
    });
    pbTex.needsUpdate = true;
  }

  /* ================= лабораторія мутацій (ідея сина) ================= */
  const lab = new THREE.Group(); lab.position.set(P.lab[0], 0, P.lab[1]); F.add(lab);
  const liquidM = new THREE.MeshStandardMaterial({ color: 0x1fb5a8, emissive: 0x1fb5a8, emissiveIntensity: 0.9, transparent: true, opacity: 0.85 });
  { lab.add(new THREE.Mesh(new RoundedBoxGeometry(2.2, 0.4, 1.4, 2, 0.08), std(0xdfe6ee, 0.4, 0.3)).translateY(0.2));
    lab.add(new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 1.3, 28, 1, true), glass(0xcdefff)).translateY(1.05));
    lab.add(new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.46, 0.9, 24), liquidM).translateY(0.88));
    lab.add(new THREE.Mesh(new THREE.CylinderGeometry(0.56, 0.56, 0.12, 28), std(0x8090a4, 0.3, 0.8)).translateY(1.75)); }
  const FUN = {};
  [['sun', -0.85], ['star', 0.85]].forEach(([m, x]) => {
    const g = new THREE.Group(); g.position.set(x, 0.4, 0.15); lab.add(g);
    const cone = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.08, 0.5, 20, 1, true), std(D.MUT[m].c, 0.3, 0.2, { emissive: new THREE.Color(D.MUT[m].c), emissiveIntensity: 0.35, side: THREE.DoubleSide })); cone.position.y = 0.55; g.add(cone);
    g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.4), std(0xcfd6de, 0.3, 0.6)).translateY(0.2));
    const tag = label(String(D.MUT[m].cost), { size: 34, scale: 0.26, bg: 'rgba(30,22,10,.75)', color: '#ffd36b' }); tag.position.y = 1.05; g.add(tag);
    B.hitBox(g, 0.8, 1.2, 0.8, 0.5); pick(g, { kind: 'funnel', m }); FUN[m] = { g, cone };
  });
  const bubbles = []; for (let i = 0; i < 9; i++) { const b = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), new THREE.MeshBasicMaterial({ color: 0xdffcff, transparent: true })); b.userData.s = Math.random(); lab.add(b); bubbles.push(b); }
  let mixing = 0, mixColor = new THREE.Color(0x1fb5a8);
  lab.traverse((m) => { if (m.isMesh) m.castShadow = true; });

  /* ================= ворони на городі ================= */
  const crowM = std(0x1d1f26, 0.5), beakM = std(0xf2b33d, 0.5);
  function makeCrow() {
    const g = new THREE.Group();
    g.add(new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 10), crowM).translateY(0.2)).children[0].scale.set(1, 0.9, 1.5);
    g.add(new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 8), crowM).translateY(0.32).translateZ(0.2));
    const beak = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.12, 6), beakM); beak.rotation.x = Math.PI / 2; beak.position.set(0, 0.31, 0.32); g.add(beak);
    const wl = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.02, 0.18), crowM); wl.position.set(0.18, 0.24, 0); g.add(wl); const wr = wl.clone(); wr.position.x = -0.18; g.add(wr);
    B.hitBox(g, 0.8, 0.8, 0.8, 0.25); g.userData.pick = { kind: 'crow' }; g.userData.wl = wl; g.userData.wr = wr;
    return g;
  }
  let crow = null, crowT = 30 + Math.random() * 20;

  /* ================= будівлі й будмайданчики ================= */
  const MAKE = { house: () => B.house(S.b.house), hammock: B.hammock, hangar: B.hangar, fuel: B.fuelStation, wash: B.washPad, barn: () => B.barn(S.b.barn), weigh: B.weighbridge, elevator: () => B.elevator(S.b.elevator), fertshed: B.fertShed, oilmill: B.oilMill, groatsmill: B.groatsMill, feedmill: B.feedMill, bioplant: B.bioPlant, pond: B.pond, gazebo: B.gazebo };
  const FP = { hangar: [5.4, 4.4], fuel: [2.4, 1.8], wash: [2.6, 2.4], barn: [3.8, 3.0], weigh: [3.8, 1.8], elevator: [5.2, 2.6], fertshed: [3.4, 2.2], oilmill: [4.2, 2.6], groatsmill: [3.8, 2.6], feedmill: [4.2, 2.6], bioplant: [4.6, 3.0], pond: [5, 5], gazebo: [2.6, 2.6], wind: [1.8, 1.8], solar: [4.0, 3.0] };
  const BL = {}; // key → група будівлі
  function placeBuilding(key, anim) {
    if (BL[key]) { F.remove(BL[key]); const ix = pickables.indexOf(BL[key]); if (ix >= 0) pickables.splice(ix, 1); }
    const g = MAKE[key](); g.position.set(P[key][0], 0, P[key][1]); F.add(g); pick(g, { kind: 'bld', key }); BL[key] = g;
    if (anim) { g.scale.set(1, 0.01, 1); W.tween(g.scale, { y: 1 }, 0.8, ease.back); fx.burst(V3(P[key][0], 1, P[key][1]), 0xd9c49c, 60, 3, 1.1); }
    if (key === 'barn') drawPiles();
    if (key === 'fertshed') B.fertBags(g.userData.bags, S.fertBags);
    return g;
  }
  const WINDS = [], SOLARS = [];
  function placeEnergy(anim) {
    while (WINDS.length < S.b.wind) { const i = WINDS.length, g = B.windTurbine(); g.position.set(P.wind[i][0], 0, P.wind[i][1]); g.rotation.y = 0.3; F.add(g); pick(g, { kind: 'energy', key: 'wind' }); WINDS.push(g); if (anim) { g.scale.set(1, 0.01, 1); W.tween(g.scale, { y: 1 }, 0.9, ease.back); } }
    while (SOLARS.length < S.b.solar) { const i = SOLARS.length, g = B.solarArray(); g.position.set(P.solar[i][0], 0, P.solar[i][1]); F.add(g); pick(g, { kind: 'energy', key: 'solar' }); SOLARS.push(g); if (anim) { g.scale.set(1, 0.01, 1); W.tween(g.scale, { y: 1 }, 0.9, ease.back); } }
  }
  // таблички «купити / збудувати / покращити»: усе, що можна придбати на цьому етапі
  function offers() {
    const o = [], st = S.stage, b = S.b, m = S.m;
    const bld = (key, at = P[key], fp = FP[key]) => { const d = D.BLD[key]; if (b[key] || st < d.stage) return; o.push({ id: 'b_' + key, kind: 'build', key, cost: d.cost[0], at, fp, name: key === 'elevator' ? `${N.elevator} · +10%` : N[key] }); };
    ['hangar', 'fuel', 'wash', 'barn', 'weigh', 'elevator', 'fertshed', 'oilmill', 'groatsmill', 'feedmill', 'bioplant', 'pond', 'gazebo'].forEach((k) => bld(k));
    if (st >= 5 && b.wind < 3) o.push({ id: 'b_wind', kind: 'energy', key: 'wind', cost: D.BLD.wind.cost[0], at: P.wind[b.wind], fp: FP.wind, name: N.wind });
    if (st >= 5 && b.solar < 2) o.push({ id: 'b_solar', kind: 'energy', key: 'solar', cost: D.BLD.solar.cost[0], at: P.solar[b.solar], fp: FP.solar, name: N.solar });
    if (st >= 6 && b.house < 3 && (b.house < 2 || st >= 7)) o.push({ id: 'u_house', kind: 'upgrade', key: 'house', cost: D.BLD.house.cost[b.house], at: [P.house[0] + 2.6, P.house[1] + 1.9], fp: [0.4, 0.4], sign: true, name: `${N.house} · ${T.level} ${b.house + 1}` });
    if (st >= 5 && b.barn === 1) o.push({ id: 'u_barn', kind: 'upgrade', key: 'barn', cost: D.BLD.barn.cost[1], at: [-2.1, -1.2], fp: [0.4, 0.4], sign: true, name: `${N.barn} · ${T.level} 2 · ${D.BLD.barn.cap[1]} ${T.tons}` });
    if (st >= 7 && b.elevator === 1) o.push({ id: 'u_elevator', kind: 'upgrade', key: 'elevator', cost: D.BLD.elevator.cost[1], at: [-14.0, 0.1], fp: [0.4, 0.4], sign: true, name: `${N.elevator} · ${T.level} 2 · +20%` });
    if (st >= 4 && m.truck.lvl < 3 && (m.truck.lvl < 2 || st >= 6)) o.push({ id: 'u_truck', kind: 'truckup', key: 'truck', cost: D.MACH.truck.up[m.truck.lvl], at: [-12.2, 0.1], fp: [0.4, 0.4], sign: true, name: `${N.truck} · ${T.level} ${m.truck.lvl + 1}` });
    if (st >= 1 && !m.tractor) o.push({ id: 'm_tractor', kind: 'machine', key: 'tractor', cost: D.MACH.tractor.cost, at: [-1.6, 0.3], fp: [0.4, 0.4], name: N.tractor, sign: true });
    if (st >= 2 && !m.combine) o.push({ id: 'm_combine', kind: 'machine', key: 'combine', cost: D.MACH.combine.cost, at: [4.7, 2.9], fp: [0.4, 0.4], name: N.combine, sign: true });
    D.ATTS.forEach((a, j) => { const need = { cultivator: 1, seeder: 2, sprayer: 3, irrigator: 3 }[a]; if (st >= need && !m.att[a]) o.push({ id: 'a_' + a, kind: 'att', key: a, cost: D.MACH[a].cost, at: P.att[a], fp: [2.2, 1.8], name: N[a] }); void j; });
    S.fields.forEach((f, i) => {
      const [fx2, fz] = P.fields[i];
      if (!f.own && st >= 2) o.push({ id: 'f_' + i, kind: 'field', key: i, cost: D.FIELD_COST[i], at: [fx2 - FH - 0.9, fz], fp: [0.4, 0.4], name: `${N.field} ${i + 1}`, sign: true });
      if (f.own && f.st === 'ripe' && !m.combine && !combineBusy(i)) o.push({ id: 'h_' + i, kind: 'hire', key: i, cost: 0, at: [fx2 - FH - 0.9, fz], fp: [0.4, 0.4], name: fmt(T.hire, { n: 25 }), sign: true });
      if (f.own && !f.pivot && st >= 5) o.push({ id: 'p_' + i, kind: 'pivot', key: i, cost: D.BLD.pivot.cost[0], at: [fx2 - FH - 0.9, fz - 1.8], fp: [0.4, 0.4], name: N.pivot, sign: true });
    });
    return o;
  }
  const SITES = {}; // id → { g, o }
  function refreshSites() {
    const list = offers(), ids = new Set(list.map((o) => o.id));
    for (const id of Object.keys(SITES)) if (!ids.has(id)) { F.remove(SITES[id].g); const ix = pickables.indexOf(SITES[id].g); if (ix >= 0) pickables.splice(ix, 1); delete SITES[id]; }
    for (const o of list) {
      const costTxt = o.kind === 'hire' ? '' : String(o.cost);
      if (SITES[o.id]) { if (SITES[o.id].o.cost !== o.cost || SITES[o.id].o.name !== o.name) { SITES[o.id].g.userData.draw(o.name, costTxt); SITES[o.id].o = o; } continue; }
      const g = B.site(o.fp[0], o.fp[1], o.name, costTxt, !!o.sign); g.position.set(o.at[0], 0, o.at[1]);
      F.add(g); pick(g, { kind: 'site', id: o.id }); SITES[o.id] = { g, o };
    }
  }

  /* ================= поля ================= */
  const FPAT = {}; // візерунки станів поля (256×256)
  const pat = (name, draw) => { const c = document.createElement('canvas'); c.width = c.height = 256; draw(c.getContext('2d')); FPAT[name] = c; };
  const rnd = (() => { let s = 7; return () => ((s = (s * 16807) % 2147483647) / 2147483647); })();
  pat('grass', (g) => { g.fillStyle = '#6a9a42'; g.fillRect(0, 0, 256, 256); for (let i = 0; i < 2600; i++) { g.fillStyle = ['#5a8a38', '#7aa84c', '#8fb85a', '#4f7a30'][i % 4]; g.fillRect(rnd() * 256, rnd() * 256, 1.5, 3 + rnd() * 4); } });
  pat('plowed', (g) => { g.fillStyle = '#5a3c24'; g.fillRect(0, 0, 256, 256); for (let y = 0; y < 256; y += 8) { g.fillStyle = '#3e2816'; g.fillRect(0, y, 256, 3); g.fillStyle = '#6e4c30'; g.fillRect(0, y + 4, 256, 2); } for (let i = 0; i < 900; i++) { g.fillStyle = 'rgba(30,18,8,.35)'; g.fillRect(rnd() * 256, rnd() * 256, 2, 2); } });
  pat('sown', (g) => { g.drawImage(FPAT.plowed, 0, 0); for (let y = 2; y < 256; y += 8) for (let x = 2; x < 256; x += 6) { g.fillStyle = 'rgba(226,200,140,.55)'; g.fillRect(x + rnd() * 2, y, 2, 2); } });
  pat('soil', (g) => { g.fillStyle = '#4e3420'; g.fillRect(0, 0, 256, 256); for (let y = 0; y < 256; y += 8) { g.fillStyle = '#3a2614'; g.fillRect(0, y, 256, 3); } for (let i = 0; i < 1500; i++) { g.fillStyle = 'rgba(90,140,60,.25)'; g.fillRect(rnd() * 256, rnd() * 256, 2, 2); } });
  pat('stubble', (g) => { g.fillStyle = '#b89a5a'; g.fillRect(0, 0, 256, 256); for (let y = 0; y < 256; y += 6) for (let x = 0; x < 256; x += 3) { g.fillStyle = rnd() < 0.5 ? '#d9bf7a' : '#9a7e44'; g.fillRect(x, y + rnd() * 2, 1.5, 3); } });
  const patFor = (st) => (st === 'grass' ? 'grass' : st === 'plowed' ? 'plowed' : st === 'sown' ? 'sown' : st === 'stubble' ? 'stubble' : 'soil');
  const laneW = FS / D.LANES;
  const FO = [];
  const cropGeo = {}, cropMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.75 });
  const GRID = 14;
  S.fields.forEach((f, i) => {
    const [cx, cz] = P.fields[i], g = new THREE.Group(); g.position.set(cx, 0, cz); F.add(g);
    const cv = document.createElement('canvas'); cv.width = cv.height = 256; const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 4;
    const plane = new THREE.Mesh(new THREE.PlaneGeometry(FS, FS), new THREE.MeshStandardMaterial({ map: tex, roughness: 1 })); plane.rotation.x = -Math.PI / 2; plane.position.y = 0.035; plane.receiveShadow = true; g.add(plane);
    const edge = new THREE.Mesh(new THREE.BoxGeometry(FS + 0.3, 0.06, FS + 0.3), std(0x6b4a2e, 1)); edge.position.y = 0.0; edge.receiveShadow = true; g.add(edge);
    // кілочки по кутах і табличка з номером
    for (const [x, z] of [[-FH, -FH], [FH, -FH], [-FH, FH], [FH, FH]]) g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.5, 6), woodM).translateX(x).translateY(0.25).translateZ(z));
    const num = label(String(i + 1), { size: 40, scale: 0.42, bg: 'rgba(30,22,10,.8)', color: '#ffd36b', depth: true }); num.position.set(-FH - 0.2, 0.9, FH + 0.2); g.add(num);
    const hit = new THREE.Mesh(new THREE.BoxGeometry(FS, 0.8, FS), new THREE.MeshBasicMaterial({ visible: false })); hit.position.y = 0.4; g.add(hit);
    pick(g, { kind: 'field', i });
    const fo = { g, cv, tex, mesh: null, crop: null, pts: [], piv: null, dirty: true, lock: null };
    for (let r = 0; r < GRID; r++) for (let c = 0; c < GRID; c++) fo.pts.push({ x: -FH + (c + 0.5) * FS / GRID + (rnd() - 0.5) * 0.18, z: -FH + (r + 0.5) * FS / GRID + (rnd() - 0.5) * 0.12, r: rnd() * 6.28, s: 0.85 + rnd() * 0.3, lane: Math.floor(r / (GRID / D.LANES)) });
    FO.push(fo);
  });
  const toFieldPx = (v) => (v + FH) / FS * 256;
  function paintField(i) {
    const f = S.fields[i], fo = FO[i], g = fo.cv.getContext('2d');
    if (!f.own) { g.drawImage(FPAT.grass, 0, 0); g.fillStyle = 'rgba(20,24,16,.35)'; g.fillRect(0, 0, 256, 256); fo.tex.needsUpdate = true; return; }
    g.drawImage(FPAT[patFor(f.st)], 0, 0);
    // частково виконана робота: смуги нового стану
    const op = activeOp(i);
    if (op) { const done = f.work[op.op] || 0, next = opResult(op.op, f); for (let L = 0; L < done; L++) strip(i, next, L, -FH, FH); }
    fo.tex.needsUpdate = true;
  }
  function strip(i, st, L, xa, xb) {
    const g = FO[i].cv.getContext('2d'), y = L * laneW / FS * 256, hgt = laneW / FS * 256 + 0.5, x0 = toFieldPx(Math.min(xa, xb)), w = Math.abs(toFieldPx(xb) - toFieldPx(xa));
    g.drawImage(FPAT[patFor(st)], x0, y, w, hgt, x0, y, w, hgt); FO[i].tex.needsUpdate = true;
  }
  const dummy = new THREE.Object3D(), tint = new THREE.Color();
  function syncCrops(i, harvestedLanes = 0, partial = null) {
    const f = S.fields[i], fo = FO[i];
    const show = f.own && f.crop && ['sown', 'grow', 'ripe'].includes(f.st);
    if (!show) { if (fo.mesh) fo.mesh.visible = false; return; }
    if (fo.crop !== f.crop) { if (fo.mesh) { fo.g.remove(fo.mesh); fo.mesh.dispose(); } cropGeo[f.crop] = cropGeo[f.crop] || B.cropGeo(D.CROPS[f.crop].model); fo.mesh = new THREE.InstancedMesh(cropGeo[f.crop], cropMat, fo.pts.length); fo.mesh.castShadow = true; fo.mesh.receiveShadow = false; fo.g.add(fo.mesh); fo.crop = f.crop; }
    fo.mesh.visible = true;
    const g = f.st === 'sown' ? 0.05 : f.st === 'ripe' ? 1 : f.grow, sc = 0.12 + 0.88 * ease.out(Math.min(1, g));
    const ripeK = f.st === 'ripe' ? 1 : Math.max(0, (g - 0.7) / 0.3);
    tint.setRGB(0.55 + 0.45 * ripeK, 0.95 + 0.05 * ripeK, 0.45 + 0.55 * ripeK);
    fo.pts.forEach((p, j) => {
      let s = sc * p.s;
      if (p.lane < harvestedLanes || (partial && p.lane === partial.lane && (partial.dir > 0 ? p.x < partial.x : p.x > partial.x))) s = 0.0001;
      if (f.pests && f.st !== 'ripe' && j % 5 === 0) s *= 0.7;
      dummy.position.set(p.x, 0.04, p.z); dummy.rotation.set(0, p.r, 0); dummy.scale.set(s, s * (f.water < 0.2 ? 0.8 : 1), s); dummy.updateMatrix();
      fo.mesh.setMatrixAt(j, dummy.matrix); fo.mesh.setColorAt(j, tint);
    });
    fo.mesh.instanceMatrix.needsUpdate = true; if (fo.mesh.instanceColor) fo.mesh.instanceColor.needsUpdate = true;
  }
  function placePivot(i, anim) { const fo = FO[i]; if (fo.piv) return; const pv = B.pivot(FH * 0.95); pv.position.set(0, 0, 0); fo.g.add(pv); fo.piv = pv; if (anim) { pv.scale.set(0.01, 0.01, 0.01); W.tween(pv.scale, { x: 1, y: 1, z: 1 }, 0.8, ease.back); } }

  // полиця з насінням для полів (біля ангара): тап — купити мішок, тягни — взяти мішок на сівалку
  const rack = new THREE.Group(); rack.position.set(P.rack[0], 0, P.rack[1]); F.add(rack);
  rack.add(new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.08, 0.7), woodM).translateY(0.5)); for (const x of [-1.2, 1.2]) rack.add(new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.5, 0.6), woodM).translateX(x).translateY(0.25));
  const RS = {};
  D.FIELD.forEach((c, j) => {
    const g = B.sack(D.CROPS[c].c, 'seed'); g.position.set(-0.95 + j * 0.63, 0.54, 0); rack.add(g); pick(g, { kind: 'fseed', c });
    RS[c] = { g, tag: null, n: -1 };
  });
  function syncRack() {
    D.FIELD.forEach((c) => { const r = RS[c], avail = S.stage >= D.CROPS[c].stage; r.g.visible = avail; const n = S.seeds[c] || 0; const txt = `${n} · ${D.CROPS[c].seed}`; if (r.n !== txt) { r.n = txt; if (r.tag) r.g.remove(r.tag); r.tag = label(txt, { size: 28, scale: 0.22, bg: 'rgba(30,22,10,.78)', color: n ? '#fff' : '#ffd36b' }); r.tag.position.y = 0.95; r.g.add(r.tag); } });
    rack.visible = S.stage >= 2;
  }
  // каністра з мастилом
  const oilcan = B.sack(0, 'oilcan'); oilcan.position.set(P.oilcan[0], 0, P.oilcan[1]); F.add(oilcan); pick(oilcan, { kind: 'oilcan' });
  // каністра з пальним — якщо техніка стала посеред поля; відро з губкою — мити руками з першого дня
  const jerry = B.sack(0, 'jerry'); jerry.position.set(P.jerry[0], 0, P.jerry[1]); F.add(jerry); pick(jerry, { kind: 'jerry' });
  const bucket = B.sack(0, 'bucket'); bucket.position.set(P.bucket[0], 0, P.bucket[1]); F.add(bucket); pick(bucket, { kind: 'bucket' });
  // виїзд у місто: далекий збут — дорожче, але довго й коштує пального
  const CITY = { mul: 1.3, fuel: 12, secs: 24 };
  const citySign = new THREE.Group(); citySign.position.set(P.city[0] + 1.7, 0, P.city[1] - 0.4); F.add(citySign);
  citySign.add(new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 1.9, 8), std(0x8a6a44, 0.8)).translateY(0.95));
  { const t = tagSprite(giSvg('city'), `${T.city} +30%`, { scale: 0.7, bg: 'rgba(28,40,78,.88)' }); t.position.y = 2.2; citySign.add(t); }
  B.hitBox(citySign, 1.8, 2.6, 1.4, 1.1); pick(citySign, { kind: 'city' });
  { const t = label('20', { size: 28, scale: 0.2, bg: 'rgba(30,22,10,.78)', color: '#ffd36b' }); t.position.y = 0.85; oilcan.add(t); }

  /* ================= техніка ================= */
  const VH = {};
  const ATT = {};
  function makeVeh(id, g, o = {}) {
    const v = { id, g, speed: o.speed || 2, path: [], onArrive: null, job: null, att: null, len: g.userData.len || 2.2, bolts: [], busy: 0, smokeT: 0, on: false, idleT: 0, eng: null, offT: 0 };
    F.add(g); pick(g, { kind: 'veh', id }); VH[id] = v; return v;
  }
  const mState = (id) => (id === 'tractor' ? S.m.tractor : id === 'combine' ? S.m.combine : id === 'truck' ? S.m.truck : null);
  function spawnTractor() {
    const g = new THREE.Group(); g.userData.len = 2.3;
    const body = new THREE.Group(); g.add(body); g.userData.body = body;
    const v = makeVeh('tractor', g, { speed: D.MACH.tractor.speed });
    B.hitBox(g, 1.7, 1.8, 2.6, 0.9);
    inst('tractor', 1.35).then((m) => { m.traverse((o) => { if (o.isMesh) { o.castShadow = true; } }); body.add(m); const bb = new THREE.Box3().setFromObject(m); v.len = Math.max(1.8, bb.max.z - bb.min.z); m.position.z -= (bb.max.z + bb.min.z) / 2 - g.position.z; }).catch(() => { body.add(new THREE.Mesh(new RoundedBoxGeometry(1.4, 1.2, 2.2, 2, 0.1), std(0xe4472f, 0.5)).translateY(0.8)); });
    const lm = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: new THREE.Color(0xfff2c8), emissiveIntensity: 0.2 }); for (const sx of [-1, 1]) body.add(new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.12, 0.04), lm).translateX(sx * 0.45).translateY(1.05).translateZ(1.2)); g.userData.lights = lm;
    g.position.set(P.park.tractor[0], 0, P.park.tractor[1]); return v;
  }
  function spawnCombine(hired) { const g = B.combine(); const v = makeVeh(hired ? 'hire' : 'combine', g, { speed: D.MACH.combine.speed }); g.position.set(hired ? 7.9 : P.park.combine[0], 0, hired ? 17 : P.park.combine[1]); if (hired) { g.traverse((m) => { if (m.isMesh && m.material.color && m.material.color.getHex() === 0x3d9a4a) { m.material = m.material.clone(); m.material.color.set(0xe4472f); } }); g.rotation.y = Math.PI; } return v; }
  function spawnTruck() { const old = VH.truck; const g = B.truck(S.m.truck.lvl); const v = makeVeh('truck', g, { speed: 3 }); if (old) { [old.eng, old.work, old.aug].forEach((x) => x && x.stop(0.1)); g.position.copy(old.g.position); g.rotation.y = old.g.rotation.y; F.remove(old.g); const ix = pickables.indexOf(old.g); if (ix >= 0) pickables.splice(ix, 1); } else g.position.set(P.park.truck[0], 0, P.park.truck[1]); v.len = g.userData.len; showLoad(); return v; }
  function spawnAtt(a) { const g = B.implement(a); g.position.set(P.att[a][0], 0, P.att[a][1]); g.rotation.y = Math.PI; F.add(g); pick(g, { kind: 'att', a }); ATT[a] = { g, a, on: null }; if (a === 'seeder' && S.m.att.seeder && S.m.att.seeder.seed) g.userData.fill.visible = true; if (a === 'sprayer' && S.m.att.sprayer && S.m.att.sprayer.fert) g.userData.fill.visible = true; return ATT[a]; }
  const jeep = makeVeh('jeep', B.jeep(), { speed: 3.4 }); jeep.g.position.set(P.park.jeep[0], 0, P.park.jeep[1]);
  if (S.m.tractor) spawnTractor();
  if (S.m.combine) spawnCombine(false);
  spawnTruck();
  for (const a of D.ATTS) if (S.m.att[a]) spawnAtt(a);
  if (S.m.tractor && S.m.tractor.att && ATT[S.m.tractor.att]) { const a = ATT[S.m.tractor.att]; a.on = 'tractor'; VH.tractor.att = a; }
  function showLoad() { const v = VH.truck, t = S.m.truck; if (!v) return; const l = v.g.userData.load, cap = D.MACH.truck.cap[t.lvl - 1]; if (t.goods) { l.visible = true; l.scale.y = 0.6; l.position.y = 0.05 + 0.15; l.material = std(D.GOODS[t.goods.k].c, 0.6); return; } l.visible = t.load > 0.01; l.scale.y = Math.max(0.01, Math.min(1, t.load / cap)); l.position.y = 0.05 + l.scale.y * 0.25; if (t.crop) l.material = std(D.CROPS[t.crop].c, 0.85); }

  // рух: їде до точки, плавно повертаючи; причіп тягнеться позаду
  function go(v, p, cb) { v.path = [p.clone().setY(0)]; v.onArrive = cb || null; v.job = null; v.warned = false; }
  function stopV(v) { v.path = []; v.onArrive = null; }
  const fwdOf = (g) => V3(Math.sin(g.rotation.y), 0, Math.cos(g.rotation.y));
  function hitchPoint(v) { return v.g.position.clone().addScaledVector(fwdOf(v.g), -v.len / 2); }
  function trail(v, dt) {
    const a = v.att; if (!a) return;
    const hp = hitchPoint(v), L = a.g.userData.len, c = a.g.position, dir = hp.clone().sub(c); dir.y = 0;
    if (dir.lengthSq() < 1e-4) return; dir.normalize();
    a.g.rotation.y = Math.atan2(dir.x, dir.z); a.g.position.copy(hp).addScaledVector(dir, -L / 2); void dt;
  }
  function moveV(v, dt) {
    if (!v.path.length) return false;
    const st = mState(v.id);
    if (st && (st.broken || st.fuel <= 0) && v.id !== 'hire') { if (st.fuel <= 0 && !v.warned) { v.warned = true; float(T.noFuel, wpos(v.g, 2.4), '#ff9a8a'); snd('crankFail', v.g.position); } return false; }
    const tgt = v.path[0], d = tgt.clone().sub(v.g.position); d.y = 0; const dist = d.length();
    // застряг (ціль недосяжна) — до наступної точки
    if (v.best === undefined || dist < v.best - 0.05) { v.best = dist; v.stuck = 0; } else if ((v.stuck += dt) > 2.5) { v.best = undefined; v.stuck = 0; v.g.position.x = clamp(tgt.x, -XL, XL); v.g.position.z = clamp(tgt.z, -ID / 2 + 0.9, ID / 2 - 0.9); }
    if (dist < 0.18) { v.best = undefined; v.path.shift(); if (!v.path.length) { const cb = v.onArrive; v.onArrive = null; if (cb) cb(); } return true; }
    const want = Math.atan2(d.x, d.z); let df = want - v.g.rotation.y; df = Math.atan2(Math.sin(df), Math.cos(df));
    v.g.rotation.y += clamp(df, -2.4 * dt, 2.4 * dt);
    const sp = v.speed * (isNight() ? 0.9 : 1) * Math.max(0.25, Math.cos(Math.min(1.4, Math.abs(df))));
    v.g.position.addScaledVector(fwdOf(v.g), Math.min(dist, sp * dt));
    const b = v.g.userData.body; if (b) b.position.y = Math.abs(Math.sin(performance.now() / 70)) * 0.012;
    if (st && v.id !== 'hire') { st.fuel = Math.max(0, st.fuel - dt * 0.05); }
    if ((v.smokeT -= dt) < 0) { v.smokeT = 0.12; fx.burst(v.g.position.clone().add(V3(0, 0.1, 0)).addScaledVector(fwdOf(v.g), -v.len / 2), 0xa08868, 1, 0.4, 0.6, 1); }
    trail(v, dt);
    v.g.position.x = clamp(v.g.position.x, -IW / 2 + 0.8, IW / 2 - 0.8); v.g.position.z = clamp(v.g.position.z, -ID / 2 + 0.8, ID / 2 - 0.8);
    return true;
  }
  // причепити: трактор під'їжджає, розвертається й здає назад до гака
  function hitch(a) {
    const v = VH.tractor; if (!v) return;
    if (v.att === a) return;
    if (v.att) { const old = v.att; snd('clunk', old.g.position, 0.7); old.on = null; v.att = null; S.m.tractor.att = null; W.tween(old.g.position, { x: P.att[old.a][0], z: P.att[old.a][1] }, 1, ease.inOut); W.tween(old.g.rotation, { y: Math.PI }, 1, ease.inOut); }
    // причепи стоять гаком до дороги (−Z): трактор заїжджає з боку дороги, розвертається й здає назад
    const L = a.g.userData.len, front = a.g.position.clone().add(V3(0, 0, -(L / 2 + v.len / 2 + 0.15)));
    v.job = null;
    go(v, front.clone().add(V3(0, 0, -2.2)), () => {
      snd('reverse', v.g.position, 0.8, 0.45);
      let ry = v.g.rotation.y; while (ry - Math.PI > Math.PI) ry -= Math.PI * 2; while (ry - Math.PI < -Math.PI) ry += Math.PI * 2; v.g.rotation.y = ry;
      W.tween(v.g.rotation, { y: Math.PI }, 0.5, ease.inOut, () => W.tween(v.g.position, { x: front.x, z: front.z }, 0.7, ease.inOut, () => {
        a.on = 'tractor'; v.att = a; S.m.tractor.att = a.a; trail(v, 0); snd('clunk', a.g.position); snd('hiss', a.g.position, 0.7, 0.15); float(fmt(T.attached, { t: N[a.a] }), wpos(v.g, 2.2), '#ffd36b');
        if (a.a === 'cultivator') cnt('hitch'); save();
      }));
    });
  }
  // польова робота: смуга за смугою, змійкою
  const OPS = { cultivator: 'plow', seeder: 'sow', sprayer: 'spray', irrigator: 'irr', combine: 'harvest' };
  function opOf(v) { return v.id === 'combine' || v.id === 'hire' ? 'combine' : v.att ? v.att.a : null; }
  function opResult(op, f) { return op === 'cultivator' ? 'plowed' : op === 'seeder' ? 'sown' : op === 'combine' ? 'stubble' : f.st; }
  function activeOp(i) { for (const v of Object.values(VH)) if (v.job && v.job.fi === i) return v.job; return null; }
  function combineBusy(i) { const v = VH.hire; return !!(v && v.job && v.job.fi === i); }
  const fieldYield = (f) => D.CROPS[f.crop].yield * (f.fert ? 1.3 : 1) * (f.pests ? 0.6 : 1) * f.stress;
  function canWork(v, i, say = true) {
    const f = S.fields[i], op = opOf(v), at = wpos(FO[i].g, 1.6);
    const no = (t) => { if (say) { float(t, at, '#ff9a8a'); api.sfx('bad'); } return false; };
    if (!f.own) return no(T.f_locked);
    if (!op) return no(`${T.hitched}: ${T.none}`);
    if (op === 'cultivator' && !['grass', 'stubble'].includes(f.st)) return no(T.notReady);
    if (op === 'seeder' && f.st !== 'plowed') return no(T.notReady);
    if (op === 'seeder' && !(S.m.att.seeder && S.m.att.seeder.seed)) return no(T.noSeed);
    if (op === 'sprayer' && !['sown', 'grow'].includes(f.st)) return no(T.notReady);
    if (op === 'sprayer' && !(S.m.att.sprayer && S.m.att.sprayer.fert)) return no(T.noSeed);
    if (op === 'irrigator' && !['sown', 'grow'].includes(f.st)) return no(T.notReady);
    if (op === 'combine' && f.st !== 'ripe') return no(T.notReady);
    const busy = activeOp(i); if (busy && busy.v !== v) return no(T.working);
    return true;
  }
  const XL = IW / 2 - 0.9; // техніка не їде за край острова
  function laneEnds(i, L) { const [cx, cz] = P.fields[i], z = cz - FH + (L + 0.5) * laneW, dir = L % 2 === 0 ? 1 : -1; return { z, dir, xs: clamp(cx - dir * (FH + 1.2), -XL, XL), xe: clamp(cx + dir * (FH + 1.2), -XL, XL) }; }
  function startWork(v, i) {
    if (!canWork(v, i)) return;
    const op = opOf(v), f = S.fields[i];
    v.job = { keep: true, v, fi: i, op, lane: f.work[op] || 0, phase: 'toStart' };
    if (op === 'seeder') v.job.seed = S.m.att.seeder.seed;
    nextLane(v);
  }
  function nextLane(v) {
    const j = v.job, e = laneEnds(j.fi, j.lane);
    j.phase = 'toStart';
    v.path = [V3(clamp(e.xs - e.dir * 0.8, -XL, XL), 0, e.z), V3(e.xs, 0, e.z)]; v.onArrive = () => { j.phase = 'lane'; v.path = [V3(e.xe, 0, e.z)]; v.onArrive = () => laneDone(v); };
  }
  function workerX(v) { const j = v.job, p = v.id === 'combine' || v.id === 'hire' ? v.g.position.clone().addScaledVector(fwdOf(v.g), v.len * 0.45) : v.att ? v.att.g.position.clone() : v.g.position.clone(); return p.x - P.fields[j.fi][0]; }
  function laneDone(v) {
    const j = v.job, f = S.fields[j.fi], op = j.op;
    strip(j.fi, opResult(op, f), j.lane, -FH, FH);
    if (op === 'combine') { const t = fieldYield(f) / D.LANES; if (v.id === 'hire') v.hold = (v.hold || 0) + t; else { S.m.combine.hopper = (S.m.combine.hopper || 0) + t; S.m.combine.crop = f.crop; } syncCrops(j.fi, j.lane + 1); }
    j.lane++; f.work[op] = j.lane;
    const st = v.id === 'hire' ? null : mState(v.id);
    if (st) {
      st.fuel = Math.max(0, st.fuel - (v.id === 'combine' ? D.MACH.combine.burn : D.MACH.tractor.burn));
      st.oil = Math.max(0, st.oil - 2.5); st.dirt = Math.min(1, st.dirt + (S.weather === 'rain' ? 0.12 : 0.06)); st.wear = Math.min(100, st.wear + (v.id === 'combine' ? 1 : 1.3));
      const ch = 0.012 + st.wear * 0.0006 + (st.oil < 25 ? 0.06 : 0) + st.dirt * 0.03;
      if ((S.forceBreak && v.id === 'tractor') || Math.random() < ch) { S.forceBreak = false; breakDown(v); save(); return; }
    }
    if (j.lane >= D.LANES) return finishOp(v);
    if (op === 'combine' && v.id === 'combine' && S.m.combine.hopper + fieldYield(f) / D.LANES > D.MACH.combine.hopper + 0.01) { float(T.hopperFull, wpos(v.g, 3), '#ffd36b'); api.sfx('bad'); v.job = null; save(); setTimeout(autoUnload, 600); return; }
    nextLane(v); save();
  }
  function finishOp(v) {
    const j = v.job, f = S.fields[j.fi], op = j.op; v.job = null; f.work[op] = 0;
    if (op === 'cultivator') { f.st = 'plowed'; f.crop = null; cnt('plow'); }
    else if (op === 'seeder') { f.st = 'sown'; f.crop = j.seed; f.grow = 0; f.fert = 0; f.pests = 0; f.stress = 1; f.water = Math.max(f.water, 0.5); S.m.att.seeder.seed = null; if (ATT.seeder) ATT.seeder.g.userData.fill.visible = false; cnt('sow'); }
    else if (op === 'sprayer') { f.fert = 1; f.pests = 0; S.m.att.sprayer.fert = 0; if (ATT.sprayer) ATT.sprayer.g.userData.fill.visible = false; }
    else if (op === 'irrigator') { f.water = 1; }
    else if (op === 'combine') { f.st = 'stubble'; f.crop = null; f.grow = 0; cnt('harvestF'); if (v.id === 'hire') hiredDone(v); else setTimeout(autoUnload, 600); }
    paintField(j.fi); syncCrops(j.fi);
    fx.burst(wpos(FO[j.fi].g, 1), 0xffd36b, 50, 3); api.sfx('ok'); api.pet('happy');
    if (v.id !== 'hire') go(v, v.g.position.clone().add(V3(-2.6, 0, 0)));
    save();
  }
  function breakDown(v) {
    const st = mState(v.id); st.broken = true; v.path = []; v.onArrive = null; if (v.job) v.job.phase = 'broken';
    float(T.broken, wpos(v.g, 2.6), '#ff6b5a'); snd('stall', v.g.position); snd('clunk', v.g.position, 1, 0.3); snd('hiss', v.g.position, 0.8, 0.4); v.on = false;
    v.bolts.forEach((b) => v.g.remove(b)); v.bolts = [];
    addBolts(v);
  }
  // червоні болти на зламаній техніці (і після перезаходу: зламана лишається зламаною, але її завжди можна полагодити)
  function addBolts(v) {
    const top = (v.g.userData.top || (v.id === 'combine' ? 3.2 : v.id === 'truck' ? 2.6 : 2.1)); for (let k = 0; k < 3; k++) { const b = new THREE.Mesh(new THREE.SphereGeometry(0.16, 14, 10), new THREE.MeshStandardMaterial({ color: 0xff3b2a, emissive: new THREE.Color(0xff3b2a), emissiveIntensity: 1.2 })); b.position.set((k - 1) * 0.62, top + (k % 2) * 0.3, 0.2 - k * 0.2); B.hitBox(b, 0.62, 0.62, 0.62, 0); b.userData.pick = { kind: 'bolt', id: v.id }; v.g.add(b); pickables.push(b); v.bolts.push(b); }
  }
  const wrenchM = std(0xc9cdd6, 0.35, 0.8);
  function fixBolt(b, id) {
    const v = VH[id]; if (!v || b.userData.fixing || v.bolts.indexOf(b) < 0) return;
    b.userData.fixing = true; snd('ratchet', wpos(b));
    const wr = new THREE.Group(); wr.add(new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.05, 0.62), wrenchM).translateZ(0.34)); wr.add(new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.04, 6, 14), wrenchM)); wr.children[1].rotation.x = Math.PI / 2; wr.position.copy(b.position).add(V3(0, 0.05, 0)); v.g.add(wr);
    const st0 = { a: 0 }; W.tween(st0, { a: Math.PI * 2.5 }, 0.5, ease.inOut, () => { v.g.remove(wr); boltDone(b, id); });
    const off = W.onFrame(() => { wr.rotation.y = st0.a; b.rotation.y = st0.a; if (!wr.parent) off(); });
  }
  function boltDone(b, id) {
    const v = VH[id]; if (!v) return;
    const ix = v.bolts.indexOf(b); if (ix < 0) return;
    v.bolts.splice(ix, 1); const pi = pickables.indexOf(b); if (pi >= 0) pickables.splice(pi, 1);
    b.material.color.set(0x6bff8a); b.material.emissive.set(0x6bff8a); W.tween(b.scale, { x: 0.01, y: 0.01, z: 0.01 }, 0.4, ease.inOut, () => v.g.remove(b));
    fx.burst(wpos(b), 0xffd36b, 14, 1.6);
    if (!v.bolts.length) { const st = mState(id); st.broken = false; st.wear = Math.max(0, st.wear - 25); float(T.repaired, wpos(v.g, 2.6), '#8fe08a'); snd('wrench', v.g.position); api.sfx('ok'); cnt('repair'); if (v.job) { if (v.job.lane >= D.LANES) finishOp(v); else nextLane(v); } save(); }
  }
  // найманий комбайн: приїжджає, збирає, віддає 75% у вантажівку (решту продає сам)
  function hireCombine(i) {
    if (VH.hire) return;
    const v = spawnCombine(true); float(T.hired, wpos(FO[i].g, 2), '#ffd36b'); api.sfx('ok'); snd('horn', v.g.position, 1, 0.4);
    v.job = { keep: true, v, fi: i, op: 'combine', lane: S.fields[i].work.combine || 0, phase: 'toStart' }; v.hold = 0; v.lastCrop = S.fields[i].crop;
    nextLane(v); refreshSites();
  }
  function hiredDone(v) {
    const crop = v.lastCrop || 'wheat', share = (v.hold || 0) * 0.75, t = S.m.truck, cap = D.MACH.truck.cap[t.lvl - 1];
    let toTruck = 0;
    if (!S.trip && !t.goods && (!t.load || t.crop === crop)) toTruck = Math.max(0, Math.min(share, cap - t.load));
    const rest = share - toTruck;
    if (rest > 0.01) { const c = Math.round(rest * grainPrice(crop) * 0.9); S.coins += c; float(`+${c}`, wpos(v.g, 3), '#ffd36b'); }
    // вантажівка може бути зламана, без пального або її саме тягнуть — тоді через 15 с комбайн продає решту сам і їде
    const tv = VH.truck, canGo = tv && !t.broken && t.fuel > 0 && !tv.busy;
    if (toTruck > 0.01 && canGo) {
      let done = false, tt = 0;
      const sellRest = () => { if (done) return; done = true; const c = Math.round(toTruck * grainPrice(crop) * 0.9); S.coins += c; float(`+${c}`, wpos(v.g, 3), '#ffd36b'); save(); leave(); };
      const off = W.onFrame((dt) => { tt += dt; if (done) off(); else if (tt > 15) { off(); sellRest(); } });
      go(tv, v.g.position.clone().add(V3(-2.2, 0, 0)), () => { if (done) return; augerTo(v, tv.g, 1.6, () => { if (done) return; done = true; t.load += toTruck; t.crop = crop; showLoad(); float(`+${toTruck.toFixed(1)} ${T.tons}`, wpos(tv.g, 2.2), '#ffd36b'); save(); leave(); }); });
    } else {
      if (toTruck > 0.01) { const c = Math.round(toTruck * grainPrice(crop) * 0.9); S.coins += c; float(`+${c}`, wpos(v.g, 3), '#ffd36b'); }
      leave();
    }
    // їде до краю острова (далі техніка не їде) — там і зникає
    function leave() { go(v, V3(7.9, 0, ID / 2 - 1.2), () => { [v.eng, v.work, v.aug].forEach((x) => x && x.stop(0.4)); F.remove(v.g); const ix = pickables.indexOf(v.g); if (ix >= 0) pickables.splice(ix, 1); delete VH.hire; refreshSites(); }); v.job = null; }
  }
  // вивантаження шнеком: зерно летить струменем
  function augerTo(v, target, dur, done) {
    const au = v.g.userData.auger; if (au) W.tween(au.rotation, { y: -Math.PI / 2 }, 0.5, ease.inOut);
    v.busy = dur; const crop = (S.m.combine && S.m.combine.crop) || v.lastCrop || 'wheat';
    if (!v.aug || v.aug.dead()) v.aug = SND.loop('grain', { vol: 0 }); v.augOn = true;
    const off = W.onFrame((dt) => { v.busy -= dt; if (Math.random() < 0.8) { const from = wpos(v.g, 2.1).addScaledVector(V3(-Math.cos(v.g.rotation.y), 0, Math.sin(v.g.rotation.y)), 1.6); fx.burst(from, new THREE.Color(D.CROPS[crop].c).getHex(), 3, 0.6, 0.5, 9); } if (v.busy <= 0) { off(); v.augOn = false; if (au) W.tween(au.rotation, { y: -0.15 }, 0.5, ease.inOut); done && done(); } });
    void target;
  }

  /* ================= дії: город ================= */
  const useStamina = (n, at) => { if (S.stamina < n) { float(T.tired, at || V3(-5, 2, 5), '#ff9a8a'); api.sfx('bad'); return false; } S.stamina -= n * (isNight() ? 1.5 : 1); return true; };
  function plant(i, k) {
    const b = S.beds[i]; if (!b.open || b.k || !(S.inv[k] > 0)) return false;
    if (!useStamina(2, bedPos(i).setY(1))) return false;
    b.k = k; b.t = 0; b.wet = 0; S.inv[k]--;
    buildPlant(BO[i], k); BO[i].plant.scale.setScalar(0.05);
    fx.burst(bedPos(i).add(V3(0, 0.35, 0)), 0x8a6440, 14, 1.4, 0.6); snd('dig', bedPos(i)); syncBins(); return true;
  }
  const bedNeed = (b) => { const { type, mut } = split(b.k); return D.CROPS[type].days / (mut ? D.MUT[mut].grow : 1); };
  function harvest(i) {
    const b = S.beds[i]; if (!b.k || b.t < bedNeed(b)) return false;
    if (!useStamina(2, bedPos(i).setY(1))) return false;
    const { type, mut } = split(b.k), n = 2 + (Math.random() < 0.45 ? 1 : 0) + (S.weather === 'rain' && Math.random() < 0.4 ? 1 : 0);
    let mutants = 0; if (mut) for (let j = 0; j < n; j++) if (Math.random() < 0.6) mutants++;
    S.inv[type] = (S.inv[type] || 0) + n - mutants; if (mutants) S.inv[b.k] = (S.inv[b.k] || 0) + mutants;
    const at = bedPos(i).add(V3(0, 0.6, 0));
    flyBits(at, ensureBin(mutants ? b.k : type).g.position.clone().setY(0.6), D.CROPS[type].c, Math.min(6, n));
    fx.burst(at, new THREE.Color(mut ? D.MUT[mut].c : D.CROPS[type].c).getHex(), 26, 2.2); float(`+${n}`, at, mut ? D.MUT[mut].c : '#fff');
    snd('crunch', at); snd('pop', at, 0.6, 0.12); api.pet('happy');
    b.k = null; b.t = 0; b.wet = 0; BO[i].plant.clear(); BO[i].built = null;
    cnt('harvestG', n); setTimeout(syncBins, 450); return true;
  }
  function water(i) {
    const b = S.beds[i]; if (!b.open || b.wet > 0.5) return;
    if (!useStamina(0.5)) return;
    b.wet = 1; BO[i].soil.material = wetM; if (b.k) b.t = Math.min(bedNeed(b), b.t + 0.04);
    fx.burst(bedPos(i).add(V3(0, 0.9, 0)), 0x8fd3ff, 22, 1.2, 0.7, 5); snd('pour', bedPos(i));
  }
  function sellCrate(k) {
    const keep = split(k).mut ? 0 : 2, n = Math.max(0, (S.inv[k] || 0) - keep);
    if (!n) { float(T.nothing, wpos(stall, 2.4), '#ff9a8a'); api.sfx('bad'); return; }
    const { type } = split(k), sum = gardenPrice(k) * n;
    S.inv[k] -= n; S.coins += sum; S.demand[type] = Math.max(0.45, (S.demand[type] || 1) - 0.05 * n);
    flyBits(ensureBin(k).g.position.clone().setY(0.6), wpos(stall, 0.8), D.CROPS[type].c, Math.min(8, n));
    setTimeout(() => { float(`+${sum}`, wpos(stall, 2.4), '#ffd36b'); fx.burst(wpos(stall, 1.6), 0xffd36b, 40, 2.6); snd('cash', wpos(stall)); }, 500);
    cnt('earnFair', sum); syncBins(); drawPrices(); save();
  }
  function buyGardenSeed(type) {
    const c = D.CROPS[type].seed; if (S.coins < c) { noCoins(wpos(SEED[type].g, 0.9), c); return; }
    S.coins -= c; S.inv[type] = (S.inv[type] || 0) + 1; ensureBin(type);
    W.tween(SEED[type].sk.scale, { x: 1.25, y: 1.4, z: 1.25 }, 0.12, ease.out, () => W.tween(SEED[type].sk.scale, { x: 1, y: 1.1, z: 1 }, 0.3, ease.back));
    flyBits(wpos(SEED[type].g, 0.4), ensureBin(type).g.position.clone().setY(0.6), D.CROPS[type].c, 1); api.sfx('coinpop'); setTimeout(syncBins, 500); save();
  }
  function unlockBed(i) {
    const c = bedCost(); if (S.coins < c) { noCoins(bedPos(i).setY(1.3), c); return; }
    S.coins -= c; S.beds[i].open = true; W.tween(BO[i].lock.scale, { x: 0.01, y: 0.01, z: 0.01 }, 0.35, ease.inOut);
    BO[i].bed.scale.set(1, 0.01, 1); W.tween(BO[i].bed.scale, { y: 1 }, 0.6, ease.back); fx.burst(bedPos(i).setY(0.5), 0xffd36b, 50, 3); snd('dig', bedPos(i)); api.sfx('ok'); save();
    BO.forEach((bo, j) => { if (!S.beds[j].open) bo.board.material.map = signTex('+' + bedCost()); });
  }
  function mutate(k, m) {
    const { type, mut } = split(k), M2 = D.MUT[m];
    if (mut || D.CROPS[type].model !== 'bean') { float(T.mutNo, wpos(FUN[m].g, 1.2), '#ff9a8a'); api.sfx('bad'); return; }
    if (!(S.inv[k] > 0)) return;
    if (S.coins < M2.cost) { noCoins(wpos(FUN[m].g, 1.2), M2.cost); return; }
    S.coins -= M2.cost; S.inv[k]--; mixing = 1.6; mixColor = new THREE.Color(M2.c);
    flyBits(ensureBin(k).g.position.clone().setY(0.6), wpos(FUN[m].g, 0.9), D.CROPS[type].c, 1); api.sfx('zap');
    setTimeout(() => {
      if (Math.random() < M2.ch) { const nk = keyOf(type, m); S.inv[nk] = (S.inv[nk] || 0) + 1; ensureBin(nk); flyBits(wpos(lab, 1.8), ensureBin(nk).g.position.clone().setY(0.6), M2.c, 1); float(T.mutOk, wpos(lab, 2.4), M2.c); fx.burst(wpos(lab, 1.6), new THREE.Color(M2.c).getHex(), 70, 3); api.sfx('win'); }
      else { S.inv[type] = (S.inv[type] || 0) + 1; float(T.mutNo, wpos(lab, 2.4), '#cfd6de'); api.sfx('bad'); }
      setTimeout(syncBins, 600); save();
    }, 1600);
    syncBins(); save();
  }
  function noCoins(at, c) { float(`${T.noCoins} · ${c}`, at, '#ff9a8a'); api.sfx('bad'); }

  /* ================= купівлі й будівництво (утримуй табличку) ================= */
  function buy(id) {
    const s = SITES[id]; if (!s) return; const o = s.o, at = wpos(s.g, 2);
    if (o.kind === 'hire') { hireCombine(o.key); return; }
    if (o.kind === 'truckup' && S.trip) { float(T.truckAway, at, '#ff9a8a'); api.sfx('bad'); return; }
    if (S.coins < o.cost) { noCoins(at, o.cost); return; }
    S.coins -= o.cost; snd(['build', 'upgrade', 'energy'].includes(o.kind) ? 'build' : ['machine', 'truckup'].includes(o.kind) ? 'horn' : o.kind === 'att' ? 'clunk' : 'ok', s.g.position); if (['machine', 'truckup', 'field'].includes(o.kind)) api.sfx('win'); float(o.kind === 'build' || o.kind === 'energy' ? T.built : T.bought, at, '#8fe08a');
    if (o.kind === 'build') { S.b[o.key] = 1; placeBuilding(o.key, true); cnt('build_' + o.key); if (['oilmill', 'groatsmill', 'feedmill'].includes(o.key)) cnt('build_mill'); if (['pond', 'gazebo'].includes(o.key)) cnt('build_rest'); if (o.key === 'elevator') cnt('elevator1'); }
    else if (o.kind === 'energy') { S.b[o.key]++; placeEnergy(true); cnt('build_' + o.key); }
    else if (o.kind === 'upgrade') { S.b[o.key]++; placeBuilding(o.key, true); if (o.key === 'house') { cnt('house2'); S.maxSt = maxStamina(); } if (o.key === 'elevator') cnt('elevator2'); upInfo(o.key); }
    else if (o.kind === 'truckup') { S.m.truck.lvl++; spawnTruck(); if (S.m.truck.lvl >= 3) cnt('truck3'); upInfo('truck'); }
    else if (o.kind === 'machine') { if (o.key === 'tractor') { S.m.tractor = { fuel: D.MACH.tractor.tank, oil: 100, dirt: 0.2, wear: 35, att: null, broken: false }; spawnTractor(); } else { S.m.combine = { fuel: D.MACH.combine.tank, oil: 100, dirt: 0, wear: 0, hopper: 0, crop: null, broken: false }; spawnCombine(false); } cnt('buy_' + o.key); }
    else if (o.kind === 'att') { S.m.att[o.key] = {}; spawnAtt(o.key); cnt('buy_' + o.key); }
    else if (o.kind === 'field') { S.fields[o.key].own = true; S.fields[o.key].st = 'grass'; paintField(o.key); if (S.fields.every((f) => f.own)) cnt('fields4'); }
    else if (o.kind === 'pivot') { S.fields[o.key].pivot = true; placePivot(o.key, true); }
    fx.burst(at, 0xffd36b, 60, 3); refreshSites(); save();
  }

  /* ================= догляд за технікою ================= */
  function refuel(v) {
    const st = mState(v.id); if (!st) return;
    const tank = v.id === 'combine' ? D.MACH.combine.tank : v.id === 'truck' ? D.MACH.truck.tank : D.MACH.tractor.tank, need = tank - st.fuel;
    if (need < 1) { float(T.refueled, wpos(v.g, 2.4), '#8fe08a'); return; }
    const own = Math.min(need, S.eth.own); S.eth.own -= own;
    const paid = Math.min(need - own, Math.floor(S.coins / 1.2)); S.coins -= Math.round(paid * 1.2);
    st.fuel += own + paid; v.warned = false;
    float(own > 0 ? T.ownFuel : `${T.refueled} −${Math.round(paid * 1.2)}`, wpos(v.g, 2.4), own > 0 ? '#7fd6ff' : '#8fe08a'); snd('fuel', v.g.position);
    cnt('refuel'); if (own > 0) cnt('ownFuel'); save();
  }
  function wash(v) {
    const st = mState(v.id); if (!st) return; const br = BL.wash && BL.wash.userData.brush;
    v.busy = 2.4; const sw = SND.loop('spray', { ...sp3(v.g.position), vol: sp3(v.g.position).vol * 0.9 });
    const off = W.onFrame((dt) => { v.busy -= dt; if (br) br.rotation.y += dt * 12; fx.burst(wpos(v.g, 1.5).add(V3((Math.random() - 0.5) * 1.5, 0.6, (Math.random() - 0.5) * 1.5)), Math.random() < 0.5 ? 0xffffff : 0x8fd3ff, 3, 1.4, 0.6, 5); if (v.busy <= 0) { off(); if (sw) sw.stop(0.4); st.dirt = 0; S.coins -= Math.min(S.coins, 5); float(T.washed, wpos(v.g, 2.4), '#8fd3ff'); api.sfx('ok'); cnt('wash'); save(); } });
  }
  function changeOil(v) {
    const st = mState(v.id); if (!st) return;
    if (S.coins < 20) { noCoins(wpos(v.g, 2.4), 20); return; }
    S.coins -= 20; st.oil = 100; float(T.oilDone, wpos(v.g, 2.4), '#ffd36b'); snd('oil', v.g.position); fx.burst(wpos(v.g, 1.4), 0x3a2a10, 16, 1.2); cnt('oil'); save();
  }

  // каністра: +20 л прямо в бак, де б машина не стояла (за ціною заправки)
  function pourJerry(v) {
    const st = mState(v.id); if (!st) return;
    const tank = v.id === 'combine' ? D.MACH.combine.tank : v.id === 'truck' ? D.MACH.truck.tank : D.MACH.tractor.tank, add = Math.min(20, tank - st.fuel);
    if (add < 1) { float(T.refueled, wpos(v.g, 2.4), '#8fe08a'); return; }
    const own = Math.min(add, S.eth.own); S.eth.own -= own; const cost = Math.round((add - own) * 1.2);
    if (S.coins < cost) { noCoins(wpos(v.g, 2.4), cost); S.eth.own += own; return; }
    S.coins -= cost; st.fuel += add; v.warned = false;
    float(fmt(T.jerryDone, { n: Math.round(add) }) + (cost ? ` −${cost}` : ''), wpos(v.g, 2.4), '#8fe08a'); snd('fuel', v.g.position);
    cnt('refuel'); if (own > 0) cnt('ownFuel'); save();
  }
  // миття руками: бруд сходить від руху губки по машині (треба саме терти, а не тримати)
  function scrub(v, px, c) {
    const st = mState(v.id); if (!st || st.dirt <= 0.001) return;
    st.dirt = Math.max(0, st.dirt - px * 0.0016); c.rub += px;
    if (Math.random() < 0.5) fx.burst(wpos(v.g, 1.0 + Math.random() * 0.8).add(V3((Math.random() - 0.5) * 1.4, 0, (Math.random() - 0.5) * 1.4)), Math.random() < 0.6 ? 0xffffff : 0x8fd3ff, 3, 0.9, 0.6, 3);
    const now = performance.now(); if (now - c.rubT > 180) { c.rubT = now; snd('erase', v.g.position, 1.4); if (Math.random() < 0.3) snd('plop', v.g.position, 0.5); }
    if (st.dirt <= 0.001) { st.dirt = 0; float(T.washed, wpos(v.g, 2.4), '#8fd3ff'); api.sfx('ok'); cnt('wash'); S.stamina = Math.max(0, S.stamina - 2); save(); }
  }
  // палета продукції — у свою вантажівку (потім у місто)
  function loadGoods(k) {
    const t = S.m.truck, n = S.goods[k]; if (!n) return;
    if (t.load > 0.01 || (t.goods && t.goods.k !== k)) { float(T.truckBusy, wpos(VH.truck.g, 2.2), '#ff9a8a'); api.sfx('bad'); return; }
    t.goods = { k, n: (t.goods ? t.goods.n : 0) + n }; S.goods[k] = 0;
    flyBits(wpos(GP[k] ? GP[k].g : VH.truck.g, 0.6), wpos(VH.truck.g, 1), D.GOODS[k].c, 5); snd('clunk', VH.truck.g.position, 0.9, 0.5);
    float(fmt(T.loadedGoods, { t: `${D.GOODS[k].n[lang]} ${goodTxt(k, t.goods.n)}` }), wpos(VH.truck.g, 2.4), '#ffd36b');
    showLoad(); syncGoods(); save();
  }
  const tripValue = () => { const t = S.m.truck; if (t.goods) return Math.round(t.goods.n * D.GOODS[t.goods.k].price * CITY.mul); if (t.load > 0.01 && t.crop) return Math.round(t.load * grainPrice(t.crop) * CITY.mul); return 0; };
  function cityTrip(v) {
    const t = S.m.truck, pay = tripValue();
    if (!pay) { float(T.tripEmpty, wpos(v.g, 2.4), '#ff9a8a'); api.sfx('bad'); return; }
    go(v, V3(P.city[0], 0, P.city[1]), () => {
      if (t.fuel < CITY.fuel) { float(fmt(T.tripFuel, { n: CITY.fuel }), wpos(v.g, 2.4), '#ff9a8a'); snd('crankFail', v.g.position); return; }
      t.fuel -= CITY.fuel; S.trip = { left: CITY.secs, pay, what: t.goods ? t.goods.k : t.crop };
      snd('horn', v.g.position); float(T.trip, wpos(v.g, 2.4), '#ffd36b');
      v.g.rotation.y = 0; W.tween(v.g.position, { z: 21 }, 1.6, ease.in, () => { v.g.visible = false; }); save();
    });
  }
  function tripBack() {
    const v = VH.truck, t = S.m.truck, tr = S.trip; if (!v || !tr) return;
    S.trip = null; v.g.visible = true; v.g.position.set(P.city[0], 0, 21); v.g.rotation.y = Math.PI;
    W.tween(v.g.position, { z: P.city[1] }, 1.6, ease.out, () => {
      S.coins += tr.pay; t.load = 0; t.crop = null; t.goods = null; showLoad();
      t.dirt = Math.min(1, t.dirt + 0.25); t.wear = Math.min(100, t.wear + 4); t.oil = Math.max(0, t.oil - 6); // далека дорога зношує
      float(fmt(T.tripBack, { n: tr.pay }), wpos(v.g, 2.6), '#ffd36b'); fx.burst(wpos(v.g, 1.6), 0xffd36b, 50, 3); snd('horn', v.g.position); snd('cash', v.g.position, 1, 0.3);
      api.coins(2); cnt('city'); if (D.CROPS[tr.what]) cnt('sellGrain'); go(v, V3(P.park.truck[0], 0, P.park.truck[1]));
      // далека дорога на зношеній, брудній чи без мастила машині може скінчитись поломкою
      if (Math.random() < 0.03 + t.wear * 0.004 + (t.oil < 25 ? 0.15 : 0) + t.dirt * 0.05) setTimeout(() => { breakDown(v); save(); }, 900);
      save();
    });
  }

  /* ================= зерно: вагова, амбар ================= */
  const barnCap = () => (S.b.barn ? D.BLD.barn.cap[S.b.barn - 1] : 0);
  const barnTotal = () => Object.values(S.barn).reduce((a, b) => a + b, 0);
  function weigh() {
    const v = VH.truck, t = S.m.truck; if (!S.b.weigh) return;
    const g = BL.weigh, deck = V3(P.weigh[0], 0, P.weigh[1]);
    go(v, deck.clone().add(V3(3.2, 0, 0)), () => go(v, deck, () => {
      let k = 0; const total = t.load, crop = t.crop, show = g.userData.show;
      v.busy = 2.2; snd('scale', deck);
      const off = W.onFrame((dt) => { k = Math.min(1, k + dt / 1.6); show((total * ease.out(k)).toFixed(1) + ' t', '#ff4d3a'); if (k >= 1) { off(); const pay = Math.round(total * grainPrice(crop)); S.coins += pay; show(total.toFixed(1) + ' t', '#6bff8a'); float(fmt(T.weighed, { t: total.toFixed(1), n: pay }), wpos(g, 2.6), '#ffd36b'); fx.burst(wpos(g, 1.6), 0xffd36b, 50, 3); snd('cash', deck); t.load = 0; t.crop = null; showLoad(); cnt('sellGrain'); save(); W.tween(g.userData.gate.rotation, { z: 1.2 }, 0.4, ease.out); setTimeout(() => { W.tween(g.userData.gate.rotation, { z: 0 }, 0.5, ease.inOut); show('0.0 t'); go(v, V3(P.park.truck[0], 0, P.park.truck[1])); }, 900); } });
    }));
  }
  function toBarn(v, from) {
    if (!S.b.barn) return;
    const front = V3(P.barn[0] + 1.6, 0, P.barn[1] + 3.3);
    go(v, front, () => {
      const key = from === S.m.combine ? 'hopper' : 'load', room = barnCap() - barnTotal(), have = from[key] || 0, amt = Math.min(room, have), crop = from.crop;
      if (have <= 0.01 || !crop) { float(T.tripEmpty, wpos(v.g, 2.4), '#ff9a8a'); api.sfx('bad'); return; }
      if (amt <= 0.01) { float(T.barnFull, wpos(BL.barn, 3), '#ff9a8a'); api.sfx('bad'); return; }
      const fin = () => { from[key] -= amt; S.barn[crop] = (S.barn[crop] || 0) + amt; if (from[key] < 0.01) { from[key] = 0; from.crop = null; } showLoad(); drawPiles(); float(`${T.stored} +${amt.toFixed(1)} ${T.tons}`, wpos(BL.barn, 3), '#ffd36b'); api.sfx('ok'); save(); };
      if (v.id === 'combine') augerTo(v, BL.barn, 1.4, fin); else { v.busy = 1.2; snd('hiss', v.g.position, 0.8); snd('grain', v.g.position, 1, 0.3); fx.burst(wpos(v.g, 1.2), new THREE.Color(D.CROPS[crop].c).getHex(), 30, 1.6); setTimeout(fin, 900); }
    });
  }
  // купки врожаю перед амбаром: їх тягнеш у цехи
  const PILES = {};
  function drawPiles() {
    const g = BL.barn && BL.barn.userData.piles; if (!g) return;
    for (const p of Object.values(PILES)) { g.remove(p); const ix = pickables.indexOf(p); if (ix >= 0) pickables.splice(ix, 1); }
    let j = 0;
    for (const [c, t] of Object.entries(S.barn)) {
      if (t < 0.05) continue;
      const p = new THREE.Group(); p.position.set(-1.4 + j * 0.95, 0, 0); g.add(p); j++;
      const mound = new THREE.Mesh(new THREE.SphereGeometry(0.42, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), std(D.CROPS[c].c, 0.9)); mound.scale.set(1, clamp(0.3 + t / 8, 0.3, 1.2), 1); mound.castShadow = mound.receiveShadow = true; p.add(mound);
      const tag = label(`${t.toFixed(1)} ${T.tons}`, { size: 28, scale: 0.22, bg: 'rgba(30,22,10,.78)' }); tag.position.y = 0.9; p.add(tag);
      B.hitBox(p, 0.9, 0.8, 0.9, 0.3); p.userData.pick = { kind: 'pile', c }; pickables.push(p); PILES[c] = p;
    }
  }
  // вантажівка з урожаєм комбайна: комбайн під'їжджає й вивантажує шнеком
  // вантажівка вільна (не в місті, без продукції, справна й з пальним) — комбайн сам вивантажує в неї
  function autoUnload() { const t = S.m.truck; if (!VH.truck || S.trip || t.goods || t.broken || !(t.fuel > 0) || (t.load > 0.01 && t.crop !== S.m.combine.crop)) return; unloadCombine(); }
  function unloadCombine() {
    const v = VH.combine, c = S.m.combine, tv = VH.truck, t = S.m.truck; if (!v || !c.hopper) return;
    if (S.trip) { float(T.truckAway, wpos(v.g, 2.6), '#ff9a8a'); api.sfx('bad'); return; }
    if (t.goods) { float(T.truckBusy, wpos(tv.g, 2.2), '#ff9a8a'); api.sfx('bad'); return; }
    if (t.load && t.crop !== c.crop) { float(T.wrongGood, wpos(tv.g, 2.2), '#ff9a8a'); api.sfx('bad'); return; }
    const cap = D.MACH.truck.cap[t.lvl - 1], amt = Math.min(c.hopper, cap - t.load); if (amt <= 0.01) { float(T.hopperFull, wpos(tv.g, 2.2), '#ff9a8a'); return; }
    const side = tv.g.position.clone().add(V3(2.4, 0, 0));
    go(v, side, () => { W.tween(v.g.rotation, { y: tv.g.rotation.y }, 0.4, ease.inOut); augerTo(v, tv.g, 1.8, () => { c.hopper -= amt; t.load += amt; t.crop = c.crop; if (c.hopper < 0.01) { c.hopper = 0; c.crop = null; } showLoad(); float(`+${amt.toFixed(1)} ${T.tons}`, wpos(tv.g, 2.2), '#ffd36b'); api.sfx('ok'); save(); }); });
  }

  /* ================= переробка, замовлення, енергія ================= */
  const PLANT_OF = { oilmill: 'oil', groatsmill: 'groats', feedmill: 'feed', bioplant: 'bio' };
  const plantState = (p) => (S.plants[p] = S.plants[p] || { in: {}, t: 0 });
  function feedPlant(bkey, crop) {
    const pk = PLANT_OF[bkey], R = D.PLANTS[pk], ps = plantState(pk), g = BL[bkey];
    if (!(crop in R.in)) { float(T.wrongGood, wpos(g, 2.6), '#ff9a8a'); api.sfx('bad'); return; }
    const have = S.barn[crop] || 0, amt = Math.min(have, 2); if (amt < 0.05) { float(fmt(T.noInBarn, { c: D.CROPS[crop].n[lang] }), wpos(g, 2.6), '#ff9a8a'); api.sfx('bad'); return; }
    S.barn[crop] = have - amt; ps.in[crop] = (ps.in[crop] || 0) + amt;
    flyBits(PILES[crop] ? wpos(PILES[crop], 0.5) : wpos(BL.barn, 1), g.userData.hopper ? wpos(g.userData.hopper) : wpos(g, 1), D.CROPS[crop].c, 6);
    float(`${T.input} ${amt.toFixed(1)} ${T.tons}`, wpos(g, 2.8), '#ffd36b'); snd('grain', wpos(g), 0.9, 0.3); drawPiles(); save();
    const lack = Object.entries(R.in).map(([c, q]) => [c, q - (ps.in[c] || 0)]).filter(([, d]) => d > 1e-3);
    if (lack.length) setTimeout(() => float(fmt(T.needMore, { n: lack.map(([c, d]) => `${d.toFixed(1)} ${T.tons} ${D.CROPS[c].n[lang]}`).join(', ') }), wpos(g, 3.4), '#ff9a8a'), 700);
  }
  const powerSupply = () => { const w = WEATHER[S.weather], dayK = isNight() ? 0 : Math.sin(Math.min(1, S.tod / 0.58) * Math.PI); return S.b.wind * 40 * w.wind + S.b.solar * 30 * w.sunF * dayK; };
  let powerUse = 0, powerK = 1, PLANT_RUN = new Set();
  function runPlants(dtH) {
    powerUse = 0; const running = [];
    for (const [bkey, pk] of Object.entries(PLANT_OF)) { if (!S.b[bkey]) continue; const R = D.PLANTS[pk], ps = plantState(pk); if (Object.entries(R.in).every(([c, q]) => (ps.in[c] || 0) >= q - 1e-6)) { running.push([bkey, pk, R, ps]); powerUse += R.kw; } }
    S.fields.forEach((f, i) => { if (f.pivot && ['sown', 'grow'].includes(f.st) && f.water < 0.75) powerUse += 10; void i; });
    PLANT_RUN = new Set(running.map((r) => r[0]));
    const sup = powerSupply(); powerK = powerUse ? clamp(sup / powerUse, 0, 1) : 1; const k = 0.5 + 0.5 * powerK; // без своєї енергії — від старої лінії, вдвічі повільніше
    for (const [bkey, pk, R, ps] of running) {
      ps.t += dtH * k / R.hours;
      const g = BL[bkey]; if (g && g.userData.spin) g.userData.spin.rotation.x += dtH * 40;
      if (ps.t >= 1) {
        ps.t = 0; for (const [c, q] of Object.entries(R.in)) ps.in[c] -= q;
        for (const [o, q] of Object.entries(R.out)) { if (o === 'ethanol') { const own = q * S.eth.split; S.eth.own += own; S.goods.ethanol += q - own; } else S.goods[o] += q; }
        float(fmt(T.produced, { t: Object.keys(R.out).map((o) => D.GOODS[o].n[lang]).join(', ') }), wpos(g, 3), '#8fe08a'); api.sfx('ok'); cnt('produce'); syncGoods(); save();
      }
    }
  }
  // палети з продукцією біля цехів
  const GP = {};
  const GOOD_AT = { oil: 'oilmill', groats: 'groatsmill', feed: 'feedmill', ethanol: 'bioplant' };
  const goodTxt = (k, n) => (D.GOODS[k].unit === 'l' ? `${Math.round(n)} ${T.liters}` : `${n.toFixed(1)} ${T.tons}`);
  function syncGoods() {
    for (const [k, bkey] of Object.entries(GOOD_AT)) {
      const n = S.goods[k] || 0, g = BL[bkey];
      if (!g || n < (D.GOODS[k].unit === 'l' ? 1 : 0.05)) { if (GP[k]) { F.remove(GP[k].g); const ix = pickables.indexOf(GP[k].g); if (ix >= 0) pickables.splice(ix, 1); delete GP[k]; } continue; }
      if (!GP[k]) { const p = B.goodsPallet(k); const o = g.userData.out || V3(0, 0, 1.6); p.position.set(P[bkey][0] + o.x, 0, P[bkey][1] + o.z); F.add(p); pick(p, { kind: 'good', k }); GP[k] = { g: p, tag: null, txt: '' }; }
      const txt = goodTxt(k, n); if (GP[k].txt !== txt) { GP[k].txt = txt; if (GP[k].tag) GP[k].g.remove(GP[k].tag); GP[k].tag = label(txt, { size: 28, scale: 0.22, bg: 'rgba(30,22,10,.78)', color: '#ffd36b' }); GP[k].tag.position.y = 1.05; GP[k].g.add(GP[k].tag); }
    }
  }
  // замовлення: вантажівка покупця чекає біля дороги
  let orderV = null, orderTag = null;
  function newOrder() {
    const avail = Object.entries(GOOD_AT).filter(([, b]) => S.b[b]).map(([k]) => k); if (!avail.length) { S.order = null; return; }
    // спершу те, що вже є на складі, потім те, на що є сировина в амбарі/цеху — щоб замовлення можна було виконати
    const can = (k) => { const R = D.PLANTS[PLANT_OF[GOOD_AT[k]]], ps = plantState(PLANT_OF[GOOD_AT[k]]); return Object.keys(R.in).every((c) => (S.barn[c] || 0) + (ps.in[c] || 0) > 0.05); };
    const pool = avail.filter((k) => S.goods[k] > 0).length ? avail.filter((k) => S.goods[k] > 0) : avail.filter(can).length ? avail.filter(can) : avail;
    const k = pool[(Math.random() * pool.length) | 0], amt = D.GOODS[k].unit === 'l' ? 200 + Math.round(Math.random() * 3) * 100 : +(0.5 + Math.round(Math.random() * 3) * 0.25).toFixed(2);
    S.order = { k, amt, got: 0, days: 0, reward: Math.round(amt * D.GOODS[k].price * 1.35) }; drawOrder();
  }
  function drawOrder() {
    if (!S.order) { if (orderV) orderV.visible = false; return; }
    if (!orderV) { orderV = B.truck(2); orderV.position.set(P.dispatch[0], 0, P.dispatch[1]); orderV.rotation.y = Math.PI / 2; F.add(orderV); pick(orderV, { kind: 'order' }); }
    orderV.visible = true; if (orderTag) orderV.remove(orderTag);
    const o = S.order, cv = document.createElement('canvas'); cv.width = 420; cv.height = 130; const g = cv.getContext('2d');
    g.fillStyle = 'rgba(14,16,22,.82)'; g.beginPath(); g.roundRect(0, 0, 420, 130, 32); g.fill();
    g.fillStyle = D.GOODS[o.k].c; g.beginPath(); g.arc(56, 65, 26, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#fff'; g.font = '800 40px Onest, system-ui'; g.textBaseline = 'middle'; g.fillText(goodTxt(o.k, Math.max(0, o.amt - o.got)), 96, 48);
    g.fillStyle = '#ffd36b'; g.font = '800 36px Onest, system-ui'; g.fillText('+' + o.reward, 96, 96);
    const tx = new THREE.CanvasTexture(cv); tx.colorSpace = THREE.SRGBColorSpace;
    orderTag = new THREE.Sprite(new THREE.SpriteMaterial({ map: tx, depthTest: false, transparent: true })); orderTag.scale.set(2.1, 0.65, 1); orderTag.position.set(0, 2.6, 0); orderTag.renderOrder = 10; orderV.add(orderTag);
  }
  function deliverGood(k) {
    const o = S.order; if (!o) return;
    if (o.k !== k) { float(T.wrongGood, wpos(orderV, 2.4), '#ff9a8a'); api.sfx('bad'); return; }
    const give = Math.min(S.goods[k], o.amt - o.got); if (give <= 0) return;
    S.goods[k] -= give; o.got += give; flyBits(wpos(GP[k] ? GP[k].g : orderV, 0.6), wpos(orderV, 0.8), D.GOODS[k].c, 6); snd('clunk', wpos(orderV), 0.8, 0.5);
    if (o.got >= o.amt - 1e-6) {
      S.coins += o.reward; float(fmt(T.orderDone, { n: o.reward }), wpos(orderV, 3), '#ffd36b'); fx.burst(wpos(orderV, 1.6), 0xffd36b, 70, 3); api.sfx('win'); snd('horn', wpos(orderV), 1, 0.9); api.coins(2); cnt('order');
      const ov = orderV; W.tween(ov.position, { x: 7.9 }, 1.2, ease.inOut, () => W.tween(ov.position, { z: -18 }, 1.4, ease.inOut, () => { ov.position.set(P.dispatch[0], 0, P.dispatch[1]); S.order = null; drawOrder(); orderCD = 40; }));
    } else drawOrder();
    syncGoods(); save();
  }
  let orderCD = 20;
  function sellGoodAtFair(k) { const n = S.goods[k]; if (!n) return; const sum = Math.round(n * D.GOODS[k].price); S.goods[k] = 0; S.coins += sum; float(`+${sum}`, wpos(stall, 2.4), '#ffd36b'); snd('cash', wpos(stall)); syncGoods(); save(); }

  /* ================= дотики ================= */
  let carry = null;
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.7, 0.9, 40), new THREE.MeshBasicMaterial({ color: 0xffe08a, transparent: true, opacity: 0.9, depthWrite: false })); ring.rotation.x = -Math.PI / 2; ring.visible = false; F.add(ring);
  const near = (p, o, r) => { const q = o.isVector3 ? o : wpos(o); return Math.hypot(p.x - q.x, p.z - q.z) < r; };
  const bedAt = (p) => { for (let i = 0; i < BEDS; i++) { const q = bedPos(i); if (Math.abs(p.x - q.x) < 0.72 && Math.abs(p.z - q.z) < 0.72) return i; } return -1; };
  const fieldAt = (p) => { for (let i = 0; i < P.fields.length; i++) { const [x, z] = P.fields[i]; if (Math.abs(p.x - x) < FH + 0.3 && Math.abs(p.z - z) < FH + 0.3) return i; } return -1; };
  function ghost(kind, color) { const g = kind === 'oilcan' || kind === 'jerry' || kind === 'bucket' ? B.sack(0, kind) : kind === 'good' ? B.goodsPallet(color) : B.sack(color || 0xd9c49c, kind === 'fert' ? 'fert' : 'seed'); g.traverse((m) => { if (m.isMesh) m.castShadow = false; }); F.add(g); return g; }
  const vehAt = (p, except) => { for (const v of Object.values(VH)) if (v.id !== except && v.id !== 'hire' && near(p, v.g, v.id === 'combine' ? 2.2 : 1.6)) return v; return null; };
  const attAt = (p) => { for (const a of Object.values(ATT)) if (near(p, a.g, 1.4)) return a; return null; };
  // куди можна поставити техніку
  function vehTarget(v, p) {
    const f = fieldAt(p); if (f >= 0 && v.id !== 'truck' && v.id !== 'jeep') return { kind: 'field', i: f, at: V3(P.fields[f][0], 0, P.fields[f][1]) };
    if (S.b.fuel && near(p, V3(...P.fuel.slice(0, 1), 0, P.fuel[1]), 1.8)) return { kind: 'fuel', at: V3(P.fuel[0], 0, P.fuel[1]) };
    if (S.b.wash && near(p, V3(P.wash[0], 0, P.wash[1]), 1.8)) return { kind: 'wash', at: V3(P.wash[0], 0, P.wash[1]) };
    if (v.id === 'tractor') { const a = attAt(p); if (a && a.on !== 'tractor') return { kind: 'att', a, at: a.g.position.clone() }; }
    if (v.id === 'combine' && !S.trip && near(p, VH.truck.g, 2.0)) return { kind: 'truck', at: VH.truck.g.position.clone() };
    if ((v.id === 'truck' || v.id === 'combine') && S.b.barn && near(p, V3(P.barn[0], 0, P.barn[1] + 1.2), 2.6)) return { kind: 'barn', at: V3(P.barn[0], 0, P.barn[1] + 2) };
    if (v.id === 'truck' && S.b.weigh && near(p, V3(P.weigh[0], 0, P.weigh[1]), 2.2)) return { kind: 'weigh', at: V3(P.weigh[0], 0, P.weigh[1]) };
    if (v.id === 'truck' && citySign.visible && near(p, V3(P.city[0], 0, P.city[1]), 2.4)) return { kind: 'city', at: V3(P.city[0], 0, P.city[1]) };
    if (S.b.hangar && near(p, V3(P.hangar[0], 0, P.hangar[1]), 2.4)) return { kind: 'hangar', at: V3(P.hangar[0], 0, P.hangar[1]) };
    return null;
  }
  function dropVeh(v, p) {
    const tg = vehTarget(v, p); v.job = null;
    if (!tg) { go(v, p); return; }
    if (tg.kind === 'field') { if (canWork(v, tg.i)) startWork(v, tg.i); }
    else if (tg.kind === 'fuel') go(v, V3(P.fuel[0] - 1.9, 0, P.fuel[1] + 0.2), () => refuel(v));
    else if (tg.kind === 'wash') go(v, V3(P.wash[0], 0, P.wash[1]), () => wash(v));
    else if (tg.kind === 'att') hitch(tg.a);
    else if (tg.kind === 'truck') unloadCombine();
    else if (tg.kind === 'barn') { if (v.id === 'truck') { if (S.m.truck.load) toBarn(v, S.m.truck); else go(v, p); } else if (S.m.combine.hopper) toBarn(v, S.m.combine); }
    else if (tg.kind === 'weigh') { if (S.m.truck.load) weigh(); else go(v, p); }
    else if (tg.kind === 'city') cityTrip(v);
    else if (tg.kind === 'hangar') go(v, tg.at.clone().add(V3((v.id === 'combine' ? 1 : -1) * 1.2, 0, 0)));
  }
  // спершу те, що тягають руками (техніка в ангарі, мішки, ящики), потім будівлі
  const TIERS = [new Set(['bolt']), new Set(['veh', 'order']), new Set(['att', 'bin', 'fseed', 'oilcan', 'jerry', 'bucket', 'pile', 'good', 'can', 'gseed']), new Set(['site', 'city'])];
  function pickFirst(e) { for (const t of TIERS) { const h2 = W.pick(e, pickables.filter((o) => o.userData.pick && t.has(o.userData.pick.kind))); if (h2) return h2; } return W.pick(e, pickables); }
  const holdMs = 850;
  cam.onDown = (e) => {
    if (!started || fishing.state === 'bite') return;
    const hit = pickFirst(e); if (!hit) return;
    const u = hit.obj.userData.pick;
    const grab = (c) => { carry = c; cam.grab(e); carry.x = e.clientX; carry.y = e.clientY; };
    if (u.kind === 'bin' && (S.inv[u.k] || 0) > 0) { grab({ kind: 'bin', k: u.k, g: ghost('seed', D.CROPS[split(u.k).type].c), planted: 0 }); api.sfx('pop'); }
    else if (u.kind === 'can') { grab({ kind: 'can' }); api.sfx('pop'); }
    else if (u.kind === 'bed' && S.beds[u.i].k && S.beds[u.i].t >= bedNeed(S.beds[u.i])) { grab({ kind: 'swipe' }); harvest(u.i); }
    else if (u.kind === 'veh' && u.id === 'truck' && S.trip) { bubble(wpos(VH.truck.g, 2.2), esc(T.truckAway)); }
    else if (u.kind === 'veh' && (mState(u.id) || {}).broken) { const v = VH[u.id]; bubble(wpos(v.g, 2.8), `<b>${esc(T.broken)}</b><br>${esc(T.needFix)}`); coachFlash = 3; api.sfx('bad'); }
    else if (u.kind === 'veh' && u.id !== 'jeep' && u.id !== 'hire') { grab({ kind: 'veh', id: u.id, moved: false }); }
    else if (u.kind === 'jerry') { grab({ kind: 'jerry', g: ghost('jerry'), moved: false }); api.sfx('pop'); }
    else if (u.kind === 'bucket') { grab({ kind: 'bucket', g: ghost('bucket'), moved: false, rub: 0, rubT: 0, px: e.clientX, py: e.clientY }); bucket.visible = false; api.sfx('pop'); }
    else if (u.kind === 'fseed' && (S.seeds[u.c] || 0) > 0) { grab({ kind: 'fseed', c: u.c, g: ghost('seed', D.CROPS[u.c].c), moved: false }); }
    else if (u.kind === 'bld' && u.key === 'fertshed' && S.fertBags > 0) { grab({ kind: 'fert', g: ghost('fert'), moved: false }); }
    else if (u.kind === 'oilcan') { grab({ kind: 'oilcan', g: ghost('oilcan'), moved: false }); }
    else if (u.kind === 'pile') { grab({ kind: 'pile', c: u.c, g: ghost('seed', D.CROPS[u.c].c), moved: false }); }
    else if (u.kind === 'good') { grab({ kind: 'good', k: u.k, g: ghost('good', u.k), moved: false }); }
    else if (u.kind === 'bld' && u.key === 'bioplant' && hit.point && near(hit.point, wpos(BL.bioplant.userData.lever), 0.9)) { grab({ kind: 'lever' }); }
    else if (u.kind === 'site') { grab({ kind: 'hold', id: u.id, t: 0, t0: performance.now() }); api.sfx('tap'); }
    else if (u.kind === 'bld' && u.key === 'pond' && fishing.state === 'idle') { grab({ kind: 'cast', moved: false }); }
    if (carry && carry.g) carry.g.visible = false;
  };
  cam.onMove = (e) => {
    if (!carry) return;
    carry.ev = { clientX: e.clientX, clientY: e.clientY };
    const g = cam.ground(e.clientX, e.clientY); if (!g) return;
    const mv = Math.hypot(e.clientX - carry.x, e.clientY - carry.y) > 10; if (mv) carry.moved = true;
    if (carry.g) { carry.g.visible = carry.moved; carry.g.position.set(g.x, 1.0, g.z); }
    if (carry.kind === 'bin') { const i = bedAt(g); if (i >= 0 && S.beds[i].open && !S.beds[i].k && plant(i, carry.k)) carry.planted++; ring.visible = near(g, stall, 2) || near(g, FUN.sun.g, 0.7) || near(g, FUN.star.g, 0.7); if (ring.visible) ring.position.set(g.x, 0.06, g.z); }
    else if (carry.kind === 'can') { can.position.set(g.x, 1.0, g.z); can.rotation.z = -0.6; const i = bedAt(g); if (i >= 0) water(i); if (Math.random() < 0.6) fx.burst(can.position.clone().add(V3(0.35, -0.1, 0)), 0x8fd3ff, 2, 0.4, 0.5, 6); }
    else if (carry.kind === 'swipe') { const i = bedAt(g); if (i >= 0) harvest(i); }
    else if (carry.kind === 'veh') { const v = VH[carry.id], tg = vehTarget(v, g); ring.visible = carry.moved; const at = tg ? tg.at : g; ring.position.set(at.x, 0.07, at.z); ring.scale.setScalar(tg && tg.kind === 'field' ? 3.4 : 1); ring.material.color.set(tg ? 0x8fe08a : 0xffe08a); }
    else if (carry.kind === 'hold') { if (mv) { carry = null; drawSite(null); } }
    else if (carry.kind === 'lever') { const lv = BL.bioplant, lp = lv.worldToLocal(g.clone()); S.eth.split = clamp(0.5 - (lp.x - 0) / 0.9, 0, 1); lv.userData.lever.rotation.z = (S.eth.split - 0.5) * 1.6; bubble(wpos(lv, 3.2), `${esc(T.split)}<br><b>${Math.round(S.eth.split * 100)}% ${esc(T.own)} · ${Math.round((1 - S.eth.split) * 100)}% ${esc(T.sale)}</b>`); }
    else if (carry.kind === 'cast') { ring.visible = carry.moved; ring.position.set(g.x, 0.08, g.z); ring.scale.setScalar(0.5); }
    else if (carry.kind === 'bucket') { const v = vehAt(g); carry.over = !!v; ring.visible = !!v && carry.moved; if (v) { ring.position.set(v.g.position.x, 0.07, v.g.position.z); ring.scale.setScalar(1.6); ring.material.color.set(0x8fd3ff); let px = 0, lx = carry.px, ly = carry.py; for (const ce of (e.getCoalescedEvents ? e.getCoalescedEvents() : null) || [e]) { px += Math.hypot(ce.clientX - lx, ce.clientY - ly); lx = ce.clientX; ly = ce.clientY; } scrub(v, px, carry); } carry.px = e.clientX; carry.py = e.clientY; }
    else { // мішки, каністра, купки, палети: підсвітити, куди впаде
      const tg = itemTarget(carry, g); ring.visible = !!tg && carry.moved; if (tg) { ring.position.set(tg.at.x, 0.07, tg.at.z); ring.scale.setScalar(1.2); ring.material.color.set(0x8fe08a); }
    }
  };
  function itemTarget(c, p) {
    if (c.kind === 'fseed') { const a = ATT.seeder; if (a && near(p, a.g, 1.6)) return { at: a.g.position, a }; }
    if (c.kind === 'fert') { const a = ATT.sprayer; if (a && near(p, a.g, 1.6)) return { at: a.g.position, a }; }
    if (c.kind === 'oilcan' || c.kind === 'jerry') { const v = vehAt(p); if (v && v.id !== 'jeep') return { at: v.g.position, v }; }
    if (c.kind === 'good') { // своя вантажівка й вантажівка замовлення можуть стояти поруч — обираємо ту, до якої ближче відпустили
      const d = (o) => { const q = wpos(o); return Math.hypot(p.x - q.x, p.z - q.z); }, cand = [];
      if (VH.truck && !S.trip && near(p, VH.truck.g, 1.8)) cand.push([d(VH.truck.g), { at: VH.truck.g.position, truck: true }]);
      if (orderV && orderV.visible && near(p, orderV, 2.2)) cand.push([d(orderV) - 0.4, { at: orderV.position, order: true }]);
      if (cand.length) return cand.sort((x, y) => x[0] - y[0])[0][1];
    }
    if (c.kind === 'pile') { for (const bkey of Object.keys(PLANT_OF)) if (BL[bkey] && near(p, BL[bkey], 2.6)) return { at: BL[bkey].position, bkey }; }
    if (c.kind === 'good' && near(p, stall, 2.2)) return { at: stall.position, fair: true };
    return null;
  }
  cam.onUp = (e) => {
    const c = carry; carry = null; ring.visible = false; ring.scale.setScalar(1); ring.material.color.set(0xffe08a); if (!c) return;
    if (c.g) F.remove(c.g);
    const g = cam.ground(e.clientX, e.clientY) || V3();
    if (c.kind === 'bin') { if (near(g, stall, 2)) sellCrate(c.k); else if (near(g, FUN.sun.g, 0.7)) mutate(c.k, 'sun'); else if (near(g, FUN.star.g, 0.7)) mutate(c.k, 'star'); else if (!c.planted) api.sfx('tap'); save(); }
    else if (c.kind === 'can') { W.tween(can.position, { x: canHome.x, y: 0, z: canHome.z }, 0.5, ease.out); can.rotation.z = 0; save(); }
    else if (c.kind === 'veh') { if (c.moved) dropVeh(VH[c.id], g); else showVeh(VH[c.id]); }
    else if (c.kind === 'hold') { drawSite(null); if (performance.now() - c.t0 >= holdMs) buy(c.id); }
    else if (c.kind === 'cast') { if (c.moved) cast(g); }
    else if (c.kind === 'lever') save();
    else if (c.kind === 'bucket') { bucket.visible = true; if (c.rub > 0) save(); }
    else if (!c.moved) tapItem(c);
    else {
      const tg = itemTarget(c, g); if (!tg) { api.sfx('tap'); return; }
      if (c.kind === 'fseed') { const sd = S.m.att.seeder; if (sd.seed) { float(T.loaded, wpos(tg.a.g, 1.6), '#ffd36b'); return; } S.seeds[c.c]--; sd.seed = c.c; tg.a.g.userData.fill.visible = true; tg.a.g.userData.fill.material = std(D.CROPS[c.c].c, 0.9); float(T.loaded, wpos(tg.a.g, 1.6), '#8fe08a'); api.sfx('ok'); cnt('loadSeed'); syncRack(); save(); }
      else if (c.kind === 'fert') { const sp = S.m.att.sprayer; if (sp.fert) return; S.fertBags--; sp.fert = 1; tg.a.g.userData.fill.visible = true; float(T.fertLoaded, wpos(tg.a.g, 1.6), '#8fe08a'); api.sfx('ok'); B.fertBags(BL.fertshed.userData.bags, S.fertBags); save(); }
      else if (c.kind === 'oilcan') changeOil(tg.v);
      else if (c.kind === 'jerry') pourJerry(tg.v);
      else if (c.kind === 'pile') feedPlant(tg.bkey, c.c);
      else if (c.kind === 'good') { if (tg.truck) loadGoods(c.k); else if (tg.order) deliverGood(c.k); else sellGoodAtFair(c.k); }
    }
  };
  function tapItem(c) {
    if (c.kind === 'fseed') buyFieldSeed(c.c);
    else if (c.kind === 'fert') buyFert();
    else if (c.kind === 'pile') bubble(wpos(PILES[c.c], 1.2), `<b>${esc(D.CROPS[c.c].n[lang])}</b> · ${S.barn[c.c].toFixed(1)} ${esc(T.tons)}<br><span class="gsub">${esc(T.c_hopper)}</span>`);
    else if (c.kind === 'good') bubble(wpos(GP[c.k].g, 1.4), `<b>${esc(D.GOODS[c.k].n[lang])}</b> · ${esc(goodTxt(c.k, S.goods[c.k]))}<br><span class="gsub">${esc(T.c_orderD)}</span>`);
    else if (c.kind === 'oilcan') bubble(wpos(oilcan, 1.2), esc(T.c_oilC));
    else if (c.kind === 'jerry') bubble(wpos(jerry, 1.2), esc(T.c_jerry));
    else if (c.kind === 'bucket') bubble(wpos(bucket, 1.2), esc(T.c_scrub));
  }
  function buyFieldSeed(c) { const cost = D.CROPS[c].seed; if (S.coins < cost) { noCoins(wpos(RS[c].g, 1), cost); return; } S.coins -= cost; S.seeds[c] = (S.seeds[c] || 0) + 1; api.sfx('coinpop'); W.tween(RS[c].g.scale, { x: 1.2, y: 1.3, z: 1.2 }, 0.12, ease.out, () => W.tween(RS[c].g.scale, { x: 1, y: 1, z: 1 }, 0.3, ease.back)); syncRack(); save(); }
  function buyFert() { if (!S.b.fertshed) return; if (S.coins < D.GOODS.fert.price) { noCoins(wpos(BL.fertshed, 2), D.GOODS.fert.price); return; } S.coins -= D.GOODS.fert.price; S.fertBags++; B.fertBags(BL.fertshed.userData.bags, S.fertBags); api.sfx('coinpop'); save(); }
  function drawSite(c) { for (const s of Object.values(SITES)) s.g.userData.draw(s.o.name, s.o.kind === 'hire' ? '' : String(s.o.cost), c && c.id === s.o.id ? c.t / (holdMs / 1000) : 0); }
  cam.onTap = (e) => {
    if (!started) return;
    if (fishing.state === 'bite') { catchFish(); return; }
    const hit = (crow && W.pick(e, [crow])) || pickFirst(e); if (!hit) { hideCard(); return; }
    const u = hit.obj.userData.pick;
    if (u.kind === 'crow') scareCrow(false);
    else if (u.kind === 'gseed') buyGardenSeed(u.type);
    else if (u.kind === 'fseed') buyFieldSeed(u.c);
    else if (u.kind === 'bolt') fixBolt(hit.obj, u.id);
    else if (u.kind === 'bed') { const b = S.beds[u.i]; if (!b.open) unlockBed(u.i); else if (b.k && b.t >= bedNeed(b)) harvest(u.i); else if (b.k) bubble(bedPos(u.i).add(V3(0, 1.6, 0)), `<b>${esc(D.CROPS[split(b.k).type].n[lang])}</b><br>${Math.round(b.t / bedNeed(b) * 100)}%${b.wet > 0 ? ' · ' + esc(T.water) : ''}`); else { coachFlash = 3; api.sfx('tap'); } }
    else if (u.kind === 'veh') showVeh(VH[u.id]);
    else if (u.kind === 'field') showField(u.i);
    else if (u.kind === 'bld') tapBuilding(u.key, hit);
    else if (u.kind === 'energy') showPower();
    else if (u.kind === 'site') { const s = SITES[u.id]; bubble(wpos(s.g, 2.4), `<b>${esc(s.o.name)}</b>${s.o.cost ? ` · ${s.o.cost} ${gi('coin', 14)}` : ''}<br><span class="gsub">${esc(s.o.kind === 'hire' ? T.c_hire : s.o.kind === 'build' || s.o.kind === 'energy' ? T.holdBuild : T.holdBuy)}</span>`); api.sfx('tap'); }
    else if (u.kind === 'att') { const a = ATT[u.a]; bubble(wpos(a.g, 1.8), `<b>${esc(N[u.a])}</b>${u.a === 'seeder' && S.m.att.seeder.seed ? ' · ' + esc(D.CROPS[S.m.att.seeder.seed].n[lang]) : ''}<br><span class="gsub">${esc(T.c_hitch)}</span>`); }
    else if (u.kind === 'stall') bubble(wpos(stall, 3.2), `<b>${esc(N.stall)}</b><br>${D.GARDEN.slice(0, 6).map((tp) => `${beanSvg(D.CROPS[tp].c, 13)} ${gardenPrice(tp)}`).join(' &nbsp;')}<br><span class="gsub">${esc(T.c_sell)}</span>`);
    else if (u.kind === 'order' && S.order && S.goods[S.order.k] > 0) deliverGood(S.order.k); // дотик — віддати, що є на складі (завод може бути далеко від вантажівки)
    else if (u.kind === 'order' && S.order) bubble(wpos(orderV, 3.2), `<b>${esc(T.order)}</b>: ${esc(D.GOODS[S.order.k].n[lang])} · ${esc(goodTxt(S.order.k, S.order.amt - S.order.got))} → +${S.order.reward}<br><span class="gsub">${esc(fmt(T.orderNeed, { b: N[GOOD_AT[S.order.k]] || '' }))}</span>`);
    else if (u.kind === 'can') bubble(wpos(can, 1), esc(T.c_water));
    else if (u.kind === 'bin') { const n = S.inv[u.k] || 0, tp = split(u.k).type; bubble(wpos(BIN[u.k].g, 1.2), `${beanSvg(D.CROPS[tp].c)} <b>${esc(D.CROPS[tp].n[lang])}${split(u.k).mut ? ' ★' : ''}</b> · ${n}<br><span class="gsub">${esc(T.c_plant)}</span>`); }
    else if (u.kind === 'funnel') bubble(wpos(FUN[u.m].g, 1.3), `<b>${Math.round(D.MUT[u.m].ch * 100)}%</b> · ${D.MUT[u.m].cost} ${gi('coin', 14)}`);
    else if (u.kind === 'pet') { petPlay('happy'); setTimeout(() => petPlay('idle'), 800); api.pet('happy'); api.sfx('pop'); fx.burst(wpos(petO, 1), 0xff7fa8, 16, 1.4); }
    else if (u.kind === 'oilcan') bubble(wpos(oilcan, 1.2), esc(T.c_oilC));
    else if (u.kind === 'city') bubble(wpos(citySign, 2.8), `<b>${esc(T.city)}</b> · ${esc(T.citySub)}<br><span class="gsub">${esc(T.c_city)}</span>`);
    else if (u.kind === 'pile' || u.kind === 'good') tapItem(u);
    api.sfx('tap');
  };
  cam.onHold = (e) => cam.onTap(e);
  // що дає будівля чи покращення — показуємо одразу після купівлі й при дотику
  const elevPct = () => 10 * S.b.elevator;
  function upInfo(key) {
    const txt = key === 'barn' ? fmt(T.upBarn, { n: barnCap() }) : key === 'elevator' ? fmt(T.upElev, { n: elevPct() }) : key === 'truck' ? fmt(T.upTruck, { n: D.MACH.truck.cap[S.m.truck.lvl - 1] }) : key === 'house' ? fmt(T.upHouse, { n: maxStamina() }) : '';
    if (txt) showCard(`<b>${esc(N[key] || key)} · ${esc(T.level)} ${key === 'truck' ? S.m.truck.lvl : S.b[key]}</b><br>${esc(txt)}`);
  }
  function tapBuilding(key, hit) {
    const g = BL[key];
    if (key === 'house') { if (isNight()) sleep(); else showCard(`<b>${esc(N.house)}</b> · ${esc(T.level)} ${S.b.house}<br>${esc(T.stamina)}: ${Math.round(S.stamina)}/${maxStamina()}`); }
    else if (key === 'hammock' || key === 'gazebo') rest(key);
    else if (key === 'pond') { if (fishing.state === 'idle') bubble(wpos(g, 1.6), esc(T.cast)); }
    else if (key === 'barn') showCard(`<b>${esc(N.barn)}</b> · ${barnTotal().toFixed(1)}/${barnCap()} ${esc(T.tons)}<br>${Object.entries(S.barn).filter(([, t]) => t > 0.05).map(([c, t]) => `${beanSvg(D.CROPS[c].c, 13)} ${esc(D.CROPS[c].n[lang])} ${t.toFixed(1)}`).join('<br>') || esc(T.empty)}`);
    else if (key === 'fertshed') buyFert();
    else if (PLANT_OF[key]) { const pk = PLANT_OF[key], R = D.PLANTS[pk], ps = plantState(pk); showCard(`<b>${esc(N[key])}</b><br>${esc(T.needs)}: ${Object.entries(R.in).map(([c, q]) => `${esc(D.CROPS[c].n[lang])} ${q} ${esc(T.tons)} (${(ps.in[c] || 0).toFixed(1)})`).join(' + ')}<br>${esc(T.gives)}: ${Object.entries(R.out).map(([o, q]) => `${esc(D.GOODS[o].n[lang])} ${goodTxt(o, q)}`).join(', ')}<br>${gauge(T.working, ps.t, '#8fe08a')}${powerUse > 0 && powerK < 0.99 ? `<span class="gsub">${esc(T.noPower)}</span>` : ''}${pk === 'bio' ? `<br>${esc(T.split)}: ${Math.round(S.eth.split * 100)}% / ${Math.round((1 - S.eth.split) * 100)}% · ${esc(T.own)} ${Math.round(S.eth.own)} ${esc(T.liters)}` : ''}`); }
    else if (key === 'elevator') showCard(`<b>${esc(N.elevator)}</b> · ${esc(T.level)} ${S.b.elevator}<br>${esc(fmt(T.upElev, { n: elevPct() }))}<br>${D.FIELD.map((c) => `${beanSvg(D.CROPS[c].c, 13)} ${D.CROPS[c].price} → <b>${grainPrice(c)}</b>/${esc(T.tons)}`).join(' &nbsp;')}${S.b.elevator < 2 ? `<br><span class="gsub">${esc(T.elevNext)}</span>` : ''}`);
    else if (key === 'weigh') showCard(`<b>${esc(N.weigh)}</b><br>${D.FIELD.map((c) => `${beanSvg(D.CROPS[c].c, 13)} ${grainPrice(c)}/${esc(T.tons)}`).join(' &nbsp;')}<br><span class="gsub">${esc(T.c_weigh)}</span>`);
    else showCard(`<b>${esc(N[key] || key)}</b>`);
    void hit;
  }

  /* ================= відпочинок: гамак, альтанка, сон, риболовля ================= */
  let resting = 0;
  function rest(key) { if (resting > 0) return; resting = key === 'gazebo' ? 2.5 : 3.5; float(T.rested, wpos(BL[key], 2.2), '#8fe08a'); api.sfx('ok'); if (BL.hammock && key === 'hammock') W.tween(BL.hammock.userData.cloth.rotation, { x: 0.25 }, 0.6, ease.inOut, () => W.tween(BL.hammock.userData.cloth.rotation, { x: 0 }, 1.6, ease.inOut)); }
  let sleepFade = 0;
  function sleep() { if (sleepFade > 0) return; sleepFade = 2.2; const e = $('#fNight'); e.textContent = T.sleep; e.classList.add('on'); api.sfx('sleep'); setTimeout(() => { newDay(true); S.tod = 0.02; S.stamina = maxStamina(); e.textContent = T.morning; }, 1100); setTimeout(() => e.classList.remove('on'), 2200); }
  const fishing = { state: 'idle', t: 0, at: null };
  function cast(g) {
    const pd = BL.pond; if (!pd) return; const c = V3(P.pond[0], 0, P.pond[1]), d = g.clone().sub(c); d.y = 0; if (d.length() > 2.1) d.setLength(2.1);
    const bob = pd.userData.bob, line = pd.userData.line; bob.position.set(d.x, 0.06, d.z); bob.visible = true; line.visible = true;
    line.geometry.setFromPoints([V3(0, 1.2, 2.0), bob.position.clone()]);
    fishing.state = 'wait'; fishing.t = 1.5 + Math.random() * 3.5; snd('cast', wpos(pd));
  }
  function catchFish() {
    const pd = BL.pond; fishing.state = 'idle'; pd.userData.bob.visible = false; pd.userData.line.visible = false;
    const n = 8 + Math.round(Math.random() * 22); S.coins += n; S.fish++; S.stamina = Math.min(maxStamina(), S.stamina + 8);
    float(fmt(T.fishGot, { n }), wpos(pd, 1.4), '#7fd6ff'); fx.burst(wpos(pd.userData.bob, 0.2), 0x8fd3ff, 30, 2.4); snd('splash', wpos(pd)); api.sfx('win'); cnt('fish'); save();
  }

  /* ================= етапи ================= */
  function checkStage() {
    const st = stageOf(); if (!st) return;
    if (st.goals.every(([k, n]) => (S.cnt[k] || 0) >= n)) {
      S.coins += st.reward; api.coins(3); S.stage++;
      float(fmt(T.stageDone, { n: st.reward }), V3(cam.target.x, 3, cam.target.z), '#ffd36b'); fx.burst(V3(cam.target.x, 2, cam.target.z), 0xffd36b, 90, 4); api.sfx('stage');
      const nx = stageOf(); if (nx) setTimeout(() => toast(fmt(T.stageNew, { t: T['st_' + nx.id] })), 1300); else setTimeout(() => toast(T.allDone), 1300);
      if (nx && nx.id === 'service') S.forceBreak = true;
      refreshSites(); syncRack(); drawStage(); save();
    } else drawStage();
  }

  /* ================= улюбленець на фермі ================= */
  let petO = null, petAnim = null, petClips = [], petProc = null, petGoal = null, petWait = 2, petJob = null;
  const petPlay = (st) => { if (petProc) petProc.set(st === 'happy' ? 'jump' : st === 'run' ? 'run' : st); else if (petAnim) { const c = st === 'walk' ? clip(petClips, /^walk$/i, /walk/i) : st === 'run' ? clip(petClips, /^gallop$/i, /^run$/i, /walk/i) : st === 'happy' ? clip(petClips, /^jump_toidle$/i, /^jump$/i, /idle_2/i, /^idle$/i) : clip(petClips, /^idle$/i, /idle/i); if (c) petAnim.play(c, { fade: 0.2 }); } };
  const petReady = (m) => { petO = m; m.position.set(-4.4, 0, 8.6); F.add(m); B.hitBox(m, 0.9, 0.9, 1.2, 0.4); pick(m, { kind: 'pet' }); petPlay('idle'); };
  if (api.petModel && api.petModel.startsWith('proc:cat')) { const m = makeCat({ coat: api.petModel.split(':')[2] }); m.scale.setScalar(1.25); petProc = m.userData.cat; petReady(m); }
  else if (api.petModel) inst(api.petModel, 0.75, { tint: api.petTint }).then((m) => { petClips = m.userData.clips; petAnim = animator(m, petClips); petReady(m); }).catch(() => { });
  function scareCrow(byPet) {
    if (!crow || crow.userData.leaving) return; crow.userData.leaving = true; snd('caw', crow.position); snd('flutter', crow.position, 1, 0.15); float(byPet ? T.petCrow : '!', wpos(crow, 0.8), '#fff');
    const tg = crow.position.clone().add(V3((Math.random() - 0.5) * 8, 7, -6)); W.tween(crow.position, { x: tg.x, y: tg.y, z: tg.z }, 1.4, ease.inOut, () => { F.remove(crow); crow = null; crowT = 30 + Math.random() * 25; });
  }
  function petThink() {
    if (crow && !crow.userData.leaving && crow.position.y < 0.6) return { kind: 'crow', at: crow.position.clone().setY(0), fast: true };
    const brk = Object.values(VH).find((v) => (mState(v.id) || {}).broken); if (brk) return { kind: 'alert', at: brk.g.position.clone().add(V3(1.2, 0, 1.2)), fast: true, v: brk };
    const ripeB = S.beds.findIndex((b) => b.k && b.t >= bedNeed(b)); if (ripeB >= 0 && Math.random() < 0.5) return { kind: 'show', at: bedPos(ripeB).add(V3(0, 0, 0.95)) };
    const ripeF = S.fields.findIndex((f) => f.st === 'ripe'); if (ripeF >= 0 && Math.random() < 0.4) return { kind: 'show', at: V3(P.fields[ripeF][0] - FH - 0.6, 0, P.fields[ripeF][1] + 1) };
    const work = Object.values(VH).find((v) => v.job && v.job.phase === 'lane'); if (work && Math.random() < 0.4) return { kind: 'follow', at: work.g.position.clone().add(V3(0, 0, 2.2)) };
    return { kind: 'walk', at: V3(-6 + (Math.random() - 0.5) * 8, 0, 8.4 + Math.random() * 1.6) };
  }

  /* ================= агроном на джипі ================= */
  const agro = { t: 25, tip: T.tip_ok, at: null, phase: 'home' };
  function agroTip() {
    const fs = S.fields.map((f, i) => [f, i]).filter(([f]) => f.own);
    let pick2 = fs.find(([f]) => f.pests && ['sown', 'grow'].includes(f.st)); if (pick2) return { t: fmt(T.tip_pests, { n: pick2[1] + 1 }), i: pick2[1] };
    pick2 = fs.find(([f]) => f.water < 0.25 && ['sown', 'grow'].includes(f.st)); if (pick2) return { t: fmt(T.tip_dry, { n: pick2[1] + 1 }), i: pick2[1] };
    pick2 = fs.find(([f]) => f.st === 'ripe'); if (pick2) return { t: fmt(T.tip_ripe, { n: pick2[1] + 1, t: D.CROPS[pick2[0].crop].n[lang] }), i: pick2[1] };
    pick2 = fs.find(([f]) => f.st === 'plowed'); if (pick2 && S.stage >= 2) return { t: fmt(T.tip_sow, { n: pick2[1] + 1 }), i: pick2[1] };
    pick2 = fs.find(([f]) => ['grass', 'stubble'].includes(f.st)); if (pick2 && S.m.tractor) return { t: fmt(T.tip_plow, { n: pick2[1] + 1 }), i: pick2[1] };
    if (S.m.tractor && S.m.tractor.oil < 30) return { t: T.tip_oil, i: -1 };
    if (S.m.tractor && S.m.tractor.dirt > 0.6) return { t: T.tip_wash, i: -1 };
    if (S.stage >= 3 && fs.some(([f]) => f.st === 'grow' && !f.fert)) return { t: T.tip_fert, i: -1 };
    if (S.stage >= 2 && !S.trip && (S.m.truck.load > 1 || S.m.truck.goods)) return { t: T.tip_city, i: -1 };
    return { t: isNight() ? T.tip_night : T.tip_ok, i: -1 };
  }
  function agroGo() {
    const tip = agroTip(); agro.tip = tip.t;
    if (tip.i < 0 || S.stage < 1) { agro.phase = 'home'; showTip(`${T.agro}: ${tip.t}`); return; }
    const [x, z] = P.fields[tip.i]; agro.phase = 'out';
    go(jeep, V3(7.9, 0, z + 2.2), () => { bubble(wpos(jeep.g, 2.0), `<b>${esc(T.agro)}</b><br>${esc(tip.t)}`); showTip(`${T.agro}: ${tip.t}`); snd('horn', jeep.g.position, 0.7); setTimeout(() => go(jeep, V3(P.park.jeep[0], 0, P.park.jeep[1]), () => { agro.phase = 'home'; }), 5200); });
    void x;
  }

  /* ================= агроном: питання кнопками ================= */
  // з ШІ — відповідь за станом саме цієї ферми; без ШІ — за правилами гри (працює й без інтернету)
  const AQ = ['aq_next', 'aq_money', 'aq_break'];
  function agroCard(answer) {
    showCard(`<b>${esc(T.agro)}</b><br>${esc(answer || agro.tip)}<div class="aq">${AQ.map((k) => `<button data-aq="${k}">${esc(T[k])}</button>`).join('')}</div>`); cardT = 16;
  }
  function agroRule(k) {
    if (k === 'aq_next') { const c = coachStep(); return c ? c.t : agroTip().t; }
    if (k === 'aq_money') return S.stage >= 4 ? T.ans_money3 : S.stage >= 2 ? T.ans_money2 : T.ans_money1;
    return T.ans_break;
  }
  function farmBrief() {
    const st = stageOf(), m = S.m, mach = (id) => { const x = m[id]; return x ? `${N[id]}: пальне ${Math.round(x.fuel)}, мастило ${Math.round(x.oil)}%, бруд ${Math.round((x.dirt || 0) * 100)}%, знос ${Math.round(x.wear || 0)}%${x.broken ? ', ЗЛАМАНИЙ' : ''}` : `${N[id]}: немає`; };
    return [`Мова відповіді: ${{ uk: 'українська', en: 'English', ru: 'русский' }[lang]}.`,
      `Етап ${S.stage + 1} з 8${st ? ` («${T['st_' + st.id]}»; цілі: ${st.goals.map(([g, n]) => `${T['g_' + g] || g} ${S.cnt[g] || 0}/${n}`).join('; ')})` : ' (усі пройдено)'}. День ${S.day}, погода ${T['w_' + S.weather]}, монет ${Math.round(S.coins)}, сили ${Math.round(S.stamina)}.`,
      `Поля: ${S.fields.map((f, i) => `№${i + 1} ${f.own ? f.st + (f.crop ? ' ' + D.CROPS[f.crop].n.uk : '') + (f.pests ? ', шкідники' : '') + (f.water < 0.25 ? ', сухе' : '') : 'не куплене'}`).join('; ')}.`,
      [mach('tractor'), mach('combine'), mach('truck')].join('. ') + `. Причепи: ${Object.keys(m.att).map((a) => N[a]).join(', ') || 'немає'}.`,
      `Збудовано: ${Object.entries(S.b).filter(([, v]) => v).map(([k]) => N[k] || k).join(', ')}. В амбарі: ${Object.entries(S.barn).filter(([, t]) => t > 0.05).map(([c, t]) => `${D.CROPS[c].n.uk} ${t.toFixed(1)} т`).join(', ') || 'порожньо'}.`,
      `Як усе працює: техніку тягнуть пальцем на поле/заправку/мийку/вагову/ангар; брудну можна мити відром; каністра з пальним — у бак будь-де; зламану лагодять натисканням червоних болтів; вантажівка везе зерно чи продукцію в місто (+30%); замовлення біля дороги (+35%); переробка дорожча за зерно.`].join('\n');
  }

  /* ================= HUD ================= */
  root.classList.add('farm3');
  W.hud.innerHTML = `<div class="gg fTop" id="fTop"></div>
    <button class="gg fStage" id="fStage"></button>
    <div class="gg fGoals" id="fGoals" style="display:none"></div>
    <div id="fBubble" class="gg fBubble" style="display:none"></div>
    <div id="fCard" class="gg fCard" style="display:none"></div>
    <div id="fCoach" class="fCoach" style="display:none"><div id="fHand" class="fHand">${gi('paw', 40)}</div></div>
    <button id="fTip" class="gg fTip" style="display:none"></button>
    <div id="fNight" class="fNight"></div>
    <div id="fSplash" class="fSplash"><div class="fsI">${['green', 'carrot', 'wheat', 'sunflower', 'corn'].map((c) => beanSvg(D.CROPS[c].c, 56)).join('')}</div><b>${esc(T.title)}</b><span>${esc(T.sub)}</span><span class="gsub">${esc(T.start)}</span></div>
    <style>
    .farm3 .fTop{position:absolute;left:8px;right:8px;top:8px;padding:6px 10px;display:flex;flex-wrap:wrap;gap:4px 10px;align-items:center;justify-content:center;font:700 14px var(--fm);color:#fff;text-shadow:0 1px 3px rgba(0,0,0,.6)}
    .farm3 .fTop span{display:inline-flex;align-items:center;gap:5px;white-space:nowrap}
    .farm3 .fTop .bar{width:40px;height:7px;border-radius:9px;background:rgba(255,255,255,.18);overflow:hidden}.farm3 .fTop .bar i{display:block;height:100%;border-radius:9px;background:linear-gradient(90deg,#ffd36b,#8fe08a)}
    .farm3 .fStage{position:absolute;left:50%;top:56px;transform:translateX(-50%);padding:6px 14px;font:700 13px var(--fb);color:#fff;display:flex;gap:8px;align-items:center;white-space:nowrap;max-width:94%}
    .farm3 .fStage em{font-style:normal;color:#ffd36b}.farm3 .fStage i{display:inline-block;width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.25);margin-left:2px}.farm3 .fStage i.ok{background:#8fe08a}
    .farm3 .fGoals{position:absolute;left:50%;top:96px;transform:translateX(-50%);padding:10px 14px;min-width:240px;max-width:92%;font:500 13.5px/1.6 var(--fb);color:#fff}
    .farm3 .fGoals b{display:block;margin-bottom:4px}.farm3 .fGoals div{display:flex;gap:8px;align-items:center}.farm3 .fGoals .ok{color:#8fe08a}.farm3 .fGoals small{opacity:.7;margin-left:auto;font-family:var(--fm)}
    .farm3 .fBubble{position:absolute;pointer-events:none;transform:translate(-50%,-110%);padding:9px 13px;font:500 13px/1.45 var(--fb);max-width:250px;text-align:center;color:#fff}
    .farm3 .fCard{position:absolute;left:50%;bottom:calc(64px + env(safe-area-inset-bottom));transform:translateX(-50%);padding:10px 16px;font:500 13.5px/1.55 var(--fb);color:#fff;min-width:220px;max-width:92%;pointer-events:auto}
    .farm3 .fCard .aq{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}.farm3 .fCard .aq button{font:600 12.5px var(--fb);color:#fff;background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.25);border-radius:999px;padding:6px 10px;cursor:pointer}
    .farm3 .gauge{display:flex;align-items:center;gap:8px;font-size:12.5px}.farm3 .gauge span{width:72px;opacity:.85}.farm3 .gauge b{flex:1;height:8px;border-radius:9px;background:rgba(255,255,255,.16);overflow:hidden}.farm3 .gauge b i{display:block;height:100%;border-radius:9px}
    .farm3 .fCoach{position:absolute;inset:0;pointer-events:none}
    .farm3 .fHand{position:absolute;transform:translate(-20%,-10%);filter:drop-shadow(0 6px 10px rgba(0,0,0,.5));transition:opacity .2s}
    .farm3 .fTip{position:absolute;left:50%;bottom:calc(12px + env(safe-area-inset-bottom));transform:translateX(-50%);padding:10px 16px;font:600 14px var(--fb);color:#fff;max-width:94%;text-align:center;line-height:1.35}
    .farm3 .fNight{position:absolute;inset:0;background:#05070c;opacity:0;pointer-events:none;transition:opacity .9s;display:flex;align-items:center;justify-content:center;font:800 26px var(--fd);color:#fff}.farm3 .fNight.on{opacity:1}
    .farm3 .fSplash{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;background:radial-gradient(circle at 50% 40%,rgba(120,190,90,.35),rgba(8,12,10,.86));cursor:pointer;text-align:center;padding:20px;color:#fff}
    .farm3 .fSplash b{font:800 clamp(28px,8vw,40px) var(--fd);text-shadow:0 4px 18px rgba(0,0,0,.6)}
    .farm3 .fSplash .gsub{animation:fPulse 1.6s ease-in-out infinite}
    .farm3 .fsI{display:flex;gap:6px;animation:fFloat 3s ease-in-out infinite}
    @keyframes fFloat{50%{transform:translateY(-10px)}}@keyframes fPulse{50%{opacity:.4}}
    </style>`;
  const $ = (s) => W.hud.querySelector(s);
  // агроном: кнопки-питання в картці (картка зʼявляється з HUD, тому слухаємо після нього)
  $('#fCard').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-aq]'); if (!b) return; e.stopPropagation();
    const k = b.dataset.aq; api.sfx('tap'); agroCard('…'); snd('horn', jeep.g.position, 0.4);
    const ai = api.ask ? await api.ask('agro', farmBrief(), T[k]) : '';
    agroCard(ai || agroRule(k));
  });
  let started = false, coachFlash = 0;
  $('#fSplash').addEventListener('click', () => { const e = $('#fSplash'); e.style.transition = 'opacity .5s'; e.style.opacity = '0'; setTimeout(() => e.remove(), 520); started = true; api.sfx('ok'); });
  $('#fStage').addEventListener('click', () => { const g = $('#fGoals'); g.style.display = g.style.display === 'none' ? '' : 'none'; api.sfx('tap'); });
  $('#fTip').addEventListener('click', () => { const st = coachStep(); if (st && st.a) cam.flyTo(st.a.clone().setY(0)); api.sfx('tap'); });
  function float(text, p3, color = '#fff') { const s = W.screen(p3), warn = color === '#ff9a8a' || color === '#ff6b5a'; const e = h('div', 'gfloat' + (warn ? ' warn' : ''), esc(text)); e.style.left = clamp(s.x, 90, W.hud.clientWidth - 90) + 'px'; e.style.top = clamp(s.y, 120, W.hud.clientHeight - 60) + 'px'; e.style.color = color; W.hud.appendChild(e); setTimeout(() => e.remove(), warn ? 4200 : 1500); } // помилки й підказки тримаються ~4 с
  function wpos(o, dy = 0) { return o.getWorldPosition(V3()).add(V3(0, dy, 0)); }
  let bubbleAt = null, bubbleT = 0, cardT = 0, tipT = 0;
  function bubble(p3, html) { const e = $('#fBubble'); e.innerHTML = html; e.style.display = ''; bubbleAt = p3.clone(); bubbleT = 3.6; }
  function showCard(html) { const e = $('#fCard'); e.innerHTML = html; e.style.display = ''; cardT = 5; }
  function hideCard() { $('#fCard').style.display = 'none'; cardT = 0; }
  function showTip(t) { tipT = 6; $('#fTip').textContent = t; $('#fTip').style.display = ''; }
  function toast(t) { showTip(t); }
  const gauge = (name, k, col) => `<div class="gauge"><span>${esc(name)}</span><b><i style="width:${Math.round(clamp(k, 0, 1) * 100)}%;background:${col}"></i></b></div>`;
  function showVeh(v) {
    if (!v) return; const st = mState(v.id);
    if (v.id === 'jeep') { agroCard(); return; }
    if (!st) return;
    const tank = v.id === 'combine' ? D.MACH.combine.tank : v.id === 'truck' ? D.MACH.truck.tank : D.MACH.tractor.tank;
    let html = `<b>${esc(N[v.id])}</b>${v.id === 'truck' ? ` · ${esc(T.level)} ${st.lvl}` : ''}${st.broken ? ` · <span style="color:#ff8a7a">${esc(T.broken)}</span>` : ''}`;
    html += gauge(T.fuel, st.fuel / tank, '#ffd36b') + gauge(T.oilL, st.oil / 100, '#c9902b') + gauge(T.clean, 1 - st.dirt, '#8fd3ff') + gauge(T.cond, 1 - st.wear / 100, '#8fe08a');
    if (v.id === 'tractor') html += `<div class="gauge"><span>${esc(T.hitched)}</span>${esc(st.att ? N[st.att] : T.none)}</div>`;
    if (v.id === 'combine') html += gauge(T.hopper, (st.hopper || 0) / D.MACH.combine.hopper, '#e2bd5a');
    if (v.id === 'truck') html += gauge(T.load, st.load / D.MACH.truck.cap[st.lvl - 1], '#e2bd5a') + (st.load ? `<span class="gsub">${esc(D.CROPS[st.crop].n[lang])} ${st.load.toFixed(1)} ${esc(T.tons)}</span>` : '');
    const todo = needs(v).map((n) => ({ '!wrench': T.c_fixBolt, '!fuel': T.c_jerry, fuel: S.b.fuel ? T.c_lowFuel : T.c_jerry, oil: v.id === 'tractor' ? T.c_oilC : T.c_oilV, mud: S.b.wash ? T.c_washS : T.c_scrub, wrench: S.b.hangar ? T.c_hangar : T.c_fixBolt })[n]).filter(Boolean);
    if (todo.length) html += todo.map((x) => `<span class="gsub">• ${esc(x)}</span>`).join('');
    else if (st.dirt > 0.3) html += `<span class="gsub">${esc(T.dirtyWarn)}</span>`;
    showCard(html);
  }
  function showField(i) {
    const f = S.fields[i]; if (!f.own) { showCard(`<b>${esc(N.field)} ${i + 1}</b> · ${esc(T.f_locked)}`); return; }
    let html = `<b>${esc(N.field)} ${i + 1}</b> · ${esc(T['f_' + f.st])}${f.crop ? ' · ' + esc(D.CROPS[f.crop].n[lang]) : ''}`;
    if (f.crop) html += gauge(T.f_grow, f.st === 'ripe' ? 1 : f.grow, '#8fe08a') + gauge(T.water, f.water, '#8fd3ff') + gauge(T.fertL, f.fert, '#f4f4f0') + (f.pests ? `<span style="color:#ff8a7a">${esc(T.pests)}!</span><br>` : '') + `<span class="gsub">${esc(T.yieldL)} ~${fieldYield(f).toFixed(1)} ${esc(T.tons)}</span>`;
    const op = activeOp(i); if (op) html += `<br><span class="gsub">${esc(N[op.op] || N.combine)}: ${op.lane}/${D.LANES}</span>`;
    showCard(html);
  }
  function showPower() { showCard(`<b>${esc(T.power)}</b><br>${gauge(`${Math.round(powerSupply())} ${T.kw}`, powerUse ? powerSupply() / powerUse : 1, '#ffd36b')}<span class="gsub">${esc(N.wind)} ×${S.b.wind} · ${esc(N.solar)} ×${S.b.solar} · ${Math.round(powerUse)} ${esc(T.kw)}</span>`); }
  let lastHud = '';
  function drawHud() {
    const hh = Math.floor(hour()), mm = Math.floor((hour() % 1) * 6) * 10;
    const txt = `${Math.floor(S.coins)}|${S.day}|${hh}:${mm}|${S.weather}|${S.next}|${Math.round(S.stamina)}|${Math.round(powerSupply())}|${powerUse}`;
    if (txt === lastHud) return; lastHud = txt;
    $('#fTop').innerHTML = `<span>${gi('coin', 18)}${Math.floor(S.coins)}</span><span>${gi(isNight() ? 'moon' : 'w_sun', 18)}${S.day} · ${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}</span><span>${gi('w_' + S.weather, 20)}<small style="opacity:.6">→</small>${gi('w_' + S.next, 16)}</span><span title="${esc(T.stamina)}">${gi('energy', 16)}<b class="bar"><i style="width:${Math.round(S.stamina / maxStamina() * 100)}%"></i></b></span>${S.b.wind || S.b.solar || powerUse ? `<span>${gi('energy', 16)}${Math.round(powerSupply())}/${powerUse} ${esc(T.kw)}</span>` : ''}`;
  }
  function drawStage() {
    const st = stageOf();
    if (!st) { $('#fStage').innerHTML = `<em>${esc(T.st_free)}</em>`; $('#fGoals').innerHTML = `<b>${esc(T.allDone)}</b>`; return; }
    const ok = st.goals.map(([k, n]) => (S.cnt[k] || 0) >= n);
    $('#fStage').innerHTML = `<em>${S.stage + 1}/${D.STAGES.length}</em> ${esc(T['st_' + st.id])} ${ok.map((o) => `<i class="${o ? 'ok' : ''}"></i>`).join('')}`;
    $('#fGoals').innerHTML = `<b>${esc(T.goals)} · +${st.reward} ${gi('coin', 14)}</b>${st.goals.map(([k, n], j) => `<div class="${ok[j] ? 'ok' : ''}">${ok[j] ? '✓' : '○'} ${esc(T['g_' + k])}<small>${Math.min(n, Math.floor(S.cnt[k] || 0))}/${n}</small></div>`).join('')}`;
  }

  /* ================= підказка-рука: що робити далі на цьому етапі ================= */
  const siteAt = (id) => (SITES[id] ? wpos(SITES[id].g, 1.2) : null);
  const vAt = (id, dy = 0.6) => (VH[id] ? wpos(VH[id].g, dy) : null);
  const fieldC = (i) => V3(P.fields[i][0], 0.3, P.fields[i][1]);
  function coachStep() {
    if (!started) return null;
    if (S.stamina < 8) return { t: T.c_rest, a: wpos(BL.hammock, 1) };
    const att = attention(); if (att) return att;
    const st = stageOf(); if (!st) return null;
    const need = (k) => (S.cnt[k] || 0) < (st.goals.find((g2) => g2[0] === k) || [0, 0])[1];
    const tr = S.m.tractor, f0 = S.fields.findIndex((f) => f.own && ['grass', 'stubble'].includes(f.st)), fP = S.fields.findIndex((f) => f.own && f.st === 'plowed'), fR = S.fields.findIndex((f) => f.own && f.st === 'ripe');
    const binK = Object.keys(S.inv).find((k) => S.inv[k] > 0 && !split(k).mut), empty = S.beds.findIndex((b) => b.open && !b.k), ripe = S.beds.findIndex((b) => b.k && b.t >= bedNeed(b));
    const hitchTo = (a) => (tr && ATT[a] && tr.att !== a ? { t: T.c_hitch, a: vAt('tractor'), b: wpos(ATT[a].g, 0.4) } : null);
    if (st.id === 'garden') {
      if (ripe >= 0) return { t: T.c_harvest, a: bedPos(ripe).add(V3(-0.6, 0.6, 0)), b: bedPos(ripe).add(V3(0.6, 0.6, 0)) };
      if (need('earnFair') && (S.cnt.harvestG || 0) >= 2) { const k = Object.keys(S.inv).find((x) => S.inv[x] > 2); if (k && BIN[k]) return { t: T.c_sell, a: BIN[k].g.position.clone().setY(0.6), b: wpos(stall, 0.8) }; }
      if (binK && empty >= 0 && BIN[binK]) return { t: T.c_plant, a: BIN[binK].g.position.clone().setY(0.6), b: bedPos(empty).setY(0.4) };
      const grow = S.beds.findIndex((b) => b.k && !b.wet); if (grow >= 0) return { t: T.c_water, a: wpos(can, 0.4), b: bedPos(grow).setY(0.5) };
      return null;
    }
    if (st.id === 'tractor') {
      if (need('buy_tractor')) return { t: T.c_buy, a: siteAt('m_tractor') };
      if (need('buy_cultivator')) return { t: T.c_buy, a: siteAt('a_cultivator') };
      return hitchTo('cultivator') || (f0 >= 0 ? { t: T.c_field, a: vAt('tractor'), b: fieldC(f0) } : null);
    }
    if (st.id === 'grain') {
      if (need('sow')) {
        if (fP < 0) return hitchTo('cultivator') || (f0 >= 0 ? { t: T.c_field, a: vAt('tractor'), b: fieldC(f0) } : null);
        if (!S.m.att.seeder) return { t: T.c_buy, a: siteAt('a_seeder') };
        if (!S.m.att.seeder.seed) { if (!(S.seeds.wheat > 0) && !(S.seeds.sunflower > 0)) return { t: T.c_buy, a: wpos(RS.wheat.g, 0.5) }; const c = S.seeds.wheat > 0 ? 'wheat' : 'sunflower'; return { t: T.c_seed, a: wpos(RS[c].g, 0.5), b: wpos(ATT.seeder.g, 0.6) }; }
        return hitchTo('seeder') || { t: T.c_field, a: vAt('tractor'), b: fieldC(fP) };
      }
      if (need('harvestF') && fR >= 0) return S.m.combine ? { t: T.c_combine, a: vAt('combine'), b: fieldC(fR) } : { t: T.c_hire, a: siteAt('h_' + fR) };
      if (need('sellGrain')) { if (!S.b.weigh) return { t: T.c_buy, a: siteAt('b_weigh') }; if (S.m.truck.load) return { t: T.c_weigh, a: vAt('truck'), b: V3(P.weigh[0], 0.3, P.weigh[1]) }; }
      return null;
    }
    if (st.id === 'service') {
      const brk = Object.values(VH).find((v) => (mState(v.id) || {}).broken); if (brk && brk.bolts[0]) return { t: T.c_repairS, a: wpos(brk.bolts[0]) };
      if (need('refuel')) return S.b.fuel ? { t: T.c_fuel, a: vAt('tractor'), b: V3(P.fuel[0], 0.3, P.fuel[1]) } : { t: T.c_buy, a: siteAt('b_fuel') };
      if (need('wash')) return S.b.wash ? { t: T.c_washS, a: vAt('tractor'), b: V3(P.wash[0], 0.3, P.wash[1]) } : { t: T.c_buy, a: siteAt('b_wash') };
      if (need('oil') && VH.tractor) return { t: T.c_oilC, a: wpos(oilcan, 0.4), b: vAt('tractor') };
      if (need('repair') && f0 >= 0) return hitchTo('cultivator') || { t: T.c_field, a: vAt('tractor'), b: fieldC(f0) };
      return null;
    }
    if (st.id === 'process') {
      if (need('build_barn')) return { t: T.c_buy, a: siteAt('b_barn') };
      if (need('build_mill')) return { t: T.c_buy, a: siteAt('b_oilmill') || siteAt('b_groatsmill') || siteAt('b_feedmill') };
      if (need('produce')) { const c = Object.keys(S.barn).find((x) => S.barn[x] > 0.5); const bk = Object.keys(PLANT_OF).find((b2) => S.b[b2] && c && c in D.PLANTS[PLANT_OF[b2]].in); if (c && bk && PILES[c]) return { t: T.c_hopper, a: wpos(PILES[c], 0.4), b: wpos(BL[bk], 1) }; if (S.m.truck.load) return { t: T.c_unload, a: vAt('truck'), b: wpos(BL.barn, 0.6) }; }
      if (need('order') && S.order && GP[S.order.k]) return { t: T.c_orderD, a: wpos(GP[S.order.k].g, 0.5), b: wpos(orderV, 0.8) };
      return null;
    }
    if (st.id === 'energy') {
      for (const k of ['wind', 'solar', 'bioplant']) if (need('build_' + k)) return { t: T.c_buy, a: siteAt('b_' + k) };
      if (need('ownFuel') && S.eth.own > 1) return { t: T.c_fuel, a: vAt('tractor'), b: V3(P.fuel[0], 0.3, P.fuel[1]) };
      return null;
    }
    if (st.id === 'rest') {
      if (need('house2')) return { t: T.c_buy, a: siteAt('u_house') };
      if (need('build_rest')) return { t: T.c_buy, a: siteAt('b_pond') || siteAt('b_gazebo') };
      if (need('fish') && BL.pond) return { t: T.cast, a: V3(P.pond[0], 0.3, P.pond[1] + 2.6), b: V3(P.pond[0], 0.2, P.pond[1]) };
      return null;
    }
    if (st.id === 'big') { for (const id of ['f_1', 'f_2', 'f_3', 'm_combine', 'u_truck', 'b_elevator', 'u_elevator']) if (SITES[id]) return { t: T.c_buy, a: siteAt(id) }; }
    return null;
  }

  /* ================= новий день ================= */
  function seedRescue() {
    const crops = Object.values(S.inv).some((n) => n > 0), planted = S.beds.some((b) => b.k), cheap = Math.min(...D.GARDEN.map((c) => D.CROPS[c].seed));
    if (crops || planted || S.coins >= cheap) return;
    S.inv.green = (S.inv.green || 0) + 4; ensureBin('green'); syncBins(); showTip(T.gift); float(T.gift, wpos(BIN.green.g, 1.4), '#8fe08a'); snd('horn', jeep.g.position, 0.7); save();
  }
  function newDay() {
    seedRescue();
    if (S.order && !S.order.got && (S.order.days = (S.order.days || 0) + 1) >= 2) { S.order = null; drawOrder(); orderCD = 5; } // нерушене замовлення через 2 дні змінюється
    setTimeout(() => snd('rooster', BL.house ? wpos(BL.house, 1) : null, 0.9), 500); // світанок — півень
    S.day++; S.weather = S.next; S.next = WK[(Math.random() * WK.length) | 0];
    S.beds.forEach((b, i) => { b.wet = Math.max(0, b.wet - 1); BO[i].soil.material = b.wet > 0 || S.weather === 'rain' ? wetM : soilM; });
    S.fields.forEach((f) => { if (['sown', 'grow'].includes(f.st) && !f.pests && Math.random() < 0.15) f.pests = 1; });
    D.GARDEN.forEach((t) => { S.demand[t] = clamp((S.demand[t] || 1) + (1 - (S.demand[t] || 1)) * 0.3 + (Math.random() - 0.5) * 0.1, 0.45, 1.45); });
    float(`${T.day} ${S.day}: ${T['w_' + S.weather]} — ${T['wd_' + S.weather]}`, V3(cam.target.x, 3, cam.target.z), '#fff');
    drawPrices(); save();
  }

  /* ================= кадр ================= */
  const C = { day: new THREE.Color(), dusk: new THREE.Color(0xff9a6a), night: new THREE.Color(0x0b1430), nightH: new THREE.Color(0x1a2440), moon: new THREE.Color(0x8fa8ff), warm: new THREE.Color(0xffb27a), white: new THREE.Color(0xfff4e0) };
  let skyT = 0, cropT = 0, saveT = 0, siteT = 0, prevNight = null;
  let warp = 1; // для автоматичних перевірок
  W.onFrame((dt0, tm) => {
    const dt = dt0 * warp;
    fitCam();
    const night = isNight();
    if (started && sleepFade <= 0) {
      const dtD = dt / D.DAYLEN * (night ? 2 : 1);
      S.tod += dtD; if (S.tod >= 1) { S.tod -= 1; newDay(); }
      const w = WEATHER[S.weather];
      // город
      S.beds.forEach((b, i) => {
        const bo = BO[i]; bo.lock.visible = !b.open; bo.soil.visible = b.open;
        if (!b.k) return; if (bo.built !== b.k) buildPlant(bo, b.k);
        const pecked = crow && crow.userData.bed === i && !crow.userData.leaving, need2 = bedNeed(b);
        if (b.t < need2 && !pecked) b.t += dtD * w.grow * (b.wet > 0 ? 1.4 : 1);
        const g = Math.min(1, b.t / need2), sc = 0.15 + 0.85 * ease.out(g);
        bo.plant.scale.setScalar(bo.plant.scale.y + (sc - bo.plant.scale.y) * Math.min(1, dt * 4));
        bo.plant.children.forEach((s2) => { const pr = s2.getObjectByName('prod'); if (pr) { pr.visible = g > 0.5; pr.scale.setScalar(Math.min(1, (g - 0.5) / 0.5 + 0.2)); } });
        prodMat(b.k).emissiveIntensity = g >= 1 ? 0.45 + Math.sin(tm * 4) * 0.3 : 0;
        bo.plant.rotation.z = Math.sin(tm * 1.3 + i) * (S.weather === 'rain' ? 0.06 : 0.025);
      });
      // поля
      S.fields.forEach((f, i) => {
        if (!f.own || !['sown', 'grow'].includes(f.st)) return;
        f.water = clamp(f.water - dtD * w.evap, 0, 1);
        const piv = f.pivot && f.water < 0.75 && powerSupply() + 1 > 0; if (piv) { f.water = Math.min(1, f.water + dtD * 2.4); if (FO[i].piv) { FO[i].piv.userData.spin.rotation.y += dt * 0.5; if (Math.random() < dt * 20) fx.burst(FO[i].g.position.clone().add(V3(Math.cos(-FO[i].piv.userData.spin.rotation.y) * 1.5, 1.6, Math.sin(-FO[i].piv.userData.spin.rotation.y) * 1.5)), 0x8fd3ff, 2, 0.8, 0.6, 5); } }
        if (f.water < 0.2) f.stress = Math.max(0.5, f.stress - dtD * 0.25);
        f.grow += dtD / D.CROPS[f.crop].days * w.grow * (f.water < 0.2 ? 0.35 : 1);
        if (f.st === 'sown' && f.grow > 0.04) f.st = 'grow';
        if (f.grow >= 1) { f.st = 'ripe'; f.grow = 1; paintField(i); syncCrops(i); fx.burst(FO[i].g.position.clone().setY(1), 0xffd36b, 40, 2.5); refreshSites(); }
      });
      runPlants(dtD * 24);
      // сили
      const regen = resting > 0 ? 18 : 0.4 + (S.b.gazebo ? 0.3 : 0); if (resting > 0) resting -= dt;
      S.stamina = Math.min(maxStamina(), S.stamina + regen * dt);
      // замовлення
      if (!S.order) { orderCD -= dt; if (orderCD <= 0) { orderCD = 30; newOrder(); } }
      // агроном
      agro.t -= dt; if (agro.t <= 0 && agro.phase === 'home') { seedRescue(); agro.t = 45 + Math.random() * 25; agroGo(); }
      // ворони
      if (!crow) { crowT -= dt; if (crowT <= 0) { const grow = S.beds.map((b, i) => (b.k && b.t < bedNeed(b) ? i : -1)).filter((i) => i >= 0); if (grow.length) { const i = grow[(Math.random() * grow.length) | 0]; crow = makeCrow(); crow.userData.bed = i; const at = bedPos(i).add(V3(0.3, 0.25, 0.3)); crow.position.copy(at).add(V3(-6, 6, -4)); F.add(crow); snd('caw', at, 0.8, 1.3); W.tween(crow.position, { x: at.x, y: at.y, z: at.z }, 1.6, ease.out); } else crowT = 15; } }
      saveT += dt; if (saveT > 10) { saveT = 0; save(); }
    }
    if (sleepFade > 0) sleepFade -= dt;
    if (crow) { const s2 = Math.sin(tm * (crow.userData.leaving ? 30 : 6)) * 0.5; crow.userData.wl.rotation.z = s2; crow.userData.wr.rotation.z = -s2; if (!crow.userData.leaving) crow.rotation.y = Math.sin(tm * 2) * 0.6; }
    // техніка
    for (const v of Object.values(VH)) {
      if (v.busy > 0 && !v.path.length) continue;
      moveV(v, dt);
      const j = v.job;
      if (j && j.phase === 'lane') {
        const x = clamp(workerX(v), -FH, FH), e = laneEnds(j.fi, j.lane), start = -e.dir * FH;
        if (j.px === undefined || j.pl !== j.lane) { j.px = start; j.pl = j.lane; }
        if (Math.abs(x - j.px) > 0.06 && Math.sign(x - j.px) === e.dir) { if (j.op !== 'sprayer' && j.op !== 'irrigator') strip(j.fi, opResult(j.op, S.fields[j.fi]), j.lane, j.px, x); j.px = x; }
        if (j.op === 'combine' && (cropT += dt) > 0.12) { cropT = 0; syncCrops(j.fi, j.lane, { lane: j.lane, x, dir: e.dir }); }
        const behind = v.att ? v.att.g.position : v.g.position;
        if (Math.random() < dt * 14) fx.burst(behind.clone().add(V3((Math.random() - 0.5) * 2, 0.25, 0)), j.op === 'sprayer' ? 0xe8ffe8 : j.op === 'irrigator' ? 0x8fd3ff : j.op === 'combine' ? 0xe2c97a : 0x7a5636, 2, 0.6, 0.7, j.op === 'irrigator' || j.op === 'sprayer' ? 3 : 2);
        if (v.g.userData.reel) v.g.userData.reel.rotation.x += dt * 5;
        if (v.att && v.att.g.userData.spin) v.att.g.userData.spin.rotation.x += dt * 3;
      }
      const lm = v.g.userData.lights; if (lm) lm.emissiveIntensity = night ? 2.4 : 0.2;
      const st = mState(v.id);
      if (st && st.broken) { if (!v.bolts.length) addBolts(v); if (Math.random() < dt * 8) fx.burst(wpos(v.g, 1.6), 0x3a3a3a, 2, 0.5, 1.2, -1); v.bolts.forEach((b, k) => b.scale.setScalar(1 + Math.sin(tm * 8 + k) * 0.2)); }
    }
    // будівлі: вітряки, димар, вікна, ліхтарі
    WINDS.forEach((g, i) => { g.userData.spin.rotation.z += dt * (0.6 + WEATHER[S.weather].wind * 2.2) + i * 0.0001; });
    if (BL.house && BL.house.userData.chimney && Math.random() < dt * 3) fx.burst(wpos(BL.house.userData.chimney, 0.6), 0xcfcfcf, 1, 0.3, 2.2, -0.6);
    // день і ніч
    const dayK = S.tod < 0.58 ? Math.sin(S.tod / 0.58 * Math.PI) : 0, w = WEATHER[S.weather], wl = S.weather === 'rain' ? 0.45 : S.weather === 'cloud' ? 0.65 : 1;
    const elev = dayK, az = (S.tod / 0.58) * Math.PI;
    const tgt = cam.target; sun.target.position.set(tgt.x, 0, tgt.z);
    if (dayK > 0) { sun.position.set(tgt.x + Math.cos(az) * 26, 6 + elev * 26, tgt.z + 8); sun.intensity = (0.3 + 2.9 * Math.pow(elev, 0.7)) * wl; sun.color.copy(C.warm).lerp(C.white, Math.min(1, elev * 1.6)); }
    else { sun.position.set(tgt.x - 10, 24, tgt.z + 6); sun.intensity = 0.35; sun.color.copy(C.moon); }
    hemi.intensity = 0.22 + 0.7 * dayK * (0.6 + 0.4 * wl);
    scene.environmentIntensity = 0.1 + 0.35 * dayK * (0.6 + 0.4 * wl); W.renderer.toneMappingExposure = 0.84 + 0.16 * dayK;
    const nightK = clamp(1 - dayK * 3, 0, 1);
    B.WIN.forEach((m) => { m.emissiveIntensity = nightK * 1.4; }); lampM.emissiveIntensity = nightK * 2.2; yardLight.intensity = nightK * 3;
    if (BL.hangar && BL.hangar.userData.lamp) BL.hangar.userData.lamp.material.emissiveIntensity = 0.4 + nightK * 1.2;
    stars.material.opacity = nightK * (S.weather === 'sun' || S.weather === 'heat' ? 0.9 : 0.3);
    if ((skyT += dt) > 0.25 || prevNight !== night) {
      skyT = 0; prevNight = night;
      C.day.set(w.sky); const duskK = clamp(1 - Math.abs(dayK - 0.18) / 0.18, 0, 1) * (dayK < 0.4 ? 1 : 0);
      skyTop.copy(C.night).lerp(C.day, Math.min(1, dayK * 2.2)); const hor = skyTop.clone().lerp(C.dusk, duskK * 0.7).lerp(C.nightH, nightK * 0.5);
      paintSky(skyTop, hor); scene.fog.color.copy(hor);
    }
    rain.visible = S.weather === 'rain';
    if (rain.visible) { const a = rainGeo.attributes.position.array; for (let i = 0; i < RN; i++) { let y = a[i * 6 + 1] - dt * 14; if (y < 0) y += 12; a[i * 6 + 1] = y; a[i * 6 + 4] = y - 0.35; } rainGeo.attributes.position.needsUpdate = true; rain.position.set(tgt.x, 0, tgt.z); }
    svcFrame(dt);
    if ((sndT += dt0) > 0.066) { const sdt = sndT; sndT = 0; soundFrame(sdt, dayK); }
    // лабораторія
    const busy = mixing > 0; if (busy) mixing -= dt;
    liquidM.emissive.lerp(busy ? mixColor : new THREE.Color(0x1fb5a8), Math.min(1, dt * 3));
    bubbles.forEach((b, i) => { b.userData.s = (b.userData.s + dt * (busy ? 0.9 : 0.25)) % 1; const s2 = b.userData.s; b.position.set(Math.cos(i * 2.3) * 0.28 * (1 - s2 * 0.3), 0.5 + s2 * 0.85, Math.sin(i * 2.3) * 0.28); b.material.opacity = 0.75 * (1 - s2); });
    // тягнеш до краю екрана — камера їде туди ж (поле може бути за межами екрана)
    if (carry && carry.ev && carry.moved && carry.kind !== 'hold' && carry.kind !== 'lever' && carry.kind !== 'cast' && !(carry.kind === 'bucket' && carry.over)) { // губкою по машині біля краю — камера не втікає
      const r = root.getBoundingClientRect(), x = carry.ev.clientX - r.left, y = carry.ev.clientY - r.top, m = 48;
      const dx = x < m ? -1 : x > r.width - m ? 1 : 0, dz = y < 120 ? -1 : y > r.height - 70 ? 1 : 0;
      if (dx || dz) { cam.target.x = clamp(cam.target.x + dx * dt0 * 10, -15, 15); cam.target.z = clamp(cam.target.z + dz * dt0 * 10, -16, 16); cam.onMove(carry.ev); }
    }
    // утримання таблички
    if (carry && carry.kind === 'hold') { carry.t = (performance.now() - carry.t0) / 1000; if ((siteT += dt) > 0.05) { siteT = 0; drawSite(carry); } if (carry.t >= holdMs / 1000) { const id = carry.id; carry = null; drawSite(null); buy(id); } }
    // риболовля
    if (fishing.state !== 'idle' && BL.pond) {
      const bob = BL.pond.userData.bob; fishing.t -= dt;
      if (fishing.state === 'wait') { bob.position.y = 0.06 + Math.sin(tm * 3) * 0.015; if (fishing.t <= 0) { fishing.state = 'bite'; fishing.t = 1.5; bubble(wpos(bob, 0.6), `<b>${esc(T.fishOn)}</b>`); snd('plop', wpos(bob)); snd('plop', wpos(bob), 0.7, 0.25); } }
      else if (fishing.state === 'bite') { bob.position.y = 0.0 + Math.sin(tm * 18) * 0.04; if (fishing.t <= 0) { fishing.state = 'idle'; bob.visible = false; BL.pond.userData.line.visible = false; float(T.fishMiss, wpos(BL.pond, 1.2), '#cfd6de'); } }
    }
    // улюбленець
    if (petO) {
      if (petAnim) petAnim.update(dt); if (petProc) petProc.update(dt);
      if (!petGoal) { petWait -= dt; if (petWait <= 0 || (crow && !crow.userData.leaving)) { petJob = petThink(); petGoal = petJob.at; petPlay(petJob.fast ? 'run' : 'walk'); } }
      if (petGoal) {
        const dv = petGoal.clone().sub(petO.position); dv.y = 0; const dist = dv.length();
        if (dist < 0.15) {
          petGoal = null; petWait = 2.5 + Math.random() * 3;
          if (petJob.kind === 'crow') { snd(PETV, petO.position); scareCrow(true); petPlay('happy'); }
          else if (petJob.kind === 'alert' || petJob.kind === 'show') { petPlay('happy'); snd(PETV, petO.position, 0.8); bubble(wpos(petO, 1.2), esc(T.pet_alert)); petWait = 5; }
          else petPlay('idle');
          if (petProc) setTimeout(() => { if (!petGoal) petPlay('idle'); }, 900);
        } else { const want = Math.atan2(dv.x, dv.z); let df = want - petO.rotation.y; df = Math.atan2(Math.sin(df), Math.cos(df)); petO.rotation.y += df * Math.min(1, dt * 8); petO.position.addScaledVector(dv.normalize(), Math.min(dist, dt * (petJob.fast ? 3.6 : 1.4))); }
      }
    }
    // HUD
    drawHud();
    if (bubbleT > 0) { bubbleT -= dt; const s2 = W.screen(bubbleAt), e = $('#fBubble'), { W: vw } = W.size(), hw = e.offsetWidth / 2 + 8; e.style.left = clamp(s2.x, hw, vw - hw) + 'px'; e.style.top = Math.max(e.offsetHeight + 100, s2.y) + 'px'; if (bubbleT <= 0) e.style.display = 'none'; }
    if (cardT > 0) { cardT -= dt; if (cardT <= 0) hideCard(); }
    if (coachFlash > 0) coachFlash -= dt;
    if (tipT > 0) tipT -= dt;
    const cs = coachStep(), co = $('#fCoach'), tip = $('#fTip');
    if (cs && cs.a && !carry) {
      if (tipT <= 0) { tip.style.display = ''; if (tip.textContent !== cs.t) tip.textContent = cs.t; }
      const a = W.screen(cs.a), b = cs.b ? W.screen(cs.b) : a, { W: vw, H: vh } = W.size();
      const on = a.x > -20 && a.x < vw + 20 && a.y > 60 && a.y < vh - 40;
      co.style.display = on ? '' : 'none';
      if (on) { const k2 = (tm % 2.2) / 1.6, q = Math.min(1, k2), hd = $('#fHand'); hd.style.left = (a.x + (b.x - a.x) * ease.inOut(q)) + 'px'; hd.style.top = (a.y + (b.y - a.y) * ease.inOut(q) + (cs.b ? 0 : Math.sin(tm * 6) * 6)) + 'px'; hd.style.opacity = k2 > 1.2 ? 0 : 1; }
    } else { co.style.display = 'none'; if (tipT <= 0) tip.style.display = 'none'; }
  });

  /* ================= стан техніки: значки, видимий бруд, ангар, дорога в місто ================= */
  const tankOf = (v) => (v.id === 'combine' ? D.MACH.combine.tank : v.id === 'truck' ? D.MACH.truck.tank : D.MACH.tractor.tank);
  function needs(v) {
    const st = mState(v.id); if (!st || v.id === 'jeep' || v.id === 'hire') return [];
    const out = [];
    if (st.broken) out.push('!wrench');
    if (st.fuel <= 0) out.push('!fuel'); else if (st.fuel < tankOf(v) * 0.25) out.push('fuel');
    if (st.oil < 25) out.push('oil');
    if (st.dirt > 0.55) out.push('mud');
    if (!st.broken && st.wear > 75) out.push('wrench');
    return out;
  }
  // що зараз найважливіше з технікою — підказка рукою на будь-якому етапі
  function attention() {
    if (S.stage < 1) return null;
    const own = Object.values(VH).filter((v) => mState(v.id) && v.g.visible);
    const br = own.find((v) => mState(v.id).broken && v.bolts[0]); if (br) return { t: T.c_fixBolt, a: wpos(br.bolts[0]) };
    const dry = own.find((v) => mState(v.id).fuel <= 0); if (dry) return { t: T.c_jerry, a: wpos(jerry, 0.4), b: vAt(dry.id) };
    const idle = own.filter((v) => !v.path.length && !v.job && !(v.busy > 0));
    const low = idle.find((v) => mState(v.id).fuel < tankOf(v) * 0.2); if (low) return S.b.fuel ? { t: T.c_lowFuel, a: vAt(low.id), b: V3(P.fuel[0], 0.3, P.fuel[1]) } : { t: T.c_jerry, a: wpos(jerry, 0.4), b: vAt(low.id) };
    const oil = idle.find((v) => mState(v.id).oil < 25); if (oil) return { t: oil.id === 'tractor' ? T.c_oilC : T.c_oilV, a: wpos(oilcan, 0.4), b: vAt(oil.id) };
    const dirty = idle.find((v) => mState(v.id).dirt > 0.6); if (dirty) return S.b.wash ? { t: T.c_washS, a: vAt(dirty.id), b: V3(P.wash[0], 0.3, P.wash[1]) } : { t: T.c_scrub, a: wpos(bucket, 0.4), b: vAt(dirty.id) };
    const worn = idle.find((v) => mState(v.id).wear > 80 && !v.inHangar); if (worn && S.b.hangar) return { t: T.c_hangar, a: vAt(worn.id), b: V3(P.hangar[0], 0.3, P.hangar[1]) };
    return null;
  }
  const ICON_IMG = {};
  function iconImg(name) { if (!ICON_IMG[name]) { const im = new Image(); im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(giSvg(name, 96)); ICON_IMG[name] = im; } return ICON_IMG[name]; }
  function badgeSprite(list) {
    const ic = 64, pad = 10, crit = list.some((x) => x[0] === '!'), names = list.map((x) => x.replace('!', ''));
    const c = document.createElement('canvas'); c.width = pad * 2 + names.length * (ic + 6) - 6; c.height = ic + pad * 2;
    const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace;
    const draw = () => { const g = c.getContext('2d'); g.clearRect(0, 0, c.width, c.height); g.fillStyle = crit ? 'rgba(206,46,34,.9)' : 'rgba(14,16,22,.8)'; g.beginPath(); g.roundRect(0, 0, c.width, c.height, c.height / 2); g.fill(); names.forEach((n, i) => { const im = iconImg(n); if (im.complete && im.naturalWidth) g.drawImage(im, pad + i * (ic + 6), pad, ic, ic); }); tx.needsUpdate = true; };
    draw(); names.forEach((n) => { const im = iconImg(n); if (!(im.complete && im.naturalWidth)) im.addEventListener('load', draw, { once: true }); });
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tx, depthTest: false, transparent: true })); const k = 0.62 / c.height; sp.scale.set(c.width * k, c.height * k, 1); sp.renderOrder = 11; return sp;
  }
  // бруд видно: фарба буріє й тьмяніє (матеріали машини — власні копії)
  const MUD = new THREE.Color(0x5b4632);
  function dirtTint(v, d) {
    const n = v.g.children.length + (v.g.userData.body ? v.g.userData.body.children.length : 0); // модель трактора довантажується пізніше
    if (v.dirtShown !== undefined && Math.abs(v.dirtShown - d) < 0.03 && v.dirtMeshes === n) return;
    v.dirtShown = d; v.dirtMeshes = n;
    const skip = new Set([...v.bolts, v.g.userData.load].filter(Boolean)), lm = v.g.userData.lights;
    v.g.traverse((o) => {
      if (!o.isMesh || skip.has(o) || Array.isArray(o.material) || !o.material || !o.material.color || o.material.visible === false || o.material.transparent || o.material === lm) return;
      if (!o.material.userData.dirtOwn) { o.material = o.material.clone(); o.material.userData.dirtOwn = true; o.material.userData.c0 = o.material.color.clone(); o.material.userData.r0 = o.material.roughness ?? 0.6; }
      o.material.color.copy(o.material.userData.c0).lerp(MUD, d * 0.55); if (o.material.roughness !== undefined) o.material.roughness = Math.min(1, o.material.userData.r0 + d * 0.35);
    });
  }
  let svcT = 0; const BADGE = {}, BADGE_OFF = V3(0, 0.35, 1.75);
  function svcFrame(dt) {
    const pulse = 0.6 + 0.4 * Math.sin(performance.now() / 150);
    // значки — перед машиною біля землі (зверху їх ховала б панель гри), стежать за нею щокадру
    for (const [id, b] of Object.entries(BADGE)) { if (!b) continue; const v = VH[id]; if (!v) continue; b.s.visible = v.g.visible; b.s.position.copy(v.g.position).add(BADGE_OFF); if (b.crit) b.s.material.opacity = pulse; }
    if ((svcT += dt) < 0.25) return; const sdt = svcT; svcT = 0;
    citySign.visible = S.stage >= 2;
    // ангар: коли всередині техніка — дах напівпрозорий, щоб її бачити й брати пальцем
    if (BL.hangar && BL.hangar.userData.roof) { const inside = Object.values(VH).some((v) => v.g.visible && Math.abs(v.g.position.x - P.hangar[0]) < 2.7 && Math.abs(v.g.position.z - P.hangar[1]) < 2.3); const op = inside ? 0.28 : 1; BL.hangar.userData.roof.forEach((m) => { if (m.material.opacity !== op) { m.material.transparent = op < 1; m.material.opacity = op; m.material.depthWrite = op >= 1; m.material.needsUpdate = true; } }); }
    if (S.trip && started) { S.trip.left -= sdt; if (S.trip.left <= 0) tripBack(); }
    for (const v of Object.values(VH)) {
      const st = mState(v.id); if (!st) continue;
      dirtTint(v, st.dirt);
      // ангар: механік поволі знімає знос, поки машина стоїть усередині
      const inH = S.b.hangar && !st.broken && !v.path.length && !v.job && near(v.g.position, V3(P.hangar[0], 0, P.hangar[1]), 2.8);
      if (inH && st.wear > 0) { if (!v.inHangar) { v.inHangar = true; float(T.inHangar, wpos(v.g, 2.4), '#8fe08a'); snd('wrench', v.g.position, 0.6); } st.wear = Math.max(0, st.wear - sdt * 0.8); if (st.wear === 0) float(T.serviced, wpos(v.g, 2.4), '#8fe08a'); } else if (!inH) v.inHangar = false;
      const L = needs(v), key = L.join(','); let b = BADGE[v.id];
      if (b && b.key !== key) { F.remove(b.s); const ix = pickables.indexOf(b.s); if (ix >= 0) pickables.splice(ix, 1); b.s.material.map.dispose(); b.s.material.dispose(); b = BADGE[v.id] = null; }
      if (!b && L.length) { const sp = badgeSprite(L); sp.userData.pick = { kind: 'veh', id: v.id }; F.add(sp); pickables.push(sp); BADGE[v.id] = { s: sp, key, crit: L.some((x) => x[0] === '!') }; }
    }
  }

  /* ================= звук: двигуни, роботи, цехи, фон ================= */
  let sndT = 0; const PLANT_SND = {};
  const WORK_SND = { cultivator: ['rumble', 0.9], seeder: ['grain', 0.35], sprayer: ['spray', 0.8], irrigator: ['spray', 0.9], combine: ['grain', 0.6] };
  function soundFrame(dt, dayK) {
    // петлі живуть лише поки потрібні: заглушена машина не витрачає процесор
    const nap = (v, k, need) => { const t = (v['_' + k] = need ? 0 : (v['_' + k] || 0) + dt); if (t > 2 && v[k]) { v[k].stop(0.1); v[k] = null; } };
    for (const v of Object.values(VH)) {
      const st = mState(v.id), dead = !!(st && (st.broken || st.fuel <= 0)) || (v.id === 'truck' && !!S.trip);
      const moving = v.path.length > 0 && !dead, j = v.job, working = !!(j && j.phase === 'lane') && moving, aug = !!v.augOn;
      if ((moving || aug || v.busy > 0) && !dead) v.idleT = 4; else v.idleT = Math.max(0, v.idleT - dt);
      const on = started && !dead && v.idleT > 0;
      if (on && !v.on) snd('crank', v.g.position, 0.9); // завівся
      else if (!on && v.on && !dead) snd('stall', v.g.position, 0.4); // заглушили після простою
      v.on = on;
      const p = sp3(v.g.position);
      if (on && !v.eng) v.eng = SND.loop('engine', { size: v.id === 'hire' ? 'combine' : v.id, rpm: 0, load: 0, vol: 0 });
      nap(v, 'eng', on); nap(v, 'work', working); nap(v, 'aug', aug);
      if (v.eng) v.eng.set({ rpm: working ? 0.78 : moving ? 0.55 : aug ? 0.62 : 0.05, load: working ? 0.95 : moving ? 0.35 : aug ? 0.55 : 0.05, vol: on ? p.vol : 0, pan: p.pan });
      const wk = working && WORK_SND[j.op];
      if (wk && (!v.work || v.work.dead() || v.workKind !== wk[0])) { if (v.work) v.work.stop(0.2); v.work = SND.loop(wk[0], { vol: 0 }); v.workKind = wk[0]; }
      if (v.work) v.work.set({ vol: wk ? p.vol * wk[1] : 0, pan: p.pan });
      if (v.aug) v.aug.set({ vol: aug ? p.vol : 0, pan: p.pan });
    }
    // цехи гудуть і брязкотять, поки працюють
    for (const bkey of Object.keys(PLANT_OF)) {
      const g = BL[bkey], on = started && PLANT_RUN.has(bkey);
      if (on && !PLANT_SND[bkey]) PLANT_SND[bkey] = SND.loop('hum', { rattle: bkey === 'bioplant' ? 0 : 11, vol: 0 });
      const h2 = PLANT_SND[bkey]; if (!h2) continue; const p = g ? sp3(wpos(g, 1), 0.6) : { vol: 0, pan: 0 };
      if (!on) { h2.offT = (h2.offT || 0) + dt; if (h2.offT > 3) { h2.stop(0.2); delete PLANT_SND[bkey]; continue; } } else h2.offT = 0;
      h2.set({ vol: on ? p.vol * (0.5 + 0.5 * powerK) : 0, pan: p.pan });
    }
    // фон: птахи вдень, цвіркуни (і жаби біля ставка) вночі, вітер за погодою, дощ, ставок
    const w = WEATHER[S.weather], rainy = S.weather === 'rain', nightK = clamp(1 - dayK * 4, 0, 1);
    SND.amb.set('birds', started ? dayK * (rainy ? 0.15 : 0.9) : 0.4);
    SND.amb.set('crickets', started ? nightK * (rainy ? 0.3 : 0.9) : 0, { frogs: !!S.b.pond });
    SND.amb.set('wind', 0.25 + 0.55 * w.wind, { strength: w.wind });
    SND.amb.set('rain', rainy ? 1 : 0, { intensity: 0.8 });
    if (BL.pond) { const p = sp3(wpos(BL.pond)); SND.amb.set('water', p.vol * 0.7, { pan: p.pan }); }
    SND.amb.tick(dt);
  }

  /* ================= дощ ================= */
  const RN = 1100, rainGeo = new THREE.BufferGeometry(), rp = new Float32Array(RN * 6);
  for (let i = 0; i < RN; i++) { const x = (Math.random() - 0.5) * 30, y = Math.random() * 12, z = (Math.random() - 0.5) * 30; rp.set([x, y, z, x + 0.03, y - 0.35, z], i * 6); }
  rainGeo.setAttribute('position', new THREE.BufferAttribute(rp, 3));
  const rain = new THREE.LineSegments(rainGeo, new THREE.LineBasicMaterial({ color: 0x9fbfff, transparent: true, opacity: 0.45 })); rain.frustumCulled = false; scene.add(rain);

  /* ================= старт ================= */
  function flyBits(from, to, color, n) {
    for (let j = 0; j < n; j++) {
      const b = new THREE.Mesh(beanGeo, std(color, 0.4)); b.position.copy(from); F.add(b);
      const mid = from.clone().lerp(to, 0.5).add(V3(0, 1.6, 0)), st = { k: 0 };
      W.tween(st, { k: 1 }, 0.55 + j * 0.06, ease.inOut, () => F.remove(b));
      const off = W.onFrame(() => { const k = st.k, a = from.clone().lerp(mid, k), c = mid.clone().lerp(to.clone().setY(0.6), k); b.position.copy(a.lerp(c, k)); b.rotation.x += 0.3; if (k >= 1) off(); });
    }
  }
  for (const k of Object.keys(MAKE)) if (S.b[k] > 0) placeBuilding(k);
  placeEnergy(false);
  S.fields.forEach((f, i) => { paintField(i); syncCrops(i); if (f.pivot) placePivot(i); });
  S.beds.forEach((b, i) => { BO[i].lock.visible = !b.open; BO[i].soil.visible = b.open; if (b.k) buildPlant(BO[i], b.k); });
  if (S.stage >= 3 && !(S.cnt.repair >= 1)) S.forceBreak = true;
  if (S.trip && VH.truck) { VH.truck.g.visible = false; VH.truck.g.position.set(P.city[0], 0, 21); }
  syncBins(); drawPrices(); syncRack(); syncGoods(); drawOrder(); refreshSites(); drawHud(); drawStage();

  root._dbg = {
    S: () => S, VH, ATT, SITES, start: () => $('#fSplash') && $('#fSplash').click(),
    where: (o) => { const p = o.isVector3 ? o : o.isObject3D ? wpos(o, 0.4) : null; return p ? W.screen(p) : null; },
    pos: (kind, a) => { const p = kind === 'site' ? siteAt(a) : kind === 'veh' ? vAt(a) : kind === 'att' ? wpos(ATT[a].g, 0.4) : kind === 'field' ? fieldC(a) : kind === 'bed' ? bedPos(a).setY(0.3) : kind === 'bin' ? BIN[a].g.position.clone().setY(0.5) : kind === 'rack' ? wpos(RS[a].g, 0.4) : kind === 'stall' ? wpos(stall, 0.8) : kind === 'bld' ? wpos(BL[a], 0.6) : kind === 'xyz' ? V3(...a) : null; if (!p) return null; const q = W.screen(p), r = root.getBoundingClientRect(); return { x: q.x + r.left, y: q.y + r.top }; },
    look: (x, z, d) => { cam.flyTo(V3(x, 0, z), d); },
    ff: (days) => { S.tod += days; while (S.tod >= 1) { S.tod -= 1; newDay(); } S.beds.forEach((b) => { if (b.k) b.t += days; }); S.fields.forEach((f, i) => { if (['sown', 'grow'].includes(f.st)) { f.grow = Math.min(1, f.grow + days / D.CROPS[f.crop].days); if (f.grow >= 1) { f.st = 'ripe'; paintField(i); } syncCrops(i); } }); refreshSites(); },
    pickAt: (x, y) => { const r = root.getBoundingClientRect(); const hit = W.pick({ clientX: x, clientY: y }, pickables); void r; return hit ? JSON.stringify(hit.obj.userData.pick) : null; }, carry: () => (carry ? carry.kind : null),
    warp: (n) => { warp = n; },
    check: () => checkStage(),
    lowres: () => { const { W: w, H: hh } = W.size(); W.renderer.setPixelRatio(0.35); W.composer.setPixelRatio && W.composer.setPixelRatio(0.35); W.composer.setSize(w, hh); },
    call: (name, ...a) => ({ feedPlant, deliverGood, sellGoodAtFair, weigh, toBarn: () => toBarn(VH.truck, S.m.truck), combineToBarn: () => toBarn(VH.combine, S.m.combine), unloadCombine, autoUnload, save, refuel: (id) => refuel(VH[id]), wash: (id) => wash(VH[id]), changeOil: (id) => changeOil(VH[id]), fixAll: (id) => { [...VH[id].bolts].forEach((b) => boltDone(b, id)); }, cast: (x, z) => cast(V3(x, 0, z)), catchFish, rest, sleep, buyFieldSeed, buyFert, loadSeed: (c) => { S.seeds[c]--; S.m.att.seeder.seed = c; ATT.seeder.g.userData.fill.visible = true; }, loadFert: () => { S.fertBags--; S.m.att.sprayer.fert = 1; ATT.sprayer.g.userData.fill.visible = true; }, newOrder, sellCrate, plant, harvest })[name](...a),
    buy: (id) => buy(id), hitch: (a) => hitch(ATT[a]), drop: (id, x, z) => dropVeh(VH[id], V3(x, 0, z)), floats: () => [...W.hud.querySelectorAll('.gfloat')].map((e) => e.textContent), veh: (id) => { const v = VH[id]; return v ? { p: v.g.position.toArray().map((x) => +x.toFixed(2)), ry: +v.g.rotation.y.toFixed(2), path: v.path.map((q) => q.toArray().map((x) => +x.toFixed(1))), job: v.job && { op: v.job.op, lane: v.job.lane, phase: v.job.phase }, att: v.att && v.att.a } : null; },
    scr: (what, k) => { const o = what === 'good' ? GP[k] && GP[k].g : what === 'order' ? orderV : what === 'truck' ? VH.truck && VH.truck.g : null; return o ? W.screen(wpos(o, 0.6)) : null; },
    order: (k, amt) => { S.order = { k, amt, got: 0, reward: Math.round(amt * D.GOODS[k].price * 1.35) }; drawOrder(); syncGoods(); },
    give: (n) => { S.coins += n; }, needs: (id) => VH[id] && needs(VH[id]), att: () => { const a = attention(); return a && a.t; }, trip: () => S.trip, pourJerry: (id) => pourJerry(VH[id]), loadGoods, cityTrip: () => cityTrip(VH.truck), tripLeft: (n) => { if (S.trip) S.trip.left = n; }, stage: (n) => { S.stage = n; refreshSites(); syncRack(); drawStage(); }
  };
  return { destroy() { save(); SND.stop(); W.destroy(); } };
}
