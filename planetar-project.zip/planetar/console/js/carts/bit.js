// БІТ У ДАТАБАЗІ 3D — переробка гри сина.
// Від оригіналу: Біт, файли = здоров'я й уміння, порча з різним «почерком»
// (404, SQL-ін'єкція, витік пам'яті, дубль), сундуки з резервними копіями,
// ухиляння в бою, «очистити або поговорити», Безіменний Нуль.
// Що виправлено: менше тексту, бій на весь екран, керування пальцем,
// мишкою чи клавішами; після кожного ворога — справжній факт про комп'ютер.
import { world, THREE, RoundedBoxGeometry, std, glow, blob, label, particles, h, esc, canvasTex, ease } from '../kit.js';
import { inst, clip, animator } from '../models.js';
import { makeCat } from '../catcrew.js';
import { gi } from '../icons.js';
import { sfx as SFX, soundScope } from '../sound.js';

const L3 = (uk, en, ru) => ({ uk, en, ru });
const TX = {
  uk: { goal: 'Врятуй Датабазу від Безіменного Нуля', start: 'Торкнись, щоб почати', h_move: 'Веди пальцем — Біт летить за ним', h_turn: 'Проведи по сяйву — очистити · слово на ворога — поговорити · файл на себе — уміння', h_slash: 'Проведи пальцем крізь сяйво', h_talk: 'Тягни слово на ворога', h_file: 'Тягни файл на Біта', tapOn: 'Торкнись, щоб іти далі', petZap: 'захистив!', intro: 'Ти — Біт. Датабазу пожирає Безіменний Нуль: усе, чого він торкається, розсипається на нулі й одиниці. Твої файли — це здоров’я й уміння. Порчу можна стерти — або переконати.', go: 'Увійти', move: 'Тягни пальцем або WASD', dodge: 'Ухиляйся!', clean: 'Очистити', talk: 'Поговорити', file: 'Файл', tap: 'Тисни в зеленій зоні!', erased: 'Стерто', calmed: 'Заспокоєно', fact: 'Справжня штука', cont: 'Далі', chest: 'Резервна копія: файли відновлено', reboot: 'Біт перезавантажився біля сундука', win: 'Датабазу врятовано!', winD: 'Безіменний Нуль більше не стирає записи. Він — перший рядок у базі.', again: 'Ще раз', trust: 'довіра', corr: 'порча', used: 'уже використано', back: 'Назад' },
  en: { goal: 'Save the Database from the Nameless Zero', start: 'Tap to start', h_move: 'Lead with your finger — Bit flies after it', h_turn: 'Swipe through the glow to clean · drag a word onto the foe to talk · a file onto yourself for a skill', h_slash: 'Swipe through the glow', h_talk: 'Drag a word onto the foe', h_file: 'Drag a file onto Bit', tapOn: 'Tap to go on', petZap: 'blocked it!', intro: 'You are Bit. The Nameless Zero is eating the Database: whatever it touches crumbles into ones and zeros. Your files are your health and skills. Corruption can be erased — or talked down.', go: 'Enter', move: 'Drag a finger or use WASD', dodge: 'Dodge!', clean: 'Clean', talk: 'Talk', file: 'File', tap: 'Tap in the green zone!', erased: 'Erased', calmed: 'Calmed', fact: 'The real thing', cont: 'Continue', chest: 'Backup found: files restored', reboot: 'Bit rebooted at the chest', win: 'The Database is saved!', winD: 'The Nameless Zero no longer erases records. It is the first row of the base.', again: 'Again', trust: 'trust', corr: 'corruption', used: 'already used', back: 'Back' },
  ru: { goal: 'Спаси Датабазу от Безымянного Ноля', start: 'Коснись, чтобы начать', h_move: 'Веди пальцем — Бит летит за ним', h_turn: 'Проведи по сиянию — очистить · слово на врага — поговорить · файл на себя — умение', h_slash: 'Проведи пальцем сквозь сияние', h_talk: 'Тяни слово на врага', h_file: 'Тяни файл на Бита', tapOn: 'Коснись, чтобы идти дальше', petZap: 'защитил!', intro: 'Ты — Бит. Датабазу пожирает Безымянный Ноль: всё, к чему он прикасается, рассыпается на нули и единицы. Твои файлы — это здоровье и умения. Порчу можно стереть — или переубедить.', go: 'Войти', move: 'Тяни пальцем или WASD', dodge: 'Уклоняйся!', clean: 'Очистить', talk: 'Поговорить', file: 'Файл', tap: 'Жми в зелёной зоне!', erased: 'Стёрто', calmed: 'Успокоено', fact: 'Настоящая штука', cont: 'Дальше', chest: 'Резервная копия: файлы восстановлены', reboot: 'Бит перезагрузился у сундука', win: 'Датабаза спасена!', winD: 'Безымянный Ноль больше не стирает записи. Он — первая строка в базе.', again: 'Ещё раз', trust: 'доверие', corr: 'порча', used: 'уже использовано', back: 'Назад' }
};
Object.assign(TX.uk, { ph_dodge: 'Ухиляйся!', ph_dodge_s: 'Веди ядро пальцем — не торкайся червоного', ph_turn: 'Твій хід', ph_turn_s: 'Обери одне: очистити, поговорити або файл', l_clean: 'Очистити', l_talk: 'Поговорити', l_file: 'Файли', route: 'Шлях до Нуля', left: 'с' });
Object.assign(TX.en, { ph_dodge: 'Dodge!', ph_dodge_s: 'Steer the core with your finger — avoid the red', ph_turn: 'Your turn', ph_turn_s: 'Pick one: clean, talk or a file', l_clean: 'Clean', l_talk: 'Talk', l_file: 'Files', route: 'Road to Zero', left: 's' });
Object.assign(TX.ru, { ph_dodge: 'Уклоняйся!', ph_dodge_s: 'Веди ядро пальцем — не касайся красного', ph_turn: 'Твой ход', ph_turn_s: 'Выбери одно: очистить, поговорить или файл', l_clean: 'Очистить', l_talk: 'Поговорить', l_file: 'Файлы', route: 'Путь к Нулю', left: 'с' });
const FILES = [
  { id: 'shield.sys', ab: L3('Щит: два удари мимо', 'Shield: two hits miss', 'Щит: два удара мимо') },
  { id: 'medic.exe', ab: L3('Лікування: +6 найслабшому', 'Heal: +6 to the weakest', 'Лечение: +6 самому слабому') },
  { id: 'scan.dll', ab: L3('Сканер: наступне очищення ×2', 'Scan: next clean ×2', 'Сканер: следующая очистка ×2') },
  { id: 'meta.meta', ab: L3('Метадані: дізнатись ім’я, довіра +3', 'Metadata: learn its name, trust +3', 'Метаданные: узнать имя, доверие +3') }
];
const FOES = [
  { id: '404', model: 'ghost', h: 1.3, z: -7, hp: 26, tr: 8, pat: ['rain'], col: '#7fe3ff',
    name: L3('Помилка 404', 'Error 404', 'Ошибка 404'),
    say: [L3('Назвати її справжнє ім’я', 'Say its real name', 'Назвать её настоящее имя'), L3('«Тебе знайдуть»', '“You will be found”', '«Тебя найдут»'), L3('Накричати', 'Shout at it', 'Накричать')],
    fact: L3('404 — так сервер каже, що сторінки за цією адресою немає. Посилання є, а запису вже нема.', '404 is how a server says there is no page at this address. The link exists, the record does not.', '404 — так сервер говорит, что страницы по этому адресу нет. Ссылка есть, а записи уже нет.') },
  { id: 'sql', model: 'skull_hopper', h: 1.0, z: -15, hp: 30, tr: 9, pat: ['bars', 'rain'], col: '#ff7a8a',
    name: L3('SQL-ін’єкція', 'SQL injection', 'SQL-инъекция'),
    say: [L3('Закрити дужку', 'Close the bracket', 'Закрыть скобку'), L3('«Ти рядок, а не команда»', '“You are text, not a command”', '«Ты строка, а не команда»'), L3('Додати ще запит', 'Add another query', 'Добавить ещё запрос')],
    fact: L3('SQL-ін’єкція — коли в звичайний текст ховають команду для бази даних. Захист: ніколи не виконувати введений текст як код.', 'SQL injection hides a database command inside plain text. Defence: never run typed text as code.', 'SQL-инъекция — когда в обычный текст прячут команду для базы данных. Защита: никогда не выполнять введённый текст как код.') },
  { id: 'leak', model: 'slime_green', h: 0.9, z: -23, hp: 32, tr: 9, pat: ['bubbles', 'mines'], col: '#9fe39a',
    name: L3('Витік пам’яті', 'Memory leak', 'Утечка памяти'),
    say: [L3('Підставити долоні', 'Hold out your hands', 'Подставить ладони'), L3('«Поверни, що взяла»', '“Give back what you took”', '«Верни, что взяла»'), L3('Вдарити по краплях', 'Hit the drops', 'Ударить по каплям')],
    fact: L3('Витік пам’яті — програма бере пам’ять і забуває її повернути. Що довше працює, то повільніший комп’ютер.', 'A memory leak: a program takes memory and forgets to give it back. The longer it runs, the slower the computer.', 'Утечка памяти — программа берёт память и забывает её вернуть. Чем дольше работает, тем медленнее компьютер.') },
  { id: 'dup', model: 'robot_flyer', tint: '#ff6b6b', h: 1.0, z: -31, hp: 34, tr: 10, pat: ['mirror', 'rain'], col: '#ff9f6b',
    name: L3('Дубль', 'The Duplicate', 'Дубль'),
    say: [L3('Злитися в один запис', 'Merge into one record', 'Слиться в одну запись'), L3('«У нас різні ключі»', '“We have different keys”', '«У нас разные ключи»'), L3('Повторити його рух', 'Copy its move', 'Повторить его движение')],
    fact: L3('Дублікати файлів займають місце. Програми знаходять їх за «відбитком» вмісту — хешем.', 'Duplicate files waste space. Programs find them by a fingerprint of the content — a hash.', 'Дубликаты файлов занимают место. Программы находят их по «отпечатку» содержимого — хешу.') },
  { id: 'zero', model: 'ghost_skull', h: 2.0, z: -40, hp: 60, tr: 14, pat: ['rain', 'bars', 'mines', 'bubbles'], col: '#c49bff', boss: true,
    name: L3('Безіменний Нуль', 'The Nameless Zero', 'Безымянный Ноль'),
    say: [L3('Простягнути свій лог', 'Offer your log', 'Протянуть свой лог'), L3('«Тут тебе не зітруть»', '“No one will erase you here”', '«Здесь тебя не сотрут»'), L3('Атакувати мовчки', 'Attack in silence', 'Атаковать молча')],
    fact: L3('Нуль був першим записом — його написали для перевірки. Тести існують, щоб програма працювала, а не щоб її ламати.', 'Zero was the first record — written as a test. Tests exist to keep programs working, not to break them.', 'Ноль был первой записью — его написали для проверки. Тесты существуют, чтобы программа работала, а не чтобы её ломать.') }
];
const CHESTS = [-3, -11, -19, -27, -35];

export function mount(root, api) {
  const lang = TX[api.lang] ? api.lang : 'uk';
  const T = TX[lang];
  const W = world(root, { quality: api.quality, bg: 0x05070b, envI: 0.25, bloom: 0.7, bloomTh: 0.72, tilt: 0.2 });
  const { scene, camera, hud } = W;
  const fx = particles(W, 600);
  // звук: тихий цифровий фон, що напружується в бою; постріли, щит, збої
  const SND = soundScope();
  const PETV = ((m) => (m.includes('cat') ? 'meow' : m.includes('fox') ? 'yip' : m.includes('frog') ? 'ribbit' : /dino|dragon|trike/.test(m) ? 'roar' : 'bark'))(api.petModel || '');
  let stepT = 0;

  /* ---------- стан ---------- */
  const S = { files: FILES.map(() => 10), foe: 0, done: FOES.map(() => null), chest: 0, mode: 'intro' };

  /* ---------- світ-плата ---------- */
  scene.fog = new THREE.FogExp2(0x05070b, 0.045);
  scene.add(new THREE.HemisphereLight(0x6fa8ff, 0x0a0a12, 0.5));
  const key = new THREE.DirectionalLight(0xbfd8ff, 1.3); key.position.set(-4, 10, 4); key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024); Object.assign(key.shadow.camera, { left: -10, right: 10, top: 10, bottom: -10, near: 1, far: 40 });
  scene.add(key, key.target);
  const boardTex = canvasTex(1024, (g, s) => {
    g.fillStyle = '#0a1a14'; g.fillRect(0, 0, s, s);
    g.strokeStyle = 'rgba(80,200,150,.35)'; g.lineWidth = 3;
    for (let i = 0; i < 70; i++) { let x = Math.random() * s, y = Math.random() * s; g.beginPath(); g.moveTo(x, y); for (let k = 0; k < 4; k++) { if (Math.random() < 0.5) x += (Math.random() - 0.5) * 300; else y += (Math.random() - 0.5) * 300; g.lineTo(x, y); } g.stroke(); g.fillStyle = 'rgba(200,170,90,.6)'; g.beginPath(); g.arc(x, y, 5, 0, 7); g.fill(); }
  });
  boardTex.repeat.set(2, 10);
  const LEN = 46, WID = 9;
  const floor = new THREE.Mesh(new RoundedBoxGeometry(WID, 0.4, LEN, 4, 0.12), std(0xffffff, 0.55, 0.2, { map: boardTex, emissiveMap: boardTex, emissive: new THREE.Color(0x3fb08a), emissiveIntensity: 0.35 }));
  floor.position.set(0, -0.2, -LEN / 2 + 3); floor.receiveShadow = true; scene.add(floor);
  // чипи-перешкоди
  const walls = [];
  const chipM = std(0x15181d, 0.35, 0.6), pinM = std(0xc9a94a, 0.3, 1);
  function chip(x, z, w, d, hh = 0.7, txt) {
    const g = new THREE.Group(); g.position.set(x, 0, z); scene.add(g);
    const body = new THREE.Mesh(new RoundedBoxGeometry(w, hh, d, 3, 0.05), chipM); body.position.y = hh / 2; body.castShadow = true; body.receiveShadow = true; g.add(body);
    const n = Math.max(2, Math.floor(d / 0.3));
    const pins = new THREE.InstancedMesh(new THREE.BoxGeometry(0.18, 0.05, 0.08), pinM, n * 2); const m = new THREE.Matrix4(); let k = 0;
    for (let i = 0; i < n; i++) for (const sx of [-1, 1]) { m.makeTranslation(sx * (w / 2 + 0.06), 0.05, -d / 2 + (i + 0.5) * d / n); pins.setMatrixAt(k++, m); }
    g.add(pins);
    if (txt) { const tg = label(txt, { scale: 0.22, bg: false, color: 'rgba(220,230,255,.75)', depth: true }); tg.position.set(0, hh + 0.02, 0); tg.material.depthTest = true; g.add(tg); }
    walls.push({ x, z, w: w + 0.3, d: d + 0.1 });
  }
  const chipNames = ['CPU', 'RAM', 'ROM', 'I/O', 'GPU', 'NET', 'SSD', 'BUS'];
  for (let z = -1; z > -LEN + 4; z -= 4) {
    const side = (z / 4) % 2 ? 1 : -1;
    chip(side * 2.8, z - 1, 2.2, 1.6, 0.6 + Math.random() * 0.5, chipNames[(-z) % 8]);
    if (z % 8 === -1) chip(-side * 3.3, z - 2.2, 1.4, 1.1, 0.5);
  }
  // бічні стіни (край плати)
  walls.push({ x: -WID / 2 - 0.5, z: -LEN / 2 + 3, w: 1, d: LEN }, { x: WID / 2 + 0.5, z: -LEN / 2 + 3, w: 1, d: LEN }, { x: 0, z: 3.4, w: WID, d: 1 }, { x: 0, z: -LEN + 2.6, w: WID, d: 1 });

  // сундуки
  const chests = CHESTS.map((z, i) => {
    const g = new THREE.Group(); g.position.set(i % 2 ? 2.6 : -2.6, 0, z + 1.2); scene.add(g);
    inst('chest', 0.6, { by: 'xz' }).then((m) => g.add(m)).catch(() => { });
    const l = new THREE.PointLight(0xffd36b, 1.2, 2.5); l.position.y = 0.8; g.add(l);
    return { g, l, used: false };
  });

  /* ---------- Біт ---------- */
  const bit = new THREE.Group(); scene.add(bit); bit.position.set(0, 0, 1.5);
  const bitLight = new THREE.PointLight(0x7fe3ff, 0.9, 4); bitLight.position.y = 1.7; bit.add(bitLight);
  let bitAnim = null, bitClips = [];
  inst('robot_flyer', 0.95).then((m) => { bit.add(m); bitClips = m.userData.clips; bitAnim = animator(m, bitClips); bitAnim.play(clip(bitClips, /^idle$/i, /idle/i)); }).catch(() => { });
  bit.add(Object.assign(blob(0.9, 0.9, 0.5), {}));

  // вороги
  const foes = FOES.map((f, i) => {
    const g = new THREE.Group(); g.position.set(0, 0, f.z); scene.add(g);
    const l = new THREE.PointLight(new THREE.Color(f.col), 2.5, 5); l.position.y = 1.2; g.add(l);
    const tg = label(f.name[lang], { scale: 0.3 }); tg.position.y = f.h + 0.5; g.add(tg);
    const o = { g, l, tg, anim: null, clips: [], m: null };
    inst(f.model, f.h, { tint: f.tint, emissive: f.col, ei: 0.25 }).then((m) => { g.add(m); o.m = m; o.clips = m.userData.clips; o.anim = animator(m, o.clips); o.anim.play(clip(o.clips, /flying_idle/i, /^idle$/i, /idle/i)); }).catch(() => { });
    return o;
  });

  // доріжка-підказка від Біта до наступної мети (ворог або сундук)
  const guide = []; { const gm = glow(0x9fefff, 1.6); for (let i = 0; i < 9; i++) { const d = new THREE.Mesh(new THREE.CircleGeometry(0.08, 12), gm); d.rotation.x = -Math.PI / 2; d.position.y = 0.03; scene.add(d); guide.push(d); } }
  /* ---------- улюбленець гравця: летить поруч, у бою закриває Біта ---------- */
  let petO = null, petAnim = null, petClips = [], petProc = null, petZapT = 3;
  const petPlay = (st) => { if (petProc) petProc.set(st === 'happy' ? 'jump' : st); else if (petAnim) { const c = st === 'walk' ? clip(petClips, /^walk$/i, /walk/i) : st === 'happy' ? clip(petClips, /^jump_toidle$/i, /^jump$/i, /^yes$/i) : clip(petClips, /^idle$/i, /flying_idle/i, /^idle/i); if (st === 'happy') petAnim.play(c, { once: true, then: () => petPlay('idle') }); else petAnim.play(c); } };
  const petReady = (m) => { petO = m; m.position.set(-0.9, 0, 2.4); scene.add(m); const hl = new THREE.PointLight(0xff9fc0, 0.6, 2.2); hl.position.y = 1; m.add(hl); petPlay('idle'); };
  if (api.petModel && api.petModel.startsWith('proc:cat')) { const m = makeCat({ coat: api.petModel.split(':')[2] }); m.scale.setScalar(1.1); petProc = m.userData.cat; petReady(m); }
  else if (api.petModel) inst(api.petModel, 0.6, { tint: api.petTint }).then((m) => { petClips = m.userData.clips; petAnim = animator(m, petClips); petReady(m); }).catch(() => { });

  /* ---------- арена бою ---------- */
  const AR = new THREE.Group(); AR.position.set(60, 0, 0); scene.add(AR);
  const AS = 2.6; // напівширина арени
  const arFloor = new THREE.Mesh(new THREE.PlaneGeometry(AS * 2 + 0.4, AS * 2 + 0.4), std(0x0a0e14, 0.6, 0.3, { map: boardTex }));
  arFloor.rotation.x = -Math.PI / 2; arFloor.receiveShadow = true; AR.add(arFloor);
  const frameM = glow(0x7fe3ff, 1.1);
  const frame = new THREE.Group(); AR.add(frame);
  for (const [x, z, w, d] of [[0, -AS, AS * 2 + 0.1, 0.06], [0, AS, AS * 2 + 0.1, 0.06], [-AS, 0, 0.06, AS * 2], [AS, 0, 0.06, AS * 2]]) { const b = new THREE.Mesh(new THREE.BoxGeometry(w, 0.08, d), frameM); b.position.set(x, 0.04, z); frame.add(b); }
  const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.17), glow(0x7fe3ff, 1.6)); core.position.y = 0.25; AR.add(core);
  const coreL = new THREE.PointLight(0x7fe3ff, 0.8, 1.6); coreL.position.y = 0.6; core.add(coreL);
  const foeBig = new THREE.Group(); foeBig.position.set(0, 0, -AS - 1.4); AR.add(foeBig);
  // постамент ворога, кутові пілони, колони даних позаду — арена виглядає як місце бою, а не порожня площина
  { const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 1.1, 0.25, 32), std(0x111820, 0.4, 0.6)); ped.position.set(0, 0.12, -AS - 1.4); ped.receiveShadow = true; AR.add(ped);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.0, 0.03, 6, 48), frameM); ring.rotation.x = Math.PI / 2; ring.position.set(0, 0.26, -AS - 1.4); AR.add(ring);
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) { const py = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.9, 0.22), std(0x141a22, 0.4, 0.6)); py.position.set(sx * (AS + 0.2), 0.45, sz * (AS + 0.2)); py.castShadow = true; AR.add(py); const tip = new THREE.Mesh(new THREE.OctahedronGeometry(0.12), frameM); tip.position.set(sx * (AS + 0.2), 1.0, sz * (AS + 0.2)); AR.add(tip); } }
  const columns = []; for (let i = 0; i < 14; i++) { const c = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1, 0.08), glow(0x3fb08a, 0.9)); c.position.set(-AS - 0.6 + i * (AS * 2 + 1.2) / 13, 0, -AS - 2.9 - (i % 3) * 0.4); c.userData.s = Math.random() * 6; AR.add(c); columns.push(c); }
  const glyph = (ch, col) => { const t = canvasTex(64, (g, s) => { g.font = 'bold 50px JetBrains Mono, monospace'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = col; g.fillText(ch, s / 2, s / 2 + 3); }); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return new THREE.SpriteMaterial({ map: t, color: new THREE.Color(2, 2, 2), transparent: true, depthWrite: false }); };
  const G0 = glyph('0', '#9fefff'), G1 = glyph('1', '#9fefff');
  const shots = [];
  const sphereG = new THREE.SphereGeometry(1, 16, 12), barG = new THREE.BoxGeometry(1, 0.2, 0.22), mineG = new THREE.OctahedronGeometry(0.13);
  const hurtM = glow(0xff5a6b, 2.4), bubM = new THREE.MeshPhysicalMaterial({ color: 0x9fe39a, emissive: 0x2f8f3a, emissiveIntensity: 1, transparent: true, opacity: 0.55, roughness: 0.1 });
  function addShot(o) { AR.add(o.obj); shots.push(o); return o; }

  /* ---------- камера ---------- */
  let portrait = false;
  W.onResize = (w, hh) => { portrait = w / hh < 0.8; camera.fov = portrait ? 50 : 40; camera.updateProjectionMatrix(); };
  const camT = new THREE.Vector3(), camL = new THREE.Vector3();

  /* ---------- керування ---------- */
  const keys = {};
  const kd = (e) => { keys[e.key.toLowerCase()] = e.type === 'keydown'; if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(e.key.toLowerCase())) e.preventDefault(); };
  window.addEventListener('keydown', kd); window.addEventListener('keyup', kd);
  W.onDispose(() => { window.removeEventListener('keydown', kd); window.removeEventListener('keyup', kd); });
  let stick = null; // {x,y,cx,cy}
  W.canvas.addEventListener('pointerdown', (e) => { stick = { sx: e.clientX, sy: e.clientY, x: e.clientX, y: e.clientY, cx: core.position.x, cz: core.position.z }; try { W.canvas.setPointerCapture(e.pointerId); } catch (_) { } });
  W.canvas.addEventListener('pointermove', (e) => { if (stick) { stick.x = e.clientX; stick.y = e.clientY; } });
  const up = () => { stick = null; };
  W.canvas.addEventListener('pointerup', up); W.canvas.addEventListener('pointercancel', up);
  function axis() {
    let x = (keys.d || keys.arrowright ? 1 : 0) - (keys.a || keys.arrowleft ? 1 : 0);
    let z = (keys.s || keys.arrowdown ? 1 : 0) - (keys.w || keys.arrowup ? 1 : 0);
    if (goal && S.mode === 'explore' && !x && !z) { const dx = goal.x - bit.position.x, dz = goal.z - bit.position.z, l = Math.hypot(dx, dz); if (l > 0.25) { x = dx / Math.max(l, 1.2); z = dz / Math.max(l, 1.2); } else goal = null; }
    const l = Math.hypot(x, z); if (l > 1) { x /= l; z /= l; }
    return { x, z };
  }

  /* ---------- HUD ---------- */
  hud.innerHTML = `<canvas id="xTrail" style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none"></canvas>
    <div id="xFiles" style="position:absolute;left:10px;top:10px;display:flex;gap:5px;flex-wrap:wrap;max-width:calc(100% - 20px)"></div>
    <div id="xFoe" class="gg" style="position:absolute;right:10px;top:54px;padding:8px 12px;display:none;min-width:150px"></div>
    <div id="xRoute" class="gg" style="position:absolute;left:10px;top:54px;padding:6px 10px;display:flex;gap:6px;align-items:center;font:600 11px var(--fb)"></div>
    <div id="xChip" class="gg" style="position:absolute;left:50%;bottom:calc(64px + env(safe-area-inset-bottom));transform:translateX(-50%);padding:6px 14px;display:none;font:800 14px var(--fd);letter-spacing:.04em;min-width:150px;text-align:center"></div>
    <div id="xPhase" style="position:absolute;left:50%;top:34%;transform:translate(-50%,-50%) scale(.8);opacity:0;pointer-events:none;text-align:center;transition:opacity .35s,transform .35s cubic-bezier(.2,1.4,.4,1)"></div>
    <div id="xMsg" style="position:absolute;left:50%;top:40%;transform:translate(-50%,-50%);font:700 22px var(--fd);text-shadow:0 4px 18px rgba(0,0,0,.8);pointer-events:none;text-align:center"></div>
    <div id="xHint" class="gg" style="position:absolute;left:50%;bottom:calc(14px + env(safe-area-inset-bottom));transform:translateX(-50%);padding:9px 14px;font:600 13px var(--fb);text-align:center;width:max-content;max-width:94%;display:none"></div>
    <div id="xHand" style="position:absolute;pointer-events:none;display:none;filter:drop-shadow(0 6px 10px rgba(0,0,0,.6));transform:translate(-20%,-10%)">${gi('paw', 40)}</div>
    <div id="xOver" style="position:absolute;inset:0;display:none;align-items:center;justify-content:center;padding:20px;background:rgba(4,8,12,.55);cursor:pointer"></div>
    <div id="xSplash" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;padding:24px;background:radial-gradient(circle at 50% 40%,rgba(60,160,140,.35),rgba(3,6,9,.9));cursor:pointer">
      <span style="font:800 clamp(30px,9vw,44px) var(--fd);letter-spacing:.02em;color:#9fefff;text-shadow:0 0 24px rgba(127,227,255,.6)">BIT</span>
      <b style="font:700 clamp(18px,5vw,24px) var(--fd);max-width:22ch">${esc(T.goal)}</b>
      <span class="gsub" style="animation:xP 1.6s ease-in-out infinite">${esc(T.start)}</span></div>
    <style>@keyframes xP{50%{opacity:.4}}</style>`;
  const $ = (s) => hud.querySelector(s);
  function filesHud() {
    $('#xFiles').innerHTML = FILES.map((f, i) => { const v = S.files[i]; return `<span class="gg" style="padding:5px 9px;border-radius:12px;display:flex;flex-direction:column;gap:3px;min-width:70px;opacity:${v > 0 ? 1 : 0.4}"><span style="font:600 10px var(--fm)">${f.id}</span><b style="display:block;height:5px;border-radius:9px;background:rgba(255,255,255,.15);overflow:hidden"><i style="display:block;height:100%;width:${v * 10}%;background:${v > 4 ? '#7fe3ff' : '#ff7a6a'}"></i></b></span>`; }).join('');
  }
  function foeHud() {
    const f = FOES[S.foe], b = battle;
    if (!b) { $('#xFoe').style.display = 'none'; return; }
    $('#xFoe').style.display = '';
    $('#xFoe').innerHTML = `<b style="font:700 14px var(--fd)">${esc(f.name[lang])}</b>
      <div class="gsub" style="font-size:11px;margin-top:4px">${T.corr}</div><b style="display:block;height:6px;border-radius:9px;background:rgba(255,255,255,.14);overflow:hidden"><i style="display:block;height:100%;width:${Math.max(0, b.hp / f.hp * 100)}%;background:#ff7a8a"></i></b>
      <div class="gsub" style="font-size:11px;margin-top:4px">${T.trust}</div><b style="display:block;height:6px;border-radius:9px;background:rgba(255,255,255,.14);overflow:hidden"><i style="display:block;height:100%;width:${Math.min(100, b.trust / f.tr * 100)}%;background:#9fe39a"></i></b>`;
  }
  function msg(t, ms = 1200) { const e = $('#xMsg'); e.textContent = t; clearTimeout(msg.t); msg.t = setTimeout(() => e.textContent = '', ms); }
  const closePanel = () => { };
  // великий банер фази: що зараз відбувається і що робити
  function banner(kind, title, sub, col) {
    const e = $('#xPhase'); clearTimeout(banner.t);
    e.innerHTML = `<div style="display:inline-flex;flex-direction:column;align-items:center;gap:6px;padding:14px 22px;border-radius:24px;background:rgba(6,12,18,.82);box-shadow:0 0 0 2px ${col},0 18px 50px -10px ${col}">${gi(kind, 44)}<b style="font:800 clamp(24px,7vw,34px) var(--fd);color:${col};text-shadow:0 0 18px ${col}">${esc(title)}</b><span style="font:600 14px var(--fb);color:#dfefff;max-width:30ch">${esc(sub)}</span></div>`;
    e.style.opacity = '1'; e.style.transform = 'translate(-50%,-50%) scale(1)';
    banner.t = setTimeout(() => { e.style.opacity = '0'; e.style.transform = 'translate(-50%,-50%) scale(.8)'; }, 1700);
  }
  function routeHud() {
    $('#xRoute').innerHTML = `<span style="opacity:.75">${esc(T.route)}</span>` + FOES.map((f, i) => { const d = S.done[i], cur = !d && S.done.findIndex((x) => !x) === i; const c = d === 'calmed' ? '#9fe39a' : d === 'erased' ? '#9fefff' : cur ? f.col : 'rgba(255,255,255,.25)'; return `<i style="display:inline-block;width:${f.boss ? 14 : 10}px;height:${f.boss ? 14 : 10}px;border-radius:50%;background:${d ? c : 'transparent'};box-shadow:inset 0 0 0 2px ${c}${cur ? `,0 0 10px ${c}` : ''}"></i>`; }).join('');
  }

  /* ---------- бій ---------- */
  let battle = null;
  function startBattle(i) {
    S.mode = 'battle'; S.foe = i;
    const f = FOES[i];
    battle = { hp: f.hp, trust: 0, round: 0, t: 0, dur: 6.5, shield: 0, scan: false, usedAb: {}, inv: 0, angry: 0, spawnT: 0, mineT: 0, trail: [] };
    core.position.set(0, 0.25, AS * 0.5);
    foeBig.clear();
    inst(f.model, f.boss ? 2.2 : 1.6, { tint: f.tint, emissive: f.col, ei: 0.3 }).then((m) => { foeBig.add(m); const a = animator(m, m.userData.clips); a.play(clip(m.userData.clips, /flying_idle/i, /^idle$/i, /idle/i)); battle && (battle.anim = a); }).catch(() => { });
    frameM.emissive.set(f.col);
    api.sfx('zap'); msg(f.name[lang], 1400);
    foeHud();
    setTimeout(() => dodgeRound(), 1200);
  }
  function dodgeRound() {
    if (!battle) return;
    closePanel(); battle.phase = 'dodge'; battle.t = 0; battle.round++;
    battle.dur = 5.5 + Math.min(3, battle.round * 0.5);
    banner('energy', T.ph_dodge, T.ph_dodge_s, '#ff7a8a'); SFX('dodge'); hint(T.ph_dodge_s);
  }
  function hurt() {
    if (battle.inv > 0) return;
    battle.inv = 0.9;
    if (battle.shield > 0) { battle.shield--; fx.burst(core.getWorldPosition(new THREE.Vector3()), 0x7fe3ff, 18, 1.6); SFX('shield'); return; }
    const alive = S.files.map((v, i) => v > 0 ? i : -1).filter((i) => i >= 0);
    const k = alive[(Math.random() * alive.length) | 0];
    S.files[k] = Math.max(0, S.files[k] - 2);
    fx.burst(core.getWorldPosition(new THREE.Vector3()), 0xff5a6b, 24, 2);
    SFX('glitch'); SFX('hit', { vol: 0.6 });
    filesHud();
    if (S.files.every((v) => v <= 0)) lose();
  }
  function spawnPattern(dt) {
    const f = FOES[S.foe], b = battle, pats = f.pat;
    const p = pats[(b.round - 1) % pats.length];
    const sp = 1 + b.angry * 0.25 + (f.boss ? 0.2 : 0);
    b.spawnT -= dt;
    if (p === 'rain' && b.spawnT <= 0) { b.spawnT = 0.16 / sp; const s = new THREE.Sprite(Math.random() < 0.5 ? G0 : G1); s.scale.set(0.34, 0.34, 1); s.position.set((Math.random() * 2 - 1) * AS, 0.3, -AS); addShot({ obj: s, v: new THREE.Vector3(0, 0, 2.6 * sp), r: 0.17 }); if ((b.shotN = (b.shotN || 0) + 1) % 2) SFX('blip', { vol: 0.35, pan: s.position.x / AS * 0.6 }); }
    if (p === 'bars' && b.spawnT <= 0) {
      b.spawnT = 1.15 / sp; const gap = (Math.random() * 2 - 1) * (AS - 0.8), gw = 1.1; SFX('laser', { vol: 0.8 });
      for (const [x0, x1] of [[-AS, gap - gw / 2], [gap + gw / 2, AS]]) { if (x1 - x0 < 0.05) continue; const m = new THREE.Mesh(barG, hurtM); m.scale.x = x1 - x0; m.position.set((x0 + x1) / 2, 0.25, -AS); addShot({ obj: m, v: new THREE.Vector3(0, 0, 2.2 * sp), bar: [x0, x1], r: 0.14 }); }
    }
    if (p === 'bubbles' && b.spawnT <= 0) { b.spawnT = 0.7 / sp; const m = new THREE.Mesh(sphereG, bubM); const a = Math.random() * 6.28; m.position.set(Math.cos(a) * AS, 0.3, Math.sin(a) * AS); m.scale.setScalar(0.18); addShot({ obj: m, v: null, chase: 1.1 * sp, grow: 0.12, r: 0.18, life: 5 }); SFX('pop', { vol: 0.5, pan: Math.cos(a) * 0.6 }); }
    if (p === 'mines') { b.mineT -= dt; if (b.mineT <= 0) { b.mineT = 0.45 / sp; const m = new THREE.Mesh(mineG, hurtM.clone()); m.material.emissiveIntensity = 0.3; m.position.copy(core.position).setY(0.15); SFX('place', { vol: 0.35 }); addShot({ obj: m, v: null, arm: 0.7, r: 0.14, life: 3.2 }); } if (b.spawnT <= 0) { b.spawnT = 0.3 / sp; const s = new THREE.Sprite(G1); s.scale.set(0.3, 0.3, 1); s.position.set((Math.random() * 2 - 1) * AS, 0.3, -AS); addShot({ obj: s, v: new THREE.Vector3(0, 0, 2.0 * sp), r: 0.15 }); } }
    if (p === 'mirror') {
      if (!b.mirror) { SFX('glitch', { vol: 0.6 }); const m = new THREE.Mesh(new THREE.OctahedronGeometry(0.2), hurtM); m.position.y = 0.25; b.mirror = addShot({ obj: m, v: null, mirror: true, r: 0.22 }); }
      if (b.spawnT <= 0) { b.spawnT = 0.35 / sp; const s = new THREE.Sprite(G0); s.scale.set(0.3, 0.3, 1); s.position.set((Math.random() * 2 - 1) * AS, 0.3, -AS); addShot({ obj: s, v: new THREE.Vector3(0, 0, 2.2 * sp), r: 0.15 }); }
    }
  }
  function clearShots() { shots.forEach((s) => AR.remove(s.obj)); shots.length = 0; if (battle) battle.mirror = null; }
  /* ---------- твій хід: усе руками ---------- */
  // сяйво на ворогові — провести пальцем крізь нього (очистити);
  // три «слова» між тобою й ворогом — тягнути на ворога (поговорити);
  // чотири дискети-файли знизу — тягнути на Біта (уміння), «мета» — на ворога.
  const TURN = new THREE.Group(); AR.add(TURN);
  const weak = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.06, 10, 32), glow(0xfff3a0, 2.6)); weak.visible = false; AR.add(weak);
  const weakCore = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 10), glow(0xffffff, 3)); weak.add(weakCore);
  let talks = [], disks = [], dragT = null, slash = null;
  function wordSprite(text, col) {
    const c = document.createElement('canvas'), g = c.getContext('2d'); const fs = 30; g.font = `700 ${fs}px Onest, system-ui`;
    const w = Math.min(520, Math.ceil(g.measureText(text).width) + 40), hh = 64; c.width = w; c.height = hh;
    g.fillStyle = 'rgba(10,22,30,.86)'; g.beginPath(); g.roundRect(0, 0, w, hh, 32); g.fill(); g.strokeStyle = col; g.lineWidth = 3; g.stroke();
    g.font = `700 ${fs}px Onest, system-ui`; g.fillStyle = '#eafcff'; g.textBaseline = 'middle'; g.fillText(text.length > 30 ? text.slice(0, 29) + '…' : text, 20, hh / 2 + 2);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthTest: false })); sp.scale.set(w / hh * 0.42, 0.42, 1); sp.renderOrder = 12; return sp;
  }
  function menu() {
    const f = FOES[S.foe], b = battle; clearShots(); b.phase = 'turn';
    TURN.clear(); talks = []; disks = [];
    const order = [0, 1, 2].sort(() => Math.random() - 0.5);
    order.forEach((k, n) => { const sp = wordSprite(f.say[k][lang], f.col); sp.position.set((n - 1) * 0.35, 0.7, -1.15 + n * 0.72); sp.userData = { pick: { kind: 'word', k }, home: sp.position.clone() }; TURN.add(sp); talks.push(sp); });
    FILES.forEach((fl, i) => {
      const g = new THREE.Group(); g.position.set(-1.65 + i * 1.1, 0.12, AS + 0.75); TURN.add(g);
      const ok = S.files[i] > 0 && !b.usedAb[i];
      const body = new THREE.Mesh(new RoundedBoxGeometry(0.62, 0.08, 0.62, 2, 0.04), std(ok ? 0x2c6fd6 : 0x3a3f48, 0.4, 0.3)); g.add(body);
      const shut = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.09, 0.18), std(0xc9d2dc, 0.3, 0.8)); shut.position.set(0, 0.005, -0.2); g.add(shut);
      const tg = label(fl.id, { scale: 0.2, bg: 'rgba(8,12,18,.7)' }); tg.position.set(0, 0.32, 0.1); g.add(tg);
      g.userData = { pick: { kind: 'disk', i, ok }, home: g.position.clone() }; disks.push(g);
    });
    weak.visible = true; b.wa = Math.random() * 6;
    // підписи трьох варіантів просто на арені
    [[T.l_talk, 0, 1.25, -1.75, '#9fe39a'], [T.l_file, 0, 0.62, AS + 1.4, '#7fe3ff']].forEach(([txt, x, y, z, col]) => { const l = label(txt, { scale: 0.3, bg: 'rgba(6,12,18,.82)', color: col }); l.position.set(x, y, z); l.renderOrder = 11; TURN.add(l); });
    if (!weak.userData.tag) { weak.userData.tag = label(T.l_clean, { scale: 0.3, bg: 'rgba(6,12,18,.82)', color: '#fff3a0' }); weak.userData.tag.position.set(0, -0.62, 0); weak.userData.tag.renderOrder = 11; weak.add(weak.userData.tag); }
    banner('star', T.ph_turn, T.ph_turn_s, '#ffd36b'); SFX('turn'); hint(T.h_turn); b.coachT = S.coached ? 0 : 4;
  }
  const pt = (e) => { const r = W.canvas.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
  const segDist = (p, a, b2) => { const dx = b2.x - a.x, dy = b2.y - a.y, l2 = dx * dx + dy * dy || 1; let t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2; t = Math.max(0, Math.min(1, t)); return Math.hypot(a.x + dx * t - p.x, a.y + dy * t - p.y); };
  const trail = []; const tcv = () => $('#xTrail');
  function turnDown(e) {
    if (!battle || battle.phase !== 'turn') return false;
    const hit = W.pick(e, [...talks, ...disks]);
    if (hit) { const u = hit.obj.userData.pick; if (u.kind === 'disk' && !u.ok) { api.sfx('bad'); return true; } dragT = hit.obj; api.sfx('pop'); return true; }
    slash = { last: pt(e), done: false, t: performance.now() }; trail.length = 0; trail.push({ ...slash.last, t: performance.now() }); return true;
  }
  function turnMove(e) {
    if (!battle || battle.phase !== 'turn') return;
    if (dragT) { const g = W.ground(e, 0.5); if (g) { dragT.position.set(g.x - AR.position.x, dragT.userData.pick.kind === 'word' ? 0.7 : 0.4, g.z - AR.position.z); } return; }
    if (!slash) return;
    const p = pt(e); trail.push({ ...p, t: performance.now() });
    if (!slash.done) {
      const ws = W.screen(weak.getWorldPosition(new THREE.Vector3())); const r = W.canvas.getBoundingClientRect();
      const d = segDist({ x: ws.x, y: ws.y }, slash.last, p), len = Math.hypot(p.x - slash.last.x, p.y - slash.last.y);
      const R = Math.max(26, Math.min(r.width, r.height) * 0.07);
      if (d < R && len > 6) { slash.done = true; strike(d / R); }
    }
    slash.last = p;
  }
  function turnUp(e) {
    if (dragT) {
      const o = dragT; dragT = null; const u = o.userData.pick;
      const toFoe = Math.hypot(o.position.x - foeBig.position.x, o.position.z - foeBig.position.z) < 1.6;
      const toBit = Math.hypot(o.position.x - core.position.x, o.position.z - core.position.z) < 1.0;
      if (u.kind === 'word' && toFoe) { say(u.k); return; }
      if (u.kind === 'disk' && (u.i === 3 ? toFoe : toBit)) { ability(u.i); return; }
      W.tween(o.position, { x: o.userData.home.x, y: o.userData.home.y, z: o.userData.home.z }, 0.35, ease.back); api.sfx('tap');
      return;
    }
    slash = null;
  }
  function strike(q) {
    const b = battle; if (!b || b.phase !== 'turn') return;
    let dmg = q < 0.3 ? 14 : q < 0.6 ? 10 : 6;
    if (b.scan) { dmg *= 2; b.scan = false; }
    b.hp -= dmg; api.sfx(dmg > 6 ? 'zap' : 'hit'); S.coached = true;
    fx.burst(weak.getWorldPosition(new THREE.Vector3()), 0xfff3a0, 30 + dmg * 3, 3);
    msg(`−${dmg}`, 800); foeHud(); afterTurn();
  }
  function say(k) {
    const gain = [4, 2, 0][k];
    battle.trust += gain; if (k === 2) battle.angry++;
    msg(gain ? `${T.trust} +${gain}` : '…', 900); api.sfx(gain ? 'ok' : 'bad'); S.coached = true;
    fx.burst(foeBig.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, 1, 0)), gain ? 0x9fe39a : 0xff7a8a, 24, 1.8);
    foeHud(); afterTurn();
  }
  function ability(i) {
    const b = battle; if (b.usedAb[i] || S.files[i] <= 0) return; b.usedAb[i] = true;
    if (i === 0) b.shield = 2;
    if (i === 1) { let w = 0; S.files.forEach((v, j) => { if (v > 0 && v < S.files[w] || S.files[w] <= 0) w = j; }); S.files[w] = Math.min(10, S.files[w] + 6); filesHud(); }
    if (i === 2) b.scan = true;
    if (i === 3) { b.trust += 3; foeHud(); }
    msg(FILES[i].ab[lang], 1300); api.sfx('grow'); S.coached = true;
    fx.burst(core.getWorldPosition(new THREE.Vector3()), 0x7fe3ff, 30, 2);
    if (battle.trust >= FOES[S.foe].tr) return afterTurn();
    menu();
  }
  function afterTurn() {
    const f = FOES[S.foe];
    weak.visible = false; TURN.clear(); talks = []; disks = []; hint('');
    if (battle.hp <= 0) return endBattle('erased');
    if (battle.trust >= f.tr) return endBattle('calmed');
    battle.phase = 'wait'; setTimeout(dodgeRound, 900);
  }
  function over(html, then) { const e = $('#xOver'); e.innerHTML = `<div class="gg" style="max-width:420px;padding:18px 20px;display:flex;flex-direction:column;gap:10px;font-size:15px;line-height:1.45;animation:viewIn .5s var(--spring)">${html}<span class="gsub" style="text-align:center;margin-top:4px">${esc(T.tapOn)}</span></div>`; e.style.display = 'flex'; e.onclick = () => { e.style.display = 'none'; e.onclick = null; then && then(); }; }
  function endBattle(how) {
    const f = FOES[S.foe]; clearShots();
    S.done[S.foe] = how; battle.phase = 'end'; routeHud(); $('#xChip').style.display = 'none';
    api.coins(how === 'calmed' ? 4 : 2); api.pet('happy'); api.sfx('coin'); SFX('data', { delay: 0.25 });
    fx.burst(foeBig.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, 1, 0)), how === 'calmed' ? 0x9fe39a : 0xffffff, 80, 3);
    over(`<b style="font:700 19px var(--fd);display:flex;gap:8px;align-items:center">${gi(how === 'calmed' ? 'joy' : 'energy', 24)} ${how === 'calmed' ? T.calmed : T.erased}: ${esc(f.name[lang])}</b><span class="gsub" style="text-transform:uppercase;letter-spacing:.08em;font-size:11px">${T.fact}</span><span>${esc(f.fact[lang])}</span>`, f.boss ? won : leave);
  }
  function leave() {
    battle = null; foeHud(); S.mode = 'explore'; hint(T.h_move);
    const o = foes[S.foe];
    if (S.done[S.foe] === 'calmed') { o.l.color.set(0x9fe39a); o.g.position.x = 3.0; if (o.m) o.m.traverse((m) => { if (m.isMesh) { m.material = m.material.clone(); m.material.emissive = new THREE.Color(0x2f8f3a); } }); }
    else { scene.remove(o.g); }
  }
  function won() { battle = null; S.mode = 'won'; hint(''); api.sfx('win'); over(`<b style="font:800 24px var(--fd);display:flex;gap:10px;align-items:center">${gi('trophy', 32)} ${T.win}</b><span>${esc(T.winD)}</span>`, () => api.exit()); }
  function lose() {
    clearShots(); battle = null; foeHud(); S.mode = 'explore';
    S.files = S.files.map(() => 6); filesHud();
    const c = chests[Math.max(0, S.chest)]; bit.position.set(c ? c.g.position.x * 0.4 : 0, 0, c ? c.g.position.z + 1.2 : 1.5);
    msg(T.reboot, 1800); api.sfx('bad');
  }
  function hint(t) { const e = $('#xHint'); if (!t) { e.style.display = 'none'; return; } e.textContent = t; e.style.display = ''; }
  $('#xSplash').addEventListener('click', () => { const e = $('#xSplash'); e.style.transition = 'opacity .5s'; e.style.opacity = '0'; setTimeout(() => e.remove(), 520); S.mode = 'explore'; hint(T.h_move); api.sfx('ok'); });
  // дотики: у бою — твій хід; у мандрівці — Біт летить туди, куди веде палець
  let goal = null;
  W.canvas.addEventListener('pointerdown', (e) => { if (S.mode === 'battle' && turnDown(e)) return; if (S.mode === 'explore') { goal = W.ground(e); hint(''); } });
  W.canvas.addEventListener('pointermove', (e) => { if (S.mode === 'battle') turnMove(e); else if (S.mode === 'explore' && stick) goal = W.ground(e); });
  W.canvas.addEventListener('pointerup', (e) => { if (S.mode === 'battle') turnUp(e); });

  /* ---------- кадр ---------- */
  const v3 = new THREE.Vector3();
  W.onFrame((dt, tm) => {
    if (bitAnim) bitAnim.update(dt);
    SND.amb.set('pad', S.mode === 'intro' ? 0.5 : 0.85, { tense: S.mode === 'battle' && !!battle && battle.phase === 'dodge' }); SND.amb.tick(dt);
    if (petO) {
      if (petAnim) petAnim.update(dt); if (petProc) petProc.update(dt);
      const inArena = S.mode === 'battle';
      const want = inArena ? new THREE.Vector3(AR.position.x - AS - 0.7, 0, AR.position.z + AS - 0.5) : bit.position.clone().add(new THREE.Vector3(-0.9, 0, 1.0));
      const dv = want.clone().sub(petO.position); dv.y = 0; const dist = dv.length();
      if (dist > 6) petO.position.copy(want);
      else if (dist > 0.15) { petO.position.addScaledVector(dv.normalize(), Math.min(dist, dt * (dist > 1.5 ? 4.2 : 2.6))); const a = Math.atan2(dv.x, dv.z); let df = a - petO.rotation.y; df = Math.atan2(Math.sin(df), Math.cos(df)); petO.rotation.y += df * Math.min(1, dt * 8); if (!petO.userData.walk) { petO.userData.walk = true; petPlay('walk'); } }
      else if (petO.userData.walk) { petO.userData.walk = false; petPlay('idle'); }
      if (inArena && battle && battle.phase === 'dodge') {
        petZapT -= dt;
        if (petZapT <= 0) { const sh = shots.find((x) => !x.bar && Math.hypot(x.obj.position.x - core.position.x, x.obj.position.z - core.position.z) < 1.1); if (sh) { petZapT = 3.5; AR.remove(sh.obj); shots.splice(shots.indexOf(sh), 1); const w = AR.position.clone().add(sh.obj.position); fx.burst(w, 0xff9fc0, 26, 2); SFX('zap', { vol: 0.5 }); SFX(PETV); msg(T.petZap, 700); petPlay('happy'); } }
      }
    }
    // фаза бою — завжди видно зверху; доріжка-підказка в мандрівці
    { const b = battle, chip = $('#xChip'); let html = '';
      if (b && b.phase === 'dodge') { const left = Math.max(0, b.dur - b.t); html = `<span style="color:#ff9aa6">${esc(T.ph_dodge)} ${Math.ceil(left)}${esc(T.left)}</span><b style="display:block;height:5px;margin-top:5px;border-radius:9px;background:rgba(255,255,255,.15);overflow:hidden"><i style="display:block;height:100%;width:${Math.round(left / b.dur * 100)}%;background:#ff7a8a"></i></b>`; }
      if (html !== chip._h) { chip._h = html; chip.innerHTML = html; chip.style.display = html ? '' : 'none'; } }
    { const show = S.mode === 'explore'; let tgt = null;
      if (show) { const ni = S.done.findIndex((d) => !d), fz = ni >= 0 ? FOES[ni].z + 0.9 : -99; const ch = chests.find((c) => !c.used && c.g.position.z < bit.position.z + 0.5 && c.g.position.z > fz); tgt = ch ? ch.g.position : ni >= 0 ? new THREE.Vector3(0, 0, fz) : null; }
      guide.forEach((d, i) => { d.visible = !!tgt; if (!tgt) return; const k = ((i + (tm * 1.5) % 1) / guide.length); d.position.x = bit.position.x + (tgt.x - bit.position.x) * k; d.position.z = bit.position.z + (tgt.z - bit.position.z) * k; d.scale.setScalar(0.6 + 0.6 * Math.sin(k * Math.PI)); }); }
    columns.forEach((c) => { c.userData.s += dt * 1.4; const hgt = 0.6 + 1.4 * (0.5 + 0.5 * Math.sin(c.userData.s)); c.scale.y = hgt; c.position.y = hgt / 2; });
    floor.material.emissiveIntensity = 0.3 + 0.08 * Math.sin(tm * 1.5);
    foes.forEach((o, i) => { if (o.anim) o.anim.update(dt); o.g.position.y = Math.sin(tm * 2 + i) * 0.08 + 0.1; o.l.intensity = 2 + Math.sin(tm * 6 + i) * 0.6; });
    if (battle && battle.anim) battle.anim.update(dt);
    if (S.mode === 'explore' || S.mode === 'intro' || S.mode === 'won') {
      const a = S.mode === 'explore' ? axis() : { x: 0, z: 0 };
      const sp = 3.4;
      if (a.x || a.z) {
        const nx = bit.position.x + a.x * sp * dt, nz = bit.position.z + a.z * sp * dt;
        let px = nx, pz = nz; const r = 0.38;
        for (const w of walls) { const dx = px - w.x, dz = pz - w.z, hx = w.w / 2 + r, hz = w.d / 2 + r; if (Math.abs(dx) < hx && Math.abs(dz) < hz) { const ox = hx - Math.abs(dx), oz = hz - Math.abs(dz); if (ox < oz) px = w.x + Math.sign(dx) * hx; else pz = w.z + Math.sign(dz) * hz; } }
        bit.position.x = px; bit.position.z = pz;
        const want = Math.atan2(a.x, a.z); let df = want - bit.rotation.y; df = Math.atan2(Math.sin(df), Math.cos(df)); bit.rotation.y += df * Math.min(1, dt * 10);
        if (bitAnim) bitAnim.play(clip(bitClips, /^walk$/i, /walk/i), { speed: 1.4 });
        if ((stepT -= dt) <= 0) { stepT = 0.28; SFX('step', { vol: 0.5 }); }
      } else if (bitAnim) bitAnim.play(clip(bitClips, /^idle$/i, /idle/i));
      bit.position.y = 0.15 + Math.sin(tm * 3) * 0.05;
      // зустрічі
      if (S.mode === 'explore') {
        // наступний ворог — це «ворота»: дійшов до його лінії — бій
        const ni = S.done.findIndex((d) => !d);
        if (ni >= 0) { const f = FOES[ni]; if (bit.position.z < f.z + 0.9) { bit.position.z = f.z + 0.9; startBattle(ni); } }
        chests.forEach((c, i) => { if (!c.used && Math.hypot(c.g.position.x - bit.position.x, c.g.position.z - bit.position.z) < 1.0) { c.used = true; S.chest = i; S.files = S.files.map(() => 10); filesHud(); SFX('data'); c.l.intensity = 0.2; fx.burst(c.g.position.clone().add(new THREE.Vector3(0, 0.6, 0)), 0xffd36b, 40, 2); msg(T.chest, 1600); api.sfx('coin'); } });
      }
      camT.set(bit.position.x * 0.6, portrait ? 8.5 : 6.2, bit.position.z + (portrait ? 5.2 : 6.2));
      camL.set(bit.position.x * 0.6, 0.4, bit.position.z - 1.2);
      key.position.set(bit.position.x - 4, 10, bit.position.z + 4); key.target.position.set(bit.position.x, 0, bit.position.z);
    } else if (S.mode === 'battle') {
      camT.set(AR.position.x, portrait ? 11.8 : 7.6, AR.position.z + (portrait ? 3.0 : 3.6));
      camL.set(AR.position.x, 0, AR.position.z - 0.4);
      key.position.set(AR.position.x - 3, 10, 4); key.target.position.copy(AR.position);
      const b = battle;
      if (b && b.phase === 'dodge') {
        b.t += dt; b.inv = Math.max(0, b.inv - dt);
        // рух ядра: відносно пальця або клавішами
        if (stick) { const k = portrait ? 0.022 : 0.016; core.position.x = stick.cx + (stick.x - stick.sx) * k; core.position.z = stick.cz + (stick.y - stick.sy) * k; }
        else { const a = axis(); core.position.x += a.x * 4.2 * dt; core.position.z += a.z * 4.2 * dt; }
        core.position.x = THREE.MathUtils.clamp(core.position.x, -AS + 0.15, AS - 0.15); core.position.z = THREE.MathUtils.clamp(core.position.z, -AS + 0.15, AS - 0.15);
        if (stick) { stick.cx = core.position.x - (stick.x - stick.sx) * (portrait ? 0.022 : 0.016); stick.cz = core.position.z - (stick.y - stick.sy) * (portrait ? 0.022 : 0.016); }
        core.visible = b.inv <= 0 || Math.sin(tm * 40) > 0;
        spawnPattern(dt);
        for (let i = shots.length - 1; i >= 0; i--) {
          const s = shots[i], o = s.obj;
          if (s.v) o.position.addScaledVector(s.v, dt);
          if (s.chase) { v3.copy(core.position).sub(o.position).setY(0).normalize(); o.position.addScaledVector(v3, s.chase * dt); o.scale.setScalar(Math.min(0.55, o.scale.x + s.grow * dt)); s.r = o.scale.x; }
          if (s.mirror) { o.position.x = -core.position.x; o.position.z = -core.position.z; o.rotation.y += dt * 4; }
          if (s.arm !== undefined) { s.arm -= dt; o.material.emissiveIntensity = s.arm > 0 ? 0.3 : 2.4; o.rotation.y += dt * 3; }
          if (s.life !== undefined) { s.life -= dt; if (s.life <= 0) { AR.remove(o); shots.splice(i, 1); continue; } }
          if (o.position.z > AS + 0.3) { AR.remove(o); shots.splice(i, 1); continue; }
          let hit = false;
          if (s.bar) hit = Math.abs(o.position.z - core.position.z) < 0.18 && core.position.x > s.bar[0] && core.position.x < s.bar[1];
          else if (s.arm === undefined || s.arm <= 0) hit = Math.hypot(o.position.x - core.position.x, o.position.z - core.position.z) < s.r + 0.12;
          if (hit) hurt();
          if (!battle) return;
        }
        if (b.t >= b.dur) menu();
      }
      if (b && b.phase === 'turn') {
        b.wa += dt * (1.1 + b.angry * 0.3);
        weak.position.set(foeBig.position.x + Math.cos(b.wa) * 0.55, (FOES[S.foe].boss ? 1.5 : 1.0) + Math.sin(b.wa * 1.7) * 0.35, foeBig.position.z + 0.6);
        weak.lookAt(camera.position.clone().sub(AR.position)); weak.scale.setScalar(1 + Math.sin(tm * 8) * 0.12);
        talks.forEach((sp, n) => { if (sp !== dragT) sp.position.y = sp.userData.home.y + Math.sin(tm * 2 + n) * 0.06; });
        if (b.coachT > 0 && !S.coached) { b.coachT -= dt; const hd = $('#xHand'); const ph = Math.floor(tm / 2.2) % 3; const k2 = (tm % 2.2) / 1.6, q = Math.min(1, k2); let A, B; const ws = weak.getWorldPosition(new THREE.Vector3());
          if (ph === 0) { A = W.screen(ws.clone().add(new THREE.Vector3(-0.9, 0, 0))); B = W.screen(ws.clone().add(new THREE.Vector3(0.9, 0, 0))); }
          else if (ph === 1 && talks[0]) { A = W.screen(talks[0].getWorldPosition(new THREE.Vector3())); B = W.screen(foeBig.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, 0.8, 0))); }
          else if (disks[1]) { A = W.screen(disks[1].getWorldPosition(new THREE.Vector3())); B = W.screen(core.getWorldPosition(new THREE.Vector3())); }
          if (A && B) { hd.style.display = ''; hd.style.left = (A.x + (B.x - A.x) * ease.inOut(q)) + 'px'; hd.style.top = (A.y + (B.y - A.y) * ease.inOut(q)) + 'px'; hd.style.opacity = k2 > 1.2 ? 0 : 1; }
          if (b.coachT <= 0) b.coachT = 4.4; } else $('#xHand').style.display = 'none';
      } else $('#xHand').style.display = 'none';
      core.rotation.y += dt * 2;
    }
    camera.position.lerp(camT, Math.min(1, dt * (S.mode === 'battle' ? 3 : 4)));
    if (!W._cl) W._cl = camL.clone(); W._cl.lerp(camL, Math.min(1, dt * 5)); camera.lookAt(W._cl);
    frameM.emissiveIntensity = 0.9 + Math.sin(tm * 3) * 0.25;
    { const c = tcv(); if (c) { const r = W.canvas.getBoundingClientRect(); if (c.width !== Math.round(r.width)) { c.width = Math.round(r.width); c.height = Math.round(r.height); } const g = c.getContext('2d'); g.clearRect(0, 0, c.width, c.height); const now = performance.now(); while (trail.length && now - trail[0].t > 260) trail.shift(); if (trail.length > 1) { g.lineCap = 'round'; for (let k = 1; k < trail.length; k++) { const a = 1 - (now - trail[k].t) / 260; g.strokeStyle = `rgba(255,243,160,${a})`; g.lineWidth = 3 + a * 9; g.beginPath(); g.moveTo(trail[k - 1].x, trail[k - 1].y); g.lineTo(trail[k].x, trail[k].y); g.stroke(); } } } }
  });

  filesHud(); routeHud();

  root._dbg = { startBattle, S, menu, phase: () => battle && battle.phase, hp: () => battle && battle.hp, trust: () => battle && battle.trust, where: (w, i) => { const o = w === 'weak' ? weak : w === 'word' ? talks[i] : w === 'disk' ? disks[i] : w === 'foe' ? foeBig : core; const v = o.getWorldPosition(new THREE.Vector3()); if (w === 'foe') v.y += 0.8; const q = W.screen(v), r = W.canvas.getBoundingClientRect(); return { x: q.x + r.left, y: q.y + r.top }; } };
  return { destroy: () => { SND.stop(); W.destroy(); } };
}
