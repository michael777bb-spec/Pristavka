// Дані ферми: культури, техніка, будівлі, переробка, етапи. Усе числами тут —
// гра лише читає ці таблиці, тож баланс правиться в одному місці.

// культури: garden — грядки руками (урожай у ящиках), field — поля технікою (урожай у тоннах)
// days — скільки ігрових днів росте; water — скільки п'є (0..1 за день); price — за ящик або за тонну
export const CROPS = {
  green: { kind: 'garden', c: '#7ccf4f', days: 0.35, price: 6, seed: 4, model: 'bean', n: { uk: 'Зелена квасоля', en: 'Green bean', ru: 'Зелёная фасоль' } },
  red: { kind: 'garden', c: '#d9483b', days: 0.55, price: 10, seed: 7, model: 'bean', n: { uk: 'Червона квасоля', en: 'Red bean', ru: 'Красная фасоль' } },
  white: { kind: 'garden', c: '#f2ead6', days: 0.8, price: 15, seed: 11, model: 'bean', n: { uk: 'Біла квасоля', en: 'White bean', ru: 'Белая фасоль' } },
  black: { kind: 'garden', c: '#3b2f45', days: 1.2, price: 32, seed: 24, model: 'bean', n: { uk: 'Чорна квасоля', en: 'Black bean', ru: 'Чёрная фасоль' } },
  carrot: { kind: 'garden', c: '#f08a24', days: 0.6, price: 9, seed: 5, model: 'carrot', n: { uk: 'Морква', en: 'Carrot', ru: 'Морковь' } },
  potato: { kind: 'garden', c: '#c9a46a', days: 0.9, price: 12, seed: 7, model: 'potato', n: { uk: 'Картопля', en: 'Potato', ru: 'Картофель' } },
  pumpkin: { kind: 'garden', c: '#f07a1a', days: 1.4, price: 30, seed: 16, model: 'pumpkin', n: { uk: 'Гарбуз', en: 'Pumpkin', ru: 'Тыква' } },
  melon: { kind: 'garden', c: '#3f8f3a', days: 1.6, price: 38, seed: 20, model: 'melon', n: { uk: 'Кавун', en: 'Watermelon', ru: 'Арбуз' } },
  wheat: { kind: 'field', c: '#e2bd5a', days: 1.6, price: 60, seed: 14, yield: 3.6, stage: 2, model: 'wheat', n: { uk: 'Пшениця', en: 'Wheat', ru: 'Пшеница' } },
  sunflower: { kind: 'field', c: '#f2c21b', days: 2, price: 95, seed: 22, yield: 2.2, stage: 2, model: 'sunflower', n: { uk: 'Соняшник', en: 'Sunflower', ru: 'Подсолнечник' } },
  corn: { kind: 'field', c: '#e8c13a', days: 2.3, price: 48, seed: 18, yield: 5.2, stage: 4, model: 'corn', n: { uk: 'Кукурудза', en: 'Corn', ru: 'Кукуруза' } },
  buckwheat: { kind: 'field', c: '#b9866a', days: 1.4, price: 120, seed: 26, yield: 1.5, stage: 4, model: 'buckwheat', n: { uk: 'Гречка', en: 'Buckwheat', ru: 'Гречиха' } }
};
export const GARDEN = Object.keys(CROPS).filter((k) => CROPS[k].kind === 'garden');
export const FIELD = Object.keys(CROPS).filter((k) => CROPS[k].kind === 'field');
// мутації з лабораторії — ідея сина: сонячні ростуть швидше, зіркові дорожчі
export const MUT = { sun: { grow: 1.5, price: 1.6, c: '#ffd34d', cost: 15, ch: 0.7 }, star: { grow: 1, price: 3, c: '#b98cff', cost: 40, ch: 0.35 } };

// продукти переробки (ціна за одиницю: л або т)
export const GOODS = {
  oil: { unit: 'l', price: 0.36, c: '#f2c21b', n: { uk: 'Соняшникова олія', en: 'Sunflower oil', ru: 'Подсолнечное масло' } },
  groats: { unit: 't', price: 230, c: '#a9724f', n: { uk: 'Гречана крупа', en: 'Buckwheat groats', ru: 'Гречневая крупа' } },
  feed: { unit: 't', price: 96, c: '#9a8a52', n: { uk: 'Комбікорм', en: 'Compound feed', ru: 'Комбикорм' } },
  ethanol: { unit: 'l', price: 0.3, c: '#7fd6ff', n: { uk: 'Біоетанол', en: 'Bioethanol', ru: 'Биоэтанол' } },
  fert: { unit: 'bag', price: 12, c: '#ffffff', n: { uk: 'Добрива', en: 'Fertilizer', ru: 'Удобрения' } }
};
// переробка: що бере, що дає, скільки триває (ігрових годин) і скільки потребує енергії (кВт)
export const PLANTS = {
  oil: { in: { sunflower: 1 }, out: { oil: 420 }, hours: 3, kw: 30 },
  groats: { in: { buckwheat: 1 }, out: { groats: 0.72 }, hours: 3, kw: 25 },
  feed: { in: { corn: 0.5, wheat: 0.5 }, out: { feed: 1 }, hours: 2, kw: 20 },
  bio: { in: { corn: 1 }, out: { ethanol: 380 }, hours: 4, kw: 35 }
};
// техніка: ціна; паливо (л) і витрата за смугу поля
export const MACH = {
  tractor: { cost: 260, tank: 60, burn: 1.2, speed: 2.0 },
  combine: { cost: 900, tank: 120, burn: 2.2, speed: 1.6, hopper: 6 },
  truck: { cost: 420, tank: 80, cap: [6, 10, 16], up: [0, 380, 620] },
  cultivator: { cost: 120 }, seeder: { cost: 160 }, sprayer: { cost: 190 }, irrigator: { cost: 240 }
};
export const ATTS = ['cultivator', 'seeder', 'sprayer', 'irrigator'];
// будівлі: ціна (за рівень), на якому етапі з'являються
export const BLD = {
  house: { cost: [0, 300, 700], stage: 0 },
  stall: { cost: [0], stage: 0 },
  lab: { cost: [0], stage: 0 },
  hangar: { cost: [180], stage: 1 },
  fuel: { cost: [90], stage: 1 },
  wash: { cost: [70], stage: 3 },
  barn: { cost: [240, 520], stage: 2, cap: [30, 80] },
  weigh: { cost: [160], stage: 2 },
  elevator: { cost: [350, 650], stage: 2 },
  fertshed: { cost: [200], stage: 3 },
  oilmill: { cost: [520], stage: 4, plant: 'oil' },
  groatsmill: { cost: [480], stage: 4, plant: 'groats' },
  feedmill: { cost: [440], stage: 4, plant: 'feed' },
  bioplant: { cost: [760], stage: 5, plant: 'bio' },
  wind: { cost: [300], stage: 5, kw: 40 },
  solar: { cost: [220], stage: 5, kw: 30 },
  pivot: { cost: [260], stage: 5 },
  pond: { cost: [150], stage: 6 },
  gazebo: { cost: [120], stage: 6 },
  hammock: { cost: [0], stage: 0 }
};
export const FIELDS = 4;
export const FIELD_COST = [0, 260, 420, 640];
export const LANES = 4;
export const DAYLEN = 150; // секунд на ігровий день (06:00 → 06:00)

// етапи: цілі (лічильники з state.cnt) і нагорода; кожен етап відкриває нове
export const STAGES = [
  { id: 'garden', goals: [['harvestG', 6], ['earnFair', 120]], reward: 60 },
  { id: 'tractor', goals: [['buy_tractor', 1], ['buy_cultivator', 1], ['plow', 1]], reward: 90 },
  { id: 'grain', goals: [['sow', 1], ['harvestF', 1], ['sellGrain', 1]], reward: 150 },
  { id: 'service', goals: [['refuel', 1], ['wash', 1], ['oil', 1], ['repair', 1]], reward: 160 },
  { id: 'process', goals: [['build_barn', 1], ['build_mill', 1], ['produce', 1], ['order', 1]], reward: 260 },
  { id: 'energy', goals: [['build_wind', 1], ['build_solar', 1], ['build_bioplant', 1], ['ownFuel', 1]], reward: 360 },
  { id: 'rest', goals: [['house2', 1], ['build_rest', 1], ['fish', 1]], reward: 300 },
  { id: 'big', goals: [['fields4', 1], ['buy_combine', 1], ['truck3', 1], ['elevator2', 1]], reward: 800 }
];
