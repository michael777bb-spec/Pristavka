// Процедурні моделі ферми: будівлі, техніка, причепи, рослини. Усе — з простих форм,
// без файлів, щоб працювало офлайн і швидко на телефоні. Перед кожної моделі — +Z.
import { THREE, RoundedBoxGeometry, std, glass, canvasTex, speckle, hipRoof, gableRoof } from '../../kit.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

const MC = new Map();
export const M = (c, r = 0.7, m = 0, extra) => { if (extra) return std(c, r, m, extra); const k = `${c}|${r}|${m}`; if (!MC.has(k)) MC.set(k, std(c, r, m)); return MC.get(k); };
export const WIN = []; // матеріали вікон — світяться вночі
const winMat = () => { const m = new THREE.MeshStandardMaterial({ color: 0x9fb8cc, roughness: 0.15, metalness: 0.2, emissive: new THREE.Color(0xffc56b), emissiveIntensity: 0 }); WIN.push(m); return m; };
const shade = (o) => { o.traverse((m) => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } }); return o; };
const box = (w, h, d, mat, x = 0, y = 0, z = 0, r = 0) => { const m = new THREE.Mesh(r ? new RoundedBoxGeometry(w, h, d, 2, r) : new THREE.BoxGeometry(w, h, d), mat); m.position.set(x, y, z); return m; };
const cyl = (rt, rb, h, mat, seg = 16, x = 0, y = 0, z = 0) => { const m = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), mat); m.position.set(x, y, z); return m; };
export const hitBox = (g, w, h, d, y = h / 2, z = 0) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshBasicMaterial({ visible: false })); m.position.set(0, y, z); g.add(m); return m; };
const planks = (base) => speckle(base, ['rgba(0,0,0,.18)', 'rgba(255,255,255,.08)'], 128, 600, 7);
const wood = () => M(0x8a5a34, 0.85);
function window2(g, x, y, z, w = 0.5, h = 0.55, ry = 0) {
  const f = new THREE.Group(); f.position.set(x, y, z); f.rotation.y = ry; g.add(f);
  f.add(box(w + 0.1, h + 0.1, 0.06, M(0xf4efe4, 0.6)));
  const pane = box(w, h, 0.07, winMat()); pane.position.z = 0.01; f.add(pane);
  f.add(box(0.04, h, 0.08, M(0xf4efe4, 0.6), 0, 0, 0.02)); f.add(box(w, 0.04, 0.08, M(0xf4efe4, 0.6), 0, 0, 0.02));
  return f;
}
function door(g, x, z, w = 0.6, h = 1.0, col = 0x6a3f22) { const d = box(w, h, 0.08, M(col, 0.7), x, h / 2, z); g.add(d); g.add(box(0.06, 0.06, 0.06, M(0xd8b04a, 0.3, 0.8), x + w * 0.32, h * 0.5, z + 0.06)); return d; }

/* ---------------- будівлі ---------------- */
export function house(lvl = 1) {
  const g = new THREE.Group();
  const W = [2.6, 3.4, 3.8][lvl - 1], D = [2.2, 2.6, 2.8][lvl - 1], H = [1.5, 1.7, 2.9][lvl - 1];
  const wallM = lvl === 1 ? M(0xb98a5a, 0.85, 0, { map: planks('#b98a5a') }) : M(lvl === 2 ? 0xf1e4cf : 0xf6efe2, 0.85);
  g.add(box(W + 0.2, 0.25, D + 0.2, M(0x8a8f96, 0.9), 0, 0.12, 0));
  g.add(box(W, H, D, wallM, 0, 0.25 + H / 2, 0));
  if (lvl === 1) for (let i = 0; i < 6; i++) g.add(box(W + 0.04, 0.04, D + 0.04, M(0x7a4c2a, 0.9), 0, 0.4 + i * (H / 6), 0));
  const roof = gableRoof(D + 0.02, W, H * 0.62, { over: 0.22, mat: M(lvl === 3 ? 0x5a6a7a : 0x9a3b2c, 0.7), wall: wallM }); roof.rotation.y = Math.PI / 2; roof.position.y = 0.25 + H; g.add(roof);
  door(g, 0, D / 2 + 0.01, 0.62, 1.05);
  window2(g, -W * 0.3, 0.25 + H * 0.55, D / 2 + 0.03); window2(g, W * 0.3, 0.25 + H * 0.55, D / 2 + 0.03);
  window2(g, W / 2 + 0.03, 0.25 + H * 0.55, 0, 0.5, 0.5, Math.PI / 2);
  if (lvl === 3) { window2(g, -W * 0.3, 0.25 + H * 0.82, D / 2 + 0.03, 0.45, 0.45); window2(g, W * 0.3, 0.25 + H * 0.82, D / 2 + 0.03, 0.45, 0.45); g.add(box(1.4, 0.08, 0.6, M(0xf4efe4, 0.6), 0, 0.25 + H * 0.62, D / 2 + 0.3)); }
  const ch = box(0.32, 1.0, 0.32, M(0x8a5040, 0.9), W * 0.28, 0.25 + H + 0.5, -D * 0.15); g.add(ch); g.userData.chimney = ch;
  if (lvl >= 2) { // ґанок з дашком
    g.add(box(1.6, 0.12, 0.9, wood(), 0, 0.3, D / 2 + 0.45));
    [-0.7, 0.7].forEach((x) => g.add(cyl(0.05, 0.05, 1.1, M(0xf4efe4, 0.6), 8, x, 0.85, D / 2 + 0.82)));
    const pr = gableRoof(1.8, 1.0, 0.28, { over: 0.06, mat: M(lvl === 3 ? 0x5a6a7a : 0x9a3b2c, 0.7) }); pr.position.set(0, 1.4, D / 2 + 0.45); g.add(pr);
  }
  // квіти під вікнами
  for (const sx of [-1, 1]) { const bx = box(0.6, 0.12, 0.16, wood(), sx * W * 0.3, 0.25 + H * 0.55 - 0.38, D / 2 + 0.1); g.add(bx); for (let i = 0; i < 4; i++) g.add(cyl(0.05, 0.05, 0.06, M([0xe4472f, 0xffd23f, 0xff7fb0, 0x8655f0][i], 0.6), 8, sx * W * 0.3 - 0.22 + i * 0.15, 0.25 + H * 0.55 - 0.28, D / 2 + 0.1)); }
  hitBox(g, W + 0.4, H + 1.5, D + 0.6);
  return shade(g);
}
export function stall() {
  const g = new THREE.Group();
  const awnTex = canvasTex(128, (c, s) => { for (let i = 0; i < 8; i++) { c.fillStyle = i % 2 ? '#efe2cf' : '#d9503f'; c.fillRect(i * s / 8, 0, s / 8, s); } });
  g.add(box(2.6, 0.8, 1.0, M(0x9a6a40, 0.8), 0, 0.4, 0, 0.05));
  const awn = box(2.9, 0.08, 1.5, std(0xffffff, 0.7, 0, { map: awnTex }), 0, 1.95, 0.15); awn.rotation.x = 0.14; g.add(awn);
  for (let i = 0; i < 10; i++) { const f = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.18, 3), M(i % 2 ? 0xefe2cf : 0xd9503f, 0.7)); f.rotation.x = Math.PI; f.position.set(-1.3 + i * 0.29, 1.78, 0.9); g.add(f); }
  [-1.25, 1.25].forEach((x) => g.add(cyl(0.05, 0.05, 1.95, M(0x7a5030, 0.8), 8, x, 0.97, 0.55)));
  hitBox(g, 2.8, 2.2, 1.8);
  return shade(g);
}
export function hangar() {
  const g = new THREE.Group(), W = 5.2, D = 4.2, R = 2.0;
  g.add(box(W + 0.6, 0.06, D + 1.4, M(0x9aa0a6, 0.95), 0, 0.03, 0.4));
  // напівциліндр уздовж Z: дуга над підлогою (θ від π/2 до 3π/2 після повороту дає y ≥ 0)
  const arch = new THREE.Mesh(new THREE.CylinderGeometry(R, R, D, 32, 1, true, Math.PI / 2, Math.PI), M(0x8fa0ad, 0.45, 0.6, { side: THREE.DoubleSide, map: speckle('#8fa0ad', ['rgba(0,0,0,.12)'], 64, 120, 3) }));
  arch.rotation.x = Math.PI / 2; arch.scale.set(W / (2 * R), 1, 1); arch.position.set(0, 0.06, 0); g.add(arch);
  const roof = [arch]; // дах стає прозорим, коли всередині техніка (щоб її було видно)
  // ребра арки
  for (let i = 0; i <= 4; i++) { const rib = new THREE.Mesh(new THREE.TorusGeometry(R, 0.05, 6, 24, Math.PI), M(0x5f6b75, 0.5, 0.6)); rib.scale.set(W / (2 * R), 1, 1); rib.position.set(0, 0.06, -D / 2 + i * D / 4); g.add(rib); roof.push(rib); }
  const back = new THREE.Mesh(new THREE.CircleGeometry(R, 32, 0, Math.PI), M(0x7d8b96, 0.6, 0.4, { side: THREE.DoubleSide })); back.scale.set(W / (2 * R), 1, 1); back.position.set(0, 0.06, -D / 2); g.add(back);
  // верстак і стіна з інструментами
  g.add(box(1.4, 0.7, 0.5, M(0x6a4a2a, 0.8), -W / 2 + 1.0, 0.41, -D / 2 + 0.4)); g.add(box(1.2, 0.6, 0.04, M(0x2e3a44, 0.6), -W / 2 + 1.0, 1.2, -D / 2 + 0.05));
  for (let i = 0; i < 5; i++) g.add(box(0.06, 0.32, 0.04, M([0xe4472f, 0xffd23f, 0x4867ee, 0x9aa0a6, 0x2fa65a][i], 0.4, 0.4), -W / 2 + 0.55 + i * 0.22, 1.2, -D / 2 + 0.09));
  const lamp = box(0.5, 0.06, 0.2, M(0xffffff, 0.3, 0, { emissive: new THREE.Color(0xfff2d0), emissiveIntensity: 1.2 }), 0, R - 0.1, 0); g.add(lamp);
  g.userData.lamp = lamp; g.userData.roof = roof;
  return shade(g);
}
export function fuelStation() {
  const g = new THREE.Group();
  g.add(box(2.4, 0.06, 1.8, M(0x8f949a, 0.95), 0, 0.03, 0));
  const tank = cyl(0.42, 0.42, 1.8, M(0xe4472f, 0.35, 0.4), 24); tank.rotation.z = Math.PI / 2; tank.position.set(-0.2, 0.75, -0.4); g.add(tank);
  for (const x of [-0.8, 0.4]) g.add(box(0.12, 0.4, 0.7, M(0x4a4f56, 0.6, 0.5), x, 0.2, -0.4));
  g.add(box(0.5, 1.1, 0.35, M(0xf4efe4, 0.4, 0.2), 0.75, 0.55, 0.35, 0.05));
  const scr = box(0.3, 0.18, 0.02, M(0x1a2a1a, 0.3, 0, { emissive: new THREE.Color(0x6bff8a), emissiveIntensity: 0.6 }), 0.75, 0.85, 0.53); g.add(scr);
  const hose = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.025, 6, 16, Math.PI * 1.2), M(0x1d1f26, 0.6)); hose.position.set(1.02, 0.55, 0.35); hose.rotation.y = Math.PI / 2; g.add(hose);
  hitBox(g, 2.6, 1.8, 2.0);
  return shade(g);
}
export function washPad() {
  const g = new THREE.Group();
  g.add(box(2.6, 0.08, 2.4, M(0x8fa3b0, 0.4, 0.1), 0, 0.04, 0));
  g.add(box(2.4, 0.02, 0.12, M(0x2e3a44, 0.5), 0, 0.085, 0));
  const pipe = M(0x2f7fd8, 0.35, 0.5);
  for (const x of [-1.2, 1.2]) g.add(cyl(0.06, 0.06, 2.1, pipe, 10, x, 1.05, 0));
  const top = cyl(0.06, 0.06, 2.46, pipe, 10, 0, 2.1, 0); top.rotation.z = Math.PI / 2; g.add(top);
  for (let i = 0; i < 5; i++) g.add(cyl(0.035, 0.05, 0.12, M(0xdfe6ee, 0.3, 0.6), 8, -0.9 + i * 0.45, 2.0, 0));
  const brush = cyl(0.22, 0.22, 1.6, M(0x4aa3ff, 0.9), 14, 0.95, 0.95, 0.7); g.add(brush); g.userData.brush = brush;
  hitBox(g, 2.6, 2.3, 2.4);
  return shade(g);
}
export function barn(lvl = 1) {
  const g = new THREE.Group(), W = lvl === 1 ? 3.6 : 4.8, D = lvl === 1 ? 2.8 : 3.4, H = lvl === 1 ? 1.9 : 2.3;
  const red = M(0xb5402f, 0.75, 0, { map: planks('#b5402f') }), white = M(0xf2eadb, 0.7);
  g.add(box(W + 0.2, 0.18, D + 0.2, M(0x8a8f96, 0.9), 0, 0.09, 0));
  g.add(box(W, H, D, red, 0, 0.18 + H / 2, 0));
  const roof = gableRoof(D, W, H * 0.6, { over: 0.2, mat: M(0x4a4f56, 0.6, 0.3), wall: red }); roof.rotation.y = Math.PI / 2; roof.position.y = 0.18 + H; g.add(roof);
  // великі ворота з білою «буквою Z» і сінне віконце
  const dw = W * 0.42, dh = H * 0.78;
  for (const sx of [-1, 1]) { const d = box(dw / 2, dh, 0.06, red, sx * dw / 4, 0.18 + dh / 2, D / 2 + 0.03); g.add(d); g.add(box(dw / 2, 0.08, 0.08, white, sx * dw / 4, 0.18 + dh - 0.04, D / 2 + 0.05)); g.add(box(dw / 2, 0.08, 0.08, white, sx * dw / 4, 0.22, D / 2 + 0.05)); const x1 = box(dw * 0.58, 0.07, 0.07, white, sx * dw / 4, 0.18 + dh / 2, D / 2 + 0.06); x1.rotation.z = sx * Math.atan2(dh, dw / 2) * 0.95; g.add(x1); }
  g.add(box(0.7, 0.6, 0.06, white, 0, 0.18 + H + H * 0.22, D / 2 + 0.02)); g.add(box(0.56, 0.46, 0.07, M(0x3a2a1c, 0.9), 0, 0.18 + H + H * 0.22, D / 2 + 0.03));
  // купки урожаю перед амбаром — показують, що лежить на складі
  const piles = new THREE.Group(); piles.position.set(0, 0, D / 2 + 1.0); g.add(piles); g.userData.piles = piles;
  hitBox(g, W + 0.4, H * 1.7, D + 0.6);
  return shade(g);
}
export function weighbridge() {
  const g = new THREE.Group();
  const deck = box(3.6, 0.14, 1.6, M(0x7d8790, 0.5, 0.6, { map: speckle('#7d8790', ['rgba(0,0,0,.25)'], 64, 300, 5) }), 0, 0.07, 0); g.add(deck);
  for (const sx of [-1, 1]) { const r = box(0.7, 0.1, 1.6, M(0x6a7077, 0.7, 0.4), sx * 2.1, 0.03, 0); r.rotation.z = sx * 0.16; g.add(r); }
  for (let i = 0; i < 9; i++) g.add(box(0.06, 0.02, 1.5, M(0x4a5058, 0.5, 0.6), -1.6 + i * 0.4, 0.15, 0));
  const booth = new THREE.Group(); booth.position.set(0.4, 0, -1.6); g.add(booth);
  booth.add(box(1.4, 1.5, 1.0, M(0xf2eadb, 0.7), 0, 0.75, 0)); const br = hipRoof(1.4, 1.0, 0.35, { over: 0.1, mat: M(0x2f6fb5, 0.6) }); br.position.y = 1.5; booth.add(br);
  window2(booth, -0.3, 0.95, 0.51, 0.5, 0.45);
  // табло ваги
  const cv = document.createElement('canvas'); cv.width = 256; cv.height = 96; const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
  const scr = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.42), new THREE.MeshBasicMaterial({ map: tex })); scr.position.set(0.3, 1.25, 0.52); booth.add(scr);
  const post = cyl(0.05, 0.05, 1.6, M(0x4a4f56, 0.5, 0.5), 8, 1.9, 0.8, -0.95); g.add(post);
  const gate = box(2.0, 0.07, 0.07, M(0xe4472f, 0.5), 0.95, 1.2, -0.95); g.add(gate); g.userData.gate = gate;
  g.userData.show = (txt, col = '#ff4d3a') => { const c = cv.getContext('2d'); c.fillStyle = '#0d0f12'; c.fillRect(0, 0, 256, 96); c.fillStyle = col; c.font = '700 64px "JetBrains Mono", monospace'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(txt, 128, 52); tex.needsUpdate = true; };
  g.userData.show('0.0 t');
  hitBox(g, 3.6, 1.6, 2.4, 0.8, -0.4);
  return shade(g);
}
export function elevator(lvl = 1) {
  const g = new THREE.Group(), n = lvl === 1 ? 2 : 4, R = 0.75, H = 3.2;
  const steel = M(0xd5dbe0, 0.35, 0.7, { map: speckle('#d5dbe0', ['rgba(0,0,0,.08)'], 64, 200, 4) });
  for (let i = 0; i < n; i++) {
    const x = -((n - 1) / 2) * 1.7 + i * 1.7;
    const s = cyl(R, R, H, steel, 28, x, H / 2 + 0.2, 0); g.add(s);
    for (let k = 1; k < 5; k++) g.add(cyl(R + 0.01, R + 0.01, 0.04, M(0x9aa3ab, 0.4, 0.7), 28, x, 0.2 + k * H / 5, 0));
    const c = new THREE.Mesh(new THREE.ConeGeometry(R * 1.04, 0.6, 28), M(0xb8c0c7, 0.35, 0.7)); c.position.set(x, H + 0.5, 0); g.add(c);
    g.add(box(0.3, 0.22, 0.06, M(0xf4efe4, 0.5), x, H * 0.6, R + 0.01));
  }
  const towerX = ((n - 1) / 2) * 1.7 + 1.4;
  g.add(box(0.6, H + 1.6, 0.6, M(0xe4472f, 0.5, 0.3), towerX, (H + 1.6) / 2, 0));
  const conv = box(0.2, 0.2, Math.hypot(towerX + 1.7 * (n - 1) / 2, 0.8), M(0x8a949c, 0.5, 0.5)); conv.rotation.y = Math.PI / 2; conv.position.set(towerX / 2, H + 1.2, 0); g.add(conv);
  const pit = box(1.4, 0.1, 1.2, M(0x3a3f45, 0.6, 0.4), towerX, 0.05, 1.2); g.add(pit);
  for (let i = 0; i < 5; i++) g.add(box(1.3, 0.03, 0.06, M(0x6a7077, 0.5, 0.6), towerX, 0.11, 0.75 + i * 0.22));
  hitBox(g, n * 1.7 + 2.6, H + 1.6, 2.4, (H + 1.6) / 2, 0.3);
  return shade(g);
}
export function fertShed() {
  const g = new THREE.Group();
  for (const x of [-1.5, 1.5]) for (const z of [-0.9, 0.9]) g.add(cyl(0.07, 0.07, 1.9, M(0x5f6b75, 0.5, 0.5), 8, x, 0.95, z));
  const r = gableRoof(3.4, 2.2, 0.5, { over: 0.15, mat: M(0x2fa65a, 0.6, 0.2) }); r.position.y = 1.9; g.add(r);
  g.add(box(3.2, 0.06, 2.0, M(0x9aa0a6, 0.95), 0, 0.03, 0));
  const bags = new THREE.Group(); g.add(bags); g.userData.bags = bags;
  hitBox(g, 3.4, 2.4, 2.4);
  return shade(g);
}
export function fertBags(g, n) { g.clear(); const m = M(0xf4f4f0, 0.8), s = M(0x2fa65a, 0.7); for (let i = 0; i < Math.min(n, 18); i++) { const b = box(0.42, 0.18, 0.3, m, -1.1 + (i % 6) * 0.44, 0.17 + ((i / 6) | 0) * 0.19, -0.3 + ((i / 6) | 0) * 0.05, 0.05); g.add(b); g.add(box(0.2, 0.05, 0.01, s, b.position.x, b.position.y, b.position.z + 0.155)); } }
function plantHall(g, col, roofCol, W = 2.6, D = 2.0, H = 1.6) {
  g.add(box(W + 0.3, 0.12, D + 0.3, M(0x8a8f96, 0.9), 0, 0.06, 0));
  g.add(box(W, H, D, M(col, 0.75), 0, 0.12 + H / 2, 0));
  const r = gableRoof(D, W, H * 0.45, { over: 0.15, mat: M(roofCol, 0.6, 0.2), wall: M(col, 0.75) }); r.rotation.y = Math.PI / 2; r.position.y = 0.12 + H; g.add(r);
  door(g, -W * 0.25, D / 2 + 0.02, 0.8, 1.1, 0x4a5058);
  window2(g, W * 0.25, 0.12 + H * 0.6, D / 2 + 0.03, 0.6, 0.45);
}
// бункер приймання сировини (куди тягнеш урожай)
function hopperAt(g, x, z) { const hp = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.12, 0.5, 4, 1, true), M(0x9aa3ab, 0.4, 0.6, { side: THREE.DoubleSide })); hp.rotation.y = Math.PI / 4; hp.position.set(x, 0.9, z); g.add(hp); g.add(box(0.12, 0.65, 0.12, M(0x6a7077, 0.5, 0.5), x, 0.33, z)); g.userData.hopper = hp; return hp; }
export function oilMill() {
  const g = new THREE.Group(); plantHall(g, 0xf2e2b8, 0xc9902b);
  const tank = cyl(0.45, 0.45, 1.6, M(0xffd23f, 0.3, 0.3), 20, 1.9, 0.92, -0.3); g.add(tank);
  const press = new THREE.Group(); press.position.set(-1.9, 0, 0.4); g.add(press);
  press.add(box(0.6, 0.8, 0.6, M(0x4a5058, 0.5, 0.6), 0, 0.4, 0)); const screw = cyl(0.12, 0.12, 0.7, M(0xc9cfd5, 0.3, 0.9), 12, 0, 1.15, 0); press.add(screw); g.userData.spin = screw;
  hopperAt(g, -1.9, 1.2); g.userData.out = new THREE.Vector3(1.0, 0, 1.6);
  hitBox(g, 4.4, 2.6, 3.0);
  return shade(g);
}
export function groatsMill() {
  const g = new THREE.Group(); plantHall(g, 0xd9b48c, 0x6a3f22, 2.4, 2.0, 1.8);
  const wheel = new THREE.Group(); wheel.position.set(-1.35, 1.0, 0); g.add(wheel); g.userData.spin = wheel;
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.75, 0.06, 6, 24), wood()); rim.rotation.y = Math.PI / 2; wheel.add(rim);
  for (let i = 0; i < 8; i++) { const sp = box(0.06, 1.5, 0.12, wood()); sp.rotation.x = i * Math.PI / 8; wheel.add(sp); }
  wheel.rotation.order = 'YXZ';
  hopperAt(g, 1.6, 1.2); g.userData.out = new THREE.Vector3(0.6, 0, 1.7);
  hitBox(g, 4.0, 2.8, 3.0);
  return shade(g);
}
export function feedMill() {
  const g = new THREE.Group(); plantHall(g, 0xc9d4c2, 0x3f6a4a, 2.4, 2.0, 1.5);
  const silo = cyl(0.55, 0.55, 2.6, M(0xd5dbe0, 0.35, 0.7), 20, 1.8, 1.3, -0.4); g.add(silo);
  const cone = new THREE.Mesh(new THREE.ConeGeometry(0.58, 0.45, 20), M(0xb8c0c7, 0.4, 0.7)); cone.position.set(1.8, 2.82, -0.4); g.add(cone);
  const mixer = cyl(0.35, 0.35, 0.6, M(0x4867ee, 0.4, 0.5), 16, -1.8, 0.5, 0.3); mixer.rotation.z = Math.PI / 2; g.add(mixer); g.userData.spin = mixer;
  hopperAt(g, -1.8, 1.3); g.userData.out = new THREE.Vector3(0.4, 0, 1.6);
  hitBox(g, 4.4, 3.0, 3.0);
  return shade(g);
}
export function bioPlant() {
  const g = new THREE.Group();
  g.add(box(4.6, 0.1, 3.0, M(0x8a8f96, 0.95), 0, 0.05, 0));
  const steel = M(0xd5dbe0, 0.3, 0.8);
  for (let i = 0; i < 3; i++) { g.add(cyl(0.5, 0.5, 1.6, steel, 20, -1.6 + i * 1.1, 0.9, -0.6)); g.add(new THREE.Mesh(new THREE.SphereGeometry(0.5, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2), steel).translateX(-1.6 + i * 1.1).translateY(1.7).translateZ(-0.6)); }
  const col = cyl(0.25, 0.25, 3.4, M(0xbfc6cc, 0.3, 0.8), 14, 1.7, 1.75, -0.7); g.add(col);
  for (let k = 0; k < 6; k++) g.add(cyl(0.3, 0.3, 0.05, M(0x8a949c, 0.4, 0.7), 14, 1.7, 0.5 + k * 0.55, -0.7));
  const pipe = cyl(0.06, 0.06, 3.4, M(0x2fa65a, 0.4, 0.5), 8, 0, 2.0, -0.6); pipe.rotation.z = Math.PI / 2; g.add(pipe);
  // бак етанолу з важелем: ліворуч — собі, праворуч — на продаж
  const tank = cyl(0.45, 0.45, 1.1, M(0x7fd6ff, 0.25, 0.4), 18, 1.2, 0.65, 0.9); g.add(tank);
  const lever = new THREE.Group(); lever.position.set(0, 0.5, 1.2); g.add(lever);
  lever.add(box(0.9, 0.1, 0.2, M(0x4a4f56, 0.5, 0.6)));
  const knob = new THREE.Group(); lever.add(knob); knob.add(cyl(0.04, 0.04, 0.5, M(0x2e3a44, 0.4, 0.6), 8, 0, 0.25, 0)); knob.add(new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 8), M(0xe4472f, 0.4)).translateY(0.52));
  g.userData.lever = knob; g.userData.leverHit = hitBox(lever, 1.2, 0.9, 0.6, 0.4, 0); g.userData.leverHit.userData.pick = null;
  hopperAt(g, -1.9, 1.1); g.userData.out = new THREE.Vector3(1.2, 0, 1.9);
  hitBox(g, 4.6, 3.6, 3.2);
  return shade(g);
}
export function windTurbine() {
  const g = new THREE.Group(), H = 5.2;
  g.add(cyl(0.6, 0.7, 0.2, M(0x9aa0a6, 0.9), 16, 0, 0.1, 0));
  g.add(cyl(0.12, 0.26, H, M(0xf4f6f8, 0.35, 0.2), 16, 0, H / 2, 0));
  const nac = box(0.36, 0.34, 0.9, M(0xf4f6f8, 0.35, 0.2), 0, H + 0.1, 0.1, 0.1); g.add(nac);
  const rot = new THREE.Group(); rot.position.set(0, H + 0.1, 0.6); g.add(rot); g.userData.spin = rot;
  rot.add(new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 10), M(0xf4f6f8, 0.3, 0.2)));
  for (let i = 0; i < 3; i++) { const b = new THREE.Group(); b.rotation.z = i * Math.PI * 2 / 3; rot.add(b); const bl = box(0.18, 2.4, 0.04, M(0xffffff, 0.3, 0.1), 0, 1.25, 0); bl.scale.x = 1; b.add(bl); b.add(box(0.12, 0.3, 0.05, M(0xe4472f, 0.4), 0, 2.35, 0)); }
  hitBox(g, 1.4, H + 1, 1.4);
  return shade(g);
}
export function solarArray() {
  const g = new THREE.Group();
  const cv = canvasTex(128, (c, s) => { c.fillStyle = '#1b3a6e'; c.fillRect(0, 0, s, s); c.strokeStyle = 'rgba(180,210,255,.55)'; c.lineWidth = 2; for (let i = 1; i < 6; i++) { c.beginPath(); c.moveTo(i * s / 6, 0); c.lineTo(i * s / 6, s); c.stroke(); } for (let i = 1; i < 4; i++) { c.beginPath(); c.moveTo(0, i * s / 4); c.lineTo(s, i * s / 4); c.stroke(); } });
  const pm = new THREE.MeshStandardMaterial({ map: cv, roughness: 0.18, metalness: 0.6, color: 0xffffff });
  for (let r = 0; r < 2; r++) for (let i = 0; i < 3; i++) {
    const p = new THREE.Group(); p.position.set(-1.3 + i * 1.3, 0, -0.7 + r * 1.5); g.add(p);
    p.add(cyl(0.04, 0.04, 0.7, M(0x8a949c, 0.4, 0.7), 6, 0, 0.35, 0));
    const pan = box(1.2, 0.04, 0.8, pm, 0, 0.75, 0); pan.rotation.x = 0.5; p.add(pan);
  }
  hitBox(g, 4.2, 1.4, 3.2);
  return shade(g);
}
export function pivot(len) {
  const g = new THREE.Group();
  g.add(box(0.5, 2.0, 0.5, M(0x8a949c, 0.4, 0.6), 0, 1.0, 0));
  const arm = new THREE.Group(); arm.position.y = 1.8; g.add(arm); g.userData.spin = arm;
  const truss = box(len, 0.08, 0.08, M(0xd5dbe0, 0.35, 0.7), len / 2, 0, 0); arm.add(truss);
  for (let i = 1; i <= 3; i++) { const x = len * i / 3; arm.add(box(0.06, 1.7, 0.06, M(0x8a949c, 0.4, 0.6), x, -0.85, 0)); const w = cyl(0.25, 0.25, 0.12, M(0x2e3a44, 0.6), 12, x, -1.6, 0); w.rotation.x = Math.PI / 2; arm.add(w); }
  for (let i = 0; i < 8; i++) arm.add(cyl(0.02, 0.03, 0.18, M(0x2f7fd8, 0.4, 0.4), 6, 0.4 + i * (len - 0.5) / 8, -0.12, 0));
  return shade(g);
}
export function pond() {
  const g = new THREE.Group();
  const shore = new THREE.Mesh(new THREE.CircleGeometry(2.7, 40), M(0xc2a77d, 1)); shore.rotation.x = -Math.PI / 2; shore.position.y = 0.02; g.add(shore);
  const water = new THREE.Mesh(new THREE.CircleGeometry(2.4, 40), new THREE.MeshStandardMaterial({ color: 0x2f7fb0, roughness: 0.08, metalness: 0.3, transparent: true, opacity: 0.92 })); water.rotation.x = -Math.PI / 2; water.position.y = 0.04; g.add(water); g.userData.water = water;
  const pier = new THREE.Group(); pier.position.set(0, 0.12, 2.0); g.add(pier);
  for (let i = 0; i < 6; i++) pier.add(box(0.9, 0.05, 0.2, wood(), 0, 0, -i * 0.22));
  for (const x of [-0.4, 0.4]) for (const z of [0, -1.1]) pier.add(cyl(0.04, 0.04, 0.4, wood(), 6, x, -0.15, z));
  for (let i = 0; i < 9; i++) { const a = i * 0.7 + 3.4, r = 2.45; g.add(cyl(0.015, 0.02, 0.6, M(0x5c8f34, 0.7), 4, Math.cos(a) * r, 0.3, Math.sin(a) * r)); g.add(cyl(0.04, 0.04, 0.12, M(0x6a3f22, 0.7), 6, Math.cos(a) * r, 0.62, Math.sin(a) * r)); }
  const bob = new THREE.Mesh(new THREE.SphereGeometry(0.06, 10, 8), M(0xe4472f, 0.4)); bob.position.set(0, 0.06, 0.4); bob.visible = false; g.add(bob); g.userData.bob = bob;
  const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]), new THREE.LineBasicMaterial({ color: 0xffffff })); line.visible = false; g.add(line); g.userData.line = line;
  hitBox(g, 5, 0.6, 5, 0.3);
  return shade(g);
}
export function gazebo() {
  const g = new THREE.Group();
  const base = cyl(1.3, 1.3, 0.16, wood(), 6, 0, 0.08, 0); g.add(base);
  for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; g.add(cyl(0.05, 0.05, 1.6, M(0xf4efe4, 0.6), 8, Math.cos(a) * 1.15, 0.95, Math.sin(a) * 1.15)); }
  const roof = new THREE.Mesh(new THREE.ConeGeometry(1.6, 0.8, 6), M(0x2f6f4a, 0.6)); roof.position.y = 2.15; g.add(roof);
  g.add(box(1.4, 0.08, 0.36, wood(), 0, 0.5, -0.6)); g.add(box(0.9, 0.06, 0.6, wood(), 0, 0.6, 0.1));
  hitBox(g, 2.8, 2.6, 2.8);
  return shade(g);
}
export function hammock() {
  const g = new THREE.Group();
  for (const x of [-1.2, 1.2]) { g.add(cyl(0.12, 0.16, 2.2, M(0x7a4c2a, 0.9), 8, x, 1.1, 0)); const c = new THREE.Mesh(new THREE.IcosahedronGeometry(0.85, 1), M(0x4f9a35, 0.8)); c.position.set(x, 2.5, 0); c.scale.y = 0.85; g.add(c); }
  const cloth = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 2.0, 16, 1, true, Math.PI, Math.PI), M(0xe4472f, 0.8, 0, { side: THREE.DoubleSide, map: canvasTex(64, (c, s) => { for (let i = 0; i < 8; i++) { c.fillStyle = i % 2 ? '#f4efe4' : '#e4472f'; c.fillRect(0, i * s / 8, s, s / 8); } }) }));
  cloth.rotation.z = Math.PI / 2; cloth.position.y = 0.95; g.add(cloth); g.userData.cloth = cloth;
  hitBox(g, 2.8, 1.6, 1.2);
  return shade(g);
}
// будмайданчик: стрічка, табличка з назвою й ціною, кран
export function site(w, d, text, cost, signOnly = false) {
  const g = new THREE.Group();
  const tape = M(0xffd23f, 0.6);
  if (!signOnly) {
  for (const [x, z, l, r] of [[0, d / 2, w, 0], [0, -d / 2, w, 0], [w / 2, 0, d, Math.PI / 2], [-w / 2, 0, d, Math.PI / 2]]) { const t = box(l, 0.05, 0.03, tape, x, 0.45, z); t.rotation.y = r; g.add(t); }
  for (const x of [-w / 2, w / 2]) for (const z of [-d / 2, d / 2]) g.add(cyl(0.04, 0.04, 0.5, M(0xe4472f, 0.6), 6, x, 0.25, z));
  g.add(box(w * 0.9, 0.02, d * 0.9, M(0xa08060, 1), 0, 0.012, 0));
  }
  const sign = new THREE.Group(); sign.position.set(0, 0, signOnly ? 0 : d / 2 + 0.2); g.add(sign);
  sign.add(cyl(0.05, 0.05, 1.4, wood(), 6, -0.55, 0.7, 0)); sign.add(cyl(0.05, 0.05, 1.4, wood(), 6, 0.55, 0.7, 0));
  const cv = document.createElement('canvas'); cv.width = 320; cv.height = 180; const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
  const board = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 0.84), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.7 })); board.position.y = 1.25; board.position.z = 0.03; sign.add(board);
  const back = box(1.56, 0.9, 0.04, wood(), 0, 1.25, 0); sign.add(back);
  g.userData.draw = (t, c, k = 0) => {
    const x = cv.getContext('2d'); x.fillStyle = '#f4e3c0'; x.fillRect(0, 0, 320, 180); x.fillStyle = '#5b3a1c'; x.textAlign = 'center';
    x.font = '700 34px Onest, system-ui'; x.fillText(t, 160, 62, 300);
    x.fillStyle = '#7a4a10'; x.font = '800 54px Onest, system-ui'; x.fillText(c, 160, 128);
    if (k > 0) { x.fillStyle = 'rgba(47,166,90,.85)'; x.fillRect(0, 160, 320 * k, 20); }
    tex.needsUpdate = true;
  };
  g.userData.draw(text, cost);
  hitBox(g, 1.9, 2.2, 1.2, 1.1, signOnly ? 0 : d / 2 + 0.2); // лише навколо таблички — щоб не заважати техніці всередині
  return shade(g);
}

/* ---------------- техніка ---------------- */
function wheel(r, w, x, y, z, col = 0x1d1f26, hub = 0xffd23f) {
  const g = new THREE.Group(); g.position.set(x, y, z);
  const t = cyl(r, r, w, M(col, 0.85), 18); t.rotation.z = Math.PI / 2; g.add(t);
  const h = cyl(r * 0.55, r * 0.55, w + 0.02, M(hub, 0.4, 0.4), 12); h.rotation.z = Math.PI / 2; g.add(h);
  return g;
}
export function combine() {
  const g = new THREE.Group(), body = new THREE.Group(); g.add(body);
  const green = M(0x3d9a4a, 0.45, 0.2), dark = M(0x2e3a44, 0.6, 0.3);
  body.add(box(1.5, 1.1, 2.4, green, 0, 1.05, -0.2, 0.08));
  body.add(box(1.3, 0.4, 1.8, green, 0, 1.8, -0.5, 0.06));
  const cab = new THREE.Group(); cab.position.set(0, 1.85, 0.75); body.add(cab);
  cab.add(box(1.0, 0.85, 0.9, glass(0xbfe6ff), 0, 0.42, 0)); cab.add(box(1.06, 0.08, 0.96, green, 0, 0.88, 0));
  body.add(wheel(0.62, 0.42, -0.85, 0.62, 0.55)); body.add(wheel(0.62, 0.42, 0.85, 0.62, 0.55)); body.add(wheel(0.36, 0.26, -0.7, 0.36, -1.15)); body.add(wheel(0.36, 0.26, 0.7, 0.36, -1.15));
  // жатка з мотовилом
  const header = new THREE.Group(); header.position.set(0, 0.45, 1.75); body.add(header);
  header.add(box(3.0, 0.35, 0.6, M(0xe4b021, 0.5, 0.2), 0, 0, 0));
  for (let i = 0; i < 12; i++) header.add(new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.3, 4), dark).translateX(-1.4 + i * 0.255).translateZ(0.38).rotateX(Math.PI / 2));
  const reel = new THREE.Group(); reel.position.set(0, 0.45, 0.2); header.add(reel); g.userData.reel = reel;
  const ax = cyl(0.04, 0.04, 2.9, dark, 8); ax.rotation.z = Math.PI / 2; reel.add(ax);
  for (let i = 0; i < 5; i++) { const b = box(2.8, 0.05, 0.05, M(0xe4472f, 0.5), 0, 0.32, 0); const k = new THREE.Group(); k.rotation.x = i * Math.PI * 2 / 5; k.add(b); reel.add(k); }
  // шнек вивантаження
  const auger = new THREE.Group(); auger.position.set(0.7, 2.05, -0.6); body.add(auger); g.userData.auger = auger;
  const ap = cyl(0.09, 0.09, 2.2, M(0x3d9a4a, 0.45, 0.2), 10, 0, 0, -1.0); ap.rotation.x = Math.PI / 2; auger.add(ap); auger.rotation.y = -0.15;
  const grain = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.02, 1.3), M(0xe2bd5a, 0.8)); grain.position.set(0, 2.0, -0.5); body.add(grain); g.userData.grain = grain;
  g.userData.lights = addLights(body, 1.0, 2.5, 1.2);
  g.userData.body = body; g.userData.len = 4.2;
  hitBox(g, 3.0, 2.6, 4.2, 1.3, 0.3);
  return shade(g);
}
export function truck(lvl = 1) {
  const g = new THREE.Group(), body = new THREE.Group(); g.add(body);
  const col = [0x4867ee, 0xe4472f, 0x2fa65a][lvl - 1], L = [3.2, 3.8, 4.6][lvl - 1];
  const cm = M(col, 0.35, 0.3);
  body.add(box(1.4, 0.3, L, M(0x2e3a44, 0.6, 0.4), 0, 0.55, 0));
  const cab = new THREE.Group(); cab.position.set(0, 0.7, L / 2 - 0.6); body.add(cab);
  cab.add(box(1.4, 1.0, 1.1, cm, 0, 0.5, 0, 0.1)); cab.add(box(1.25, 0.45, 0.06, glass(0xbfe6ff), 0, 0.68, 0.53)); cab.add(box(1.0, 0.18, 0.06, M(0x1d1f26, 0.4), 0, 0.15, 0.56));
  const bed = new THREE.Group(); bed.position.set(0, 0.7, -0.6); body.add(bed);
  const BL = L - 1.4, sideM = M(0x8a949c, 0.5, 0.5);
  bed.add(box(1.45, 0.08, BL, sideM, 0, 0, 0)); for (const sx of [-1, 1]) bed.add(box(0.06, 0.6, BL, sideM, sx * 0.7, 0.3, 0)); bed.add(box(1.45, 0.6, 0.06, sideM, 0, 0.3, -BL / 2)); bed.add(box(1.45, 0.6, 0.06, sideM, 0, 0.3, BL / 2));
  const load = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.5, BL - 0.1), M(0xe2bd5a, 0.85)); load.position.y = 0.05; load.scale.y = 0.01; load.visible = false; bed.add(load); g.userData.load = load;
  const nW = lvl === 3 ? 3 : 2; for (let i = 0; i < nW; i++) { const z = i === 0 ? L / 2 - 0.65 : -L / 2 + 0.5 + (i - 1) * 0.75; body.add(wheel(0.36, 0.26, -0.72, 0.36, z)); body.add(wheel(0.36, 0.26, 0.72, 0.36, z)); }
  g.userData.lights = addLights(body, 0.7, 1.0, L / 2 + 0.02);
  g.userData.body = body; g.userData.len = L;
  hitBox(g, 1.8, 1.8, L + 0.2, 0.9);
  return shade(g);
}
export function jeep() {
  const g = new THREE.Group(), body = new THREE.Group(); g.add(body);
  const k = M(0x6b7d3a, 0.5, 0.2);
  body.add(box(1.2, 0.5, 2.0, k, 0, 0.6, 0, 0.1)); body.add(box(1.1, 0.5, 1.0, k, 0, 1.05, -0.2, 0.08));
  body.add(box(1.0, 0.36, 0.05, glass(0xbfe6ff), 0, 1.08, 0.31)); for (const sx of [-1, 1]) body.add(box(0.05, 0.32, 0.7, glass(0xbfe6ff), sx * 0.56, 1.08, -0.2));
  for (const x of [-0.58, 0.58]) for (const z of [-0.65, 0.65]) body.add(wheel(0.28, 0.2, x, 0.28, z, 0x1d1f26, 0xd5dbe0));
  const spare = cyl(0.25, 0.25, 0.15, M(0x1d1f26, 0.8), 12, 0, 0.75, -1.08); spare.rotation.x = Math.PI / 2; body.add(spare);
  g.userData.lights = addLights(body, 0.45, 0.7, 1.02);
  g.userData.body = body; g.userData.len = 2.2;
  hitBox(g, 1.5, 1.6, 2.4, 0.8);
  return shade(g);
}
function addLights(parent, hx, y, z) { const m = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: new THREE.Color(0xfff2c8), emissiveIntensity: 0.2 }); for (const sx of [-1, 1]) parent.add(box(0.18, 0.12, 0.04, m, sx * hx, y, z)); return m; }
// причепи для трактора: передом до трактора (+Z), гак на z = len/2
export function implement(kind) {
  const g = new THREE.Group(), body = new THREE.Group(); g.add(body);
  const frame = M(0xe4472f, 0.45, 0.3), steel = M(0x9aa3ab, 0.35, 0.8), dark = M(0x2e3a44, 0.6, 0.3);
  let len = 1.4;
  if (kind === 'cultivator') {
    body.add(box(2.4, 0.12, 0.14, frame, 0, 0.55, 0.2)); body.add(box(2.4, 0.12, 0.14, frame, 0, 0.55, -0.35));
    for (let i = 0; i < 9; i++) { const t = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.025, 4, 10, Math.PI), steel); t.position.set(-1.1 + i * 0.275, 0.35, (i % 2 ? 0.2 : -0.35)); t.rotation.y = Math.PI / 2; body.add(t); }
    body.add(box(0.12, 0.12, 0.9, frame, 0, 0.6, 0.6)); len = 1.6;
  } else if (kind === 'seeder') {
    body.add(box(2.2, 0.55, 0.8, M(0x2f6fb5, 0.4, 0.3), 0, 0.85, 0, 0.06)); body.add(box(2.3, 0.08, 0.9, M(0x245a94, 0.4, 0.3), 0, 1.15, 0));
    for (let i = 0; i < 8; i++) body.add(cyl(0.025, 0.025, 0.5, steel, 6, -0.95 + i * 0.27, 0.35, 0.1));
    body.add(wheel(0.32, 0.18, -1.2, 0.32, -0.25, 0x1d1f26, 0xd5dbe0)); body.add(wheel(0.32, 0.18, 1.2, 0.32, -0.25, 0x1d1f26, 0xd5dbe0));
    body.add(box(0.12, 0.12, 0.8, frame, 0, 0.55, 0.75));
    const seed = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.04, 0.7), M(0xe2bd5a, 0.9)); seed.position.y = 1.12; seed.visible = false; body.add(seed); g.userData.fill = seed; len = 1.7;
  } else if (kind === 'sprayer') {
    const tank = cyl(0.42, 0.42, 1.2, M(0xf4f4f0, 0.35, 0.2), 18, 0, 0.85, 0); tank.rotation.x = Math.PI / 2; body.add(tank);
    for (const sx of [-1, 1]) { const arm = box(0.95, 0.06, 0.06, steel, sx * 0.72, 0.75, -0.55); body.add(arm); for (let i = 0; i < 4; i++) body.add(cyl(0.02, 0.03, 0.1, M(0x2f7fd8, 0.4, 0.4), 6, sx * (0.35 + i * 0.27), 0.68, -0.55)); }
    body.add(wheel(0.34, 0.2, -0.55, 0.34, 0, 0x1d1f26, 0xd5dbe0)); body.add(wheel(0.34, 0.2, 0.55, 0.34, 0, 0x1d1f26, 0xd5dbe0));
    body.add(box(0.12, 0.12, 0.8, frame, 0, 0.5, 0.8));
    const fl = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.04, 0.8), M(0x8fe08a, 0.4)); fl.position.y = 1.29; fl.visible = false; body.add(fl); g.userData.fill = fl; len = 1.8;
  } else if (kind === 'irrigator') {
    const reel = new THREE.Group(); reel.position.set(0, 0.85, 0); body.add(reel); g.userData.spin = reel;
    const drum = cyl(0.55, 0.55, 0.7, M(0x2f7fd8, 0.4, 0.3), 20); drum.rotation.z = Math.PI / 2; reel.add(drum);
    for (const sx of [-1, 1]) { const r = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.05, 6, 20), M(0xe4b021, 0.4, 0.3)); r.rotation.y = Math.PI / 2; r.position.x = sx * 0.38; reel.add(r); }
    body.add(box(1.2, 0.1, 1.0, dark, 0, 0.3, 0)); body.add(wheel(0.32, 0.18, -0.7, 0.32, 0, 0x1d1f26, 0xd5dbe0)); body.add(wheel(0.32, 0.18, 0.7, 0.32, 0, 0x1d1f26, 0xd5dbe0));
    body.add(box(0.12, 0.12, 0.8, frame, 0, 0.45, 0.8)); len = 1.6;
  }
  g.userData.body = body; g.userData.len = len; g.userData.kind = kind;
  hitBox(g, 2.6, 1.4, len + 0.2, 0.7);
  return shade(g);
}
// бочка/палета продукції біля цеху
export function goodsPallet(kind) {
  const g = new THREE.Group();
  g.add(box(1.0, 0.1, 0.8, wood(), 0, 0.05, 0));
  if (kind === 'oil') for (let i = 0; i < 6; i++) { const b = cyl(0.08, 0.08, 0.36, glass(0xffd23f), 10, -0.32 + (i % 3) * 0.32, 0.28, i < 3 ? -0.18 : 0.18); g.add(b); g.add(cyl(0.035, 0.035, 0.06, M(0xe4472f, 0.5), 8, b.position.x, 0.49, b.position.z)); }
  else if (kind === 'ethanol') { const b = cyl(0.3, 0.3, 0.8, M(0x2f7fd8, 0.35, 0.4), 18, 0, 0.5, 0); g.add(b); g.add(box(0.4, 0.14, 0.01, M(0xffffff, 0.5), 0, 0.55, 0.3)); }
  else { const col = kind === 'groats' ? 0xd9b48c : 0xb5a46a; for (let i = 0; i < 4; i++) { const s = box(0.42, 0.22, 0.32, M(col, 0.85), -0.22 + (i % 2) * 0.44, 0.22 + ((i / 2) | 0) * 0.22, 0, 0.06); g.add(s); } }
  hitBox(g, 1.1, 1.0, 0.9);
  return shade(g);
}
// мішок насіння / каністра мастила / каністра пального / відро / мішок добрив — те, що тягаєш руками
export function sack(color, kind = 'seed') {
  const g = new THREE.Group();
  if (kind === 'oilcan') { g.add(box(0.36, 0.5, 0.2, M(0x2f6fb5, 0.4, 0.3), 0, 0.25, 0, 0.04)); g.add(cyl(0.05, 0.05, 0.1, M(0xffd23f, 0.4), 8, 0.1, 0.55, 0)); g.add(box(0.2, 0.05, 0.05, M(0x1d1f26, 0.6), -0.05, 0.56, 0)); }
  else if (kind === 'jerry') { // каністра з пальним: червона, з ручкою й носиком
    g.add(box(0.42, 0.52, 0.2, M(0xd8392b, 0.45, 0.2), 0, 0.26, 0, 0.04)); g.add(box(0.26, 0.06, 0.08, M(0x1d1f26, 0.6), -0.04, 0.56, 0)); g.add(cyl(0.045, 0.045, 0.12, M(0x2b2e36, 0.5), 8, 0.15, 0.58, 0));
    for (const sx of [-1, 1]) g.add(box(0.03, 0.32, 0.01, M(0xa82a1f, 0.5), sx * 0.09, 0.26, 0.105).rotateZ(sx * 0.6));
  } else if (kind === 'bucket') { // відро з водою й губкою — мити техніку руками
    g.add(cyl(0.26, 0.2, 0.42, M(0x7fa8c9, 0.45, 0.3), 18, 0, 0.21, 0)); g.add(cyl(0.235, 0.235, 0.02, glass(0x8fd3ff), 18, 0, 0.39, 0));
    g.add(box(0.26, 0.1, 0.16, M(0xffd23f, 0.9), 0.04, 0.45, 0, 0.03)); const hdl = new THREE.Mesh(new THREE.TorusGeometry(0.25, 0.012, 6, 20, Math.PI), M(0x5a6275, 0.4, 0.6)); hdl.position.y = 0.42; g.add(hdl);
  }
  else { const s = new THREE.Mesh(new THREE.SphereGeometry(0.24, 14, 10), M(kind === 'fert' ? 0xf4f4f0 : 0xd9c49c, 0.9)); s.scale.set(1, 1.2, 0.85); s.position.y = 0.28; g.add(s); g.add(new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 8), M(color, 0.5)).translateY(0.58)); }
  hitBox(g, 0.6, 0.8, 0.6);
  return shade(g);
}

/* ---------------- рослини для полів: одна геометрія на культуру (InstancedMesh) ---------------- */
function colored(geo, col) { const c = new THREE.Color(col), n = geo.attributes.position.count, a = new Float32Array(n * 3); for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; } geo.setAttribute('color', new THREE.BufferAttribute(a, 3)); return geo; }
const clean = (g) => { g = g.index ? g.toNonIndexed() : g; for (const k of Object.keys(g.attributes)) if (!['position', 'normal', 'color'].includes(k)) g.deleteAttribute(k); return g; };
export function cropGeo(kind) {
  const parts = [];
  const P = (geo, col, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, s = [1, 1, 1]) => { geo.scale(...s); geo.rotateX(rx); geo.rotateY(ry); geo.rotateZ(rz); geo.translate(x, y, z); parts.push(clean(colored(geo, col))); };
  if (kind === 'wheat') { for (let i = 0; i < 5; i++) { const a = i * 1.26, r = 0.06; P(new THREE.CylinderGeometry(0.008, 0.012, 0.55, 4), '#c9a43a', Math.cos(a) * r, 0.27, Math.sin(a) * r, Math.cos(a) * 0.12, 0, Math.sin(a) * 0.12); P(new THREE.CapsuleGeometry(0.022, 0.1, 2, 4), '#e2bd5a', Math.cos(a) * (r + 0.03), 0.6, Math.sin(a) * (r + 0.03), Math.cos(a) * 0.15, 0, Math.sin(a) * 0.15); } }
  else if (kind === 'sunflower') { P(new THREE.CylinderGeometry(0.02, 0.03, 0.9, 5), '#5c8f34', 0, 0.45, 0); P(new THREE.SphereGeometry(0.09, 6, 4), '#4f9a35', 0.06, 0.4, 0, 0, 0, 0, [1.4, 0.2, 0.8]); P(new THREE.CylinderGeometry(0.1, 0.1, 0.04, 10), '#f2c21b', 0, 0.92, 0.04, 1.2, 0, 0); P(new THREE.CylinderGeometry(0.06, 0.06, 0.05, 10), '#5a3a1a', 0, 0.92, 0.06, 1.2, 0, 0); }
  else if (kind === 'corn') { P(new THREE.CylinderGeometry(0.02, 0.03, 1.15, 5), '#6aa33a', 0, 0.57, 0); for (let i = 0; i < 4; i++) P(new THREE.SphereGeometry(0.12, 6, 4), '#5c9a35', Math.cos(i * 1.7) * 0.08, 0.35 + i * 0.18, Math.sin(i * 1.7) * 0.08, 0, i * 1.7, 0.6, [1.6, 0.12, 0.4]); P(new THREE.CapsuleGeometry(0.035, 0.12, 2, 6), '#f2c94a', 0.05, 0.7, 0.02, 0, 0, 0.3); P(new THREE.ConeGeometry(0.04, 0.16, 4), '#d9b85a', 0, 1.2, 0); }
  else if (kind === 'buckwheat') { P(new THREE.CylinderGeometry(0.012, 0.02, 0.45, 4), '#a8443a', 0, 0.22, 0); for (let i = 0; i < 5; i++) P(new THREE.SphereGeometry(0.05, 5, 4), i % 2 ? '#f4e4ea' : '#e8b8c8', Math.cos(i * 1.3) * 0.07, 0.42 + (i % 3) * 0.04, Math.sin(i * 1.3) * 0.07); P(new THREE.SphereGeometry(0.08, 5, 4), '#4f9a35', 0, 0.22, 0, 0, 0, 0, [1.2, 0.3, 1.2]); }
  else P(new THREE.ConeGeometry(0.05, 0.3, 4), '#5c8f34', 0, 0.15, 0); // трава
  return mergeGeometries(parts);
}
