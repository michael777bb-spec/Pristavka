// ЛІКАРНЯНІ ІСТОРІЇ 3D — переробка гри сина.
// Текст розділу 1 «Між ударами серця» — сина, без змін (uk/en/ru).
// Що нове: лікарня-макет у розрізі, кожна сцена — своя кімната; камера
// пливе туди, де відбувається дія; монітор б'ється з пульсом сцени;
// світло — за часом доби. І редактор: будь-хто пише свою історію.
import { world, THREE, RoundedBoxGeometry, std, glow, blob, label, h, esc, canvasTex, ease } from '../kit.js';
import { inst, clip, animator } from '../models.js';
import { makeCat } from '../catcrew.js';
import { gi, giSvg } from '../icons.js';
import { tagSprite } from '../kit.js';
import { sfx as SFX, soundScope } from '../sound.js';

const TX = {
  uk: { aiHelp: 'Допоможи продовжити (ШІ)', aiNo: 'ШІ зараз недоступний. Підказка: напиши, що герой бачить, що відчуває і що скаже далі.', tapOn: 'торкнись, щоб далі', holdRestart: 'затисни — почати спочатку', petVisit: 'прийшов провідати!', what: 'Що обереш?', title: 'Лікарняні історії', story1: 'Між ударами серця', story1d: 'Андрій і Аліна після аварії вчаться жити далі. 40 сцен.', own: 'Своя історія', ownD: 'Напиши сцени, обери кімнати — і грай.', play: 'Грати', cont: 'Продовжити', restart: 'Спочатку', next: 'Далі', nextScene: 'Наступна сцена', end: 'Кінець розділу. Далі буде.', scenes: 'Сцени', edit: 'Редактор', addScene: 'Додати сцену', room: 'Кімната', sceneTitle: 'Назва сцени', text: 'Текст (абзаци через порожній рядок)', question: 'Запитання (необов’язково)', opt: 'Варіант', resp: 'Відповідь на варіант', save: 'Зберегти', del: 'Видалити', back: 'Назад', empty: 'Поки немає сцен.', traits: { c: 'Близькість', o: 'Чесність', p: 'Терпіння' }, menu: 'Меню',
    rooms: { icu: 'Реанімація', cardio: 'Кардіологія', pulmo: 'Пульмонологія', rehabA: 'Реабілітація', rehabL: 'Реабілітація 2', lounge: 'Вітальня', corridor: 'Коридор', nurses: 'Пост медсестер', lobby: 'Хол' } },
  en: { aiHelp: 'Help me continue (AI)', aiNo: 'AI is not available now. Tip: write what the hero sees, feels and says next.', tapOn: 'tap to go on', holdRestart: 'hold to start over', petVisit: 'came to visit!', what: 'What will you choose?', title: 'Hospital Stories', story1: 'Between Heartbeats', story1d: 'Andrey and Alina learn to live on after the crash. 40 scenes.', own: 'Your own story', ownD: 'Write scenes, pick rooms — and play.', play: 'Play', cont: 'Continue', restart: 'From the start', next: 'Next', nextScene: 'Next scene', end: 'End of the chapter. To be continued.', scenes: 'Scenes', edit: 'Editor', addScene: 'Add a scene', room: 'Room', sceneTitle: 'Scene title', text: 'Text (paragraphs separated by a blank line)', question: 'Question (optional)', opt: 'Option', resp: 'Response to the option', save: 'Save', del: 'Delete', back: 'Back', empty: 'No scenes yet.', traits: { c: 'Closeness', o: 'Honesty', p: 'Patience' }, menu: 'Menu',
    rooms: { icu: 'Intensive care', cardio: 'Cardiology', pulmo: 'Pulmonology', rehabA: 'Rehab', rehabL: 'Rehab 2', lounge: 'Lounge', corridor: 'Corridor', nurses: 'Nurses’ station', lobby: 'Lobby' } },
  ru: { aiHelp: 'Помоги продолжить (ИИ)', aiNo: 'ИИ сейчас недоступен. Подсказка: напиши, что герой видит, чувствует и что скажет дальше.', tapOn: 'коснись, чтобы дальше', holdRestart: 'зажми — начать сначала', petVisit: 'пришёл проведать!', what: 'Что выберешь?', title: 'Больничные истории', story1: 'Между ударами сердца', story1d: 'Андрей и Алина после аварии учатся жить дальше. 40 сцен.', own: 'Своя история', ownD: 'Напиши сцены, выбери комнаты — и играй.', play: 'Играть', cont: 'Продолжить', restart: 'Сначала', next: 'Дальше', nextScene: 'Следующая сцена', end: 'Конец главы. Продолжение следует.', scenes: 'Сцены', edit: 'Редактор', addScene: 'Добавить сцену', room: 'Комната', sceneTitle: 'Название сцены', text: 'Текст (абзацы через пустую строку)', question: 'Вопрос (необязательно)', opt: 'Вариант', resp: 'Ответ на вариант', save: 'Сохранить', del: 'Удалить', back: 'Назад', empty: 'Пока нет сцен.', traits: { c: 'Близость', o: 'Честность', p: 'Терпение' }, menu: 'Меню',
    rooms: { icu: 'Реанимация', cardio: 'Кардиология', pulmo: 'Пульмонология', rehabA: 'Реабилитация', rehabL: 'Реабилитация 2', lounge: 'Гостиная', corridor: 'Коридор', nurses: 'Пост медсестёр', lobby: 'Холл' } }
};
const NAMES = { A: { uk: 'Андрій', en: 'Andrey', ru: 'Андрей' }, L: { uk: 'Аліна', en: 'Alina', ru: 'Алина' } };
// поверхи: 0 — перший
const LAYOUT = { lobby: [0, 0], nurses: [0, 1], corridor: [0, 2], lounge: [1, 0], rehabA: [1, 1], rehabL: [1, 2], icu: [2, 0], cardio: [2, 1], pulmo: [2, 2] };
const RW = 3.2, RD = 2.7, RH = 1.75;
const WALL = { icu: '#dfe9ee', cardio: '#e9e3f2', pulmo: '#e2efe6', rehabA: '#f2ead9', rehabL: '#f1e2df', lounge: '#efe6d6', corridor: '#e6e8ea', nurses: '#dfeaf2', lobby: '#ece7dd' };

export function mount(root, api) {
  const lang = TX[api.lang] ? api.lang : 'uk';
  const T = TX[lang];
  const W = world(root, { quality: api.quality, bg: 0x10141c, envI: 0.35, bloom: 0.12, bloomTh: 0.97, tilt: 0, exposure: 0.9 });
  const { scene, camera, hud } = W;
  let CH = null;
  // звук: тиша палати (вентиляція, годинник у вітальні), монітор у такт пульсу сцени, шелест сторінок
  const SND = soundScope(); let sceneNight = false;

  /* ---------- світло ---------- */
  const hemi = new THREE.HemisphereLight(0xe8f0ff, 0x3a3328, 0.55); scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff0dc, 1.8); sun.position.set(-6, 9, 9); sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048); Object.assign(sun.shadow.camera, { left: -8, right: 8, top: 8, bottom: -8, near: 1, far: 40 }); sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.02;
  scene.add(sun);
  const bgCv = document.createElement('canvas'); bgCv.width = 4; bgCv.height = 256;
  const bgTex = new THREE.CanvasTexture(bgCv); bgTex.colorSpace = THREE.SRGBColorSpace; scene.background = bgTex;
  function sky(top, mid) { const g = bgCv.getContext('2d'), gr = g.createLinearGradient(0, 0, 0, 256); gr.addColorStop(0, top); gr.addColorStop(0.6, mid); gr.addColorStop(1, '#0c1017'); g.fillStyle = gr; g.fillRect(0, 0, 4, 256); bgTex.needsUpdate = true; }
  sky('#8fb4d8', '#3c4c63');

  /* ---------- будівля в розрізі ---------- */
  const B = new THREE.Group(); scene.add(B);
  const slabM = std(0xd9dbe0, 0.7), outM = std(0xf3efe7, 0.85);
  const floorTex = canvasTex(256, (g, s) => { g.fillStyle = '#cfd6d9'; g.fillRect(0, 0, s, s); g.strokeStyle = 'rgba(0,0,0,.08)'; g.lineWidth = 2; for (let i = 0; i <= 8; i++) { g.beginPath(); g.moveTo(i * s / 8, 0); g.lineTo(i * s / 8, s); g.stroke(); g.beginPath(); g.moveTo(0, i * s / 8); g.lineTo(s, i * s / 8); g.stroke(); } }); floorTex.repeat.set(2, 2);
  const rooms = {};
  const bedM = std(0xf4f6f8, 0.6), frameM2 = std(0x9aa3ad, 0.35, 0.8), blanketM = std(0x7fb3d5, 0.85), woodM = std(0xa77b52, 0.7), sofaM = std(0x5d7a8c, 0.9), plantPot = std(0xb46a45, 0.8);
  function bed(g, x, z, col) {
    const b = new THREE.Group(); b.position.set(x, 0, z); g.add(b);
    const fr = new THREE.Mesh(new RoundedBoxGeometry(0.9, 0.12, 1.7, 2, 0.03), frameM2); fr.position.y = 0.38; b.add(fr);
    const mat = new THREE.Mesh(new RoundedBoxGeometry(0.84, 0.12, 1.64, 3, 0.05), bedM); mat.position.y = 0.5; b.add(mat);
    const bl = new THREE.Mesh(new RoundedBoxGeometry(0.86, 0.06, 0.95, 3, 0.03), col ? std(col, 0.85) : blanketM); bl.position.set(0, 0.58, 0.3); b.add(bl);
    const pil = new THREE.Mesh(new RoundedBoxGeometry(0.6, 0.1, 0.28, 3, 0.05), bedM); pil.position.set(0, 0.6, -0.62); b.add(pil);
    for (const [lx, lz] of [[-0.4, -0.78], [0.4, -0.78], [-0.4, 0.78], [0.4, 0.78]]) { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.36, 8), frameM2); l.position.set(lx, 0.18, lz); b.add(l); }
    const head = new THREE.Mesh(new RoundedBoxGeometry(0.9, 0.5, 0.05, 2, 0.02), frameM2); head.position.set(0, 0.65, -0.86); b.add(head);
    b.traverse((m) => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
    return b;
  }
  function monitor(g, x, z) {
    const cv = document.createElement('canvas'); cv.width = 256; cv.height = 160;
    const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 1.3, 8), frameM2); pole.position.set(x, 0.65, z); g.add(pole);
    const box = new THREE.Mesh(new RoundedBoxGeometry(0.5, 0.34, 0.08, 2, 0.02), std(0x2b2f36, 0.4, 0.3)); box.position.set(x, 1.3, z + 0.03); box.castShadow = true; g.add(box);
    const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.44, 0.28), new THREE.MeshBasicMaterial({ map: tex })); scr.position.set(x, 1.3, z + 0.075); g.add(scr);
    return { cv, tex, t: 0, x: 0, last: 80 };
  }
  function sofa(g, x, z, ry = 0) {
    const s = new THREE.Group(); s.position.set(x, 0, z); s.rotation.y = ry; g.add(s);
    const seat = new THREE.Mesh(new RoundedBoxGeometry(1.3, 0.22, 0.6, 3, 0.07), sofaM); seat.position.y = 0.25; s.add(seat);
    const back = new THREE.Mesh(new RoundedBoxGeometry(1.3, 0.45, 0.16, 3, 0.07), sofaM); back.position.set(0, 0.5, -0.24); s.add(back);
    for (const sx of [-0.62, 0.62]) { const arm = new THREE.Mesh(new RoundedBoxGeometry(0.14, 0.32, 0.6, 3, 0.06), sofaM); arm.position.set(sx, 0.38, 0); s.add(arm); }
    s.traverse((m) => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
  }
  function table(g, x, z, w = 0.8, d = 0.5, hh = 0.42) {
    const top = new THREE.Mesh(new RoundedBoxGeometry(w, 0.05, d, 2, 0.02), woodM); top.position.set(x, hh, z); top.castShadow = true; g.add(top);
    for (const [lx, lz] of [[-w / 2 + 0.05, -d / 2 + 0.05], [w / 2 - 0.05, -d / 2 + 0.05], [-w / 2 + 0.05, d / 2 - 0.05], [w / 2 - 0.05, d / 2 - 0.05]]) { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, hh, 6), woodM); l.position.set(x + lx, hh / 2, z + lz); g.add(l); }
  }
  function plant(g, x, z) { const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.09, 0.22, 16), plantPot); pot.position.set(x, 0.11, z); pot.castShadow = true; g.add(pot); inst('bush', 0.45).then((m) => { m.position.set(x, 0.2, z); g.add(m); }).catch(() => { }); }

  for (const [id, [fl, col]] of Object.entries(LAYOUT)) {
    const g = new THREE.Group(); g.position.set((col - 1) * (RW + 0.12), fl * (RH + 0.14), 0); B.add(g);
    const wallM = std(WALL[id], 0.9);
    const floor = new THREE.Mesh(new THREE.BoxGeometry(RW, 0.12, RD), std(0xffffff, 0.75, 0, { map: floorTex })); floor.position.y = -0.06; floor.receiveShadow = true; g.add(floor);
    const back = new THREE.Mesh(new THREE.BoxGeometry(RW, RH, 0.1), wallM); back.position.set(0, RH / 2, -RD / 2); back.receiveShadow = true; g.add(back);
    for (const sx of [-1, 1]) { const side = new THREE.Mesh(new THREE.BoxGeometry(0.08, RH, RD), wallM); side.position.set(sx * RW / 2, RH / 2, 0); side.receiveShadow = true; side.castShadow = true; g.add(side); }
    // вікно в задній стіні
    const winM = new THREE.MeshBasicMaterial({ color: new THREE.Color(0.9, 1.05, 1.25) });
    const win = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.7), winM); win.position.set(0.7, 1.05, -RD / 2 + 0.056); g.add(win);
    const wf = new THREE.Mesh(new THREE.BoxGeometry(0.98, 0.78, 0.04), std(0xffffff, 0.5)); wf.position.set(0.7, 1.05, -RD / 2 + 0.04); g.add(wf);
    const cross = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.7, 0.02), std(0xffffff, 0.5)); cross.position.set(0.7, 1.05, -RD / 2 + 0.07); g.add(cross);
    // стельова лампа
    const lampM = new THREE.MeshBasicMaterial({ color: new THREE.Color(1.2, 1.15, 1.05) });
    const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.03, 0.22), lampM); lamp.position.set(0, RH - 0.02, 0); g.add(lamp);
    const light = new THREE.PointLight(0xfff1dc, 0, 5, 1.6); light.position.set(0, RH - 0.25, 0.2); g.add(light);
    const r = { id, g, winM, lampM, light, mon: null, spots: [] };
    // меблі за типом кімнати
    if (['icu', 'cardio', 'pulmo', 'rehabA', 'rehabL'].includes(id)) {
      bed(g, -0.55, -0.25, id === 'rehabL' ? '#d59aa8' : id === 'pulmo' ? '#8fc5a5' : null);
      if (id === 'icu' || id === 'cardio' || id === 'pulmo') r.mon = monitor(g, -1.25, -0.95);
      const chair = new THREE.Mesh(new RoundedBoxGeometry(0.38, 0.4, 0.38, 2, 0.05), sofaM); chair.position.set(0.55, 0.2, 0.35); chair.castShadow = true; g.add(chair);
      table(g, 0.95, -0.85, 0.45, 0.35, 0.55);
      if (id.startsWith('rehab')) { const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1.4, 8), frameM2); bar.rotation.z = Math.PI / 2; bar.position.set(0.6, 0.85, -1.2); g.add(bar); }
      r.spots = [[-0.55, 0.55, -0.4, 'sit'], [0.75, 0, 0.5, 'idle'], [0.2, 0, 0.75, 'idle']];
    } else if (id === 'lounge') { sofa(g, -0.5, -0.7); table(g, -0.5, 0.05); plant(g, 1.25, -1.0); const tv = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.5, 0.05), std(0x111111, 0.3)); tv.position.set(0.8, 0.95, -RD / 2 + 0.1); g.add(tv); r.spots = [[-0.8, 0.28, -0.65, 'sit'], [-0.2, 0.28, -0.65, 'sit'], [0.8, 0, 0.4, 'idle']]; }
    else if (id === 'corridor') { for (const x of [-0.9, 0.6]) { const bench = new THREE.Mesh(new RoundedBoxGeometry(0.9, 0.08, 0.35, 2, 0.03), woodM); bench.position.set(x, 0.4, -1.05); bench.castShadow = true; g.add(bench); } plant(g, 1.3, -1.05); r.spots = [[-0.9, 0.42, -1.0, 'sit'], [0.3, 0, 0.2, 'idle'], [-0.2, 0, 0.6, 'idle']]; }
    else if (id === 'nurses') { const desk = new THREE.Mesh(new RoundedBoxGeometry(1.8, 0.75, 0.5, 2, 0.04), std(0xe9e4da, 0.6)); desk.position.set(0, 0.38, -0.6); desk.castShadow = true; g.add(desk); r.mon = monitor(g, -0.6, -0.95); r.spots = [[0.2, 0, -1.05, 'idle'], [-0.3, 0, 0.5, 'idle'], [0.6, 0, 0.6, 'idle']]; }
    else if (id === 'lobby') { const desk = new THREE.Mesh(new RoundedBoxGeometry(1.4, 0.7, 0.5, 2, 0.04), woodM); desk.position.set(0.7, 0.35, -0.7); desk.castShadow = true; g.add(desk); sofa(g, -0.8, -0.85); plant(g, -1.35, 0.6); r.spots = [[-0.9, 0.28, -0.8, 'sit'], [0.0, 0, 0.4, 'idle'], [0.7, 0, -1.1, 'idle']]; }
    const tg = label(T.rooms[id], { scale: 0.22 }); tg.position.set(-RW / 2 + 0.55, RH - 0.15, 0.6); g.add(tg);
    rooms[id] = r;
  }
  // зовнішній каркас і дах
  const BW = 3 * RW + 0.5, BH = 3 * (RH + 0.14);
  const roof = new THREE.Mesh(new RoundedBoxGeometry(BW, 0.2, RD + 0.3, 3, 0.05), outM); roof.position.set(0, BH, 0); roof.castShadow = true; B.add(roof);
  const sign = label('+ ЛІКАРНЯ', { scale: 0.35, bg: 'rgba(214,64,64,.95)' }); sign.position.set(0, BH + 0.45, 0.4); B.add(sign);
  const groundM = std(0x5a6a55, 0.95); const ground = new THREE.Mesh(new RoundedBoxGeometry(BW + 4, 0.3, RD + 4, 3, 0.1), groundM); ground.position.set(0, -0.28, 0.8); ground.receiveShadow = true; B.add(ground);
  inst('ambulance', 1.2, { by: 'xz' }).then((m) => { m.position.set(-BW / 2 - 0.8, -0.13, 1.6); m.rotation.y = Math.PI / 2; B.add(m); }).catch(() => { });
  ['tree_oak', 'tree_fat'].forEach((n, i) => inst(n, 2.0).then((m) => { m.position.set(i ? BW / 2 + 1.2 : -BW / 2 - 1.3, -0.13, -0.6); B.add(m); }).catch(() => { }));
  B.position.y = -BH / 2 + 0.4;

  /* ---------- персонажі ---------- */
  const people = {};
  const CAST = { A: 'mini_male_a', L: 'mini_female_a', N: 'mini_female_b', D: 'mini_male_b' };
  Object.entries(CAST).forEach(([k, n]) => { const g = new THREE.Group(); g.visible = false; B.add(g); people[k] = { g, anim: null, clips: [] }; inst(n, 0.95).then((m) => { g.add(m); people[k].clips = m.userData.clips; people[k].anim = animator(m, m.userData.clips); people[k].anim.play(clip(m.userData.clips, /^idle$/i)); }).catch(() => { }); });

  /* ---------- камера ---------- */
  let portrait = false, focusRoom = null;
  const camT = new THREE.Vector3(0, 2, 16), lookT = new THREE.Vector3(), look = new THREE.Vector3();
  function overview() {
    const tan = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)), asp = camera.aspect || 1;
    const d = Math.max((BW * 0.62) / (tan * asp), (BH * 0.75) / tan);
    camT.set(0, 1.2, d); lookT.set(0, 0.2, 0);
  }
  function toRoom(id) {
    const r = rooms[id]; focusRoom = id;
    const p = new THREE.Vector3(); r.g.getWorldPosition(p);
    const tan = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)), asp = camera.aspect || 1;
    const d = Math.max((RW * 0.6) / (tan * asp), (RH * 0.95) / tan) + RD / 2;
    const yOff = portrait ? -0.95 : 0;
    camT.set(p.x + (portrait ? 0 : 0.9), p.y + RH * 0.55 + 0.35, p.z + d);
    lookT.set(p.x + (portrait ? 0 : 0.9), p.y + RH * 0.45 + yOff, p.z - 0.2);
  }
  W.onResize = (w, hh) => { portrait = w / hh < 0.8; camera.fov = portrait ? 46 : 34; camera.updateProjectionMatrix(); if (focusRoom) toRoom(focusRoom); else overview(); };

  /* ---------- сцена: розставити людей, світло ---------- */
  function stage(sc) {
    const id = rooms[sc.loc] ? sc.loc : 'lounge';
    toRoom(id);
    const r = rooms[id];
    Object.values(rooms).forEach((o) => { o.light.intensity = 0; o.lampM.color.setRGB(0.5, 0.5, 0.5); });
    const when = (sc.when && (sc.when.uk || sc.when[lang] || '')) + '';
    const night = /ніч|вечір|night|evening|ночь|вечер/i.test((sc.when && sc.when[lang]) || when); sceneNight = night;
    sky(night ? '#1b2440' : '#8fb4d8', night ? '#121a2c' : '#3c4c63');
    sun.intensity = night ? 0.12 : 1.5; hemi.intensity = night ? 0.18 : 0.55;
    Object.values(rooms).forEach((o) => { o.winM.color.setRGB(night ? 0.08 : 0.9, night ? 0.11 : 1.05, night ? 0.25 : 1.25); });
    r.light.intensity = night ? 1.6 : 0.9; r.lampM.color.setRGB(1.3, 1.22, 1.05);
    const pov = sc.pov === 'L' ? 'L' : 'A', other = pov === 'A' ? 'L' : 'A';
    const cast = ['icu', 'cardio', 'pulmo', 'nurses'].includes(id) ? [pov, 'N'] : id.startsWith('rehab') ? [pov, 'D'] : [pov, other];
    Object.values(people).forEach((p) => { p.g.visible = false; });
    cast.forEach((k, i) => {
      const p = people[k], sp = r.spots[i] || r.spots[0];
      p.g.visible = true;
      const wp = new THREE.Vector3(sp[0], sp[1], sp[2]); r.g.localToWorld(wp); B.worldToLocal(wp);
      p.g.position.copy(wp); p.g.rotation.y = sp[3] === 'sit' ? (id.startsWith('rehab') || ['icu', 'cardio', 'pulmo'].includes(id) ? Math.PI / 2 : 0) : -0.4 + i * 0.5;
      if (p.anim) p.anim.play(clip(p.clips, sp[3] === 'sit' ? /^sit$/i : /^idle$/i) || clip(p.clips, /^idle$/i));
    });
    r.bpm = (sc.v && sc.v.bpm) || 76;
  }

  /* ---------- текст: субтитри, бульбашки над головами, вибір — бульбашками ---------- */
  hud.innerHTML = `<div id="sSub" class="gg sSub" style="display:none"></div>
    <div id="sBub" class="sBub" style="display:none"></div>
    <div id="sChoice" class="sChoice" style="display:none"></div>
    <div id="sPanel"></div>
    <button class="gbtn" id="sMenu" style="position:absolute;right:10px;top:10px;height:40px;width:40px;padding:0" aria-label="${T.menu}">${gi('home', 22)}</button>
    <div id="sTraits" style="position:absolute;left:10px;top:10px;display:flex;gap:6px"></div>
    <div id="sProg" class="gg" style="position:absolute;left:10px;top:52px;padding:5px 12px;font:600 12px var(--fm);display:none;max-width:calc(100% - 70px);white-space:nowrap;overflow:hidden;text-overflow:ellipsis"></div>
    <style>
    .sSub{position:absolute;left:50%;bottom:calc(14px + env(safe-area-inset-bottom));transform:translateX(-50%);width:min(94%,620px);padding:14px 16px 10px;font:500 16px/1.5 var(--fb);color:#fff;animation:viewIn .35s var(--ease)}
    .sSub .who{display:block;font:600 11px var(--fm);letter-spacing:.06em;text-transform:uppercase;color:rgba(255,255,255,.6);margin-bottom:4px}
    .sSub .more{display:block;text-align:right;font:600 11px var(--fb);color:rgba(255,255,255,.5);margin-top:6px;animation:sBlink 1.4s ease-in-out infinite}
    .sBub{position:absolute;transform:translate(-50%,-100%);max-width:min(78vw,340px);padding:10px 14px;border-radius:20px;font:600 15px/1.4 var(--fb);color:#1a1d24;background:#fff;box-shadow:0 10px 28px rgba(0,0,0,.4);pointer-events:none;animation:viewIn .3s var(--spring)}
    .sBub::after{content:"";position:absolute;left:50%;bottom:-9px;margin-left:-9px;border:9px solid transparent;border-bottom:0;border-top-color:#fff}
    .sBub.L{background:#ffe3ea}.sBub.L::after{border-top-color:#ffe3ea}.sBub.A{background:#e3f8ff}.sBub.A::after{border-top-color:#e3f8ff}
    .sBub.th{font-style:italic;font-weight:500;background:rgba(255,248,225,.96);border-radius:26px}.sBub.th::after{width:12px;height:12px;border:0;border-radius:50%;background:rgba(255,248,225,.96);bottom:-16px;margin-left:-6px}
    .sChoice{position:absolute;left:50%;bottom:calc(14px + env(safe-area-inset-bottom));transform:translateX(-50%);width:min(94%,560px);display:flex;flex-direction:column;gap:8px;align-items:stretch}
    .sChoice b{font:600 13px var(--fb);color:rgba(255,255,255,.8);text-align:center;text-shadow:0 2px 8px rgba(0,0,0,.7)}
    .sChoice button{border:0;text-align:left;padding:12px 16px;border-radius:20px 20px 20px 6px;font:600 15px/1.35 var(--fb);color:#14202a;background:linear-gradient(180deg,#f3fcff,#d6f1fb);box-shadow:0 10px 24px -8px rgba(0,0,0,.6);cursor:pointer;animation:viewIn .4s var(--spring) both;transition:transform .2s}
    .sChoice button:active{transform:scale(.97)}
    @keyframes sBlink{50%{opacity:.3}}
    </style>`;
  const $ = (s) => hud.querySelector(s);
  const L = (o) => (o && (o[lang] || o.uk || o.ru)) || '';
  let story = null, pos = { s: 0, k: 0, c: 0 }, traits = { c: 0, o: 0, p: 0 }, chosen = null, storyKey = 'ch1', mode = 'home';
  function traitsHud() { $('#sTraits').innerHTML = storyKey === 'ch1' && mode === 'play' ? `<span class="gg" style="padding:6px 10px;display:flex;gap:10px;align-items:center;font:600 13px var(--fm)" title="${T.traits.c} · ${T.traits.o} · ${T.traits.p}"><span style="display:flex;gap:3px;align-items:center">${gi('joy', 16)}${traits.c}</span><span style="display:flex;gap:3px;align-items:center">${gi('star', 16)}${traits.o}</span><span style="display:flex;gap:3px;align-items:center">${gi('cal', 16)}${traits.p}</span></span>` : ''; }
  function panel(html) { $('#sPanel').innerHTML = html ? `<div class="gg gpop side story">${html}</div>` : ''; }
  // довгий абзац ділимо на шматки по 1–2 речення, щоб не було полотна тексту
  function chunks(t) { const parts = String(t).split(/\n\s*\n/).flatMap((par) => par.match(/[^.!?…]+[.!?…]+["»”’)]*\s*|[^.!?…]+$/g) || [par]); const out = []; let cur = ''; for (const p of parts) { if ((cur + p).length > 170 && cur) { out.push(cur.trim()); cur = p; } else cur += p; } if (cur.trim()) out.push(cur.trim()); return out.length ? out : [String(t)]; }
  let bubAt = null; // хто говорить: ключ персонажа
  function clearText() { $('#sSub').style.display = 'none'; $('#sBub').style.display = 'none'; $('#sChoice').style.display = 'none'; bubAt = null; }
  function render() {
    clearText(); panel('');
    const sc = story[pos.s];
    if (!sc) { mode = 'end'; endCard(); return; }
    $('#sProg').style.display = ''; $('#sProg').textContent = `${pos.s + 1}/${story.length} · ${L(sc.when)}`;
    const st = sc.steps[pos.k];
    if (!st) { pos.s++; if (pos.s >= story.length) { api.coins(5); api.pet('happy'); mode = 'end'; endCard(); return; } startScene(); return; }
    const pov = sc.pov === 'L' ? 'L' : 'A';
    if (st.k === 'p' || (st.k === 'c' && chosen !== null)) {
      const txt = st.k === 'p' ? L(st.t) : L(st.opts[chosen].r);
      const ch = chunks(txt); const k = Math.min(pos.c, ch.length - 1);
      $('#sSub').innerHTML = `${st.k === 'c' ? `<span class="who">${esc(L(st.opts[chosen].l))}</span>` : ''}${esc(ch[k])}<span class="more">${esc(T.tapOn)} ${k + 1 < ch.length ? '· ' + (k + 1) + '/' + ch.length : ''}</span>`;
      $('#sSub').style.display = ''; return;
    }
    if (st.k === 'th') { const b = $('#sBub'); b.className = 'sBub th'; b.textContent = L(st.t); b.style.display = ''; bubAt = pov; return; }
    if (st.k === 'm') { const who = st.f === 'L' ? 'L' : st.f === 'A' ? 'A' : pov; const b = $('#sBub'); b.className = 'sBub ' + who; b.innerHTML = `<span style="display:block;font:600 10px var(--fm);opacity:.6;text-transform:uppercase">${esc(L(NAMES[st.f] || {}))}</span>${esc(L(st.t))}`; b.style.display = ''; bubAt = people[who] && people[who].g.visible ? who : pov; return; }
    if (st.k === 'c') {
      const c = $('#sChoice'); c.innerHTML = `<b>${esc(L(st.q) || T.what)}</b>` + st.opts.map((o, i) => `<button data-s="choose" data-v="${i}" style="animation-delay:${i * 0.08}s">${esc(L(o.l))}</button>`).join('');
      c.style.display = ''; return;
    }
  }
  function step() {
    if (mode !== 'play') return;
    const sc = story[pos.s]; const st = sc && sc.steps[pos.k];
    if (st && st.k === 'c' && chosen === null) return;
    if (st && (st.k === 'p' || st.k === 'c')) { const n = chunks(st.k === 'p' ? L(st.t) : L(st.opts[chosen].r)).length; if (pos.c + 1 < n) { pos.c++; render(); api.sfx('page'); return; } }
    chosen = null; pos.k++; pos.c = 0;
    if (storyKey === 'ch1') api.store.set('pos', pos);
    api.sfx('page'); render();
  }
  function startScene() { SFX('whoosh', { vol: 0.5 }); if (storyKey === 'ch1') api.store.set('total', story.length); mode = 'play'; pos.k = 0; pos.c = 0; chosen = null; stage(story[pos.s] || story[story.length - 1]); signs.visible = false; traitsHud(); render(); if (storyKey === 'ch1') api.store.set('pos', pos); placePet(); }
  function endCard() { clearText(); $('#sProg').style.display = 'none'; panel(`<span class="gtitle" style="display:flex;gap:8px;align-items:center">${gi('trophy', 26)} ${T.end}</span><span class="gsub" style="text-align:center">${esc(T.tapOn)}</span>`); $('#sPanel').onclick = () => { $('#sPanel').onclick = null; home(); }; }
  // торкання сцени: далі; торкання улюбленця — він радіє
  W.canvas.addEventListener('click', (e) => {
    if (petO && mode === 'play') { const hit = W.pick(e, [petO]); if (hit) { petPlay('happy'); api.pet('happy'); api.sfx(api.petModel && api.petModel.includes('cat') ? 'purr' : 'yip'); return; } }
    if (mode === 'home') { const hit = W.pick(e, signs.children); if (hit) { const u = hit.obj.userData.pick; if (u.kind === 'story') startStory(api.store.get('pos', null) ? 'cont' : 'restart'); else if (u.kind === 'own') { editing = -1; editor(); } } return; }
    step();
  });
  let holdT = null;
  W.canvas.addEventListener('pointerdown', (e) => { if (mode !== 'home') return; const hit = W.pick(e, signs.children); if (hit && hit.obj.userData.pick.kind === 'story') holdT = setTimeout(() => { holdT = null; startStory('restart'); api.sfx('ok'); }, 650); });
  W.canvas.addEventListener('pointerup', () => { clearTimeout(holdT); });
  hud.addEventListener('click', (e) => { if (e.target === hud || e.target.closest('#sSub') || e.target.closest('#sBub')) step(); });
  async function startStory(how) { storyKey = 'ch1'; story = await loadCH(); if (how === 'restart') { pos = { s: 0, k: 0, c: 0 }; traits = { c: 0, o: 0, p: 0 }; api.store.set('traits', traits); } else { pos = Object.assign({ s: 0, k: 0, c: 0 }, api.store.get('pos', {})); traits = api.store.get('traits', traits); } startScene(); }

  /* ---------- улюбленець гравця приходить провідати ---------- */
  let petO = null, petAnim = null, petClips = [], petProc = null;
  const petPlay = (st) => { if (petProc) { petProc.set(st === 'happy' ? 'jump' : st); if (st === 'happy') setTimeout(() => petProc.set('sit'), 900); } else if (petAnim) { const c = st === 'happy' ? clip(petClips, /^jump_toidle$/i, /^jump$/i, /^yes$/i) : clip(petClips, /^idle$/i, /^idle/i); if (st === 'happy') petAnim.play(c, { once: true, then: () => petPlay('idle') }); else petAnim.play(c); } };
  if (api.petModel && api.petModel.startsWith('proc:cat')) { petO = makeCat({ coat: api.petModel.split(':')[2] }); petO.scale.setScalar(0.62); petProc = petO.userData.cat; petProc.set('sit'); }
  else if (api.petModel) inst(api.petModel, 0.36, { tint: api.petTint }).then((m) => { petO = m; petClips = m.userData.clips; petAnim = animator(m, petClips); petPlay('idle'); placePet(); }).catch(() => { });
  if (petO) { petO.visible = false; B.add(petO); }
  function placePet() {
    if (!petO) return; if (!petO.parent) B.add(petO);
    const r = focusRoom && rooms[focusRoom]; if (!r || mode !== 'play') { petO.visible = false; return; }
    const wp = new THREE.Vector3(1.05, 0, 0.75); r.g.localToWorld(wp); B.worldToLocal(wp); petO.position.copy(wp); petO.rotation.y = -0.6; petO.visible = true;
  }

  /* ---------- меню на самій сцені: табличка історії й блокнот ---------- */
  const signs = new THREE.Group(); B.add(signs);
  { const st = tagSprite(giSvg('play'), T.story1, { scale: 0.75, bg: 'rgba(214,64,64,.92)' }); st.position.set(0, 3 * (RH + 0.14) + 1.25, 0.6); st.userData.pick = { kind: 'story' }; signs.add(st);
    const sub = label(T.holdRestart, { scale: 0.26, bg: 'rgba(10,12,18,.6)' }); sub.position.set(0, 3 * (RH + 0.14) + 0.75, 0.6); signs.add(sub);
    const ow = tagSprite(giSvg('chat'), T.own, { scale: 0.55 }); ow.position.set(3 * RW / 2 + 0.9, 0.9, 1.6); ow.userData.pick = { kind: 'own' }; signs.add(ow); }

  /* ---------- меню й редактор ---------- */
  let own = api.store.get('own', []);
  function home() {
    mode = 'home'; focusRoom = null; overview(); Object.values(people).forEach((p) => p.g.visible = false);
    clearText(); panel(''); $('#sProg').style.display = 'none'; signs.visible = true; storyKey = 'ch1'; traitsHud(); placePet();
  }
  let editing = -1;
  function editor() {
    if (editing >= 0) {
      const sc = own[editing] || { loc: 'lounge', title: '', text: '', q: '', o1: '', r1: '', o2: '', r2: '' };
      const opts = Object.keys(LAYOUT).map((k) => `<option value="${k}" ${sc.loc === k ? 'selected' : ''}>${T.rooms[k]}</option>`).join('');
      const inp = 'style="width:100%;box-sizing:border-box;background:rgba(0,0,0,.25);border:1px solid rgba(255,255,255,.18);border-radius:12px;color:#fff;font:15px var(--fb);padding:10px"';
      panel(`<span class="gtitle">${T.edit}</span>
        <label class="gsub">${T.room}<select id="eLoc" ${inp}>${opts}</select></label>
        <label class="gsub">${T.sceneTitle}<input id="eTitle" ${inp} value="${esc(sc.title)}"></label>
        <label class="gsub">${T.text}<textarea id="eText" rows="5" ${inp}>${esc(sc.text)}</textarea></label>
        <button class="gbtn" data-s="aiHelp" style="justify-content:flex-start">${gi('bulb', 18)} ${T.aiHelp}</button>
        <label class="gsub">${T.question}<input id="eQ" ${inp} value="${esc(sc.q)}"></label>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px"><input id="eO1" ${inp} placeholder="${T.opt} 1" value="${esc(sc.o1)}"><input id="eO2" ${inp} placeholder="${T.opt} 2" value="${esc(sc.o2)}"><textarea id="eR1" rows="2" ${inp} placeholder="${T.resp} 1">${esc(sc.r1)}</textarea><textarea id="eR2" rows="2" ${inp} placeholder="${T.resp} 2">${esc(sc.r2)}</textarea></div>
        <div style="display:flex;gap:8px"><button class="gbtn prim" data-s="saveScene" style="flex:1">${T.save}</button>${editing < own.length ? `<button class="gbtn" data-s="delScene">${T.del}</button>` : ''}<button class="gbtn" data-s="editList">${T.back}</button></div>`);
      const sel = $('#eLoc'); sel.addEventListener('change', () => toRoom(sel.value)); toRoom(sc.loc);
      return;
    }
    panel(`<span class="gtitle">${T.own} · ${T.scenes}</span>
      ${own.length ? own.map((s, i) => `<button class="gbtn" data-s="editScene" data-v="${i}" style="justify-content:flex-start">${i + 1}. ${esc(s.title || T.rooms[s.loc])} · <span class="gsub">${T.rooms[s.loc]}</span></button>`).join('') : `<span class="gsub">${T.empty}</span>`}
      <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="gbtn prim" data-s="editScene" data-v="${own.length}" style="flex:1">${gi('plus', 18)} ${T.addScene}</button>${own.length ? `<button class="gbtn" data-s="playOwn">${gi('play', 18)} ${T.play}</button>` : ''}<button class="gbtn" data-s="home">${T.back}</button></div>`);
  }
  function ownToStory() {
    const w = (t) => ({ uk: t, en: t, ru: t });
    return own.map((s) => ({ title: w(s.title || T.rooms[s.loc]), when: w(T.rooms[s.loc]), pov: 'A', loc: s.loc, v: { bpm: 74 }, steps: [...s.text.split(/\n\s*\n/).filter((x) => x.trim()).map((x) => ({ k: 'p', t: w(x.trim()) })), ...(s.q && s.o1 ? [{ k: 'c', q: w(s.q), opts: [{ l: w(s.o1), r: w(s.r1 || '…') }, ...(s.o2 ? [{ l: w(s.o2), r: w(s.r2 || '…') }] : [])] }] : [])] }));
  }
  hud.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-s]'); if (!b) return; e.stopPropagation(); const a = b.dataset.s, v = +b.dataset.v;
    api.sfx(a === 'choose' ? 'choose' : 'tap');
    if (a === 'choose') { const st = story[pos.s].steps[pos.k]; chosen = v; pos.c = 0; const fx2 = st.opts[v].fx || {}; for (const k in fx2) if (k in traits) traits[k] += fx2[k]; if (storyKey === 'ch1') api.store.set('traits', traits); traitsHud(); render(); }
    else if (a === 'home') home();
    else if (a === 'editor' || a === 'editList') { mode = 'edit'; editing = -1; editor(); }
    else if (a === 'editScene') { mode = 'edit'; editing = v; editor(); }
    else if (a === 'aiHelp') {
      const ta = $('#eText'), btn = b; btn.disabled = true; const was = btn.innerHTML; btn.textContent = '…';
      const room = T.rooms[$('#eLoc').value] || '', title = $('#eTitle').value, txt = ta.value.trim();
      const ans = api.ask ? await api.ask('story', `Мова відповіді: ${{ uk: 'українська', en: 'English', ru: 'русский' }[lang]}. Місце: лікарня, кімната «${room}». Назва сцени: «${title}». Це історія про підлітків, що одужують після аварії; тон — теплий і чесний.`, txt ? `Продовж цю сцену 2–4 реченнями:\n${txt.slice(-1200)}` : 'Запропонуй початок сцени: 2–4 речення.') : '';
      btn.disabled = false; btn.innerHTML = was;
      if (ans) { ta.value = (txt ? txt + '\n\n' : '') + ans.trim(); api.sfx('ok'); } else api.toast(T.aiNo);
    }
    else if (a === 'saveScene') { own[editing] = { loc: $('#eLoc').value, title: $('#eTitle').value, text: $('#eText').value, q: $('#eQ').value, o1: $('#eO1').value, r1: $('#eR1').value, o2: $('#eO2').value, r2: $('#eR2').value }; api.store.set('own', own); editing = -1; editor(); api.sfx('ok'); }
    else if (a === 'delScene') { own.splice(editing, 1); api.store.set('own', own); editing = -1; editor(); }
    else if (a === 'playOwn') { storyKey = 'own'; story = ownToStory(); pos = { s: 0, k: 0, c: 0 }; startScene(); }
  });
  $('#sMenu').addEventListener('click', (e) => { e.stopPropagation(); api.sfx('tap'); home(); });
  async function loadCH() { if (!CH) CH = (await import('./istorii_ch1.js')).default; return CH; }

  /* ---------- кадр ---------- */
  W.onFrame((dt, tm) => {
    SND.amb.set('room', mode === 'play' ? 0.9 : 0.5, { clock: focusRoom === 'lounge' || focusRoom === 'lobby' });
    SND.amb.set('birds', mode === 'play' && !sceneNight && /lounge|rehab|lobby/.test(focusRoom || '') ? 0.18 : 0);
    SND.amb.tick(dt);
    camera.position.lerp(camT, Math.min(1, dt * 2.2));
    look.lerp(lookT, Math.min(1, dt * 2.6)); camera.lookAt(look);
    Object.values(people).forEach((p) => { if (p.anim && p.g.visible) p.anim.update(dt); });
    if (petO && petO.visible) { if (petAnim) petAnim.update(dt); if (petProc) petProc.update(dt); }
    if (bubAt && people[bubAt]) { const v = people[bubAt].g.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, 1.12, 0)); const q = W.screen(v), e = $('#sBub'), { W: vw } = W.size(), hw = e.offsetWidth / 2 + 8; e.style.left = THREE.MathUtils.clamp(q.x, hw, vw - hw) + 'px'; e.style.top = Math.max(e.offsetHeight + 60, q.y) + 'px'; }
    // монітор: живий пульс сцени
    const r = focusRoom && rooms[focusRoom];
    if (r && r.mon) {
      const m = r.mon, g = m.cv.getContext('2d'), bpm = r.bpm || 76;
      if (!m.init) { g.fillStyle = '#04110c'; g.fillRect(0, 0, 256, 160); m.init = true; }
      const per = 60 / bpm, ph0 = (m.t % per) / per; m.t += dt; const ph1 = (m.t % per) / per;
      if (mode === 'play' && ((ph0 < 0.1 && ph1 >= 0.1) || (ph1 < ph0 && ph1 >= 0.1))) SFX('beat', { vol: sceneNight ? 0.45 : 0.6 }); // «піп» разом зі сплеском на екрані
      const steps = Math.max(1, Math.round(dt * 90));
      for (let i = 0; i < steps; i++) {
        m.x = (m.x + 1) % 256; const ph = ((m.t + i / 90) % per) / per;
        const y = 80 - (ph > 0.1 && ph < 0.13 ? 50 : ph > 0.13 && ph < 0.16 ? -20 : ph > 0.3 && ph < 0.4 ? 8 : 0);
        g.fillStyle = '#04110c'; g.fillRect(m.x, 0, 8, 120);
        g.strokeStyle = '#46ff9a'; g.lineWidth = 2.5; g.beginPath(); g.moveTo(m.x - 1, m.last); g.lineTo(m.x, y); g.stroke(); m.last = y;
      }
      g.fillStyle = '#04110c'; g.fillRect(0, 122, 256, 38); g.fillStyle = '#46ff9a'; g.font = 'bold 26px JetBrains Mono, monospace'; g.fillText(`♥ ${bpm}`, 10, 152);
      m.tex.needsUpdate = true;
    }
  });

  overview();
  home();
  root._dbg = { startScene, toRoom, stage: (i) => loadCH().then((c) => { story = c; pos = { s: i, k: 0 }; startScene(); }) };
  return { destroy: () => { SND.stop(); W.destroy(); } };
}
