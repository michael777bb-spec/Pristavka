// Звук Planetar: один рушій для приставки й усіх ігор. Усе синтезується в браузері —
// без звукових файлів, тому працює й без інтернету.
//
// Правила міксу (їх перевіряє тест tools/sound_check.py):
//  1. Важливе звучить у смузі 300 Гц – 5 кГц. Динамік телефона нижче ~250 Гц майже не грає,
//     тож кожен «бас» має відгук вище (гармоніки, клац, шурхіт).
//  2. Жодних голих синусів-пищалок: у звуку є атака, тіло і хвіст; мелодійне — «молоточком» (як маримба).
//  3. Групи гучності: ui (кнопки) — тихо й коротко; fx (дії у світі); amb (фон) — найтихіше; voice (тварини).
//  4. Вимикач діє миттєво: головна гучність → 0, разом із фоновими петлями; у фоновій вкладці звук на паузі.
//  5. Звук із місця у світі: панорама за положенням на екрані, гучність — за відстанню до камери.

let A = null, TEST = null, G = null, NOISE = null, PW = null;
const muted = () => !!window.__planetarMute;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const R = (a, b) => a + Math.random() * (b - a);

export function audioCtx() {
  if (TEST) return TEST;
  if (!A) { const C = window.AudioContext || window.webkitAudioContext; if (!C) return null; A = new C({ latencyHint: 'interactive' }); }
  if (A.state === 'suspended' && !document.hidden && !muted()) A.resume().catch(() => { });
  return A;
}
export function noiseBuf() {
  const a = audioCtx(); if (NOISE && NOISE.sampleRate === a.sampleRate) return NOISE;
  const n = a.sampleRate * 2, b = a.createBuffer(1, n, a.sampleRate), d = b.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
  NOISE = b; return b;
}
// коротка «кімната» — щоб звуки не були сухими й пласкими
function makeIR(a, sec) {
  const n = Math.floor(a.sampleRate * sec), b = a.createBuffer(2, n, a.sampleRate);
  for (let c = 0; c < 2; c++) {
    const d = b.getChannelData(c); let lp = 0;
    for (let i = 0; i < n; i++) { const t = i / a.sampleRate; lp += (Math.random() * 2 - 1 - lp) * (0.55 - 0.4 * (t / sec)); d[i] = lp * Math.exp(-t / (sec * 0.28)) * (t < 0.008 ? t / 0.008 : 1); }
  }
  return b;
}
const LEVEL = { ui: 0.5, fx: 0.78, amb: 0.42, voice: 0.85 };
function graph() {
  const a = audioCtx(); if (!a) return null;
  if (G && G.a === a) { syncMute(); return G; }
  const master = a.createGain(); master.gain.value = muted() && !TEST ? 0 : 1;
  const hp = a.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 70; hp.Q.value = 0.6;
  const comp = a.createDynamicsCompressor(); comp.threshold.value = -16; comp.knee.value = 12; comp.ratio.value = 3.5; comp.attack.value = 0.004; comp.release.value = 0.25;
  const lim = a.createDynamicsCompressor(); lim.threshold.value = -2; lim.knee.value = 0; lim.ratio.value = 20; lim.attack.value = 0.001; lim.release.value = 0.08;
  master.connect(hp); hp.connect(comp); comp.connect(lim); lim.connect(a.destination);
  const verb = a.createConvolver(); verb.buffer = makeIR(a, 1.3); const vg = a.createGain(); vg.gain.value = 0.55; verb.connect(vg); vg.connect(master);
  const bus = {}; for (const [k, v] of Object.entries(LEVEL)) { const g = a.createGain(); g.gain.value = v; g.connect(master); bus[k] = g; }
  G = { a, master, verb, bus, mute: muted() && !TEST };
  return G;
}
function syncMute() {
  if (!G || TEST) return; const m = muted(); if (m === G.mute) return; G.mute = m;
  const t = G.a.currentTime; G.master.gain.cancelScheduledValues(t); G.master.gain.setTargetAtTime(m ? 0 : 1, t, 0.03);
  if (m) setTimeout(() => { if (muted() && A && A.state === 'running') A.suspend().catch(() => { }); }, 200);
  else if (A && A.state !== 'running' && !document.hidden) A.resume().catch(() => { });
}
// вимикач у приставці кличе це одразу після зміни window.__planetarMute
export function soundSync() { if (G) syncMute(); else if (!muted() && A) A.resume().catch(() => { }); }
export function bus(name = 'fx') { const g = graph(); return g ? g.bus[name] || g.bus.fx : null; }
if (typeof document !== 'undefined') {
  document.addEventListener('visibilitychange', () => { if (!A) return; if (document.hidden) A.suspend().catch(() => { }); else if (!muted()) A.resume().catch(() => { }); });
  // iOS і Chrome вмикають звук лише після дотику: перший дотик «будить» контекст
  const wake = () => { if (A && A.state !== 'running' && !muted() && !document.hidden) A.resume().catch(() => { }); };
  ['pointerdown', 'touchend', 'keydown'].forEach((e) => window.addEventListener(e, wake, { capture: true, passive: true }));
}

/* ---------------- примітиви ----------------
   m — «мікс» одного звуку: { a, t (час старту), out (вхід: гучність → панорама → група + відлуння) } */
let live = 0;
const track = (s) => { live++; s.onended = () => { live = Math.max(0, live - 1); }; return s; };
function mix(g, o = {}, busName = 'fx', verb = 0) {
  const a = g.a, out = a.createGain(); out.gain.value = clamp(o.vol ?? 1, 0, 2);
  let tail = g.bus[busName] || g.bus.fx;
  if (o.pan && a.createStereoPanner) { const p = a.createStereoPanner(); p.pan.value = clamp(o.pan, -1, 1); p.connect(tail); tail = p; }
  out.connect(tail);
  const v = verb + (o.verb || 0); if (v > 0) { const s = a.createGain(); s.gain.value = v; out.connect(s); s.connect(g.verb); }
  return { a, out, t: a.currentTime + 0.006 + (o.delay || 0) };
}
function envGain(m, t, att, dur, peak, hold = 0) {
  const g = m.a.createGain(), p = g.gain; p.setValueAtTime(0.0001, t);
  p.exponentialRampToValueAtTime(Math.max(0.0002, peak), t + att); if (hold) p.setValueAtTime(Math.max(0.0002, peak), t + att + hold);
  p.exponentialRampToValueAtTime(0.0001, t + dur); return g;
}
// тон: f → f1 (ковзання), фільтр за бажанням
function osc(m, { type = 'sine', f = 440, f1, t = 0, dur = 0.2, att = 0.005, peak = 0.1, hold = 0, lin = false, lp, bp, q = 1, wave, vib = 0, vibF = 6 }) {
  const a = m.a, t0 = m.t + t, o = a.createOscillator();
  if (wave) o.setPeriodicWave(wave); else o.type = type;
  o.frequency.setValueAtTime(f, t0); if (f1 && f1 !== f) (lin ? o.frequency.linearRampToValueAtTime(f1, t0 + dur) : o.frequency.exponentialRampToValueAtTime(f1, t0 + dur));
  if (vib) { const l = a.createOscillator(), lg = a.createGain(); l.frequency.value = vibF; lg.gain.value = vib; l.connect(lg); lg.connect(o.frequency); l.start(t0); l.stop(t0 + dur + 0.05); }
  const g = envGain(m, t0, att, dur, peak, hold); let n = o;
  if (lp || bp) { const fl = a.createBiquadFilter(); fl.type = bp ? 'bandpass' : 'lowpass'; fl.frequency.value = bp || lp; fl.Q.value = q; o.connect(fl); n = fl; }
  n.connect(g); g.connect(m.out); track(o); o.start(t0); o.stop(t0 + dur + 0.03); return o;
}
// шум через фільтр: f → f1
function nz(m, { t = 0, dur = 0.2, att = 0.005, peak = 0.1, hold = 0, f = 1200, f1, q = 1, type = 'bandpass', hp }) {
  const a = m.a, t0 = m.t + t, s = a.createBufferSource(); s.buffer = noiseBuf();
  const fl = a.createBiquadFilter(); fl.type = type; fl.frequency.setValueAtTime(f, t0); if (f1) fl.frequency.exponentialRampToValueAtTime(f1, t0 + dur); fl.Q.value = q;
  const g = envGain(m, t0, att, dur, peak, hold); s.connect(fl);
  if (hp) { const h2 = a.createBiquadFilter(); h2.type = 'highpass'; h2.frequency.value = hp; fl.connect(h2); h2.connect(g); } else fl.connect(g);
  g.connect(m.out); track(s); s.start(t0, Math.random() * 1.5); s.stop(t0 + dur + 0.03); return s;
}
const click = (m, { t = 0, f = 2600, q = 1.2, peak = 0.3, dur = 0.012 } = {}) => nz(m, { t, f, q, peak, dur, att: 0.001 });
// металеві й скляні звуки: набір негармонійних обертонів, кожен згасає по-своєму
const METAL = [[1, 1, 1], [2.32, 0.5, 0.7], [4.25, 0.28, 0.45], [6.63, 0.14, 0.3]];
const COIN = [[1, 1, 1], [1.5, 0.35, 0.8], [2.76, 0.3, 0.5], [5.4, 0.12, 0.3]];
const GLASS = [[1, 1, 1], [2.01, 0.3, 0.6], [3.98, 0.15, 0.35]];
function bell(m, { f, t = 0, dur = 0.5, peak = 0.1, parts = METAL }) {
  for (const [r, amp, dk] of parts) if (f * r < 9000) osc(m, { f: f * r, t, dur: dur * dk, att: 0.002, peak: peak * amp });
}
// «молоточок» (маримба): основний тон + обертон ×3.9 + легкий стук
function mallet(m, { f, t = 0, peak = 0.16, dur = 0.42, soft = 0 }) {
  osc(m, { type: soft ? 'sine' : 'triangle', f, t, dur, att: 0.003, peak });
  osc(m, { f: f * 3.93, t, dur: dur * 0.25, att: 0.002, peak: peak * (soft ? 0.12 : 0.3) });
  if (!soft) osc(m, { f: f * 9.8, t, dur: 0.05, att: 0.001, peak: peak * 0.08 });
  click(m, { t, f: Math.min(5000, f * 3), q: 2, peak: peak * 0.6, dur: 0.008 });
}
// бульбашка/крапля: синус, що швидко ковзає вгору (так звучить вода)
const drop = (m, { t = 0, f = 900, k = 1.7, dur = 0.05, peak = 0.1 }) => osc(m, { f, f1: f * k, t, dur, att: 0.002, peak });
// голос тварини чи птаха: пилка через три смуги голосних (форманти)
const VOW = { i: [300, 2300, 3000], e: [500, 1900, 2600], a: [800, 1250, 2600], o: [500, 900, 2400], u: [350, 750, 2300] };
function vox(m, { t = 0, dur = 0.3, f0, vow, peak = 0.2, rough = 0, breath = 0.1, vib = 0, vibF = 6 }) {
  const a = m.a, t0 = m.t + t, o = a.createOscillator(); o.type = 'sawtooth';
  f0.forEach(([k, f], i) => (i ? o.frequency.exponentialRampToValueAtTime(f, t0 + k * dur) : o.frequency.setValueAtTime(f, t0)));
  if (vib) { const l = a.createOscillator(), lg = a.createGain(); l.frequency.value = vibF; lg.gain.value = vib; l.connect(lg); lg.connect(o.frequency); l.start(t0); l.stop(t0 + dur + 0.05); }
  const src = a.createGain(); o.connect(src);
  if (rough) { const n = a.createBufferSource(); n.buffer = noiseBuf(); const ng = a.createGain(); ng.gain.value = rough; n.connect(ng); ng.connect(src); n.start(t0, Math.random()); n.stop(t0 + dur + 0.05); }
  const g = envGain(m, t0, Math.min(0.03, dur / 5), dur, peak);
  [0, 1, 2].forEach((fi) => {
    const fl = a.createBiquadFilter(); fl.type = 'bandpass'; fl.Q.value = fi ? 8 : 4;
    vow.forEach(([k, v], i) => { const hz = VOW[v][fi]; i ? fl.frequency.linearRampToValueAtTime(hz, t0 + k * dur) : fl.frequency.setValueAtTime(hz, t0); });
    const fg = a.createGain(); fg.gain.value = [1, 0.6, 0.25][fi]; src.connect(fl); fl.connect(fg); fg.connect(g);
  });
  if (breath) nz(m, { t, dur, f: 2600, q: 0.6, peak: peak * breath, att: 0.02 });
  g.connect(m.out); track(o); o.start(t0); o.stop(t0 + dur + 0.05);
}

/* ---------------- бібліотека звуків ----------------
   кожен: (m, x) — m мікс, x — необов'язковий параметр (сила, кількість) */
const UI = new Set(['tap', 'pop', 'ok', 'bad', 'place', 'pencil', 'erase', 'page', 'choose', 'toggle', 'coinpop']);
const VERB = { ok: 0.12, win: 0.25, coin: 0.12, stage: 0.3, sleep: 0.45, choose: 0.15, beat: 0.2, data: 0.25, shield: 0.2, rooster: 0.15, thunder: 0.2, bell: 0.3 };
const LIB = {
  // ---- інтерфейс: тихо, коротко, «дерев'яно» ----
  tap: (m) => { click(m, { f: 2200, q: 1.2, peak: 0.9, dur: 0.014 }); osc(m, { type: 'triangle', f: 1180, f1: 960, dur: 0.05, peak: 0.22 }); },
  toggle: (m) => { click(m, { f: 1600, q: 2, peak: 0.7, dur: 0.014 }); click(m, { t: 0.035, f: 2100, q: 2, peak: 0.45 }); osc(m, { type: 'triangle', f: 900, f1: 700, dur: 0.05, peak: 0.08 }); },
  pop: (m) => { osc(m, { f: 420, f1: 1020, dur: 0.075, peak: 0.45, att: 0.004 }); click(m, { f: 1800, peak: 0.3, dur: 0.008 }); },
  ok: (m) => { mallet(m, { f: 784, peak: 0.17 }); mallet(m, { f: 1175, t: 0.085, peak: 0.15 }); },
  bad: (m) => { mallet(m, { f: 392, peak: 0.14, soft: 1, dur: 0.3 }); mallet(m, { f: 330, t: 0.11, peak: 0.13, soft: 1, dur: 0.38 }); },
  win: (m) => { [523, 659, 784, 1047].forEach((f, i) => mallet(m, { f, t: i * 0.09, peak: 0.15 })); bell(m, { f: 2093, t: 0.36, dur: 1.1, peak: 0.05, parts: GLASS }); },
  coin: (m) => { bell(m, { f: 1976, dur: 0.35, peak: 0.12, parts: COIN }); bell(m, { f: 2637, t: 0.07, dur: 0.55, peak: 0.11, parts: COIN }); },
  coinpop: (m) => bell(m, { f: 2960, dur: 0.16, peak: 0.12, parts: COIN }),
  cash: (m) => { nz(m, { f: 900, f1: 2200, q: 0.8, dur: 0.18, peak: 0.08, att: 0.03 }); bell(m, { f: 3136, t: 0.12, dur: 0.7, peak: 0.08, parts: COIN }); bell(m, { f: 2349, t: 0.16, dur: 0.6, peak: 0.07, parts: COIN }); },
  whoosh: (m) => nz(m, { dur: 0.32, f: 500, f1: 1800, q: 0.9, peak: 0.16, att: 0.12 }),
  grow: (m) => { [392, 494, 587, 784].forEach((f, i) => osc(m, { type: 'triangle', f, t: i * 0.06, dur: 0.5, att: 0.04, peak: 0.05 })); nz(m, { t: 0.1, dur: 0.4, f: 5000, q: 0.7, peak: 0.03, att: 0.1 }); },
  step: (m) => { click(m, { f: 1100, q: 0.8, peak: 0.6, dur: 0.02 }); nz(m, { dur: 0.06, f: 700, q: 1, peak: 0.3 }); },
  place: (m) => { click(m, { f: 1500, q: 1, peak: 0.9, dur: 0.012 }); nz(m, { dur: 0.06, f: 950, q: 2.5, peak: 0.6 }); osc(m, { type: 'triangle', f: 520, f1: 360, dur: 0.07, peak: 0.25 }); },
  pencil: (m) => { nz(m, { dur: 0.05, f: 3200, q: 0.8, peak: 0.16 }); nz(m, { t: 0.06, dur: 0.045, f: 2900, q: 0.8, peak: 0.13 }); },
  erase: (m) => nz(m, { dur: 0.16, f: 2000, f1: 1500, q: 0.6, peak: 0.14, att: 0.03 }),
  page: (m) => { nz(m, { dur: 0.18, f: 2300, f1: 1500, q: 0.7, peak: 0.15, att: 0.04 }); nz(m, { t: 0.05, dur: 0.06, f: 4200, q: 1, peak: 0.04 }); },
  choose: (m) => { click(m, { f: 2000, q: 1.5, peak: 0.15 }); mallet(m, { f: 659, peak: 0.12, soft: 1, dur: 0.35 }); mallet(m, { f: 988, t: 0.07, peak: 0.1, soft: 1, dur: 0.4 }); },
  // ---- удари й метал ----
  hit: (m) => { click(m, { f: 1600, q: 0.9, peak: 0.7, dur: 0.016 }); nz(m, { dur: 0.13, f: 900, f1: 420, q: 1, peak: 0.7 }); osc(m, { type: 'triangle', f: 320, f1: 180, dur: 0.1, peak: 0.12 }); },
  clunk: (m) => { click(m, { f: 2200, q: 1, peak: 0.3 }); nz(m, { dur: 0.14, f: 850, q: 1.4, peak: 0.3 }); bell(m, { f: 430, dur: 0.3, peak: 0.1 }); osc(m, { type: 'triangle', f: 190, f1: 120, dur: 0.12, peak: 0.2 }); },
  hiss: (m) => nz(m, { dur: 0.5, att: 0.06, f: 3000, q: 0.5, peak: 0.12 }),
  ratchet: (m, n = 6) => { for (let i = 0; i < n; i++) click(m, { t: i * 0.055, f: R(3000, 3800), q: 3.5, peak: 0.32, dur: 0.008 }); bell(m, { f: 1250, t: n * 0.055, dur: 0.25, peak: 0.05 }); },
  wrench: (m) => { click(m, { f: 3000, q: 2, peak: 0.25 }); bell(m, { f: 1320, dur: 0.35, peak: 0.1 }); },
  build: (m) => { for (let i = 0; i < 3; i++) { click(m, { t: i * 0.2, f: 2400, q: 1, peak: 0.35 }); nz(m, { t: i * 0.2, dur: 0.07, f: 1400, q: 1.2, peak: 0.22 }); osc(m, { type: 'triangle', t: i * 0.2, f: 520, f1: 380, dur: 0.08, peak: 0.12 }); } LIB.ok({ ...m, t: m.t + 0.66 }); },
  reverse: (m, n = 3) => { for (let i = 0; i < n; i++) osc(m, { type: 'square', f: 1180, t: i * 0.34, dur: 0.17, att: 0.004, hold: 0.12, peak: 0.035, lp: 2600 }); },
  horn: (m) => { osc(m, { type: 'square', f: 349, dur: 0.38, att: 0.02, hold: 0.28, peak: 0.05, lp: 1500 }); osc(m, { type: 'square', f: 440, dur: 0.38, att: 0.02, hold: 0.28, peak: 0.045, lp: 1500 }); },
  dig: (m) => { click(m, { f: 1200, q: 1, peak: 0.45, dur: 0.012 }); nz(m, { dur: 0.13, f: 650, q: 1, peak: 0.45 }); nz(m, { t: 0.02, dur: 0.08, f: 2500, q: 0.8, peak: 0.1 }); },
  crank: (m) => { for (let i = 0; i < 5; i++) nz(m, { t: i * 0.085, dur: 0.07, f: 820, q: 1.5, peak: 0.22, att: 0.01 }); nz(m, { t: 0.45, dur: 0.2, f: 520, q: 0.9, peak: 0.4, att: 0.005 }); click(m, { t: 0.45, f: 1400, peak: 0.3 }); },
  crankFail: (m) => { let t = 0; for (let i = 0; i < 6; i++) { nz(m, { t, dur: 0.07, f: 780 - i * 40, q: 1.5, peak: 0.22 - i * 0.025, att: 0.01 }); t += 0.09 + i * 0.012; } click(m, { t: t + 0.05, f: 1600, peak: 0.25 }); },
  stall: (m) => { [0.3, 0.2, 0.1].forEach((pk, i) => nz(m, { t: i * 0.13, dur: 0.11, f: 600, q: 1, peak: pk })); },
  flutter: (m) => { for (let i = 0; i < 10; i++) nz(m, { t: i * 0.036, dur: 0.03, f: 1300, q: 0.8, peak: 0.16 * (1 - i / 12) }); },
  // ---- рідини ----
  pour: (m) => { nz(m, { dur: 0.7, f: 1600, q: 0.8, peak: 0.12, att: 0.08 }); for (let i = 0; i < 10; i++) drop(m, { t: R(0.02, 0.6), f: R(500, 1300), peak: 0.07 }); },
  fuel: (m) => { click(m, { f: 1500, peak: 0.2 }); nz(m, { dur: 1.2, f: 900, type: 'lowpass', q: 0.7, peak: 0.07, att: 0.2 }); for (let i = 0; i < 14; i++) drop(m, { t: R(0.1, 1.1), f: R(260, 520), k: 1.6, dur: 0.06, peak: 0.12 }); },
  oil: (m) => { for (let i = 0; i < 9; i++) drop(m, { t: 0.08 + i * 0.13 + R(0, 0.05), f: R(230, 420), k: 1.5, dur: 0.09, peak: 0.13 }); nz(m, { dur: 1.2, f: 700, q: 0.8, peak: 0.05, att: 0.2 }); },
  plop: (m) => { drop(m, { f: 300, k: 2.4, dur: 0.09, peak: 0.2 }); nz(m, { t: 0.02, dur: 0.18, f: 1300, q: 0.8, peak: 0.07 }); },
  splash: (m) => { nz(m, { dur: 0.45, f: 4000, f1: 700, type: 'lowpass', q: 0.7, peak: 0.22, att: 0.01 }); for (let i = 0; i < 7; i++) drop(m, { t: R(0.03, 0.3), f: R(600, 1600), peak: 0.06 }); },
  cast: (m) => { nz(m, { dur: 0.26, f: 600, f1: 2600, q: 0.9, peak: 0.14, att: 0.1 }); for (let i = 0; i < 6; i++) click(m, { t: 0.2 + i * 0.03, f: 4200, q: 4, peak: 0.12, dur: 0.006 }); LIB.plop({ ...m, t: m.t + 0.5 }); },
  // ---- ферма ----
  crunch: (m) => { nz(m, { dur: 0.16, f: 4000, type: 'highpass', q: 0.5, peak: 0.05, att: 0.02 }); for (let i = 0; i < 4; i++) nz(m, { t: i * 0.045 + R(0, 0.02), f: R(1500, 3200), q: 1.3, dur: 0.035, peak: 0.26 }); },
  grain: (m) => { nz(m, { dur: 1.0, f: 2000, q: 0.5, peak: 0.13, att: 0.15 }); for (let i = 0; i < 22; i++) click(m, { t: R(0.05, 0.95), f: R(2500, 5000), q: 2, peak: R(0.04, 0.12), dur: 0.004 }); },
  scale: (m) => { osc(m, { type: 'square', f: 1568, dur: 0.07, att: 0.003, peak: 0.03, lp: 3200 }); osc(m, { type: 'square', f: 1568, t: 0.12, dur: 0.07, att: 0.003, peak: 0.03, lp: 3200 }); },
  rooster: (m) => {
    const s = [[0, 0.13, 560, 'u'], [0.15, 0.12, 680, 'a'], [0.29, 0.14, 740, 'e'], [0.46, 0.62, 800, 'u']];
    s.forEach(([t, dur, f, v], i) => vox(m, { t, dur, f0: i === 3 ? [[0, f], [0.2, f * 1.06], [1, f * 0.72]] : [[0, f * 0.9], [1, f]], vow: [[0, v], [1, i === 3 ? 'o' : v]], peak: 0.2, rough: 0.25, breath: 0.15, vib: i === 3 ? 18 : 0, vibF: 9 }));
  },
  caw: (m) => { for (let i = 0; i < 2; i++) vox(m, { t: i * 0.34, dur: 0.24, f0: [[0, 520 + i * 30], [0.3, 600], [1, 430]], vow: [[0, 'a'], [1, 'o']], peak: 0.2, rough: 0.6, breath: 0.35 }); },
  sleep: (m) => { [784, 659, 523].forEach((f, i) => bell(m, { f, t: i * 0.32, dur: 1.4, peak: 0.07, parts: GLASS })); },
  stage: (m) => { [392, 523, 659, 784, 1047].forEach((f, i) => mallet(m, { f, t: i * 0.08, peak: 0.14 })); bell(m, { f: 2093, t: 0.42, dur: 1.4, peak: 0.06, parts: GLASS }); nz(m, { t: 0.3, dur: 0.9, f: 6000, q: 0.6, peak: 0.025, att: 0.2 }); },
  bell: (m) => bell(m, { f: 880, dur: 1.6, peak: 0.08, parts: [[1, 1, 1], [2.0, 0.5, 0.7], [2.4, 0.35, 0.6], [3.0, 0.2, 0.4], [4.1, 0.1, 0.3]] }),
  // ---- електрика ----
  zap: (m) => { for (let i = 0; i < 8; i++) click(m, { t: R(0, 0.28), f: R(1600, 3400), q: 1.8, peak: R(0.15, 0.35), dur: 0.006 }); osc(m, { type: 'sawtooth', f: 240, f1: 200, dur: 0.28, att: 0.01, peak: 0.06, bp: 900, q: 0.7 }); nz(m, { dur: 0.3, f: 2200, q: 0.8, peak: 0.08 }); },
  spark: (m) => { for (let i = 0; i < 4; i++) click(m, { t: R(0, 0.12), f: R(1800, 3600), q: 2, peak: R(0.15, 0.35), dur: 0.006 }); },
  switch: (m) => { click(m, { f: 1800, q: 1.6, peak: 0.7, dur: 0.014 }); nz(m, { dur: 0.06, f: 800, q: 1.5, peak: 0.35 }); click(m, { t: 0.028, f: 2600, q: 1.6, peak: 0.45 }); },
  powerUp: (m) => { osc(m, { type: 'sawtooth', f: 160, f1: 700, dur: 0.5, att: 0.05, peak: 0.05, lp: 1600 }); osc(m, { f: 320, f1: 1400, dur: 0.5, att: 0.05, peak: 0.04 }); },
  powerDown: (m) => { osc(m, { type: 'sawtooth', f: 700, f1: 130, dur: 0.55, att: 0.01, peak: 0.05, lp: 1600 }); osc(m, { f: 1400, f1: 260, dur: 0.5, att: 0.01, peak: 0.035 }); },
  thunder: (m, k = 1) => { nz(m, { dur: 0.18, f: 2500, type: 'highpass', q: 0.5, peak: 0.12 * k }); nz(m, { t: 0.05, dur: 2.6, f: 700, f1: 160, type: 'lowpass', q: 0.6, peak: 0.45 * k, att: 0.06 }); nz(m, { t: 0.15, dur: 1.8, f: 380, q: 0.8, peak: 0.3 * k, att: 0.2 }); for (let i = 0; i < 5; i++) nz(m, { t: R(0.1, 1.2), dur: 0.25, f: R(250, 600), q: 1, peak: 0.12 * k }); },
  // ---- лікарня ----
  beat: (m) => { osc(m, { f: 880, dur: 0.12, att: 0.006, hold: 0.05, peak: 0.06 }); osc(m, { f: 1760, dur: 0.1, att: 0.006, peak: 0.012 }); },
  // ---- цифровий світ (Біт) ----
  laser: (m) => { osc(m, { type: 'square', f: 1700, f1: 320, dur: 0.15, att: 0.003, peak: 0.06, lp: 3200 }); osc(m, { f: 2500, f1: 620, dur: 0.12, peak: 0.05 }); },
  shield: (m) => { bell(m, { f: 1400, dur: 0.5, peak: 0.08, parts: GLASS }); osc(m, { f: 700, f1: 1400, dur: 0.22, att: 0.02, peak: 0.05 }); },
  glitch: (m) => { for (let i = 0; i < 6; i++) osc(m, { type: 'square', f: R(220, 1900), t: i * 0.028, dur: 0.026, att: 0.001, peak: 0.05, lp: 4000 }); nz(m, { dur: 0.08, f: 1800, q: 0.6, peak: 0.08 }); },
  dodge: (m) => { osc(m, { type: 'sawtooth', f: 220, f1: 660, dur: 0.38, att: 0.03, peak: 0.05, lp: 1700 }); nz(m, { dur: 0.35, f: 600, f1: 2200, q: 0.9, peak: 0.08, att: 0.15 }); },
  turn: (m) => { mallet(m, { f: 880, peak: 0.13 }); mallet(m, { f: 1319, t: 0.08, peak: 0.12 }); },
  data: (m) => { [1047, 1319, 1568, 2093].forEach((f, i) => osc(m, { type: 'triangle', f, t: i * 0.055, dur: 0.22, att: 0.004, peak: 0.07 })); },
  blip: (m) => osc(m, { type: 'triangle', f: R(1200, 2400), dur: 0.06, att: 0.003, peak: 0.16 }),
  // ---- тварини (запасні, якщо голоси улюбленця ще не завантажені) ----
  meow: (m) => vox(m, { dur: 0.6, f0: [[0, 480], [0.35, 760], [1, 420]], vow: [[0, 'i'], [0.4, 'a'], [1, 'u']], vib: 12, peak: 0.22 }),
  mew: (m) => vox(m, { dur: 0.28, f0: [[0, 700], [1, 900]], vow: [[0, 'i'], [1, 'e']], peak: 0.16 }),
  yip: (m) => vox(m, { dur: 0.18, f0: [[0, 900], [0.4, 1250], [1, 700]], vow: [[0, 'e'], [1, 'a']], peak: 0.2 }),
  bark: (m) => vox(m, { dur: 0.16, f0: [[0, 330], [0.3, 420], [1, 210]], vow: [[0, 'a'], [1, 'o']], rough: 0.25, breath: 0.25, peak: 0.3 }),
  squeak: (m) => osc(m, { f: 1200, f1: 1800, dur: 0.12, peak: 0.06, att: 0.01 }),
  purr: (m) => { for (let i = 0; i < 6; i++) nz(m, { t: i * 0.16, dur: 0.14, f: 480, q: 1.2, peak: 0.2, att: 0.03 }); },
  roar: (m) => vox(m, { dur: 1.0, f0: [[0, 120], [0.3, 180], [1, 90]], vow: [[0, 'a'], [0.5, 'o'], [1, 'u']], rough: 0.8, breath: 0.35, peak: 0.35, vib: 10, vibF: 22 }),
  ribbit: (m) => { [0, 0.16].forEach((d) => { for (let k = 0; k < 5; k++) vox(m, { t: d + k * 0.022, dur: 0.03, f0: [[0, 300], [1, 260]], vow: [[0, 'o'], [1, 'u']], peak: 0.25 }); }); },
  howl: (m) => vox(m, { dur: 1.4, f0: [[0, 330], [0.3, 560], [0.8, 520], [1, 380]], vow: [[0, 'u'], [0.4, 'o'], [1, 'u']], vib: 9, vibF: 5, peak: 0.22 }),
  slurp: (m) => { for (let i = 0; i < 4; i++) drop(m, { t: i * 0.14, f: 400, k: 1.8, dur: 0.07, peak: 0.08 }); },
  // ---- голоси природи (їх кличе фон, але можна й напряму) ----
  chirp: (m) => birdNote(m, 0),
  cricket: (m) => cricketChirp(m, 0, 3200)
};
const ANIMAL = new Set(['meow', 'mew', 'purr', 'yip', 'bark', 'squeak', 'roar', 'ribbit', 'howl', 'growl', 'bleat', 'chirp']);
let voiceHook = null; // голоси улюбленця (voice.js) — якщо є, тварини звучать ними
export function setVoiceHook(fn) { voiceHook = fn; }

const lastAt = {};
// sfx(kind, { pan, vol, delay }) — головний виклик для ігор
export function sfx(kind, o = {}) {
  if (muted() && !TEST) return;
  if (voiceHook && ANIMAL.has(kind) && kind !== 'chirp' && !TEST) { try { voiceHook(kind, o); } catch (_) { } return; }
  const fn = LIB[kind]; if (!fn) return;
  const now = performance.now(); if (!TEST && now - (lastAt[kind] || 0) < 35) return; lastAt[kind] = now;
  if (live > 48 && !TEST) return;
  try { const g = graph(); if (!g) return; fn(mix(g, o, UI.has(kind) ? 'ui' : o.bus || 'fx', VERB[kind] || 0), o.x); } catch (_) { }
}
export const SOUNDS = Object.keys(LIB);
// для перевірки: стан звуку (контекст, головна гучність, кількість звуків, що грають)
export function soundState() { return { ctx: A ? A.state : 'none', master: G ? +G.master.gain.value.toFixed(3) : null, muted: muted(), live }; }

/* ---------------- голоси природи ---------------- */
function birdNote(m, t) {
  const f = R(2100, 3500), up = Math.random() < 0.5;
  osc(m, { f: up ? f * 0.8 : f * 1.15, f1: up ? f * 1.2 : f * 0.75, t, dur: R(0.05, 0.13), att: 0.008, peak: R(0.06, 0.11), vib: R(150, 400), vibF: R(25, 60) });
}
function cricketChirp(m, t, f) { for (let i = 0; i < 3; i++) osc(m, { f, t: t + i * 0.032, dur: 0.022, att: 0.003, peak: 0.07 }); }

/* ---------------- петлі: двигун, зерно, бризки, фон ----------------
   loop(kind, opts) → { set({ vol, pan, rpm, load, ... }), tick(dt), stop(fade) } */
function engineWave(a) {
  if (PW && PW.a === a) return PW.w;
  // «порядки» двигуна: гармоніки обертання вала, напівцілі слабші; нерівності — як у справжнього дизеля
  const N = 110, re = new Float32Array(N + 1), im = new Float32Array(N + 1); let s = 9;
  const rnd = () => ((s = (s * 16807) % 2147483647) / 2147483647);
  for (let n = 1; n <= N; n++) { const half = n % 2 === 1; im[n] = (half ? 0.45 : 1) * Math.pow(n, -0.62) * (0.6 + 0.8 * rnd()); re[n] = (rnd() - 0.5) * 0.2 * Math.pow(n, -0.62); }
  const w = a.createPeriodicWave(re, im, { disableNormalization: false }); PW = { a, w }; return w;
}
const ENG = {
  tractor: { idle: 27, max: 64, body: 520, clat: 1900, k: 1 },
  combine: { idle: 23, max: 52, body: 430, clat: 1500, k: 1.1 },
  truck: { idle: 25, max: 72, body: 600, clat: 2100, k: 0.9 },
  jeep: { idle: 32, max: 105, body: 900, clat: 2600, k: 0.7 },
  gen: { idle: 25, max: 25, body: 480, clat: 1700, k: 0.8 }
};
function makeLoop(kind, o = {}) {
  const g = graph(); if (!g) return null; const a = g.a;
  const out = a.createGain(); out.gain.value = 0; const pan = a.createStereoPanner ? a.createStereoPanner() : null;
  const dst = g.bus[o.bus || (['wind', 'rain', 'birds', 'crickets', 'city', 'room', 'pad', 'water', 'night'].includes(kind) ? 'amb' : 'fx')];
  if (pan) { out.connect(pan); pan.connect(dst); } else out.connect(dst);
  const nodes = [], srcs = [];
  const N = () => { const s = a.createBufferSource(); s.buffer = noiseBuf(); s.loop = true; srcs.push(s); return s; };
  const O = (type, f) => { const s = a.createOscillator(); s.type = type; s.frequency.value = f; srcs.push(s); return s; };
  const F = (type, f, q = 1) => { const x = a.createBiquadFilter(); x.type = type; x.frequency.value = f; x.Q.value = q; nodes.push(x); return x; };
  const Gn = (v) => { const x = a.createGain(); x.gain.value = v; nodes.push(x); return x; };
  const T = (p, v, tc = 0.12) => p.setTargetAtTime(v, a.currentTime, tc);
  const h = { kind, vol: 0, set() { }, tick() { }, stop: null };
  // планувальник подій для живого фону: власний годинник, щоб події не злипались
  // кадр за кадром: події цього кадру лягають у [зараз + 30 мс, + dt]; у тесті годинник іде від викликів tick
  let clock = a.currentTime;
  const adv = (dt) => { if (TEST) clock += dt; else clock = a.currentTime + 0.03; };
  const when = (spread) => clock + Math.random() * spread;
  const sm = (at) => ({ a, out, t: at });
  const canTick = () => !muted() && (a.state === 'running' || TEST) && h.vol > 0.01;

  if (kind === 'engine') {
    const E = ENG[o.size] || ENG.tractor;
    const base = O('sine', E.idle / 2); base.setPeriodicWave(engineWave(a));
    const body = F('bandpass', E.body, 1.1), bodyG = Gn(0.9), main = F('lowpass', 900), mainG = Gn(0.5);
    base.connect(body); body.connect(bodyG); bodyG.connect(out); base.connect(main); main.connect(mainG); mainG.connect(out);
    // дизельне «тах-тах»: шум, що спалахує з частотою спалахів у циліндрах
    const cl = N(), clF = F('bandpass', E.clat, 1.4), am = Gn(0.5), clG = Gn(0.25), lfo = O('square', E.idle), lfoG = Gn(0.45);
    cl.connect(clF); clF.connect(am); am.connect(clG); clG.connect(out); lfo.connect(lfoG); lfoG.connect(am.gain);
    const air = N(), airF = F('lowpass', 420, 0.7), airG = Gn(0.12); air.connect(airF); airF.connect(airG); airG.connect(out);
    h.set = ({ rpm, load, vol, pan: p }) => {
      if (rpm !== undefined) { const f = E.idle + (E.max - E.idle) * clamp(rpm, 0, 1); T(base.frequency, f / 2, 0.25); T(lfo.frequency, f, 0.25); h.rpm = rpm; }
      if (load !== undefined) { const L = clamp(load, 0, 1); T(main.frequency, 700 + 2200 * L, 0.3); T(clG.gain, (0.18 + 0.3 * L) * E.k, 0.3); T(bodyG.gain, 0.8 + 0.5 * L, 0.3); }
      if (vol !== undefined) { h.vol = vol; T(out.gain, clamp(vol, 0, 1.2) * 0.22, 0.15); }
      if (p !== undefined && pan) T(pan.pan, clamp(p, -1, 1), 0.1);
    };
  } else if (kind === 'grain' || kind === 'spray' || kind === 'water' || kind === 'hum' || kind === 'rumble') {
    if (kind === 'grain') { // зерно сиплеться шнеком: шурхіт, що «зернить» від повільних коливань
      const s1 = N(), f1 = F('bandpass', 2400, 0.6), g1 = Gn(0.5), s2 = N(), f2 = F('bandpass', 900, 1), g2 = Gn(0.35);
      const mod = N(), mf = F('lowpass', 30, 0.7), mg = Gn(0.6); mod.connect(mf); mf.connect(mg); mg.connect(g1.gain);
      s1.connect(f1); f1.connect(g1); g1.connect(out); s2.connect(f2); f2.connect(g2); g2.connect(out);
    } else if (kind === 'spray') { // обприскувач, мийка, дощувач
      const s1 = N(), f1 = F('highpass', 1800, 0.6), f2 = F('bandpass', 3400, 0.5), g1 = Gn(0.6), p = O('sine', 6), pg = Gn(0.2);
      s1.connect(f1); f1.connect(f2); f2.connect(g1); g1.connect(out); p.connect(pg); pg.connect(g1.gain);
    } else if (kind === 'water') { // струмок/ставок
      const s1 = N(), f1 = F('bandpass', 1300, 1.6), g1 = Gn(0.4), mod = N(), mf = F('lowpass', 9, 0.7), mg = Gn(0.5);
      mod.connect(mf); mf.connect(mg); mg.connect(g1.gain); s1.connect(f1); f1.connect(g1); g1.connect(out);
    } else if (kind === 'hum') { // електрика / цех: гудіння з чутними обертонами + брязкіт механізмів
      const o1 = O('sawtooth', 120), f1 = F('lowpass', 1100, 0.8), hp1 = F('highpass', 220, 0.7), g1 = Gn(0.6), o2 = O('triangle', 360), g2 = Gn(0.08);
      o1.connect(f1); f1.connect(hp1); hp1.connect(g1); g1.connect(out); o2.connect(g2); g2.connect(out);
      const r = N(), rf = F('bandpass', 1400, 2), ra = Gn(0.4), rl = O('square', o.rattle || 11), rlg = Gn(o.rattle ? 0.4 : 0), rg = Gn(o.rattle ? 0.3 : 0);
      r.connect(rf); rf.connect(ra); ra.connect(rg); rg.connect(out); rl.connect(rlg); rlg.connect(ra.gain);
    } else { // rumble — гул далекої дороги
      const s1 = N(), f1 = F('lowpass', 620, 0.6), f2 = F('highpass', 160, 0.6), g1 = Gn(0.6); s1.connect(f1); f1.connect(f2); f2.connect(g1); g1.connect(out);
    }
    const peak = { grain: 0.32, spray: 0.18, water: 0.3, hum: 0.16, rumble: 0.3 }[kind];
    h.set = ({ vol, pan: p }) => { if (vol !== undefined) { h.vol = vol; T(out.gain, clamp(vol, 0, 1.2) * peak, 0.2); } if (p !== undefined && pan) T(pan.pan, clamp(p, -1, 1), 0.1); };
  } else if (kind === 'wind') {
    const s1 = N(), f1 = F('bandpass', 450, 0.8), g1 = Gn(0.6), l1 = O('sine', 0.071), l1g = Gn(220), l2 = O('sine', 0.13), l2g = Gn(0.3);
    l1.connect(l1g); l1g.connect(f1.frequency); l2.connect(l2g); l2g.connect(g1.gain);
    const s2 = N(), f2 = F('bandpass', 1400, 2.5), g2 = Gn(0.12), l3 = O('sine', 0.19), l3g = Gn(500); l3.connect(l3g); l3g.connect(f2.frequency);
    s1.connect(f1); f1.connect(g1); g1.connect(out); s2.connect(f2); f2.connect(g2); g2.connect(out);
    h.set = ({ vol, strength }) => { if (vol !== undefined) { h.vol = vol; T(out.gain, clamp(vol, 0, 1.2) * 0.3, 0.6); } if (strength !== undefined && strength !== h.str) { h.str = strength; T(f1.frequency, 350 + 400 * strength, 1); T(g2.gain, 0.05 + 0.25 * strength, 1); } };
  } else if (kind === 'rain') {
    // дощ = безліч крапель-бульбашок + широкий шум, ліворуч і праворуч різний
    const mk = (pv) => { const s = N(), f1 = F('highpass', 900, 0.5), f2 = F('lowpass', 4800, 0.5), g = Gn(0.5); s.connect(f1); f1.connect(f2); f2.connect(g); if (a.createStereoPanner) { const p = a.createStereoPanner(); p.pan.value = pv; nodes.push(p); g.connect(p); p.connect(out); } else g.connect(out); };
    mk(-0.6); mk(0.6);
    const lowS = N(), lowF = F('bandpass', 700, 0.9), lowG = Gn(0.3); lowS.connect(lowF); lowF.connect(lowG); lowG.connect(out);
    let inten = 0.6;
    h.set = ({ vol, intensity }) => { if (vol !== undefined) { h.vol = vol; T(out.gain, clamp(vol, 0, 1.2) * 0.18, 0.8); } if (intensity !== undefined) inten = intensity; };
    h.tick = (dt) => { adv(dt); if (!canTick()) return; const n = Math.round(dt * (12 + 40 * inten) * h.vol); for (let i = 0; i < n; i++) { const m = sm(when(dt)); drop(m, { f: R(1400, 3400), k: R(1.2, 1.6), dur: R(0.012, 0.025), peak: R(0.04, 0.12) }); } };
  } else if (kind === 'birds') {
    let next = 0.5; const birds = [R(-0.7, -0.2), R(0.2, 0.7), R(-0.3, 0.3)].map((p) => { if (!a.createStereoPanner) return out; const x = a.createStereoPanner(); x.pan.value = p; x.connect(out); nodes.push(x); return x; });
    h.set = ({ vol }) => { if (vol !== undefined) { h.vol = vol; T(out.gain, clamp(vol, 0, 1.2), 0.8); } };
    h.tick = (dt) => { adv(dt); if (!canTick()) return; next -= dt; if (next > 0) return; next = R(1.2, 4.5); const at = when(0.05), o2 = birds[(Math.random() * birds.length) | 0], m = { a, out: o2, t: at }, n = 2 + ((Math.random() * 4) | 0); let tt = 0; for (let i = 0; i < n; i++) { birdNote(m, tt); tt += R(0.08, 0.2); } };
  } else if (kind === 'crickets' || kind === 'night') {
    const cr = [[R(-0.8, -0.3), 3100, R(0.42, 0.55)], [R(0.3, 0.8), 3400, R(0.5, 0.65)], [R(-0.2, 0.2), 2900, R(0.6, 0.8)]].map(([p, f, per]) => { let o2 = out; if (a.createStereoPanner) { o2 = a.createStereoPanner(); o2.pan.value = p; o2.connect(out); nodes.push(o2); } return { o2, f, per, ph: Math.random() * per, rest: 0 }; });
    let frog = R(3, 8);
    h.set = ({ vol }) => { if (vol !== undefined) { h.vol = vol; T(out.gain, clamp(vol, 0, 1.2), 0.8); } };
    h.tick = (dt) => {
      adv(dt); if (!canTick()) return;
      for (const c of cr) { if (c.rest > 0) { c.rest -= dt; continue; } c.ph -= dt; if (c.ph <= 0) { c.ph += c.per; if (Math.random() < 0.06) c.rest = R(1, 3); cricketChirp({ a, out: c.o2, t: when(0.02) }, 0, c.f); } }
      if (o.frogs) { frog -= dt; if (frog <= 0) { frog = R(4, 11); const m = { a, out, t: when(0.05) }; for (let k = 0; k < 4; k++) vox(m, { t: k * 0.025, dur: 0.03, f0: [[0, 290], [1, 250]], vow: [[0, 'o'], [1, 'u']], peak: 0.09 }); } }
    };
  } else if (kind === 'city') {
    const s1 = N(), f1 = F('lowpass', 650, 0.6), f2 = F('highpass', 170, 0.6), g1 = Gn(0.5); s1.connect(f1); f1.connect(f2); f2.connect(g1); g1.connect(out);
    let car = R(2, 5);
    h.set = ({ vol }) => { if (vol !== undefined) { h.vol = vol; T(out.gain, clamp(vol, 0, 1.2) * 0.22, 0.8); } };
    h.tick = (dt) => {
      adv(dt); if (!canTick()) return; car -= dt; if (car > 0) return; car = R(4, 10);
      const at = when(0.05), s = a.createBufferSource(); s.buffer = noiseBuf(); const f = a.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 1.2; const gg = a.createGain(); let p = null;
      f.frequency.setValueAtTime(380, at); f.frequency.linearRampToValueAtTime(820, at + 1.1); f.frequency.linearRampToValueAtTime(420, at + 2.4);
      gg.gain.setValueAtTime(0.0001, at); gg.gain.exponentialRampToValueAtTime(0.9, at + 1.1); gg.gain.exponentialRampToValueAtTime(0.0001, at + 2.4);
      s.connect(f); f.connect(gg); if (a.createStereoPanner) { p = a.createStereoPanner(); const dir = Math.random() < 0.5 ? 1 : -1; p.pan.setValueAtTime(-0.8 * dir, at); p.pan.linearRampToValueAtTime(0.8 * dir, at + 2.4); gg.connect(p); p.connect(out); } else gg.connect(out);
      track(s); s.start(at, Math.random()); s.stop(at + 2.5);
    };
  } else if (kind === 'room') { // тиша палати: вентиляція + (за бажанням) годинник
    const s1 = N(), f1 = F('lowpass', 520, 0.6), f2 = F('highpass', 140, 0.6), g1 = Gn(0.5); s1.connect(f1); f1.connect(f2); f2.connect(g1); g1.connect(out);
    let tk = 1;
    h.set = ({ vol, clock: c }) => { if (vol !== undefined) { h.vol = vol; T(out.gain, clamp(vol, 0, 1.2) * 0.14, 0.8); } if (c !== undefined) h.clock = c; };
    h.tick = (dt) => { adv(dt); if (!canTick() || !h.clock) return; tk -= dt; if (tk > 0) return; tk += 1; click({ a, out, t: when(0.01) }, { f: 3200, q: 3, peak: 0.5, dur: 0.006 }); };
  } else if (kind === 'pad') { // цифровий фон Біта: тихий акорд, що «дихає», і зрідка — біпи
    const fl = F('lowpass', 900, 0.8), lf = O('sine', 0.05), lfg = Gn(320); lf.connect(lfg); lfg.connect(fl.frequency); const pg = Gn(0.5); fl.connect(pg); pg.connect(out);
    const pulse = O('sine', 2), pulseG = Gn(0); pulse.connect(pulseG); pulseG.connect(pg.gain);
    const CH = { calm: [220, 261.6, 329.6], tense: [220, 261.6, 311.1] };
    const vs = [0, 1, 2].map((i) => { const o1 = O('triangle', CH.calm[i]), o2 = O('triangle', CH.calm[i] * 1.004); o1.connect(fl); o2.connect(fl); return [o1, o2]; });
    let bl = 1;
    h.set = ({ vol, tense }) => {
      if (vol !== undefined) { h.vol = vol; T(out.gain, clamp(vol, 0, 1.2) * 0.12, 0.8); }
      if (tense !== undefined && tense !== h.tense) { h.tense = tense; const c = tense ? CH.tense : CH.calm; vs.forEach(([o1, o2], i) => { T(o1.frequency, c[i], 0.4); T(o2.frequency, c[i] * 1.004, 0.4); }); T(pulseG.gain, tense ? 0.35 : 0, 0.5); T(pulse.frequency, tense ? 2.5 : 2, 0.5); }
    };
    h.tick = (dt) => { adv(dt); if (!canTick()) return; bl -= dt; if (bl > 0) return; bl = R(0.8, 2.6); osc({ a, out, t: when(0.05) }, { type: 'triangle', f: [1047, 1175, 1319, 1568, 1760, 2093][(Math.random() * 6) | 0], dur: 0.07, att: 0.004, peak: 0.25 }); };
  }
  srcs.forEach((s) => { if (s.buffer) s.start(a.currentTime, Math.random() * 1.5); else s.start(a.currentTime); });
  let dead = false;
  h.stop = (fade = 0.3) => {
    if (dead) return; dead = true; const t = a.currentTime; out.gain.cancelScheduledValues(t); out.gain.setTargetAtTime(0, t, Math.max(0.01, fade / 4));
    srcs.forEach((s) => { try { s.stop(t + fade + 0.05); } catch (_) { } });
    setTimeout(() => { try { out.disconnect(); } catch (_) { } }, (fade + 0.2) * 1000);
  };
  h.dead = () => dead;
  if (o.vol !== undefined || o.rpm !== undefined) h.set(o);
  return h;
}
export function loop(kind, o) { try { return makeLoop(kind, o); } catch (_) { return null; } }

/* ---------------- фон гри: шари вмикаються/вимикаються плавно ----------------
   const amb = ambience(); amb.set('birds', 0.8); ... у кадрі: amb.tick(dt) */
export function ambience() {
  const L = {};
  return {
    set(name, level, p = {}) { const l = L[name] || (L[name] = { h: null, lvl: 0, want: 0, p: {}, idle: 0 }); l.want = clamp(level, 0, 1.5); Object.assign(l.p, p); },
    tick(dt) {
      for (const [name, l] of Object.entries(L)) {
        l.lvl += (l.want - l.lvl) * Math.min(1, dt * 1.5);
        if (l.want > 0.01 && (!l.h || l.h.dead())) { if (muted()) continue; l.h = loop(l.p.kind || name, l.p); }
        if (!l.h) continue;
        l.h.set({ ...l.p, vol: l.lvl }); l.h.tick(dt);
        if (l.want <= 0.01 && l.lvl < 0.01) { if ((l.idle += dt) > 3) { l.h.stop(0.3); l.h = null; l.idle = 0; } } else l.idle = 0;
      }
    },
    stop() { for (const l of Object.values(L)) { if (l.h) l.h.stop(0.25); l.h = null; } }
  };
}

/* ---------------- звук із місця у світі ----------------
   const at = spatial(W); sfx('clunk', at(position)) */
export function spatial(W, ref = 16) {
  const v = new W.THREE.Vector3();
  return (p, extra = 1) => {
    if (!p) return { vol: extra };
    v.copy(p).project(W.camera);
    const d = W.camera.position.distanceTo(p); let g = clamp(ref / Math.max(1, d), 0.1, 1);
    if (v.z > 1 || Math.abs(v.x) > 1.25 || Math.abs(v.y) > 1.3) g *= 0.4;
    return { pan: clamp(v.x * 0.65, -0.75, 0.75), vol: g * extra };
  };
}

// усе, що гра створила, — зупиняється разом із нею
export function soundScope() {
  const hs = new Set(), amb = ambience();
  return {
    amb,
    loop(kind, o) { const h = loop(kind, o); if (h) hs.add(h); return h; },
    stop() { hs.forEach((h) => h.stop(0.2)); hs.clear(); amb.stop(); }
  };
}

// для перевірки: відрендерити звук без динаміка (OfflineAudioContext) і повернути відліки
export async function renderOffline(run, dur = 2, sr = 44100) {
  const C = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  TEST = new C(2, Math.ceil(sr * dur), sr); G = null; PW = null; live = 0; for (const k in lastAt) delete lastAt[k];
  try { await run({ sfx, loop }); const b = await TEST.startRendering(); return [Array.from(b.getChannelData(0)), Array.from(b.getChannelData(1))]; }
  finally { TEST = null; G = null; PW = null; live = 0; }
}
