/* ============================================================
   Головоломки: генератори з перевіркою єдиного розв'язку.
   Без ШІ й без мережі. Однаковий seed → однакова головоломка
   (тому «головоломка дня» однакова для всіх).
   ============================================================ */

export function rng(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function hashSeed(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function shuffle(arr, r) {
  for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; }
  return arr;
}

export const LEVELS = ['easy', 'medium', 'hard', 'expert'];

/* ---------------- СУДОКУ (4×4, 6×6, 9×9) ----------------
   Рівень задає розмір: легко — 4×4 (квадрати 2×2), середньо — 6×6 (2×3),
   складно й експерт — 9×9 (3×3), експерт з меншою кількістю підказок. */
export const SUDOKU_SIZE = { easy: 4, medium: 6, hard: 9, expert: 9 };
export const boxDims = (n) => (n === 4 ? [2, 2] : n === 6 ? [2, 3] : [3, 3]); // [рядків, стовпців] у квадраті
const boxOf = (n, r, c) => { const [br, bc] = boxDims(n); return ((r / br) | 0) * (n / bc) + ((c / bc) | 0); };
function sudokuCount(g, limit, n = 9) {
  const N = n * n, full = ((1 << (n + 1)) - 2);
  const rows = new Array(n).fill(0), cols = new Array(n).fill(0), boxes = new Array(n).fill(0);
  const empty = [];
  for (let i = 0; i < N; i++) {
    const v = g[i];
    if (v) {
      const b = 1 << v, r = (i / n) | 0, c = i % n, x = boxOf(n, r, c);
      if ((rows[r] | cols[c] | boxes[x]) & b) return 0;
      rows[r] |= b; cols[c] |= b; boxes[x] |= b;
    } else empty.push(i);
  }
  let count = 0;
  const grid = g.slice();
  function rec() {
    if (count >= limit) return;
    let best = -1, bestMask = 0, bestN = n + 1;
    for (let k = 0; k < empty.length; k++) {
      const i = empty[k];
      if (grid[i]) continue;
      const r = (i / n) | 0, c = i % n, x = boxOf(n, r, c);
      const m = ~(rows[r] | cols[c] | boxes[x]) & full;
      let q = 0, mm = m; while (mm) { mm &= mm - 1; q++; }
      if (q < bestN) { bestN = q; best = i; bestMask = m; if (q <= 1) break; }
    }
    if (best < 0) { count++; return; }
    if (bestN === 0) return;
    const r = (best / n) | 0, c = best % n, x = boxOf(n, r, c);
    for (let v = 1; v <= n; v++) {
      const b = 1 << v;
      if (!(bestMask & b)) continue;
      grid[best] = v; rows[r] |= b; cols[c] |= b; boxes[x] |= b;
      rec();
      grid[best] = 0; rows[r] &= ~b; cols[c] &= ~b; boxes[x] &= ~b;
      if (count >= limit) return;
    }
  }
  rec();
  return count;
}
function sudokuFill(r, n = 9) {
  const N = n * n, g = new Array(N).fill(0), [br, bc] = boxDims(n);
  function rec(i) {
    if (i === N) return true;
    const row = (i / n) | 0, col = i % n;
    const nums = shuffle([...Array(n)].map((_, k) => k + 1), r);
    for (const v of nums) {
      let ok = true;
      for (let k = 0; k < n && ok; k++) if (g[row * n + k] === v || g[k * n + col] === v) ok = false;
      const r0 = ((row / br) | 0) * br, c0 = ((col / bc) | 0) * bc;
      for (let a = 0; a < br && ok; a++) for (let b = 0; b < bc; b++) if (g[(r0 + a) * n + c0 + b] === v) { ok = false; break; }
      if (!ok) continue;
      g[i] = v;
      if (rec(i + 1)) return true;
      g[i] = 0;
    }
    return false;
  }
  rec(0);
  return g;
}
export function genSudoku(seed, level) {
  const r = rng(seed);
  const n = SUDOKU_SIZE[level] || 9, N = n * n;
  const solution = sudokuFill(r, n);
  const target = { easy: 6, medium: 14, hard: 32, expert: 25 }[level] || 32;
  const puzzle = solution.slice();
  const order = shuffle([...Array(N).keys()], r);
  let clues = N;
  for (const i of order) {
    if (clues <= target) break;
    const keep = puzzle[i];
    puzzle[i] = 0;
    if (sudokuCount(puzzle, 2, n) !== 1) puzzle[i] = keep; else clues--;
  }
  const [br, bc] = boxDims(n);
  return { type: 'sudoku', size: n, br, bc, puzzle, solution, clues };
}
export function sudokuConflicts(g, n = Math.round(Math.sqrt(g.length))) {
  const bad = new Set(), N = n * n;
  for (let i = 0; i < N; i++) {
    if (!g[i]) continue;
    const r = (i / n) | 0, c = i % n;
    for (let j = i + 1; j < N; j++) {
      if (g[j] !== g[i]) continue;
      const r2 = (j / n) | 0, c2 = j % n;
      if (r === r2 || c === c2 || boxOf(n, r, c) === boxOf(n, r2, c2)) { bad.add(i); bad.add(j); }
    }
  }
  return bad;
}

/* ---------------- ТАНГО (6×6, сонце/місяць) ----------------
   Правила: у рядку й стовпчику по 3 сонця й 3 місяці; не більше
   двох однакових поспіль; «=» — сусіди однакові, «×» — різні. */
const TN = 6;
function tangoValidPartial(g, i, cons) {
  const r = (i / TN) | 0, c = i % TN, v = g[i];
  let s = 0, m = 0;
  for (let k = 0; k < TN; k++) { const x = g[r * TN + k]; if (x === 1) s++; else if (x === 2) m++; }
  if (s > 3 || m > 3) return false;
  s = 0; m = 0;
  for (let k = 0; k < TN; k++) { const x = g[k * TN + c]; if (x === 1) s++; else if (x === 2) m++; }
  if (s > 3 || m > 3) return false;
  for (let k = Math.max(0, c - 2); k <= Math.min(TN - 3, c); k++) {
    const a = g[r * TN + k], b = g[r * TN + k + 1], d = g[r * TN + k + 2];
    if (a && a === b && b === d) return false;
  }
  for (let k = Math.max(0, r - 2); k <= Math.min(TN - 3, r); k++) {
    const a = g[k * TN + c], b = g[(k + 1) * TN + c], d = g[(k + 2) * TN + c];
    if (a && a === b && b === d) return false;
  }
  const list = cons.byCell[i];
  if (list) for (const q of list) {
    const o = q.a === i ? q.b : q.a, ov = g[o];
    if (!ov) continue;
    if (q.t === '=' && ov !== v) return false;
    if (q.t === 'x' && ov === v) return false;
  }
  return true;
}
function indexCons(list) {
  const byCell = {};
  for (const q of list) { (byCell[q.a] = byCell[q.a] || []).push(q); (byCell[q.b] = byCell[q.b] || []).push(q); }
  return { list, byCell };
}
function tangoCount(givens, consList, limit) {
  const g = givens.slice(), cons = indexCons(consList);
  for (let i = 0; i < TN * TN; i++) if (g[i] && !tangoValidPartial(g, i, cons)) return 0;
  let count = 0;
  function rec(i) {
    if (count >= limit) return;
    while (i < TN * TN && g[i]) i++;
    if (i === TN * TN) { count++; return; }
    for (const v of [1, 2]) {
      g[i] = v;
      if (tangoValidPartial(g, i, cons)) rec(i + 1);
      g[i] = 0;
      if (count >= limit) return;
    }
  }
  rec(0);
  return count;
}
function tangoFill(r) {
  const g = new Array(TN * TN).fill(0), cons = indexCons([]);
  function rec(i) {
    if (i === TN * TN) return true;
    for (const v of shuffle([1, 2], r)) {
      g[i] = v;
      if (tangoValidPartial(g, i, cons) && rec(i + 1)) return true;
      g[i] = 0;
    }
    return false;
  }
  rec(0);
  return g;
}
export function genTango(seed, level) {
  const r = rng(seed);
  const solution = tangoFill(r);
  const nCons = { easy: 4, medium: 6, hard: 8, expert: 10 }[level] || 6;
  const minGivens = { easy: 12, medium: 8, hard: 5, expert: 3 }[level] || 8;
  const edges = [];
  for (let i = 0; i < TN * TN; i++) {
    const rr = (i / TN) | 0, c = i % TN;
    if (c < TN - 1) edges.push([i, i + 1]);
    if (rr < TN - 1) edges.push([i, i + TN]);
  }
  const cons = shuffle(edges, r).slice(0, nCons).map(([a, b]) => ({ a, b, t: solution[a] === solution[b] ? '=' : 'x' }));
  const givens = solution.slice();
  let n = TN * TN;
  for (const i of shuffle([...Array(TN * TN).keys()], r)) {
    if (n <= minGivens) break;
    const keep = givens[i];
    givens[i] = 0;
    if (tangoCount(givens, cons, 2) !== 1) givens[i] = keep; else n--;
  }
  return { type: 'tango', size: TN, puzzle: givens, solution, cons };
}
export function tangoErrors(g, cons) {
  const bad = new Set(), ix = indexCons(cons);
  for (let i = 0; i < TN * TN; i++) if (g[i] && !tangoValidPartial(g, i, ix)) bad.add(i);
  return bad;
}

/* ---------------- КОРОЛЕВИ (як у LinkedIn) ----------------
   N×N, N кольорових областей. По одній королеві в кожному рядку,
   стовпчику й області; королеви не торкаються навіть кутами. */
function queensPlacement(n, r) {
  const p = new Array(n).fill(-1), used = new Array(n).fill(false);
  function rec(row) {
    if (row === n) return true;
    for (const c of shuffle([...Array(n).keys()], r)) {
      if (used[c]) continue;
      if (row > 0 && Math.abs(p[row - 1] - c) <= 1) continue;
      p[row] = c; used[c] = true;
      if (rec(row + 1)) return true;
      used[c] = false; p[row] = -1;
    }
    return false;
  }
  rec(0);
  return p;
}
function queensSolve(n, reg, limit) {
  const sols = [], p = new Array(n).fill(-1), usedC = new Array(n).fill(false), usedR = new Array(n).fill(false);
  function rec(row) {
    if (sols.length >= limit) return;
    if (row === n) { sols.push(p.slice()); return; }
    for (let c = 0; c < n; c++) {
      if (usedC[c]) continue;
      const g = reg[row * n + c];
      if (usedR[g]) continue;
      if (row > 0 && Math.abs(p[row - 1] - c) <= 1) continue;
      p[row] = c; usedC[c] = true; usedR[g] = true;
      rec(row + 1);
      usedC[c] = false; usedR[g] = false; p[row] = -1;
      if (sols.length >= limit) return;
    }
  }
  rec(0);
  return sols;
}
function connectedWithout(n, reg, cell) {
  /* чи лишиться область цілою, якщо прибрати cell */
  const g = reg[cell], cells = [];
  for (let i = 0; i < n * n; i++) if (i !== cell && reg[i] === g) cells.push(i);
  if (!cells.length) return false;
  const seen = new Set([cells[0]]), st = [cells[0]];
  while (st.length) {
    const i = st.pop(), r = (i / n) | 0, c = i % n;
    for (const [dr, dc] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const rr = r + dr, cc = c + dc;
      if (rr < 0 || cc < 0 || rr >= n || cc >= n) continue;
      const j = rr * n + cc;
      if (j !== cell && reg[j] === g && !seen.has(j)) { seen.add(j); st.push(j); }
    }
  }
  return seen.size === cells.length;
}
export function genQueens(seed, level) {
  const n = { easy: 6, medium: 7, hard: 8, expert: 9 }[level] || 7;
  for (let attempt = 0; attempt < 40; attempt++) {
    const r = rng(seed + attempt * 7919);
    const q = queensPlacement(n, r);
    const reg = new Array(n * n).fill(-1);
    const frontier = [];
    for (let row = 0; row < n; row++) { reg[row * n + q[row]] = row; frontier.push(row * n + q[row]); }
    let left = n * n - n;
    while (left > 0) {
      const i = frontier[Math.floor(r() * frontier.length)];
      const rr = (i / n) | 0, c = i % n;
      const nb = shuffle([[1, 0], [-1, 0], [0, 1], [0, -1]], r).map(([dr, dc]) => [rr + dr, c + dc])
        .filter(([a, b]) => a >= 0 && b >= 0 && a < n && b < n && reg[a * n + b] < 0);
      if (!nb.length) { frontier.splice(frontier.indexOf(i), 1); continue; }
      const j = nb[0][0] * n + nb[0][1];
      reg[j] = reg[i]; frontier.push(j); left--;
    }
    const truth = q;
    for (let step = 0; step < 400; step++) {
      const sols = queensSolve(n, reg, 2);
      if (sols.length === 1) return { type: 'queens', size: n, regions: reg, solution: truth };
      const alt = sols.find(s => s.some((c, i) => c !== truth[i]));
      if (!alt) break;
      /* ламаємо чужий розв'язок: клітинку його королеви віддаємо сусідній області */
      const rows = shuffle([...Array(n).keys()].filter(i => alt[i] !== truth[i]), r);
      let moved = false;
      for (const row of rows) {
        const cell = row * n + alt[row];
        if (truth[row] === alt[row]) continue;
        if (!connectedWithout(n, reg, cell)) continue;
        const rr = (cell / n) | 0, c = cell % n;
        const opts = shuffle([[1, 0], [-1, 0], [0, 1], [0, -1]], r).map(([dr, dc]) => [rr + dr, c + dc])
          .filter(([a, b]) => a >= 0 && b >= 0 && a < n && b < n && reg[a * n + b] !== reg[cell]);
        if (!opts.length) continue;
        reg[cell] = reg[opts[0][0] * n + opts[0][1]];
        moved = true;
        break;
      }
      if (!moved) break;
    }
  }
  return null;
}
export function queensErrors(n, reg, marks) {
  /* marks: 0 порожньо, 1 хрестик, 2 королева */
  const qs = [];
  for (let i = 0; i < n * n; i++) if (marks[i] === 2) qs.push(i);
  const bad = new Set();
  for (let a = 0; a < qs.length; a++) for (let b = a + 1; b < qs.length; b++) {
    const i = qs[a], j = qs[b];
    const r1 = (i / n) | 0, c1 = i % n, r2 = (j / n) | 0, c2 = j % n;
    if (r1 === r2 || c1 === c2 || reg[i] === reg[j] || (Math.abs(r1 - r2) <= 1 && Math.abs(c1 - c2) <= 1)) { bad.add(i); bad.add(j); }
  }
  return { bad, count: qs.length };
}

export function generate(type, seed, level) {
  if (type === 'sudoku') return genSudoku(seed, level);
  if (type === 'tango') return genTango(seed, level);
  if (type === 'queens') return genQueens(seed, level);
  return null;
}
export const _test = { sudokuCount, tangoCount, queensSolve };
