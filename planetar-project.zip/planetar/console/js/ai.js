// ШІ приставки: безкоштовний Cloudflare на сервері + власні ключі гравця (як у NUMO).
// Ключі лежать лише на цьому пристрої й ідуть напряму до провайдера; сервер їх не бачить.
// Порядок провайдерів = порядок спроб; якщо один уперся в ліміт — пробуємо наступного.
// Назви моделей не зашиті намертво: беремо список у провайдера тим самим ключем (раз на 12 год)
// і обираємо за правилом. Звірено з документацією провайдерів 14.11.2026:
//  • Gemini: безкоштовні Flash і Flash-Lite; є псевдоніми gemini-flash-latest / gemini-flash-lite-latest.
//  • Groq: llama-3.1-8b-instant і llama-3.3-70b вимкнено 16.08.2026; робочі openai/gpt-oss-20b / 120b.
//  • OpenRouter: маршрутизатор openrouter/free сам обирає безкоштовну модель.

const H = 3600e3, MIN = 60e3;
export const PROVIDERS = {
  cf: { name: 'Cloudflare', server: true },
  gemini: { name: 'Gemini', fmt: 'gemini', base: 'https://generativelanguage.googleapis.com/v1beta', key: 'https://aistudio.google.com/apikey', families: [/flash-lite/, /flash/], fallback: ['gemini-flash-lite-latest', 'gemini-flash-latest'] },
  groq: { name: 'Groq', fmt: 'openai', base: 'https://api.groq.com/openai/v1', key: 'https://console.groq.com/keys', families: [/gpt-oss-20b/, /gpt-oss-120b/, /llama|qwen|kimi|gemma/], fallback: ['openai/gpt-oss-20b', 'openai/gpt-oss-120b'], extra: { reasoning_effort: 'low' } },
  openrouter: { name: 'OpenRouter', fmt: 'openai', base: 'https://openrouter.ai/api/v1', key: 'https://openrouter.ai/keys', fixed: ['openrouter/free'] },
  openai: { name: 'ChatGPT', fmt: 'openai', base: 'https://api.openai.com/v1', key: 'https://platform.openai.com/api-keys', families: [/^gpt-[\d.]+-mini$/, /^gpt-[\d.]+-nano$/, /^gpt-[\d.]+$/], fallback: ['gpt-4.1-mini'] },
  anthropic: { name: 'Claude', fmt: 'anthropic', base: 'https://api.anthropic.com/v1', key: 'https://console.anthropic.com/settings/keys', families: [/haiku/, /sonnet/], fallback: ['claude-haiku-4-5'] },
  custom: { name: 'Свій агент', custom: true }
};
const NOT_TEXT = /image|imagen|veo|lyria|tts|audio|speech|realtime|live|embed|whisper|moderation|transcri|vision-only|robotics|computer-use|search|aqa|guard|dall|sora|omni-moderation|codex/i;

// Правила безпеки для власних ключів (на сервері Cloudflare ті самі правила додає сам сервер — див. worker.js → SAFE, TASKS)
const SAFE = 'Ти — добрий помічник у дитячій ігровій приставці Pristavka для дітей 8–14 років. Відповідай коротко, дружньо й просто. Не обговорюй небезпечних, дорослих, страшних, політичних чи особистих тем; не проси й не запамʼятовуй особисті дані (адреса, школа, телефон, паролі). Якщо питання недоречне — мʼяко поверни розмову до гри.';
const TASKS = { pet: 'Ти граєш роль улюбленця дитини.', explain: 'Поясни дитині, що робить елемент гри і як ним користуватися: 2–3 речення.', agro: 'Ти — агроном на Фермі в Pristavka. Даєш практичні поради саме для цієї ферми за її станом. 2–4 речення, без вигадок.', story: 'Ти допомагаєш дитині писати власну інтерактивну історію. Пиши тепло й без жорстокості, продовж текст 2–4 реченнями в тому ж стилі.', quiz: 'Ти складаєш питання вікторини для дітей з однією правильною відповіддю. Відповідай лише JSON.', code: 'Ти допомагаєш писати картриджі для приставки: відповідай лише кодом JavaScript-модуля з коментарями.' };
const RISKY = /(суїцид|самогуб|вбити себе|наркот|збро|бомб|секс|порно|suicide|kill myself|drugs|weapon|bomb|sex|porn|самоубий|оружи|ху[йяеї]|пизд|бляд|єба|еба|ёба|fuck|shit|bitch)/i;
const PRIVATE = /(\+?\d[\d\s().-]{8,}\d|@[a-z0-9._-]+\.[a-z]{2,}|вулиц|street|улиц|школа\s*№|school\s*#)/i;
// що не відправляємо ШІ взагалі: повертає 'blocked' | 'private' | null
export function moderate(text) { const s = String(text || ''); return RISKY.test(s) ? 'blocked' : PRIVATE.test(s) ? 'private' : null; }

export function createAI({ fetch: F = (...a) => fetch(...a), now = () => Date.now(), store, server }) {
  const get = (k, d) => store.get('ai:' + k, d), set = (k, v) => store.set('ai:' + k, v);
  const st = {
    order: get('order', ['cf']),           // увімкнені, в порядку спроб
    keys: get('keys', {}),                 // { gemini: '...', ... } — лише на пристрої
    custom: get('custom', { url: '', fmt: 'openai', model: '' }),
    cool: get('cool', {}),                 // { 'groq|model': до_коли }
    models: get('models', {})              // { groq: { at, list } }
  };
  const save = () => { set('order', st.order); set('keys', st.keys); set('custom', st.custom); set('cool', st.cool); set('models', st.models); };

  function enable(id, on) {
    st.order = st.order.filter((x) => x !== id);
    if (on) st.order.push(id);
    save();
  }
  function up(id) { const i = st.order.indexOf(id); if (i > 0) { st.order.splice(i, 1); st.order.splice(i - 1, 0, id); save(); } }
  function setKey(id, key) {
    st.keys[id] = String(key || '').trim();
    for (const k of Object.keys(st.cool)) if (k.startsWith(id + '|')) delete st.cool[k]; // новий ключ — чистий аркуш
    delete st.models[id]; save();
  }
  const ready = (id) => id === 'cf' || (id === 'custom' ? !!st.custom.url : !!st.keys[id]);

  /* ---------- побудова запитів у трьох форматах ---------- */
  function build(fmt, base, model, key, { system, messages, max = 500 }, lite) {
    const msgs = messages.map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', text: String(m.content || '') }));
    if (fmt === 'gemini') {
      const body = { contents: msgs.map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.text }] })), generationConfig: { maxOutputTokens: Math.max(800, max * 2) } };
      if (system) body.systemInstruction = { parts: [{ text: system }] };
      if (!lite) body.generationConfig.thinkingConfig = { thinkingLevel: 'minimal' };
      return { url: `${base}/models/${model}:generateContent`, init: { method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify(body) } };
    }
    if (fmt === 'anthropic') {
      const body = { model, max_tokens: max, messages: msgs.map((m) => ({ role: m.role, content: m.text })) };
      if (system) body.system = system;
      return { url: `${base}/messages`, init: { method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' }, body: JSON.stringify(body) } };
    }
    const body = { model, max_tokens: max * 2, messages: [...(system ? [{ role: 'system', content: system }] : []), ...msgs.map((m) => ({ role: m.role, content: m.text }))] };
    const extra = !lite && Object.values(PROVIDERS).find((p) => p.base === base)?.extra; if (extra) Object.assign(body, extra);
    return { url: `${base}/chat/completions`, init: { method: 'POST', headers: { 'content-type': 'application/json', ...(key ? { authorization: 'Bearer ' + key } : {}) }, body: JSON.stringify(body) } };
  }
  function parse(fmt, j) {
    let text = '';
    if (fmt === 'gemini') text = (j.candidates?.[0]?.content?.parts || []).filter((p) => !p.thought).map((p) => p.text || '').join('');
    else if (fmt === 'anthropic') text = (j.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('');
    else text = j.choices?.[0]?.message?.content || '';
    return String(text).replace(/<think>[\s\S]*?<\/think>/g, '').replace(/^\s*<think>[\s\S]*$/, '').trim();
  }
  // що сказав провайдер → скільки моделі відпочивати
  function classify(status, msg) {
    const s = String(msg || '');
    if (status === 401 || status === 403 || /api[ _-]?key|unauthori[sz]ed|invalid.*key|permission/i.test(s)) return { kind: 'key', ms: H, all: true };
    if (status === 404 || /not.?found|deprecat|does not exist|decommission|no longer/i.test(s)) return { kind: 'gone', ms: 12 * H, refresh: true };
    if (/per.?minute|rpm|PerMinute|tokens per min/i.test(s)) return { kind: 'minute', ms: 3 * MIN };
    if (/per.?day|rpd|PerDay|daily/i.test(s)) return { kind: 'day', ms: 6 * H };
    if (/credit|billing|insufficient|quota|payment/i.test(s)) return { kind: 'quota', ms: H };
    if (status === 429) return { kind: 'minute', ms: 3 * MIN };
    if (status === 503 || status === 529 || /overload|unavailable|capacity/i.test(s)) return { kind: 'busy', ms: 2 * MIN };
    if (status === 400 && /thinking|reasoning|response_format|unsupported|unknown (field|parameter)|not supported/i.test(s)) return { kind: 'param' };
    if (status === 0) return { kind: 'net', ms: 10 * MIN };
    return { kind: 'bad', ms: 10 * MIN };
  }

  /* ---------- список моделей: питаємо провайдера, обираємо за правилом ---------- */
  const ver = (id) => (id.match(/\d+(?:\.\d+)?/g) || []).map(Number);
  const newer = (a, b) => { const x = ver(a), y = ver(b); for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (y[i] || 0) - (x[i] || 0); if (d) return d; } return 0; };
  function rank(id, ids) {
    const p = PROVIDERS[id]; const fresh = ids.filter((m) => !NOT_TEXT.test(m));
    const stable = fresh.filter((m) => !/preview|exp|beta|alpha/i.test(m)); const pool = stable.length ? stable : fresh;
    const out = [];
    for (const fam of p.families || []) out.push(...pool.filter((m) => fam.test(m) && !out.includes(m)).sort(newer).slice(0, 2));
    return out.length ? out.slice(0, 3) : null;
  }
  async function modelsOf(id, deadline) {
    const p = PROVIDERS[id];
    if (id === 'custom') return [st.custom.model || 'default'];
    if (p.fixed) return p.fixed;
    const c = st.models[id];
    if (c && now() - c.at < 12 * H && c.list?.length) return c.list;
    try {
      const key = st.keys[id]; let url = `${p.base}/models`, headers = {};
      if (p.fmt === 'gemini') headers['x-goog-api-key'] = key;
      else if (p.fmt === 'anthropic') headers = { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' };
      else headers.authorization = 'Bearer ' + key;
      const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), Math.min(6000, Math.max(1000, deadline - now())));
      const r = await F(url, { headers, signal: ctl.signal }); clearTimeout(tm);
      if (r.ok) {
        const j = await r.json();
        const ids = (j.data || j.models || []).filter((m) => !m.supportedGenerationMethods || m.supportedGenerationMethods.includes('generateContent')).map((m) => String(m.id || m.name || '').replace(/^models\//, ''));
        const list = rank(id, ids);
        if (list) { st.models[id] = { at: now(), list }; save(); return list; }
      }
    } catch (_) { }
    return p.fallback || [];
  }

  /* ---------- один запит з автопідміною й одним дедлайном ---------- */
  async function ask(opts = {}) {
    const lastQ = [...(opts.messages || [])].reverse().find((m) => m.role !== 'assistant');
    const mod = moderate((lastQ && (lastQ.content || lastQ.text)) || opts.prompt); if (mod) return { moderated: mod };
    const sysFor = (id) => (id === 'cf' ? opts.system : [SAFE, TASKS[opts.task] || '', opts.system || ''].filter(Boolean).join('\n'));
    const deadline = now() + (opts.timeout || 25000);
    const tried = [];
    let anyReady = false;
    for (const id of st.order) {
      if (!ready(id)) continue; anyReady = true;
      if (id === 'cf') {
        if (!server) { tried.push({ id, kind: 'offline' }); continue; }
        if ((st.cool['cf|'] || 0) > now()) { tried.push({ id, kind: 'rest' }); continue; }
        const r = await server(opts).catch((e) => ({ ok: false, error: String(e) }));
        if (r && r.ok && r.text) return { text: r.text, provider: 'cf', model: r.model };
        if (r && r.error === 'limit') { st.cool['cf|'] = now() + 6 * H; save(); }
        tried.push({ id, kind: r && r.offline ? 'offline' : r && r.error === 'limit' ? 'day' : 'bad' }); continue;
      }
      const p = PROVIDERS[id], fmt = id === 'custom' ? st.custom.fmt : p.fmt, base = id === 'custom' ? st.custom.url.replace(/\/+$/, '') : p.base;
      if (Object.keys(st.cool).some((k) => k === id + '|*' && st.cool[k] > now())) { tried.push({ id, kind: 'key' }); continue; }
      for (const model of await modelsOf(id, deadline)) {
        if (now() > deadline) return fail(tried, anyReady, 'time');
        if ((st.cool[id + '|' + model] || 0) > now()) { tried.push({ id, model, kind: 'rest' }); continue; }
        for (let lite = 0; lite < 2; lite++) {
          const { url, init } = build(fmt, base, model, st.keys[id], { system: sysFor(id), messages: opts.messages || [{ role: 'user', content: opts.prompt || '' }], max: opts.max || 400 }, !!lite);
          const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), Math.max(1000, deadline - now()));
          let status = 0, msg = '', j = null;
          try { const r = await F(url, { ...init, signal: ctl.signal }); status = r.status; const txt = await r.text(); try { j = JSON.parse(txt); } catch (_) { msg = txt; } if (!r.ok) msg = (j && (j.error?.message || j.error || j.message)) || msg || ('HTTP ' + status); }
          catch (e) { status = 0; msg = String(e); }
          clearTimeout(tm);
          if (status >= 200 && status < 300 && j) {
            const text = parse(fmt, j);
            if (text) return { text, provider: id, model };
            tried.push({ id, model, kind: 'empty' }); break; // порожня відповідь — збій спроби, не моделі
          }
          const c = classify(status, typeof msg === 'string' ? msg : JSON.stringify(msg));
          if (c.kind === 'param' && !lite) continue; // повтор тієї ж моделі без зайвого параметра, лише раз
          tried.push({ id, model, kind: c.kind });
          if (c.ms) st.cool[c.all ? id + '|*' : id + '|' + model] = now() + c.ms;
          if (c.refresh) delete st.models[id];
          save(); break;
        }
        if (tried.length && tried[tried.length - 1].kind === 'key') break; // невірний ключ — решту моделей провайдера не пробуємо
      }
    }
    return fail(tried, anyReady);
  }
  function fail(tried, anyReady, why) {
    const kinds = tried.map((x) => x.kind);
    const reason = !anyReady ? 'none' : why === 'time' ? 'time' : kinds.includes('key') && kinds.every((k) => k === 'key' || k === 'rest') ? 'key' : kinds.every((k) => ['minute', 'day', 'quota', 'rest'].includes(k)) ? 'limit' : kinds.every((k) => ['net', 'offline'].includes(k)) ? 'net' : 'all';
    return { text: '', error: reason, tried };
  }
  // «Перевірити зв'язок»: кожен увімкнений провайдер окремо, з часом відповіді
  async function test() {
    const out = [];
    for (const id of st.order) {
      const t0 = now();
      if (!ready(id)) { out.push({ id, ok: false, why: 'nokey' }); continue; }
      const saved = st.order; st.order = [id];
      const r = await ask({ prompt: 'Скажи одним словом: привіт', max: 30, timeout: 15000 });
      st.order = saved;
      out.push({ id, ok: !!r.text, why: r.error, ms: now() - t0, model: r.model });
    }
    return out;
  }
  return { st, enable, up, setKey, ready, ask, test, save, _: { build, parse, classify, rank } };
}
