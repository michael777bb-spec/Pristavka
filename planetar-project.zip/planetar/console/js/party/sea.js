// Морський бій: у кімнаті (2–4 гравці, вільні місця — боти) або проти комп’ютера на одному пристрої.
// Лише HTML і CSS, без WebGL — працює на будь-якому телефоні, планшеті й ПК, зокрема на старих.
//
// Як улаштовано: усі гравці отримують однаковий упорядкований потік повідомлень (сервер кімнати
// нумерує їх), і кожен сам рахує той самий стан: флоти, постріли, чия черга. Ведучий (host) ще й
// розставляє флоти ботам, стріляє за ботів і за тих, хто вийшов або задовго думає (таймер ходу).
// Повідомлення: { t:'fleet', ships:[[r,c,len,dir]…] } і { t:'shot', target, cell, k } (k — номер пострілу:
// запізнілий чи подвійний постріл просто не застосовується).

const TX = {
  uk: { place: 'Розстав кораблі', placeHint: 'Тягни корабель, щоб пересунути. Торкнись — повернути.', shuffle: 'Перемішати', ready: 'Готово', waitPlace: 'Чекаємо, поки інші розставлять кораблі', readyN: 'готові: {a} з {b}', yourTurn: 'Твій хід — стріляй!', turnOf: 'Хід: {n}', you: 'Ти', miss: 'мимо', hit: 'влучив!', sunk: 'потопив!', out: '{n}: флот потоплено', win: 'Перемога!', winner: 'Переміг: {n}', again: 'Ще раз', leave: 'Вийти', waitHost: 'Чекаємо, поки ведучий почне знову', yourFleet: 'Твій флот', lost: 'Твій флот потоплено — дивись, хто переможе', spectate: 'Гра вже йде — ти дивишся', timeout: 'Час минув — постріл за тебе', bad: 'Тут кораблі торкаються — так не можна', pick: 'Обери, по кому стріляти' },
  en: { place: 'Place your ships', placeHint: 'Drag a ship to move it. Tap it to turn it.', shuffle: 'Shuffle', ready: 'Ready', waitPlace: 'Waiting for the others to place their ships', readyN: 'ready: {a} of {b}', yourTurn: 'Your turn — fire!', turnOf: 'Turn: {n}', you: 'You', miss: 'miss', hit: 'hit!', sunk: 'sunk!', out: '{n}: fleet sunk', win: 'Victory!', winner: 'Winner: {n}', again: 'Again', leave: 'Leave', waitHost: 'Waiting for the host to start again', yourFleet: 'Your fleet', lost: 'Your fleet is sunk — watch who wins', spectate: 'The game is on — you are watching', timeout: 'Time is up — a shot was fired for you', bad: 'Ships would touch here — not allowed', pick: 'Choose whom to fire at' },
  ru: { place: 'Расставь корабли', placeHint: 'Тяни корабль, чтобы передвинуть. Коснись — повернуть.', shuffle: 'Перемешать', ready: 'Готово', waitPlace: 'Ждём, пока остальные расставят корабли', readyN: 'готовы: {a} из {b}', yourTurn: 'Твой ход — стреляй!', turnOf: 'Ход: {n}', you: 'Ты', miss: 'мимо', hit: 'попал!', sunk: 'потопил!', out: '{n}: флот потоплен', win: 'Победа!', winner: 'Победил: {n}', again: 'Ещё раз', leave: 'Выйти', waitHost: 'Ждём, пока ведущий начнёт снова', yourFleet: 'Твой флот', lost: 'Твой флот потоплен — смотри, кто победит', spectate: 'Игра уже идёт — ты смотришь', timeout: 'Время вышло — выстрел за тебя', bad: 'Здесь корабли касаются — так нельзя', pick: 'Выбери, по кому стрелять' }
};
const fmt = (s, o) => String(s).replace(/\{(\w+)\}/g, (_, k) => o[k] ?? '');
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const TURN_S = 30, PLACE_S = 120;

/* ---------- правила: флот, перевірка, випадкова розстановка ---------- */
export function setup(players) { return players <= 2 ? { size: 10, fleet: [4, 3, 3, 2, 2, 2, 1, 1, 1, 1] } : { size: 8, fleet: [4, 3, 2, 2, 1, 1] }; }
function cellsOf(s, N) { const out = []; for (let k = 0; k < s.len; k++) out.push((s.r + (s.dir ? k : 0)) * N + s.c + (s.dir ? 0 : k)); return out; }
function fits(s, N) { return s.r >= 0 && s.c >= 0 && (s.dir ? s.r + s.len : s.c + s.len) <= N && (s.dir ? s.c < N : s.r < N); }
// чи можна поставити корабель s, не торкаючись інших (навіть кутами)
function free(s, ships, N, skip) {
  if (!fits(s, N)) return false;
  const busy = new Set(); ships.forEach((o, j) => { if (j === skip) return; for (const i of cellsOf(o, N)) { const r = (i / N) | 0, c = i % N; for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) busy.add((r + dr) * 100 + c + dc); } });
  return cellsOf(s, N).every((i) => !busy.has(((i / N) | 0) * 100 + i % N));
}
export function randomFleet(N, fleet) {
  for (let attempt = 0; attempt < 50; attempt++) {
    const ships = []; let ok = true;
    for (const len of fleet) {
      let placed = false;
      for (let k = 0; k < 400 && !placed; k++) { const s = { r: (Math.random() * N) | 0, c: (Math.random() * N) | 0, len, dir: Math.random() < 0.5 ? 1 : 0 }; if (free(s, ships, N)) { ships.push(s); placed = true; } }
      if (!placed) { ok = false; break; }
    }
    if (ok) return ships;
  }
  return null;
}
function validFleet(arr, N, fleet) {
  if (!Array.isArray(arr) || arr.length !== fleet.length) return null;
  const ships = arr.map((a) => ({ r: a[0] | 0, c: a[1] | 0, len: a[2] | 0, dir: a[3] ? 1 : 0 }));
  if (ships.map((s) => s.len).sort((a, b) => b - a).join() !== fleet.slice().sort((a, b) => b - a).join()) return null;
  for (let j = 0; j < ships.length; j++) if (!free(ships[j], ships.slice(0, j), N)) return null;
  return ships;
}

/* ---------- гра ---------- */
export function mount(root, X) {
  const L = TX[X.lang] || TX.uk, N = X.data.size, FLEET = X.data.fleet, me = String(X.me);
  const order = X.roster.map((p, i) => ({ ...p, id: String(p.id), i, ships: null, shot: new Uint8Array(N * N), alive: true, sunkN: 0 }));
  const P = new Map(order.map((p) => [p.id, p]));
  const mine = P.get(me);            // null — я глядач (зайшов, коли гра вже йшла)
  let phase = 'place', cur = 0, shots = 0, place = mine ? randomFleet(N, FLEET) : null, sent = false;
  let target = null, last = null, msg = '', winner = null, outOrder = [], autoT = 0, placeT = 0, turnAt = Date.now(), alive = true;

  root.innerHTML = `<div class="sea"><div class="sea-top"><b class="sea-turn"></b><i class="sea-timer"><b></b></i></div><div class="sea-tabs"></div><div class="sea-main"></div><div class="sea-foot"></div><div class="sea-over" hidden></div></div>`;
  const el = { box: root.querySelector('.sea'), turn: root.querySelector('.sea-turn'), timer: root.querySelector('.sea-timer'), tabs: root.querySelector('.sea-tabs'), main: root.querySelector('.sea-main'), foot: root.querySelector('.sea-foot'), over: root.querySelector('.sea-over') };
  let big = 300, mini = 110;
  function fit() {
    const W = root.clientWidth, H = root.clientHeight, wide = W > H * 1.15;
    el.box.classList.toggle('wide', wide);
    const tabsH = phase === 'battle' && order.length > 2 ? 40 : 0;
    if (wide) { big = Math.floor(Math.min(H - 60 - tabsH, W * 0.6)); mini = Math.floor(Math.min(W - big - 48, H * 0.42, 220)); }
    else { mini = phase === 'battle' && mine ? Math.floor(Math.max(84, Math.min(150, H * 0.2))) : 0; big = Math.floor(Math.min(W - 20, H - 52 - tabsH - (phase === 'battle' ? mini + 14 : 76))); }
    big = Math.max(150, big); render();
  }
  const ro = new ResizeObserver(fit); ro.observe(root);

  /* ---- малювання ---- */
  const nameOf = (p) => p.id === me ? L.you : p.name;
  function board(p, size, o) {
    const cs = size / N, reveal = o.own || phase === 'over';
    let h = `<div class="sea-board ${o.cls || ''}" data-id="${p.id}" style="width:${size}px;height:${size}px;--cs:${cs}px;--n:${N}">`;
    for (let i = 0; i < N * N; i++) { const v = p.shot[i]; h += `<i class="sc${v === 1 ? ' m' : v === 2 ? ' h' : v === 3 ? ' a' : v === 4 ? ' h s' : ''}${last && last.t === p.id && last.cell === i ? ' boom' : ''}"></i>`; }
    const ships = o.ships || p.ships || [];
    ships.forEach((s, j) => {
      const sunk = p.ships && cellsOf(s, N).every((i) => p.shot[i] === 4);
      if (!reveal && !sunk) return;
      const pad = cs * 0.1;
      h += `<b class="sh${s.dir ? ' v' : ''}${sunk ? ' dead' : ''}${o.drag && o.drag.j === j ? ' lift' : ''}" style="left:${s.c * cs + pad}px;top:${s.r * cs + pad}px;width:${(s.dir ? 1 : s.len) * cs - pad * 2}px;height:${(s.dir ? s.len : 1) * cs - pad * 2}px"></b>`;
    });
    if (o.ghost) { const g = o.ghost; h += `<b class="sh ghost${g.ok ? '' : ' bad'}${g.s.dir ? ' v' : ''}" style="left:${g.s.c * cs}px;top:${g.s.r * cs}px;width:${(g.s.dir ? 1 : g.s.len) * cs}px;height:${(g.s.dir ? g.s.len : 1) * cs}px"></b>`; }
    return h + '</div>';
  }
  const shooter = () => order[cur];
  function aliveOpp(of) { return order.filter((p) => p.alive && p.id !== of); }
  function pickTarget() { if (!mine || !mine.alive) return; const op = aliveOpp(me); if (!target || !op.some((p) => p.id === target)) { const k = order.findIndex((p) => p.id === me); target = (op.find((p) => p.i > k) || op[0] || {}).id || null; } }
  function render() {
    if (!alive) return;
    el.box.dataset.phase = phase;
    if (phase === 'place') {
      el.tabs.innerHTML = '';
      const ready = order.filter((p) => p.ships).length;
      if (mine && !sent) {
        el.turn.textContent = L.place;
        el.main.innerHTML = board(mine, big, { own: true, ships: place, cls: 'edit', drag, ghost });
        el.foot.innerHTML = `<p class="sea-hint">${esc(msg || L.placeHint)}</p><div class="sea-btns"><button class="chip" data-sea="shuffle">${esc(L.shuffle)}</button><button class="chip on" data-sea="ready">${esc(L.ready)}</button></div>`;
      } else {
        el.turn.textContent = mine ? L.waitPlace : L.spectate;
        el.main.innerHTML = mine ? board(mine, big, { own: true, cls: 'dim' }) : '';
        el.foot.innerHTML = `<p class="sea-hint">${esc(fmt(L.readyN, { a: ready, b: order.length }))}</p>`;
      }
      return;
    }
    const s = shooter(), my = phase === 'battle' && mine && mine.alive && s.id === me;
    if (my) pickTarget();
    const view = P.get(target) || aliveOpp(me)[0] || order.find((p) => p.id !== me);
    el.turn.innerHTML = phase === 'over' ? esc(fmt(L.winner, { n: winner ? nameOf(winner) : '—' })) : my ? `<span class="me">${esc(L.yourTurn)}</span>` : esc(fmt(L.turnOf, { n: nameOf(s) }));
    el.tabs.innerHTML = order.length > 2 ? order.filter((p) => p.id !== me).map((p) => `<button class="chip sm${view && p.id === view.id ? ' on' : ''}${p.alive ? '' : ' gone'}" data-sea="view" data-arg="${esc(p.id)}" style="--c:${p.c}"><i class="dot"></i>${esc(p.name)} · ${p.ships ? p.ships.length - p.sunkN : 0}</button>`).join('') : '';
    el.main.innerHTML = view ? board(view, big, { cls: `target${my && view.alive && view.id !== me ? ' live' : ''}` }) : '';
    el.foot.innerHTML = (mine ? `<div class="sea-mine"><span>${esc(L.yourFleet)}</span>${board(mine, mini, { own: true, cls: 'mini' })}</div>` : '') + `<p class="sea-log">${esc(msg || (mine && !mine.alive && phase === 'battle' ? L.lost : ''))}</p>`;
  }
  function timerBar(sec) { const b = el.timer.querySelector('b'); el.timer.style.visibility = sec ? 'visible' : 'hidden'; if (!sec) return; b.style.animation = 'none'; void b.offsetWidth; b.style.animation = `seaTime ${sec}s linear forwards`; }

  /* ---- розстановка: тягнути й повертати ---- */
  let drag = null, ghost = null, aim = null;
  function cellAt(bd, x, y) { const r = bd.getBoundingClientRect(), c = Math.floor((x - r.left) / (r.width / N)), w = Math.floor((y - r.top) / (r.height / N)); return { r: w, c, inside: c >= 0 && w >= 0 && c < N && w < N }; }
  function onDown(e) {
    const bd = e.target.closest && e.target.closest('.sea-board'); if (!bd || !alive) return;
    if (phase === 'place' && mine && !sent && bd.classList.contains('edit')) {
      const p = cellAt(bd, e.clientX, e.clientY); if (!p.inside) return;
      const j = place.findIndex((s) => cellsOf(s, N).includes(p.r * N + p.c)); if (j < 0) return;
      e.preventDefault(); drag = { j, id: e.pointerId, x: e.clientX, y: e.clientY, offR: p.r - place[j].r, offC: p.c - place[j].c, moved: false }; render();
    } else if (bd.classList.contains('live')) {
      const p = cellAt(bd, e.clientX, e.clientY); if (!p.inside) return;
      e.preventDefault(); aim = { id: e.pointerId, t: bd.dataset.id, cell: p.r * N + p.c };
    }
  }
  function onMove(e) {
    if (!drag || e.pointerId !== drag.id) return;
    if (!drag.moved && Math.hypot(e.clientX - drag.x, e.clientY - drag.y) < 8) return;
    drag.moved = true; const bd = el.main.querySelector('.sea-board'); if (!bd) return;
    const p = cellAt(bd, e.clientX, e.clientY), s = { ...place[drag.j], r: p.r - drag.offR, c: p.c - drag.offC };
    ghost = { s, ok: free(s, place, N, drag.j) }; render();
  }
  function onUp(e) {
    if (aim && e.pointerId === aim.id) {
      const a = aim; aim = null; const bd = el.main.querySelector('.sea-board.live');
      if (bd && e.type === 'pointerup') { const p = cellAt(bd, e.clientX, e.clientY); if (p.inside && p.r * N + p.c === a.cell) fire(a.t, a.cell); }
      return;
    }
    if (!drag || e.pointerId !== drag.id) return;
    const d = drag; drag = null; msg = '';
    if (!d.moved) { const s = place[d.j], t = { ...s, dir: s.dir ? 0 : 1 }; if (free(t, place, N, d.j)) { place[d.j] = t; X.sfx('place'); } else { msg = L.bad; X.sfx('bad'); } }
    else if (ghost && ghost.ok) { place[d.j] = ghost.s; X.sfx('place'); }
    else { msg = L.bad; X.sfx('bad'); }
    ghost = null; render();
  }
  function onClick(e) {
    const b = e.target.closest && e.target.closest('[data-sea]'); if (!b || !alive) return;
    const a = b.dataset.sea;
    if (a === 'shuffle') { place = randomFleet(N, FLEET); msg = ''; X.sfx('page'); render(); }
    else if (a === 'ready' && !sent && place) { sent = true; X.send({ t: 'fleet', ships: place.map((s) => [s.r, s.c, s.len, s.dir]) }); X.sfx('ok'); render(); }
    else if (a === 'view') { target = b.dataset.arg; render(); }
    else if (a === 'again') X.again();
    else if (a === 'leave') X.leave();
  }
  root.addEventListener('pointerdown', onDown);
  document.addEventListener('pointermove', onMove, { passive: true });
  document.addEventListener('pointerup', onUp); document.addEventListener('pointercancel', onUp);
  root.addEventListener('click', onClick);

  /* ---- постріл ---- */
  let firing = -1;
  function fire(tid, cell) {
    const t = P.get(tid); if (!t || phase !== 'battle' || shooter().id !== me || firing === shots || t.shot[cell]) return;
    firing = shots; X.send({ t: 'shot', target: tid, cell, k: shots });
  }

  /* ---- застосування повідомлень (у всіх однаково) ---- */
  function onMsg(m) {
    if (!alive || m.t !== 'move' || !m.data) return;
    const d = m.data, by = String(d.bot !== undefined ? d.bot : m.from), p = P.get(by); if (!p) return;
    if (d.t === 'fleet' && phase === 'place' && !p.ships) {
      const ships = validFleet(d.ships, N, FLEET); if (!ships) return;
      p.ships = ships.map((s) => ({ ...s, cells: cellsOf(s, N), hits: 0 }));
      if (p.id === me) sent = true;
      if (order.every((q) => q.ships)) { phase = 'battle'; cur = 0; shots = 0; turnAt = Date.now(); X.sfx('whoosh'); fit(); timerBar(order[0].bot ? 0 : TURN_S); }
      else render();
    } else if (d.t === 'shot' && phase === 'battle') {
      const t = P.get(String(d.target)), cell = d.cell | 0;
      if (by !== shooter().id || d.k !== shots || !t || !t.alive || t.id === by || cell < 0 || cell >= N * N || t.shot[cell]) return;
      shots++; firing = -1;
      const s = t.ships.find((q) => q.cells.includes(cell)); let res = 'miss';
      if (s) {
        s.hits++; t.shot[cell] = 2; res = 'hit';
        if (s.hits >= s.len) {
          res = 'sunk'; t.sunkN++;
          for (const i of s.cells) { t.shot[i] = 4; const r = (i / N) | 0, c = i % N; for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) { const rr = r + dr, cc = c + dc; if (rr >= 0 && cc >= 0 && rr < N && cc < N && !t.shot[rr * N + cc]) t.shot[rr * N + cc] = 3; } }
          if (t.sunkN >= t.ships.length) { t.alive = false; outOrder.push(t); }
        }
      } else t.shot[cell] = 1;
      last = { t: t.id, cell, res };
      msg = `${nameOf(p)} → ${nameOf(t)}: ${L[res]}${!t.alive ? ' · ' + fmt(L.out, { n: nameOf(t) }) : ''}${d.auto && by === me ? ' · ' + L.timeout : ''}`;
      X.sfx(res === 'miss' ? 'splash' : res === 'hit' ? 'hit' : 'thunder');
      if (t.id === me && res !== 'miss' && navigator.vibrate) try { navigator.vibrate(res === 'sunk' ? [30, 40, 60] : 25); } catch (_) { }
      const left = order.filter((q) => q.alive);
      if (left.length <= 1) { phase = 'over'; winner = left[0] || p; X.sfx(winner.id === me ? 'win' : 'bad'); timerBar(0); showOver(); }
      else {
        if (res === 'miss' || !aliveOpp(by).length) { do { cur = (cur + 1) % order.length; } while (!order[cur].alive); }
        turnAt = Date.now(); timerBar(order[cur].bot ? 0 : TURN_S);
        if (order[cur].id === me) { X.sfx('bell'); if (!t.alive || t.id === me) target = null; }
        else if (t.id !== me && t.alive && (!mine || order[cur].id !== me)) target = t.id; // глядимо туди, куди стріляють
      }
      render();
    }
    host();
  }
  function showOver() {
    const rank = [winner, ...outOrder.slice().reverse().filter((p) => p !== winner)];
    el.over.hidden = false;
    el.over.innerHTML = `<div class="sea-res"><b class="disp">${esc(winner && winner.id === me ? L.win : fmt(L.winner, { n: winner ? nameOf(winner) : '—' }))}</b>${rank.map((p, i) => `<div class="lead${p.id === me ? ' me' : ''}"><span>${X.medal(i)} ${esc(nameOf(p))}</span><span class="mono">${p.ships ? p.ships.length - p.sunkN : 0}</span></div>`).join('')}<span class="row">${X.host ? `<button class="chip on" data-sea="again">${esc(L.again)}</button>` : `<span class="muted">${esc(L.waitHost)}</span>`}<button class="chip" data-sea="leave">${esc(L.leave)}</button></span></div>`;
  }

  /* ---- ведучий: боти, таймери, ті, хто вийшов ---- */
  function host() {
    if (!X.host || !alive) return;
    clearTimeout(autoT);
    const live = X.live();
    if (phase === 'place') {
      const need = order.filter((p) => !p.ships && (p.bot || !live.has(p.id)));
      if (need.length) { autoT = setTimeout(() => { const p = need[0]; if (!p.ships) X.send({ t: 'fleet', bot: p.id, ships: randomFleet(N, FLEET).map((s) => [s.r, s.c, s.len, s.dir]) }); }, need[0].bot ? 300 : 2500); return; }
      return;
    }
    if (phase !== 'battle') return;
    const s = shooter(), absent = !s.bot && !live.has(s.id);
    const wait = s.bot ? 700 + Math.random() * 900 : absent ? 1500 : Math.max(0, TURN_S * 1000 - (Date.now() - turnAt));
    const k = shots;
    autoT = setTimeout(() => { if (shots !== k || phase !== 'battle') return; const a = aiShot(s, s.bot ? X.data.level : 'easy'); if (a) X.send({ t: 'shot', bot: s.id, target: a.target, cell: a.cell, k, auto: !s.bot }); }, wait);
  }
  // розстановка: для людей ведучий чекає PLACE_S секунд, далі ставить флот випадково
  if (X.host) placeT = setTimeout(() => { for (const p of order) if (!p.ships && !p.bot) X.send({ t: 'fleet', bot: p.id, ships: randomFleet(N, FLEET).map((s) => [s.r, s.c, s.len, s.dir]) }); }, PLACE_S * 1000);

  // комп’ютер стріляє лише за тим, що бачать усі (постріли на полях), — флотів суперників він «не підглядає»
  function aiShot(s, level) {
    const opp = aliveOpp(s.id); if (!opp.length) return null;
    const open = (t) => { const a = []; for (let i = 0; i < N * N; i++) if (t.shot[i] === 2) a.push(i); return a; };
    const t = opp.find((o) => open(o).length) || opp[(Math.random() * opp.length) | 0];
    const hits = open(t), empty = (i) => i >= 0 && i < N * N && !t.shot[i];
    let cand = [];
    if (hits.length && !(level === 'easy' && Math.random() < 0.4)) {
      const rows = new Set(hits.map((i) => (i / N) | 0)), cols = new Set(hits.map((i) => i % N));
      if (hits.length > 1 && (rows.size === 1 || cols.size === 1)) { const lo = Math.min(...hits), hi = Math.max(...hits), step = rows.size === 1 ? 1 : N; for (const i of [lo - step, hi + step]) if (empty(i) && (step === N || ((i / N) | 0) === ((lo / N) | 0))) cand.push(i); }
      if (!cand.length) for (const i of hits) { const r = (i / N) | 0, c = i % N; for (const [dr, dc] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const rr = r + dr, cc = c + dc; if (rr >= 0 && cc >= 0 && rr < N && cc < N && empty(rr * N + cc)) cand.push(rr * N + cc); } }
    }
    if (!cand.length) { for (let i = 0; i < N * N; i++) if (empty(i)) cand.push(i); if (level !== 'easy') { const par = cand.filter((i) => (((i / N) | 0) + i % N) % 2 === 0); if (par.length) cand = par; } }
    return cand.length ? { target: t.id, cell: cand[(Math.random() * cand.length) | 0] } : null;
  }

  // для автоматичних перевірок (?dbg): однаковий «відбиток» стану в усіх гравців = гра узгоджена
  if (/[?&]dbg/.test(location.search)) window.__sea = { phase: () => phase, shots: () => shots, cur: () => order[cur] && order[cur].id, me, winner: () => winner && winner.id, sig: () => order.map((p) => p.id + ':' + (p.ships ? p.ships.length : '-') + ':' + Array.from(p.shot).join('')).join('|') };
  fit(); host(); if (mine) timerBar(PLACE_S);
  return {
    onMsg,
    onLobby() { host(); },               // хтось вийшов — ведучий підхопить його хід
    destroy() { alive = false; clearTimeout(autoT); clearTimeout(placeT); ro.disconnect(); document.removeEventListener('pointermove', onMove); document.removeEventListener('pointerup', onUp); document.removeEventListener('pointercancel', onUp); root.innerHTML = ''; }
  };
}
