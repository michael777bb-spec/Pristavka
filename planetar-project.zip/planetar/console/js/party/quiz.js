// Вікторина: у кімнаті (2–12 гравців, вільні місця — боти) або на одному пристрої (по черзі чи проти ботів).
// Лише HTML і CSS — працює на будь-якому пристрої, також без інтернету (питання — у quizbank.js).
//
// Веде гру ведучий (host): обирає питання, розсилає їх, приймає відповіді, рахує очки й показує результат.
// Інші лише показують те, що прислав ведучий, і надсилають свою відповідь.
// Стани від ведучого: { t:'q', n, total, id | ai:{q,o,a}, who, T } → { t:'rev', n, a, picks, gain, score } → … → { t:'end', score }.
// Відповідь гравця: { t:'ans', n, k } (k — номер кнопки на екрані).
import { BANK, TOPICS, question } from './quizbank.js';

const TX = {
  uk: { get: 'Приготуйся…', qn: 'Питання {n} з {t}', who: 'Відповідає: {n}', you: 'Ти', wait: 'Чекаємо інших…', right: 'Правильно!', wrong: 'Ні — правильна відповідь виділена', none: 'Час минув', ai: 'ШІ', end: 'Вікторина завершена', winner: 'Переміг: {n}', again: 'Ще раз', leave: 'Вийти', waitHost: 'Чекаємо, поки ведучий почне знову', pts: 'очок', yourTurn: 'Твоя черга!' },
  en: { get: 'Get ready…', qn: 'Question {n} of {t}', who: 'Answering: {n}', you: 'You', wait: 'Waiting for the others…', right: 'Correct!', wrong: 'No — the right answer is highlighted', none: 'Time is up', ai: 'AI', end: 'Quiz finished', winner: 'Winner: {n}', again: 'Again', leave: 'Leave', waitHost: 'Waiting for the host to start again', pts: 'pts', yourTurn: 'Your turn!' },
  ru: { get: 'Приготовься…', qn: 'Вопрос {n} из {t}', who: 'Отвечает: {n}', you: 'Ты', wait: 'Ждём остальных…', right: 'Правильно!', wrong: 'Нет — правильный ответ выделен', none: 'Время вышло', ai: 'ИИ', end: 'Викторина окончена', winner: 'Победил: {n}', again: 'Ещё раз', leave: 'Выйти', waitHost: 'Ждём, пока ведущий начнёт снова', pts: 'очк.', yourTurn: 'Твоя очередь!' }
};
const fmt = (s, o) => String(s).replace(/\{(\w+)\}/g, (_, k) => o[k] ?? '');
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
// однакове «випадкове» в усіх гравців: варіанти питання n перемішуються за спільним зерном гри
function rng(seed) { let s = (seed >>> 0) || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }
function shuffled(arr, seed) { const a = arr.slice(), r = rng(seed); for (let i = a.length - 1; i > 0; i--) { const j = (r() * (i + 1)) | 0; [a[i], a[j]] = [a[j], a[i]]; } return a; }
const SHAPES = ['▲', '◆', '●', '■'];
const ACC = { easy: 0.5, medium: 0.68, hard: 0.85 };   // як часто бот відповідає правильно

export function mount(root, X) {
  const L = TX[X.lang] || TX.uk, me = String(X.me), D = X.data;
  const people = X.roster.map((p) => ({ ...p, id: String(p.id) })), byId = new Map(people.map((p) => [p.id, p]));
  const T = D.mode === 'turns' ? 25 : 20;
  let st = null, picked = -1, answered = new Set(), score = {}, alive = true;
  root.innerHTML = `<div class="quiz"><div class="qz-top"><span class="qz-n"></span><span class="qz-tag"></span><i class="sea-timer qz-timer"><b></b></i></div><div class="qz-who"></div><div class="qz-q"></div><div class="qz-opts"></div><div class="qz-foot"></div></div>`;
  const el = { box: root.querySelector('.quiz'), n: root.querySelector('.qz-n'), tag: root.querySelector('.qz-tag'), timer: root.querySelector('.qz-timer'), who: root.querySelector('.qz-who'), q: root.querySelector('.qz-q'), opts: root.querySelector('.qz-opts'), foot: root.querySelector('.qz-foot') };
  const nameOf = (id) => id === me ? L.you : (byId.get(id) || {}).name || '—';
  const fit = () => { const H = root.clientHeight, W = root.clientWidth; el.box.style.setProperty('--qf', Math.max(15, Math.min(26, Math.min(W / 18, H / 26))) + 'px'); el.box.classList.toggle('wide', W > H * 1.2); };
  const ro = new ResizeObserver(fit); ro.observe(root);

  /* ---- що показати для питання ---- */
  function view(s) {
    if (s.ai) return { q: s.ai.q, o: s.ai.o, a: s.ai.a, ai: true, topic: s.topic };
    const q = question(s.id, X.lang); if (!q) return null;
    const ord = shuffled([0, 1, 2, 3], (D.seed >>> 0) + s.n * 7919 + s.id);
    return { q: q.q, o: ord.map((i) => q.o[i]), a: ord.indexOf(0), topic: q.topic };
  }
  function timerBar(sec) { const b = el.timer.querySelector('b'); el.timer.style.visibility = sec ? 'visible' : 'hidden'; if (!sec) return; b.style.animation = 'none'; void b.offsetWidth; b.style.animation = `seaTime ${sec}s linear forwards`; }
  function board(sc, gain, limit) {
    const rows = people.slice().sort((a, b) => (sc[b.id] || 0) - (sc[a.id] || 0));
    return `<div class="qz-board">${rows.slice(0, limit || rows.length).map((p, i) => `<div class="lead${p.id === me ? ' me' : ''}"><span>${X.medal(i)} ${esc(nameOf(p.id))}</span><span class="mono">${gain && gain[p.id] ? `<em>+${gain[p.id]}</em> ` : ''}${sc[p.id] || 0}</span></div>`).join('')}</div>`;
  }
  function dots() { return `<div class="qz-dots">${people.filter((p) => !st || !st.who || st.who === p.id).map((p) => `<i class="${answered.has(p.id) ? 'on' : ''}" style="--c:${p.c}" title="${esc(p.name)}"></i>`).join('')}</div>`; }
  function canAnswer() { return st && st.t === 'q' && picked < 0 && (st.who ? (st.who === me || (X.local && !(byId.get(st.who) || {}).bot)) : byId.has(me)); }
  function render() {
    if (!alive) return;
    if (!st) { el.n.textContent = ''; el.q.innerHTML = `<b class="qz-get">${esc(L.get)}</b>`; el.opts.innerHTML = ''; el.foot.innerHTML = ''; el.who.innerHTML = ''; return; }
    if (st.t === 'end') {
      timerBar(0); const rows = people.slice().sort((a, b) => (st.score[b.id] || 0) - (st.score[a.id] || 0)), top = rows[0];
      el.n.textContent = L.end; el.tag.textContent = ''; el.who.innerHTML = ''; el.opts.innerHTML = '';
      el.q.innerHTML = `<div class="qz-end"><b class="disp qz-win">${esc(top && top.id === me ? '🏆 ' + L.end : fmt(L.winner, { n: top ? nameOf(top.id) : '—' }))}</b>${board(st.score)}</div>`;
      el.foot.innerHTML = `<span class="row">${X.host ? `<button class="chip on" data-qz="again">${esc(L.again)}</button>` : `<span class="muted">${esc(L.waitHost)}</span>`}<button class="chip" data-qz="leave">${esc(L.leave)}</button></span>`;
      return;
    }
    const v = view(st); if (!v) return;
    const rev = st.t === 'rev';
    el.n.textContent = fmt(L.qn, { n: st.n + 1, t: st.total });
    el.tag.innerHTML = `${esc((TOPICS[v.topic] || TOPICS.all)[X.lang] || '')}${v.ai ? ` · <b class="ai">✨ ${esc(L.ai)}</b>` : ''}`;
    el.who.innerHTML = st.who ? `<span class="chip sm on" style="--c:${(byId.get(st.who) || {}).c}">${esc(st.who === me ? L.yourTurn : fmt(L.who, { n: nameOf(st.who) }))}</span>` : '';
    el.q.innerHTML = `<p>${esc(v.q)}</p>`;
    const mine = rev ? (st.picks[st.who || me] ?? -1) : picked;
    el.opts.innerHTML = v.o.map((o, k) => `<button class="qz-o o${k}${rev && k === st.a ? ' ok' : ''}${rev && k === mine && k !== st.a ? ' no' : ''}${!rev && k === picked ? ' sel' : ''}" data-qz="ans" data-k="${k}" ${canAnswer() ? '' : 'disabled'}><i>${SHAPES[k]}</i><span>${esc(o)}</span></button>`).join('');
    if (rev) {
      const who = st.who || me, got = st.gain[who];
      el.foot.innerHTML = (byId.has(who) ? `<p class="qz-res ${got ? 'good' : 'bad'}">${esc(got ? `${L.right} +${got}` : mine < 0 ? L.none : L.wrong)}</p>` : '') + board(st.score, st.gain, 5);
    } else el.foot.innerHTML = (picked >= 0 ? `<p class="muted">${esc(L.wait)}</p>` : '') + dots();
  }
  function onClick(e) {
    const b = e.target.closest && e.target.closest('[data-qz]'); if (!b || !alive) return;
    if (b.dataset.qz === 'ans' && canAnswer()) { picked = +b.dataset.k; X.sfx('choose'); X.send({ t: 'ans', n: st.n, k: picked, ...(st.who && st.who !== me ? { as: st.who } : {}) }); render(); }
    else if (b.dataset.qz === 'again') X.again();
    else if (b.dataset.qz === 'leave') X.leave();
  }
  root.addEventListener('click', onClick);

  /* ---- повідомлення ---- */
  function onMsg(m) {
    if (!alive) return;
    if (m.t === 'state' && m.data) {
      const s = m.data;
      if (s.t === 'q') { st = s; picked = -1; answered = new Set(); timerBar(s.T); X.sfx('page'); if (s.who === me) X.sfx('bell'); }
      else if (s.t === 'rev' && st && s.n === st.n) { st = { ...st, ...s, t: 'rev' }; score = s.score; timerBar(0); const who = st.who || me; X.sfx(s.gain[who] ? 'coin' : (st.picks[who] ?? -1) < 0 ? 'blip' : 'bad'); }
      else if (s.t === 'end') { st = s; score = s.score; X.sfx('win'); }
      render(); return;
    }
    if (m.t === 'move' && m.data && m.data.t === 'ans') {
      const d = m.data, by = String(d.bot !== undefined ? d.bot : d.as !== undefined && X.local ? d.as : m.from);
      if (st && st.t === 'q' && d.n === st.n) { answered.add(by); if (!alive) return; const f = el.foot.querySelector('.qz-dots'); if (f) f.outerHTML = dots(); }
      if (X.host) H.answer(by, d);
    }
  }

  /* ---- ведучий ---- */
  const H = { qs: [], n: -1, at: 0, ans: new Map(), t1: 0, t2: 0, score: {} };
  function prepare() {
    const ids = BANK.map((_, i) => i).filter((i) => D.topic === 'all' || !D.topic || BANK[i][0] === D.topic);
    const seen = new Set(X.store.get('quiz:seen', []));
    const mix = shuffled(ids, D.seed), fresh = mix.filter((i) => !seen.has(i)), old = mix.filter((i) => seen.has(i));
    const pick = fresh.concat(old).slice(0, D.count);
    const keep = [...seen, ...pick]; X.store.set('quiz:seen', keep.length >= BANK.length ? pick : keep.slice(-150));
    H.qs = pick.map((id) => ({ id }));
    people.forEach((p) => { H.score[p.id] = 0; });
  }
  H.answer = (by, d) => {
    if (H.n < 0 || d.n !== H.n || H.ans.has(by) || !byId.has(by)) return;
    const q = H.qs[H.n]; if (q.who && q.who !== by) return;
    H.ans.set(by, { k: d.k | 0, at: Date.now() });
    const live = X.live(), need = q.who ? [q.who] : people.filter((p) => p.bot || live.has(p.id)).map((p) => p.id);
    if (need.every((id) => H.ans.has(id))) { clearTimeout(H.t1); H.t1 = setTimeout(reveal, 450); }
  };
  function ask() {
    H.n++; H.ans = new Map();
    if (H.n >= H.qs.length) { X.state({ t: 'end', score: { ...H.score } }); return; }
    const q = H.qs[H.n];
    if (D.mode === 'turns') q.who = people[H.n % people.length].id;
    X.state({ t: 'q', n: H.n, total: H.qs.length, T, ...(q.ai ? { ai: q.ai, topic: D.topic } : { id: q.id }), ...(q.who ? { who: q.who } : {}) });
    H.at = Date.now();
    const v = q.ai ? q.ai : view({ id: q.id, n: H.n });
    // боти «думають» 2–12 с і відповідають з різною точністю
    for (const p of people) if (p.bot && (!q.who || q.who === p.id)) {
      const acc = ACC[D.level] || ACC.medium, k = Math.random() < acc ? v.a : [0, 1, 2, 3].filter((x) => x !== v.a)[(Math.random() * 3) | 0];
      setTimeout(() => { if (alive && H.n === q.n0) X.send({ t: 'ans', n: H.n, k, bot: p.id }); }, 1800 + Math.random() * (D.level === 'hard' ? 6000 : 10000));
    }
    q.n0 = H.n;
    // гравець вийшов — не чекаємо його; інакше — до кінця часу
    const live = X.live(); const absent = q.who && !byId.get(q.who).bot && !live.has(q.who);
    clearTimeout(H.t1); H.t1 = setTimeout(reveal, absent ? 1500 : T * 1000 + 700);
  }
  function reveal() {
    const q = H.qs[H.n]; if (!q) return;
    const v = q.ai ? q.ai : view({ id: q.id, n: H.n }), picks = {}, gain = {};
    for (const [id, a] of H.ans) { picks[id] = a.k; if (a.k === v.a) { const dt = (a.at - H.at) / 1000; gain[id] = 100 + Math.round(50 * Math.max(0, 1 - dt / T)); H.score[id] = (H.score[id] || 0) + gain[id]; } }
    X.state({ t: 'rev', n: H.n, a: v.a, picks, gain, score: { ...H.score } });
    clearTimeout(H.t2); H.t2 = setTimeout(() => { if (alive) ask(); }, 4200);
  }
  async function start() {
    prepare();
    // нові питання від ШІ (якщо доступний): до трьох, у проміжках; без ШІ — лише офлайн-набір
    try {
      const extra = await Promise.race([X.aiQuestions ? X.aiQuestions(3, D.topic) : [], new Promise((r) => setTimeout(() => r([]), 7000))]);
      (extra || []).slice(0, 3).forEach((a, j) => { const o = shuffled([0, 1, 2, 3], D.seed + 31 * j), q = { ai: { q: a.q, o: o.map((i) => a.o[i]), a: o.indexOf(0) } }; H.qs.splice(Math.min(H.qs.length, 2 + j * 3), 0, q); });
      H.qs = H.qs.slice(0, D.count); // питання ШІ замінюють кілька з набору, а не подовжують гру
    } catch (_) { }
    if (alive) setTimeout(() => { if (alive) ask(); }, 900);
  }

  if (/[?&]dbg/.test(location.search)) window.__quiz = { st: () => st, me };
  fit(); render();
  if (X.host) start();
  return {
    onMsg,
    onLobby() { if (!X.host || !st || st.t !== 'q') return; const q = H.qs[H.n]; if (!q) return; const live = X.live(), need = q.who ? [q.who] : people.filter((p) => p.bot || live.has(p.id)).map((p) => p.id); if (need.every((id) => H.ans.has(id))) { clearTimeout(H.t1); H.t1 = setTimeout(reveal, 450); } },
    destroy() { alive = false; clearTimeout(H.t1); clearTimeout(H.t2); ro.disconnect(); root.innerHTML = ''; }
  };
}
