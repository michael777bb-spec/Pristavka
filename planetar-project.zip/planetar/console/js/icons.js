// Власні іконки Pristavka у стилі «рідкого скла»: кожна — кольорова «цукерка»
// з градієнтом, темним контуром і скляним відблиском зверху. Жодних системних емодзі:
// на iPhone, Android і Windows вони виглядають однаково.
const PAL = {
  amber: ['#FFE6A6', '#FF9A3A'], cyan: ['#C4F6FF', '#36AEE0'], pink: ['#FFC9D8', '#EE5480'], green: ['#D2F9BF', '#3DBB64'],
  violet: ['#E6D2FF', '#8655F0'], blue: ['#CFDDFF', '#4867EE'], red: ['#FFC6B9', '#E4472F'], white: ['#FFFFFF', '#AEBBCF'],
  lime: ['#F4FFB0', '#9CCB1C'], brown: ['#F6D3A0', '#B97837'], teal: ['#C2FFF0', '#1FAF97'], dark: ['#5A6275', '#1A1E28']
};
export function iconDefs() {
  const g = Object.entries(PAL).map(([k, [a, b]]) => `<linearGradient id="gg-${k}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>`).join('');
  return `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>${g}<linearGradient id="gg-gloss" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".78"/><stop offset=".45" stop-color="#fff" stop-opacity=".08"/><stop offset=".55" stop-color="#fff" stop-opacity="0"/></linearGradient></defs></svg>`;
}
const OUT = 'stroke="rgba(8,10,18,.55)" stroke-width=".9" stroke-linejoin="round"';
// фігура з кольором + той самий контур зі склом зверху
const P = (c, d) => `<path d="${d}" fill="url(#gg-${c})" ${OUT}/><path d="${d}" fill="url(#gg-gloss)"/>`;
const E = (c, el) => `<${el} fill="url(#gg-${c})" ${OUT}/><${el} fill="url(#gg-gloss)"/>`;
const L = (col, d, w = 1.8) => `<path d="${d}" fill="none" stroke="${col}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"/>`;
const dot = (x, y, r, col = '#fff') => `<circle cx="${x}" cy="${y}" r="${r}" fill="${col}"/>`;
function star(cx, cy, r1, r2, n = 5, rot = -90) { let d = ''; for (let i = 0; i < n * 2; i++) { const r = i % 2 ? r2 : r1, a = (rot + i * 180 / n) * Math.PI / 180; d += (i ? 'L' : 'M') + (cx + r * Math.cos(a)).toFixed(2) + ' ' + (cy + r * Math.sin(a)).toFixed(2); } return d + 'Z'; }
function gear(cx, cy, r, teeth = 8) { let s = ''; for (let i = 0; i < teeth; i++) s += `<rect x="${cx - 1.7}" y="${cy - r - 2.4}" width="3.4" height="5" rx="1.1" transform="rotate(${i * 360 / teeth} ${cx} ${cy})" fill="url(#gg-white)" ${OUT}/>`; return s + E('white', `circle cx="${cx}" cy="${cy}" r="${r}"`) + `<circle cx="${cx}" cy="${cy}" r="${r * 0.38}" fill="#3a4152"/>`; }
const PAW = (c) => P(c, 'M12 12.2c-3.1 0-5.6 2.5-5.6 4.7 0 1.7 1.4 2.5 2.9 2.5 1 0 1.8-.5 2.7-.5s1.7.5 2.7.5c1.5 0 2.9-.8 2.9-2.5 0-2.2-2.5-4.7-5.6-4.7z') + ['6.1 10.4', '9.4 6.6', '14.6 6.6', '17.9 10.4'].map((p) => { const [x, y] = p.split(' '); return E(c, `ellipse cx="${x}" cy="${y}" rx="1.95" ry="2.45"`); }).join('');

const I = {
  // навігація
  home: () => P('amber', 'M7.5 7h9a5 5 0 0 1 4.9 6l-.8 3.6a2.6 2.6 0 0 1-4.5 1.1L14.6 16H9.4l-1.5 1.7a2.6 2.6 0 0 1-4.5-1.1L2.6 13a5 5 0 0 1 4.9-6z') + L('#5b3407', 'M7.5 10.2v3.2M5.9 11.8h3.2', 1.7) + dot(15.6, 10.6, 1.1, '#5b3407') + dot(17.4, 12.6, 1.1, '#5b3407'),
  games: () => P('cyan', 'M6.5 3h11A1.5 1.5 0 0 1 19 4.5v15a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 5 19.5v-15A1.5 1.5 0 0 1 6.5 3z') + E('amber', 'rect x="7.6" y="7.4" width="8.8" height="7" rx="1.4"') + L('rgba(8,40,60,.7)', 'M8.5 18h7M8 4.8h8', 1.4),
  puzzles: () => E('cyan', 'rect x="3" y="3" width="8" height="8" rx="2.2"') + E('violet', 'rect x="13" y="3" width="8" height="8" rx="2.2"') + E('pink', 'rect x="3" y="13" width="8" height="8" rx="2.2"') + E('amber', 'rect x="13" y="13" width="8" height="8" rx="2.2"'),
  pet: () => PAW('pink'),
  together: () => E('green', 'circle cx="8.5" cy="8" r="3.4"') + P('green', 'M2.5 19.5c.4-3.6 2.8-5.6 6-5.6s5.6 2 6 5.6z') + E('teal', 'circle cx="16.2" cy="9.2" r="2.8"') + P('teal', 'M13.6 14.4c.9-.6 1.8-.8 2.8-.8 2.6 0 4.6 1.7 5 4.9h-6.2c-.2-1.6-.8-3-1.6-4.1z'),
  ai: () => P('violet', star(12, 12, 9.5, 3.4, 4, -90)) + E('amber', `path d="${star(19, 5, 3, 1.1, 4, -90)}"`),
  settings: () => gear(12, 12, 6.4),
  // головоломки
  cal: () => P('white', 'M4 7a3 3 0 0 1 3-3h10a3 3 0 0 1 3 3v10.5a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5z') + P('red', 'M4 7a3 3 0 0 1 3-3h10a3 3 0 0 1 3 3v2.2H4z') + E('dark', 'rect x="7.2" y="2.2" width="2" height="4" rx="1"') + E('dark', 'rect x="14.8" y="2.2" width="2" height="4" rx="1"') + P('amber', star(12, 14.6, 3.6, 1.6)),
  dice: () => `<g transform="rotate(-10 12 12)">${E('white', 'rect x="4" y="4" width="16" height="16" rx="4"')}${dot(8.3, 8.3, 1.6, '#E4472F')}${dot(12, 12, 1.6, '#E4472F')}${dot(15.7, 15.7, 1.6, '#E4472F')}${dot(15.7, 8.3, 1.6, '#E4472F')}${dot(8.3, 15.7, 1.6, '#E4472F')}</g>`,
  eye: () => P('white', 'M2.2 12C4.8 7.4 8.2 5.4 12 5.4s7.2 2 9.8 6.6c-2.6 4.6-6 6.6-9.8 6.6S4.8 16.6 2.2 12z') + E('cyan', 'circle cx="12" cy="12" r="4"') + dot(12, 12, 1.8, '#0b1a24') + dot(13.4, 10.6, 1, '#fff'),
  trophy: () => L('#E89530', 'M7.2 6H4.6a2.4 2.4 0 0 0 2.9 4.6M16.8 6h2.6a2.4 2.4 0 0 1-2.9 4.6', 1.8) + P('amber', 'M6.8 3.5h10.4v5.6a5.2 5.2 0 0 1-10.4 0z') + E('amber', 'rect x="10.8" y="13.6" width="2.4" height="3.2" rx=".8"') + E('amber', 'rect x="7.2" y="16.4" width="9.6" height="4" rx="1.4"') + `<path d="${star(12, 8.4, 2.5, 1.1)}" fill="#fff" opacity=".9"/>`,
  help: () => E('violet', 'circle cx="12" cy="12" r="9"') + L('#fff', 'M9.5 9.4a2.6 2.6 0 1 1 3.6 2.4c-.8.3-1.1.9-1.1 1.7v.4', 2.3) + dot(12, 16.9, 1.3),
  bulb: () => P('amber', 'M12 2.8a6.3 6.3 0 0 0-3.7 11.4c.6.5 1 1.2 1 2V17h5.4v-.8c0-.8.4-1.5 1-2A6.3 6.3 0 0 0 12 2.8z') + E('white', 'rect x="9.2" y="17.4" width="5.6" height="3.6" rx="1.3"') + L('rgba(120,60,0,.55)', 'M10.4 12.6 12 10.4l1.6 2.2', 1.4),
  erase: () => P('red', 'M9.2 5h9.3A2.5 2.5 0 0 1 21 7.5v9a2.5 2.5 0 0 1-2.5 2.5H9.2L3 12z') + L('#fff', 'M11.8 9.4l5 5.2M16.8 9.4l-5 5.2', 2.2),
  coin: () => E('amber', 'circle cx="12" cy="12" r="9"') + `<circle cx="12" cy="12" r="6.3" fill="none" stroke="rgba(120,60,0,.45)" stroke-width="1.2"/>` + `<path d="${star(12, 12, 3.6, 1.6)}" fill="#fff" opacity=".85"/>`,
  // улюбленець
  paw: () => PAW('pink'),
  pawA: () => PAW('amber'),
  ball: () => E('lime', 'circle cx="12" cy="12" r="8.6"') + L('#fff', 'M5.2 7c3.3 2.3 3.3 7.7 0 10M18.8 7c-3.3 2.3-3.3 7.7 0 10', 1.5),
  cap: () => P('blue', 'M6.4 10.6v4.2c0 1.7 2.5 3.2 5.6 3.2s5.6-1.5 5.6-3.2v-4.2L12 13.2z') + P('blue', 'M12 4.2 22 8.8 12 13.4 2 8.8z') + L('#FFC067', 'M19.6 9.9v5.2', 1.6) + E('amber', 'circle cx="19.6" cy="16.2" r="1.6"'),
  chat: () => P('cyan', 'M5 4.5h14A2.5 2.5 0 0 1 21.5 7v7.5A2.5 2.5 0 0 1 19 17h-6.6l-4.9 3.6V17H5a2.5 2.5 0 0 1-2.5-2.5V7A2.5 2.5 0 0 1 5 4.5z') + dot(8, 10.8, 1.35, '#0b3346') + dot(12, 10.8, 1.35, '#0b3346') + dot(16, 10.8, 1.35, '#0b3346'),
  hat: () => P('violet', 'M8.2 3.8h7.6a1.2 1.2 0 0 1 1.2 1.2V15H7V5a1.2 1.2 0 0 1 1.2-1.2z') + E('red', 'rect x="7" y="11.4" width="10" height="2.4"') + E('violet', 'ellipse cx="12" cy="16.4" rx="9" ry="2.8"'),
  bone: () => P('white', 'M7.6 4.6a2.4 2.4 0 0 0-3.6 2.9 2.4 2.4 0 0 0 2.5 3.4l6.6 6.6a2.4 2.4 0 0 0 3.4 2.5 2.4 2.4 0 0 0 2.9-3.6 2.4 2.4 0 0 0-2.9-3.6l-6.6-6.6a2.4 2.4 0 0 0-2.3-1.6z'),
  laser: () => `<circle cx="12" cy="12" r="9" fill="#FF4D3A" opacity=".18"/><circle cx="12" cy="12" r="6" fill="#FF4D3A" opacity=".3"/>` + E('red', 'circle cx="12" cy="12" r="3.4"') + L('#FF8A73', 'M12 1.8v2.6M12 19.6v2.6M1.8 12h2.6M19.6 12h2.6', 1.6),
  yarn: () => E('pink', 'circle cx="11" cy="11.5" r="8"') + L('rgba(255,255,255,.85)', 'M4.6 8.4c4 .2 8.6 2.6 11.6 7.4M6.2 15.8c1.2-4.2 4.6-8.6 9.6-10M10.4 3.6c.4 4.6 3.6 9.4 8.4 10.8', 1.2) + L('#EE5480', 'M17.2 16.6c1.6 1.4 2.6 3 4.4 3.6', 1.6),
  fly: () => `<ellipse cx="8" cy="8.4" rx="4.6" ry="3.2" fill="#C4F6FF" opacity=".75" transform="rotate(-30 8 8.4)" ${OUT}/><ellipse cx="16" cy="8.4" rx="4.6" ry="3.2" fill="#C4F6FF" opacity=".75" transform="rotate(30 16 8.4)" ${OUT}/>` + E('dark', 'ellipse cx="12" cy="14" rx="4" ry="5.6"') + dot(10.4, 9.4, 1.4, '#E4472F') + dot(13.6, 9.4, 1.4, '#E4472F'),
  cookie: () => P('brown', 'M12 3a9 9 0 1 0 9 9 3 3 0 0 1-3.6-3.2A3 3 0 0 1 14 5.6 3 3 0 0 1 12 3z') + dot(8.5, 10, 1.3, '#4a2a0c') + dot(12.5, 14.5, 1.4, '#4a2a0c') + dot(8.8, 15.6, 1.1, '#4a2a0c') + dot(15.6, 17, 1, '#4a2a0c') + dot(11.6, 8.6, .9, '#4a2a0c'),
  // команди
  sit: () => E('amber', 'rect x="5" y="13" width="14" height="6.5" rx="3.2"') + L('#EE5480', 'M12 3.5v6.8M8.8 7.4 12 10.6l3.2-3.2', 2.2),
  lie: () => E('blue', 'rect x="2.5" y="12" width="19" height="7" rx="3"') + `<text x="15" y="10" font-family="system-ui" font-weight="800" font-size="7.5" fill="#CFDDFF" stroke="rgba(8,10,18,.5)" stroke-width=".5">z</text><text x="18.6" y="6.4" font-family="system-ui" font-weight="800" font-size="5.5" fill="#CFDDFF">z</text>`,
  jump: () => L('#3DBB64', 'M4 19c2-9 6-13.5 10.5-13.5', 2.6) + P('green', 'M13 2.5 20 5.6l-6.2 4.4z') + E('green', 'rect x="2.5" y="19" width="7" height="2.4" rx="1.2"'),
  spin: () => L('url(#gg-blue)', 'M19 12a7 7 0 1 1-2.2-5.1', 3) + P('blue', 'M15.4 2.8 20.6 6l-5.4 3z'),
  voice: () => P('violet', 'M3.5 9h3.6l5.2-4.4v14.8L7.1 15H3.5z') + L('#8655F0', 'M15.4 8.6a4.6 4.6 0 0 1 0 6.8M18 6a8.2 8.2 0 0 1 0 12', 2),
  // гардероб
  none: () => E('white', 'circle cx="12" cy="12" r="8.5"') + L('#E4472F', 'M6.2 17.8 17.8 6.2', 2.6),
  party: () => P('pink', 'M12 2.8 18.6 19.5H5.4z') + L('#FFE6A6', 'M9.4 10.4l5.4 1.6M8 14.6l8.2 2.2', 1.6) + E('amber', 'circle cx="12" cy="3" r="2"') + E('cyan', 'ellipse cx="12" cy="19.6" rx="7.2" ry="1.6"'),
  beanie: () => P('blue', 'M4.8 15.2a7.2 7.2 0 0 1 14.4 0z') + E('cyan', 'rect x="4" y="14.4" width="16" height="4.6" rx="2.2"') + E('white', 'circle cx="12" cy="6.4" r="2.2"'),
  crown: () => P('amber', 'M3.5 8.2 8 11.8l4-6.4 4 6.4 4.5-3.6-1.7 10.6H5.2z') + dot(12, 14.6, 1.5, '#EE5480') + dot(7.8, 15.2, 1.1, '#36AEE0') + dot(16.2, 15.2, 1.1, '#36AEE0'),
  wreath: () => L('#3DBB64', 'M4.2 13.4c1.6 3.4 4.6 5.4 7.8 5.4s6.2-2 7.8-5.4', 2.2) + [[4.6, 12.2, 'pink'], [8, 16.4, 'amber'], [12, 17.8, 'violet'], [16, 16.4, 'pink'], [19.4, 12.2, 'amber']].map(([x, y, c]) => E(c, `circle cx="${x}" cy="${y}" r="2.5"`) + dot(x, y, .9, '#fff')).join('') + P('cyan', 'M12 4.2c1.4 2 1.6 4.6 0 6.6-1.6-2-1.4-4.6 0-6.6z'),
  visor: () => P('blue', 'M4.6 14.4a7.4 7.4 0 0 1 14.8 0z') + P('blue', 'M13.4 14.4h8.2c.6 0 .8.8.3 1.1-1.6 1-3.8 1.5-6 1.5H13z') + dot(12, 7.4, 1.1, '#FFE6A6') + L('rgba(255,255,255,.7)', 'M12 7.4v6.8', 1.1),
  cups: () => P('red', 'M3.4 19 5 9.8h5.2L11.8 19z') + P('blue', 'M12.2 19l1.6-9.2H19l1.6 9.2z') + E('brown', 'circle cx="7.6" cy="20" r="1.6"') + L('rgba(255,255,255,.6)', 'M5.8 12.2h3.6M14.6 12.2h3.6', 1.2) + P('amber', 'M10.2 3.4l1.8 2.8 1.8-2.8') ,
  wand: () => L('#B97837', 'M3.6 20.6 13.6 6.4', 1.8) + L('rgba(255,255,255,.75)', 'M13.6 6.4c2.4 1.6 3.2 4.4 2.6 7.6', 1) + P('pink', 'M16.2 14c2.6.2 4.6 1.8 5.2 4.6-2.8.2-4.8-1-5.8-3.4z') + P('violet', 'M16.2 14c-1 2.4-.6 5 1.2 7-1.6-.6-2.8-2.2-2.8-4.2z'),
  tug: () => L('#B97837', 'M3 12c3-2.2 6-2.2 9 0s6 2.2 9 0', 2.6) + E('amber', 'circle cx="3.4" cy="12" r="2.2"') + E('amber', 'circle cx="20.6" cy="12" r="2.2"'),
  g_up: () => L('#FFE39A', 'M12 20V5M6.8 10 12 4.6l5.2 5.4', 2.4),
  g_down: () => L('#FFE39A', 'M12 4v15M6.8 14l5.2 5.4 5.2-5.4', 2.4),
  g_side: () => L('#FFE39A', 'M3.6 12h16.8M8 7.4 3.4 12 8 16.6M16 7.4l4.6 4.6-4.6 4.6', 2.2),
  g_circle: () => L('#FFE39A', 'M18.6 8.2A7.6 7.6 0 1 0 19.4 14', 2.4) + L('#FFE39A', 'M15.4 8.4h3.6V4.8', 2.4),
  g_hold: () => E('amber', 'circle cx="12" cy="12" r="4.2"') + `<circle cx="12" cy="12" r="8.4" fill="none" stroke="#FFE39A" stroke-width="2" stroke-dasharray="3 2.4"/>`,
  g_dbl: () => E('amber', 'circle cx="8.6" cy="12" r="3.4"') + E('amber', 'circle cx="15.8" cy="12" r="3.4"'),
  bow: () => P('pink', 'M12 12 4.2 6.8c-1.3-.8-2.7.2-2.7 1.6v7.2c0 1.4 1.4 2.4 2.7 1.6z') + P('pink', 'M12 12l7.8-5.2c1.3-.8 2.7.2 2.7 1.6v7.2c0 1.4-1.4 2.4-2.7 1.6z') + E('red', 'rect x="9.8" y="9.6" width="4.4" height="4.8" rx="1.6"'),
  // потреби
  food: () => P('red', 'M3 11.5h18a9 7 0 0 1-18 0z') + E('brown', 'circle cx="8.6" cy="10.4" r="2"') + E('brown', 'circle cx="12.4" cy="9.6" r="2.2"') + E('brown', 'circle cx="16" cy="10.6" r="1.9"'),
  water: () => P('cyan', 'M12 2.8c3.6 4.6 6.2 8 6.2 11.1a6.2 6.2 0 0 1-12.4 0c0-3.1 2.6-6.5 6.2-11.1z'),
  joy: () => P('pink', 'M12 20.2s-7.6-4.6-9.1-9.4C1.9 7.2 4.3 4.4 7.3 4.4c2 0 3.5 1.2 4.7 2.8 1.2-1.6 2.7-2.8 4.7-2.8 3 0 5.4 2.8 4.4 6.4-1.5 4.8-9.1 9.4-9.1 9.4z'),
  energy: () => P('amber', 'M13.6 2.3 4.8 13.6h6.3L9.6 21.7 19.2 9.9h-6.3z'),
  // звук
  sound: () => P('white', 'M3.5 9h3.6l5.2-4.4v14.8L7.1 15H3.5z') + L('#7FE3FF', 'M15.4 8.6a4.6 4.6 0 0 1 0 6.8M18 6a8.2 8.2 0 0 1 0 12', 2),
  mute: () => P('white', 'M3.5 9h3.6l5.2-4.4v14.8L7.1 15H3.5z') + L('#FF6B55', 'M15.5 9.2l5 5.6M20.5 9.2l-5 5.6', 2.2),
  // разом
  globe: () => E('cyan', 'circle cx="12" cy="12" r="9"') + L('rgba(255,255,255,.85)', 'M3.4 12h17.2M12 3.2c-3 3-3 14.6 0 17.6M12 3.2c3 3 3 14.6 0 17.6', 1.3),
  near: () => E('dark', 'rect x="8" y="5" width="8" height="14" rx="2.2"') + `<rect x="9.4" y="7" width="5.2" height="9" rx=".8" fill="#7FE3FF" opacity=".9"/>` + L('#3DBB64', 'M5 8.5a6 6 0 0 0 0 7M2.6 6.4a9.2 9.2 0 0 0 0 11.2M19 8.5a6 6 0 0 1 0 7M21.4 6.4a9.2 9.2 0 0 1 0 11.2', 1.6),
  device: () => E('violet', 'rect x="6.5" y="3" width="11" height="18" rx="2.6"') + `<rect x="8.2" y="5.4" width="7.6" height="11.6" rx="1" fill="#1A1E28" opacity=".55"/>` + L('#FFE6A6', 'M10 11.2a2.2 2.2 0 1 1 1.4 2', 1.5) + P('amber', 'M9.2 9.4l1 2.6 2.4-1.2z'),
  // інше
  play: () => P('amber', 'M7 4.2 19.5 12 7 19.8z'),
  share: () => E('green', 'circle cx="6" cy="12" r="2.8"') + E('green', 'circle cx="17.5" cy="6" r="2.8"') + E('green', 'circle cx="17.5" cy="18" r="2.8"') + L('#3DBB64', 'M8.4 10.8l6.8-3.6M8.4 13.2l6.8 3.6', 1.8),
  exit: () => P('red', 'M4 4.5h8.5v15H4z') + L('#E4472F', 'M13.5 12h7M17.5 8.6 21 12l-3.5 3.4', 2.2),
  again: () => L('url(#gg-green)', 'M5 12a7 7 0 1 0 2.2-5.1', 3) + P('green', 'M8.8 2.6 3.4 5.8l5.6 2.9z'),
  bot: () => E('white', 'rect x="4.5" y="7.5" width="15" height="12" rx="4"') + dot(9.4, 13.4, 1.7, '#36AEE0') + dot(14.6, 13.4, 1.7, '#36AEE0') + L('#AEBBCF', 'M12 7.5V4.2', 1.6) + E('red', 'circle cx="12" cy="3.6" r="1.6"'),
  key: () => E('amber', 'circle cx="8" cy="12" r="4.6"') + `<circle cx="8" cy="12" r="1.6" fill="#5b3407"/>` + P('amber', 'M12 10.8h9v2.4h-1.6v2.4h-2.4v-2.4H12z'),
  send: () => P('cyan', 'M3 4.2 21 12 3 19.8l2.6-7.8z'),
  w_sun: () => `<g>${[0, 45, 90, 135, 180, 225, 270, 315].map((a) => `<rect x="11" y="1.6" width="2" height="3.6" rx="1" fill="#FFB547" transform="rotate(${a} 12 12)"/>`).join('')}</g>` + E('amber', 'circle cx="12" cy="12" r="5.6"'),
  w_rain: () => P('white', 'M7 15.5a4.5 4.5 0 0 1-.4-9A5.6 5.6 0 0 1 17.4 7.6 3.9 3.9 0 0 1 17 15.5z') + L('#36AEE0', 'M8 18l-1 3M12 18l-1 3M16 18l-1 3', 1.8),
  w_heat: () => E('red', 'circle cx="12" cy="12" r="6.2"') + L('#FF9A3A', 'M12 1.8v2.6M12 19.6v2.6M1.8 12h2.6M19.6 12h2.6M4.8 4.8l1.8 1.8M17.4 17.4l1.8 1.8M4.8 19.2l1.8-1.8M17.4 6.6l1.8-1.8', 1.8),
  w_cloud: () => P('white', 'M7 18a4.6 4.6 0 0 1-.4-9.2 5.8 5.8 0 0 1 11 1.3A4 4 0 0 1 17.2 18z'),
  moon: () => P('cyan', 'M15.8 20.2A9 9 0 0 1 9.4 3.4 9.4 9.4 0 1 0 20.6 15a8.8 8.8 0 0 1-4.8 5.2z') + dot(9, 9, 1, '#fff'),
  star: () => P('amber', star(12, 12.6, 9.6, 4.2)),
  storm: () => P('dark', 'M7 14.5a4.5 4.5 0 0 1-.4-9A5.6 5.6 0 0 1 17.4 6.6 3.9 3.9 0 0 1 17 14.5z') + P('amber', 'M12.6 12.5 9.6 17h2.6l-1.2 4.6 4.4-6h-2.6l1.4-3.1z'),
  lock: () => L('#AEBBCF', 'M8 10.5V8a4 4 0 0 1 8 0v2.5', 2.4) + P('amber', 'M5.5 10.5h13a1 1 0 0 1 1 1v8a1.5 1.5 0 0 1-1.5 1.5h-12A1.5 1.5 0 0 1 4.5 19.5v-8a1 1 0 0 1 1-1z') + `<circle cx="12" cy="15.2" r="1.6" fill="#5b3407"/>`,
  f_happy: () => E('amber', 'circle cx="12" cy="12" r="9.5"') + dot(8.8, 10, 1.4, '#3a2306') + dot(15.2, 10, 1.4, '#3a2306') + L('#3a2306', 'M7.8 13.6a4.6 4.6 0 0 0 8.4 0', 1.8),
  f_ok: () => E('white', 'circle cx="12" cy="12" r="9.5"') + dot(8.8, 10, 1.4, '#3a4152') + dot(15.2, 10, 1.4, '#3a4152') + L('#3a4152', 'M8.4 15h7.2', 1.8),
  f_sad: () => E('red', 'circle cx="12" cy="12" r="9.5"') + L('#3a0f06', 'M7.4 8.6l2.8 1.4M16.6 8.6l-2.8 1.4', 1.6) + L('#3a0f06', 'M8 16.4a4.6 4.6 0 0 1 8 0', 1.8),
  fuel: () => P('red', 'M7 3h5l1.5 2H17a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z') + L('rgba(255,255,255,.85)', 'M9 11l6 6M15 11l-6 6', 1.6) + L('rgba(8,10,18,.6)', 'M7.5 6h3.5', 1.6),
  oil: () => P('brown', 'M12 3c3.4 4.4 5.8 7.6 5.8 10.6a5.8 5.8 0 0 1-11.6 0C6.2 10.6 8.6 7.4 12 3z') + dot(10, 14.5, 1.5, 'rgba(255,255,255,.7)'),
  wrench: () => P('white', 'M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.4-3.4a6 6 0 0 1-7.9 7.9l-6.6 6.6a2.1 2.1 0 0 1-3-3l6.6-6.6a6 6 0 0 1 7.9-7.9z'),
  mud: () => E('brown', 'circle cx="12" cy="13" r="6"') + E('brown', 'circle cx="5" cy="8.5" r="2.2"') + E('brown', 'circle cx="19" cy="7.5" r="1.7"') + E('brown', 'circle cx="18.6" cy="19" r="1.5"'),
  wash: () => P('amber', 'M4 11h16v7a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 18z') + E('cyan', 'circle cx="8" cy="7" r="2.6"') + E('cyan', 'circle cx="14" cy="5" r="1.9"') + E('cyan', 'circle cx="17.6" cy="8.4" r="1.4"'),
  city: () => P('blue', 'M2.5 21V11h5.5v10z') + P('violet', 'M9 21V3.5h6.5V21z') + P('teal', 'M16.5 21v-8h5v8z') + dot(11.2, 7, 0.9) + dot(13.3, 7, 0.9) + dot(11.2, 10.5, 0.9) + dot(13.3, 10.5, 0.9) + dot(11.2, 14, 0.9) + dot(13.3, 14, 0.9),
  truck: () => P('green', 'M2.5 6.5h11v9.5h-11z') + P('teal', 'M13.5 9.5h4.2l3.3 3.6V16h-7.5z') + E('dark', 'circle cx="7" cy="17.3" r="2.2"') + E('dark', 'circle cx="17" cy="17.3" r="2.2"'),
  pencil: () => `<g transform="rotate(45 12 12)">${E('amber', 'rect x="9.2" y="2.5" width="5.6" height="14" rx="1.2"')}<path d="M9.2 16.5h5.6L12 21.6z" fill="#F6D3A0" ${OUT}/><path d="M11 19.6h2L12 21.6z" fill="#3a4152"/>${E('pink', 'rect x="9.2" y="1.2" width="5.6" height="2.6" rx="1"')}</g>`,
  plus: () => E('green', 'circle cx="12" cy="12" r="9"') + L('#fff', 'M12 7.5v9M7.5 12h9', 2.4),
  ship: () => `<path d="M3.2 14.2h17.6l-2.4 4.3c-.3.5-.8.8-1.4.8H7c-.6 0-1.1-.3-1.4-.8z" fill="#9FB4CC" stroke="#5C6E86" stroke-width=".9" stroke-linejoin="round"/><path d="M7 14.2V11h7.5l1.8 3.2" fill="#DCE5F0" stroke="#5C6E86" stroke-width=".9" stroke-linejoin="round"/><path d="M10.6 11V5.2l4.6 5.8" fill="#FF8FA8" stroke="#B24A62" stroke-width=".8" stroke-linejoin="round"/><path d="M2.5 21.2c1.4 0 1.4-.9 2.8-.9s1.4.9 2.8.9 1.4-.9 2.8-.9 1.4.9 2.8.9 1.4-.9 2.8-.9 1.4.9 2.8.9" fill="none" stroke="#7FE3FF" stroke-width="1.2" stroke-linecap="round"/>`,
  // культури Ферми: щоб мішки з насінням, сівалку й поле було видно з першого погляду
  c_wheat: () => `<path d="M12 22.5V8.5" stroke="#B98A2C" stroke-width="1.6" stroke-linecap="round" fill="none"/>` + [[16.6, -1], [13.3, 1], [10, -1], [16.6, 1], [13.3, -1], [10, 1]].map(([y, s]) => `<ellipse cx="${12 + s * 2.1}" cy="${y}" rx="1.7" ry="2.8" transform="rotate(${s * 32} ${12 + s * 2.1} ${y})" fill="#E9B23A" stroke="#8A5A14" stroke-width=".8"/>`).join('') + `<ellipse cx="12" cy="6.4" rx="1.6" ry="2.7" fill="#E9B23A" stroke="#8A5A14" stroke-width=".8"/><path d="M12 3.6V1.2M10.6 4.2 9.3 2M13.4 4.2 14.7 2" stroke="#D9A940" stroke-width=".8" stroke-linecap="round"/>`,
  c_sunflower: () => Array.from({ length: 12 }, (_, i) => `<ellipse cx="12" cy="4.6" rx="2" ry="3.4" fill="#FFC21A" stroke="#D99A00" stroke-width=".5" transform="rotate(${i * 30} 12 12)"/>`).join('') + `<circle cx="12" cy="12" r="4.6" fill="#5B3418"/><circle cx="12" cy="12" r="4.6" fill="none" stroke="#3A200D" stroke-width=".8"/>` + [[10.4, 10.6], [13.3, 10.3], [12, 12.4], [10.6, 13.6], [13.5, 13.4]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r=".75" fill="#8A5A2B"/>`).join(''),
  c_corn: () => `<path d="M6 21.5c1.5-5 1.7-9.5 1-14 2.6 2.3 4 5.6 4.3 9.5z" fill="#5FB548" stroke="#3D8A2E" stroke-width=".7"/><path d="M18 21.5c-1.5-5-1.7-9.5-1-14-2.6 2.3-4 5.6-4.3 9.5z" fill="#6CC352" stroke="#3D8A2E" stroke-width=".7"/>` + `<ellipse cx="12" cy="11.5" rx="3.6" ry="8.3" fill="#F7CD3B" stroke="#C99A12" stroke-width=".8"/>` + `<path d="M9 8h6M8.6 11h6.8M8.6 14h6.8M9.1 17h5.8M10.5 4.4v14.6M13.5 4.4v14.6" stroke="#D9A514" stroke-width=".7" fill="none"/>`,
  c_buckwheat: () => [[7.2, 15.5, -18], [16.6, 15.8, 14], [12, 8.2, 0]].map(([x, y, r]) => `<g transform="rotate(${r} ${x} ${y})"><path d="M${x} ${y - 5.2}l4.4 7.6c.4.8-.1 1.6-1 1.6h-6.8c-.9 0-1.4-.8-1-1.6z" fill="#8B5A3A" stroke="#5E3720" stroke-width=".8" stroke-linejoin="round"/><path d="M${x} ${y - 4.2}v7.2" stroke="#B98463" stroke-width=".9" stroke-linecap="round"/></g>`).join(''),
  flag: () => L('#AEBBCF', 'M5 21V3.5', 2) + `<path d="M5.6 4h13l-2.6 4 2.6 4h-13z" fill="#fff" ${OUT}/><path d="M5.6 4h3.2v2.7H5.6zM12 4h3.2v2.7H12zM8.8 6.7H12v2.6H8.8zM15.2 6.7h2.1l-.6 1 .7 1.6h-2.2zM5.6 9.3h3.2V12H5.6zM12 9.3h3.2V12H12z" fill="#1A1E28"/>`,
  m1: () => E('amber', 'circle cx="12" cy="12" r="9"') + `<text x="12" y="16.3" text-anchor="middle" font-family="system-ui" font-weight="800" font-size="11.5" fill="#5b3407">1</text>`,
  m2: () => E('white', 'circle cx="12" cy="12" r="9"') + `<text x="12" y="16.3" text-anchor="middle" font-family="system-ui" font-weight="800" font-size="11.5" fill="#3a4152">2</text>`,
  m3: () => E('brown', 'circle cx="12" cy="12" r="9"') + `<text x="12" y="16.3" text-anchor="middle" font-family="system-ui" font-weight="800" font-size="11.5" fill="#4a2a0c">3</text>`
};
export const ICON_NAMES = Object.keys(I);
// окрема картинка (з власними градієнтами) — для 3D-табличок у грі
export function giSvg(name, size = 96) { const f = I[name]; if (!f) return ''; const d = iconDefs().replace(/^<svg[^>]*>|<\/svg>$/g, ''); return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="${size}" height="${size}">${d}${f()}</svg>`; }
export function gi(name, size = 22, cls = '') { const f = I[name]; if (!f) return ''; return `<svg class="gi ${cls}" viewBox="0 0 24 24" width="${size}" height="${size}" aria-hidden="true">${f()}</svg>`; }
