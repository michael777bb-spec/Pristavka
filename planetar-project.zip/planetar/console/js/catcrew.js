// Коти приставки, зроблені кодом (без файлів моделей).
// makeCat({ crew: true }) — кіт-електрик Іскри за малюнком сина:
//   біла каска з блискавкою, сині очі, темно-синя роба з помаранчевими смугами.
// makeCat({ coat: 'ginger' }) — домашній кіт-улюбленець різних забарвлень.
// Анімація процедурна: idle, walk, run, sit, lie, eat, drink, paw, jump,
// pounce, groom, purr, repair, carried — плавно перетікають одна в одну.
import * as THREE from 'three';

const COATS = {
  grey: { fur: 0x7d8aa0, belly: 0xf3f1ec, eye: 0x1b4fa8, stripes: null },
  ginger: { fur: 0xe8893a, belly: 0xfbeedd, eye: 0x3f8f2f, stripes: '#b85a1c' },
  black: { fur: 0x26262c, belly: 0x2e2e35, eye: 0xd8b21c, stripes: null },
  white: { fur: 0xf4f2ee, belly: 0xffffff, eye: 0x3a7fd8, stripes: null },
  tux: { fur: 0x23232a, belly: 0xf6f4ef, eye: 0x4caf50, stripes: null },
  tabby: { fur: 0x9a8a76, belly: 0xefe6d6, eye: 0x8a9a2a, stripes: '#5a4a3a' },
  calico: { fur: 0xf6f1e8, belly: 0xffffff, eye: 0xc98a1c, patches: ['#e8893a', '#2a2a2e'] }
};
export const CAT_COATS = Object.keys(COATS);

const texCache = {};
function furTex(c) {
  const key = (c.stripes || '') + (c.patches || []).join() + c.fur;
  if (texCache[key]) return texCache[key];
  const cv = document.createElement('canvas'); cv.width = 256; cv.height = 128; const g = cv.getContext('2d');
  g.fillStyle = '#' + new THREE.Color(c.fur).getHexString(); g.fillRect(0, 0, 256, 128);
  if (c.stripes) { g.fillStyle = c.stripes; for (let i = 0; i < 9; i++) { const x = i * 29 + 6; g.beginPath(); g.moveTo(x, 0); g.bezierCurveTo(x + 10, 40, x - 8, 80, x + 6, 128); g.lineTo(x + 12, 128); g.bezierCurveTo(x, 80, x + 18, 40, x + 9, 0); g.fill(); } }
  if (c.patches) c.patches.forEach((p, k) => { g.fillStyle = p; for (let i = 0; i < 4; i++) { g.beginPath(); g.ellipse(30 + Math.random() * 200, 20 + Math.random() * 90, 18 + Math.random() * 26, 12 + Math.random() * 18, Math.random() * 3, 0, 7); g.fill(); } });
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = THREE.RepeatWrapping;
  texCache[key] = t; return t;
}
let crewM = null;
function crewMats() {
  if (crewM) return crewM;
  const helmet = new THREE.MeshPhysicalMaterial({ color: 0xe9e9e4, roughness: 0.42, clearcoat: 0.5, clearcoatRoughness: 0.35 });
  const navy = new THREE.MeshStandardMaterial({ color: 0x1c2b4d, roughness: 0.8 });
  const orange = new THREE.MeshStandardMaterial({ color: 0xff8a1f, roughness: 0.5, emissive: 0x401a00 });
  const cv = document.createElement('canvas'); cv.width = 128; cv.height = 64; const g = cv.getContext('2d');
  g.fillStyle = '#e9e9e4'; g.fillRect(0, 0, 128, 64);
  g.fillStyle = '#ffb000'; g.beginPath(); g.moveTo(52, 6); g.lineTo(36, 36); g.lineTo(54, 34); g.lineTo(44, 60); g.lineTo(76, 24); g.lineTo(58, 26); g.lineTo(68, 6); g.closePath(); g.fill();
  const logo = new THREE.CanvasTexture(cv); logo.colorSpace = THREE.SRGBColorSpace;
  crewM = { helmet, navy, orange, logo: new THREE.MeshPhysicalMaterial({ map: logo, roughness: 0.4, clearcoat: 0.5 }) };
  return crewM;
}
const lerp = (a, b, k) => a + (b - a) * k;

export function makeCat(o = {}) {
  const crew = !!o.crew;
  const C = COATS[o.coat] || COATS.grey;
  const furM = new THREE.MeshPhysicalMaterial({ color: (C.stripes || C.patches) ? 0xffffff : C.fur, map: (C.stripes || C.patches) ? furTex(C) : null, roughness: 0.78, sheen: 1, sheenColor: new THREE.Color(C.fur).lerp(new THREE.Color(0xffffff), 0.25), sheenRoughness: 0.6 });
  const headM = (C.stripes || C.patches) ? new THREE.MeshPhysicalMaterial({ color: C.patches ? C.fur : new THREE.Color(C.fur).lerp(new THREE.Color(0xffffff), 0.08), roughness: 0.78, sheen: 1, sheenColor: new THREE.Color(0xffffff), sheenRoughness: 0.5 }) : furM;
  const bellyM = new THREE.MeshPhysicalMaterial({ color: C.belly, roughness: 0.8, sheen: 1, sheenColor: new THREE.Color(0xffffff), sheenRoughness: 0.6 });
  const pinkM = new THREE.MeshStandardMaterial({ color: 0xf2a3a8, roughness: 0.6 });
  const eyeM = new THREE.MeshPhysicalMaterial({ color: C.eye, roughness: 0.05, clearcoat: 1, clearcoatRoughness: 0.05 });
  const pupilM = new THREE.MeshStandardMaterial({ color: 0x05070c, roughness: 0.2 });
  const glintM = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const M = crew ? crewMats() : null;
  const bodyM = crew ? M.navy : furM;

  const root = new THREE.Group();
  const rig = new THREE.Group(); root.add(rig);
  const add = (geo, mat, p, s, parent, r) => { const m = new THREE.Mesh(geo, mat); if (p) m.position.set(...p); if (s) m.scale.set(...s); if (r) m.rotation.set(...r); m.castShadow = true; parent.add(m); return m; };
  // тулуб обертається навколо стегон — так виходить «сісти»
  const hips = new THREE.Group(); hips.position.set(0, 0.26, -0.12); rig.add(hips);
  const body = new THREE.Group(); body.position.set(0, 0.04, 0.12); hips.add(body);
  add(new THREE.CapsuleGeometry(0.16, 0.2, 8, 16), bodyM, [0, 0, 0], [1, 1, 1.05], body, [Math.PI / 2, 0, 0]);
  if (crew) for (const z of [-0.06, 0.08]) add(new THREE.TorusGeometry(0.163, 0.018, 8, 32), M.orange, [0, 0, z], null, body);
  add(new THREE.SphereGeometry(0.11, 16, 12), bellyM, [0, 0.0, 0.19], [1, 1.15, 0.6], body);
  // голова
  const neck = new THREE.Group(); neck.position.set(0, 0.17, 0.17); body.add(neck);
  const head = new THREE.Group(); head.position.set(0, 0.08, 0.02); neck.add(head);
  add(new THREE.SphereGeometry(0.2, 32, 24), headM, [0, 0, 0], [1.08, 0.94, 0.98], head);
  if (C.patches) add(new THREE.SphereGeometry(0.1, 16, 12), new THREE.MeshPhysicalMaterial({ color: C.patches[0], roughness: 0.8, sheen: 1 }), [0.09, 0.08, 0.1], [1, 0.8, 0.5], head);
  add(new THREE.SphereGeometry(0.1, 20, 14), bellyM, [0, -0.07, 0.13], [1.3, 0.8, 0.8], head);
  add(new THREE.SphereGeometry(0.022, 12, 8), pinkM, [0, -0.035, 0.205], [1.3, 0.9, 1], head);
  const mouth = add(new THREE.SphereGeometry(0.025, 10, 8), pinkM, [0, -0.1, 0.17], [1.2, 0.4, 0.6], head); mouth.visible = false;
  // язичок: висувається, коли кіт лакає воду
  const tongue = add(new THREE.CapsuleGeometry(0.016, 0.05, 4, 8), new THREE.MeshStandardMaterial({ color: 0xe8707d, roughness: 0.45 }), [0, -0.105, 0.16], [1.35, 0.3, 1], head, [Math.PI / 2 + 0.5, 0, 0]); tongue.visible = false;
  const eyes = [];
  for (const sx of [-1, 1]) {
    const eg = new THREE.Group(); eg.position.set(sx * 0.085, 0.02, 0.165); head.add(eg);
    add(new THREE.SphereGeometry(0.055, 20, 14), eyeM, [0, 0, 0], [1, 1.15, 0.6], eg);
    add(new THREE.SphereGeometry(0.03, 12, 8), pupilM, [0, -0.005, 0.03], [1, 1.3, 0.5], eg);
    add(new THREE.SphereGeometry(0.012, 8, 6), glintM, [0.018, 0.02, 0.04], null, eg);
    eyes.push(eg);
    const ear = add(new THREE.ConeGeometry(0.065, 0.14, 16), headM, crew ? [sx * 0.165, 0.13, -0.02] : [sx * 0.12, 0.17, -0.02], null, head, [0, 0, crew ? -sx * 0.75 : -sx * 0.3]);
    add(new THREE.ConeGeometry(0.04, 0.08, 12), pinkM, [0, -0.01, 0.02], null, ear);
    for (const k of [-1, 1]) { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.002, 0.002, 0.14, 4), glintM); w.position.set(sx * 0.11, -0.06 + k * 0.012, 0.17); w.rotation.z = Math.PI / 2 + k * 0.12 * sx; head.add(w); }
  }
  if (crew) {
    const hel = new THREE.Group(); hel.position.set(0, 0.07, -0.015); hel.scale.setScalar(0.86); head.add(hel);
    add(new THREE.SphereGeometry(0.19, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), M.helmet, [0, 0.03, 0], [1.08, 0.95, 1.05], hel);
    add(new THREE.CylinderGeometry(0.23, 0.23, 0.02, 32), M.helmet, [0, 0.03, 0.02], [1, 1, 1.05], hel);
    add(new THREE.TorusGeometry(0.17, 0.012, 8, 24, Math.PI), M.helmet, [0, 0.04, 0], [1, 1.05, 1], hel, [0, Math.PI / 2, 0]);
    add(new THREE.PlaneGeometry(0.12, 0.06), M.logo, [0, 0.11, 0.185], null, hel, [-0.55, 0, 0]);
  }
  // лапи: передні кріпляться до тулуба, задні — до стегон
  const legs = [];
  const mkLeg = (parent, x, y, z) => { const hip = new THREE.Group(); hip.position.set(x, y, z); parent.add(hip); add(new THREE.CapsuleGeometry(0.045, 0.1, 6, 10), crew ? M.navy : furM, [0, -0.08, 0], null, hip); add(new THREE.SphereGeometry(0.05, 12, 10), bellyM, [0, -0.17, 0.01], [1, 0.7, 1.2], hip); legs.push(hip); return hip; };
  const fl = mkLeg(body, -0.09, -0.1, 0.12), fr = mkLeg(body, 0.09, -0.1, 0.12);
  const bl = mkLeg(hips, -0.09, -0.06, 0.0), br = mkLeg(hips, 0.09, -0.06, 0.0);
  // хвіст
  const tail = []; const tbase = new THREE.Group(); tbase.position.set(0, 0.08, -0.08); hips.add(tbase); let prev = tbase;
  for (let i = 0; i < 10; i++) { const seg = new THREE.Group(); seg.position.set(0, 0.028, -0.014); prev.add(seg); add(new THREE.SphereGeometry(0.04 - i * 0.0018, 10, 8), i === 9 && !crew ? bellyM : furM, [0, 0, 0], null, seg); tail.push(seg); prev = seg; }
  const tool = crew ? add(new THREE.BoxGeometry(0.12, 0.08, 0.06), M.orange, [0.17, 0.2, 0.05], null, rig) : null; if (tool) tool.visible = false;

  // поточні значення пози (плавно наздоганяють цільові)
  const P = { hipsY: 0.26, hipsRX: 0, headRX: 0, headRY: 0, frX: 0, flX: 0, blX: 0, brX: 0, legY: 0, tailUp: -0.25, eyesY: 1, jump: 0 };
  let t = Math.random() * 10, state = 'idle', st = 0, blink = 2 + Math.random() * 3;
  const api = {
    head, mouth, tongue,
    set(s) { if (s !== state) { state = s; st = 0; } if (tool) tool.visible = s === 'repair'; mouth.visible = s === 'meow' || s === 'eat'; tongue.visible = s === 'drink'; },
    get state() { return state; },
    update(dt) {
      t += dt; st += dt; blink -= dt;
      const run = state === 'run' || state === 'pounce', walk = state === 'walk' || run;
      const f = run ? 15 : 9;
      const goal = { hipsY: 0.26, hipsRX: 0, headRX: Math.sin(t * 1.3) * 0.05, headRY: state === 'idle' ? Math.sin(t * 0.7) * 0.35 : 0, frX: 0, flX: 0, blX: 0, brX: 0, legY: 0, tailUp: -0.25, eyesY: 1, jump: 0 };
      if (walk) { const s = Math.sin(t * f); goal.flX = s * 0.7; goal.brX = s * 0.7; goal.frX = -s * 0.7; goal.blX = -s * 0.7; goal.hipsY = 0.26 + Math.abs(Math.sin(t * f)) * 0.03; goal.tailUp = 0.1; }
      if (state === 'sit' || state === 'paw' || state === 'groom' || state === 'meow') { goal.hipsY = 0.2; goal.hipsRX = -0.62; goal.headRX = 0.5; goal.frX = 0.62; goal.flX = 0.62; goal.blX = -0.85; goal.brX = -0.85; goal.tailUp = -1.2; }
      if (state === 'paw') { goal.frX = -1.9 + Math.sin(st * 8) * 0.25; }
      if (state === 'groom') { goal.flX = -1.6; goal.headRX = 0.9; goal.headRY = -0.4 + Math.sin(st * 6) * 0.15; }
      if (state === 'meow') { goal.headRX = 0.1; }
      if (state === 'lie' || state === 'sleep' || state === 'purr') { goal.hipsY = 0.12; goal.frX = -1.35; goal.flX = -1.35; goal.blX = 1.35; goal.brX = 1.35; goal.headRX = state === 'sleep' ? 0.35 : 0.05; goal.tailUp = -1.3; if (state === 'sleep') goal.eyesY = 0.12; if (state === 'purr') goal.eyesY = 0.35; }
      // їсть: голова глибоко в мисці, жує з поворотом голови; п'є: голова нерухомо низько, працює лише язик
      if (state === 'eat') { goal.hipsRX = 0.3; goal.headRX = 0.82 + Math.max(0, Math.sin(st * 7)) * 0.16; goal.headRY = Math.sin(st * 3.5) * 0.12; goal.frX = -0.25; goal.flX = -0.25; goal.tailUp = 0.2; }
      if (state === 'drink') { goal.hipsY = 0.2; goal.hipsRX = 0.42; goal.headRX = 0.95 + Math.sin(st * 22) * 0.015; goal.frX = -0.55; goal.flX = -0.55; goal.blX = -0.7; goal.brX = -0.7; goal.tailUp = -0.05; goal.eyesY = 0.45; }
      if (state === 'sniff') { goal.hipsRX = 0.25; goal.headRX = 0.7; goal.headRY = Math.sin(st * 5) * 0.45; goal.frX = -0.2; goal.flX = -0.2; goal.tailUp = 0.35; }
      if (state === 'beg') { goal.hipsY = 0.24; goal.hipsRX = -1.15; goal.headRX = 0.65; goal.frX = 1.7 + Math.sin(st * 6) * 0.2; goal.flX = 1.7 - Math.sin(st * 6) * 0.2; goal.blX = -1.2; goal.brX = -1.2; goal.tailUp = 0.3; }
      if (state === 'swat') { goal.hipsY = 0.2; goal.hipsRX = -0.5; goal.headRX = -0.2; goal.frX = -2.3 + Math.sin(st * 16) * 0.5; goal.flX = 0.4; goal.blX = -0.6; goal.brX = -0.6; goal.tailUp = 0.5; }
      if (state === 'look') { goal.hipsY = 0.22; goal.hipsRX = -0.35; goal.headRX = -0.35; goal.frX = 0.35; goal.flX = 0.35; goal.blX = -0.5; goal.brX = -0.5; goal.tailUp = Math.sin(t * 8) * 0.3; }
      if (state === 'jump') { const k = Math.min(1, st / 0.7); goal.jump = Math.sin(k * Math.PI) * 0.45; goal.frX = -0.8; goal.flX = -0.8; goal.blX = 0.8; goal.brX = 0.8; goal.tailUp = 0.6; }
      if (state === 'pounce') { goal.hipsRX = 0.15; goal.frX = -0.9; goal.flX = -0.9; }
      if (state === 'crouch') { goal.hipsY = 0.17; goal.hipsRX = 0.12; goal.frX = -0.5; goal.flX = -0.5; goal.blX = 0.9; goal.brX = 0.9; goal.tailUp = Math.sin(t * 10) * 0.4; }
      if (state === 'repair') { goal.headRX = 0.35 + Math.sin(t * 12) * 0.05; goal.frX = -0.6 + Math.sin(t * 14) * 0.35; }
      if (state === 'carried') { const s = Math.sin(t * 6); goal.frX = s * 0.5 + 0.4; goal.flX = -s * 0.5 + 0.4; goal.blX = s * 0.4 + 0.5; goal.brX = -s * 0.4 + 0.5; goal.tailUp = 0.4; goal.headRY = Math.sin(t * 3) * 0.3; }
      if (blink < 0) { goal.eyesY = 0.1; if (blink < -0.12) blink = 2 + Math.random() * 4; }
      const k = Math.min(1, dt * (walk || state === 'jump' ? 18 : 9));
      for (const key in P) P[key] = lerp(P[key], goal[key], key === 'eyesY' ? Math.min(1, dt * 30) : k);
      hips.position.y = P.hipsY + P.jump; hips.rotation.x = P.hipsRX;
      neck.rotation.x = -P.hipsRX * 0.7; head.rotation.x = P.headRX; head.rotation.y = P.headRY;
      fl.rotation.x = P.flX; fr.rotation.x = P.frX; bl.rotation.x = P.blX; br.rotation.x = P.brX;
      eyes.forEach((e) => { e.scale.y = P.eyesY; });
      tail.forEach((s, i) => { s.rotation.x = P.tailUp * (i === 0 ? 1 : 0.14) + Math.sin(t * (state === 'crouch' ? 10 : 3) - i * 0.6) * 0.1; s.rotation.z = Math.sin(t * 2.2 - i * 0.5) * (state === 'idle' || state === 'purr' ? 0.25 : 0.1); });
      rig.rotation.z = state === 'carried' ? Math.sin(t * 4) * 0.12 : 0;
      if (tool && state === 'repair') tool.rotation.z = Math.sin(t * 18) * 0.3;
      // язик ритмічно висувається (≈3.5 рази на секунду, як у справжнього кота); щелепа жує
      if (state === 'drink') { const k2 = Math.max(0, Math.sin(st * 22)); tongue.position.z = 0.15 + k2 * 0.05; tongue.position.y = -0.105 - k2 * 0.03; tongue.scale.z = 0.6 + k2 * 0.6; }
      if (state === 'eat') mouth.scale.y = 0.2 + Math.max(0, Math.sin(st * 14)) * 0.6;
    }
  };
  root.userData.cat = api;
  root.scale.setScalar(o.scale || 1);
  return root;
}
