/* ============================================================
   ПРОДУКТИВНІСТЬ — одне місце для всього, що гріє телефон.
   Рівні: high · normal · eco (+ off = без 3D, це в app.js).
   Кожен 3D-шар (фон-плата, улюбленець, ігри) бере налаштування звідси:
   роздільність (dpr), ліміт кадрів, тіні, згладжування, розмиття.
   Зайві кадри — головна причина нагріву й розряду: фон повільний,
   йому не потрібно 60–120 кадрів на секунду.
   ============================================================ */

export const TIERS = ['high', 'normal', 'eco'];

const P = {
  //          фон-плата (stage)                                  улюбленець (pet)                  ігри (kit.world)
  high: { dpr: 2, msaa: true, shadows: true, blur: 2, fps: 60, idleFps: 30, petDpr: 2, petAA: true, petShadows: true, petFps: 60, gameDpr: 2, gameFps: 60, gameShadows: true, bloom: true, tilt: true, anim: true },
  normal: { dpr: 1.25, msaa: false, shadows: false, blur: 1, fps: 30, idleFps: 15, petDpr: 1.5, petAA: false, petShadows: true, petFps: 30, gameDpr: 1.5, gameFps: 60, gameShadows: true, bloom: true, tilt: true, anim: true },
  // eco: у грі без тіней — це вдвічі менше малювання і менше шейдерів, які телефон компілює на старті гри
  eco: { dpr: 1, msaa: false, shadows: false, blur: 1, fps: 24, idleFps: 10, petDpr: 1.25, petAA: false, petShadows: false, petFps: 30, gameDpr: 1, gameFps: 30, gameShadows: false, bloom: false, tilt: false, anim: false }
};

// «Без 3D» (off) стосується фону; улюбленець і ігри тоді — найлегші (eco)
export function profile(q) { return P[q === 'off' ? 'eco' : q] || P.normal; }

/* Слабкий пристрій: старий iPhone (iOS 15 і нижче: SE 1, 6s, 7) або Android із малою памʼяттю / старим Chrome.
   На ньому фонова 3D-сцена вимкнена за замовчуванням, а ігри завжди йдуть у найлегшому режимі. */
let weakCache = null;
export function iosMajor() {
  const m = /\b(?:iPhone|iPad|iPod)\b.*? OS (\d+)_/.exec(navigator.userAgent || '');
  return m ? +m[1] : 0;
}
export function weakDevice() {
  if (weakCache !== null) return weakCache;
  let w = false;
  try {
    if (/[?&]weak=1/.test(location.search)) w = true;
    const ios = iosMajor();
    if (ios && ios <= 15) w = true;
    const ua = navigator.userAgent || '';
    if (/Android/.test(ua)) {
      const cr = /Chrome\/(\d+)/.exec(ua);
      if (cr && +cr[1] < 90) w = true;
      if (navigator.deviceMemory && navigator.deviceMemory <= 2) w = true;
      if (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4 && navigator.deviceMemory && navigator.deviceMemory <= 3) w = true;
    }
  } catch (_) { }
  return (weakCache = w);
}

/* Якість для 3D-ігор. Слабкий пристрій або «Без 3D» → найлегша. Якщо гра минулого разу
   «впала» (сторінка перезапустилась посеред гри) — app.js теж просить найлегшу. */
export function gameQuality(q, forceLite) { return forceLite || weakDevice() || q === 'off' ? 'eco' : q; }

/* Який рівень вмикати, коли людина нічого не вибирала.
   Дотиковий екран (телефон/планшет) → eco: тихо, холодно, економить батарею.
   Комп'ютер → high. Користувач завжди може змінити в «Налаштуваннях». */
export function defaultQuality() {
  if (weakDevice()) return 'off'; // старий телефон: без фонової 3D-сцени — швидкий старт і холодний телефон
  try {
    const coarse = window.matchMedia('(pointer:coarse)').matches;
    const saver = navigator.connection && navigator.connection.saveData;
    const calm = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (coarse || saver || calm) return 'eco';
  } catch (_) { }
  return 'high';
}

/* Крок вниз, коли пристрій не тягне: high → normal → eco → off */
export function lower(q) { return q === 'high' ? 'normal' : q === 'normal' ? 'eco' : 'off'; }

/* Обмежувач кадрів. Повертає true, коли кадр треба малювати.
   Працює за часом, тож однаково на 60, 90 і 120 Гц екранах. */
export function limiter(getFps) {
  let last = 0;
  return function (now) {
    const f = getFps();
    if (!f || f >= 60) { last = now; return true; }
    if (now - last >= 1000 / f - 2) { last = now; return true; }
    return false;
  };
}

/* Скільки було «втраченого» часу між кадрами: для автоматичного зниження якості */
export function slowMeter(opts) {
  const o = Object.assign({ warm: 60, bad: 45, ratio: 2.2, minGap: 70 }, opts || {});
  let n = 0, bad = 0, last = 0, fired = false;
  return {
    reset() { last = 0; bad = Math.max(0, bad - 10); },
    /** now — час кадру (мс), want — бажаний інтервал (мс). true = пристрій не справляється */
    tick(now, want) {
      if (fired) return false;
      const gap = last ? now - last : 0; last = now;
      if (++n < o.warm || !gap) return false;               // перші кадри: компіляція шейдерів, не рахуємо
      if (gap > Math.max(o.minGap, want * o.ratio)) bad += 2; else if (bad > 0) bad -= 1;
      if (bad >= o.bad) { fired = true; return true; }
      return false;
    }
  };
}
