/* ============================================================
   ПРОДУКТИВНІСТЬ — одне місце для всього, що гріє телефон.
   Рівні: high · normal · eco (+ off = без 3D, це в app.js).
   Кожен 3D-шар (фон-плата, улюбленець, ігри) бере налаштування звідси:
   роздільність (dpr), ліміт кадрів, тіні, згладжування, розмиття.
   Зайві кадри — головна причина нагріву й розряду: фон повільний,
   йому не потрібно 60–120 кадрів на секунду.
   ============================================================ */

export const TIERS = ['high', 'normal', 'eco'];

const P = {
  //          фон-плата (stage)                                  улюбленець (pet)                  ігри (kit.world)
  high: { dpr: 2, msaa: true, shadows: true, blur: 2, fps: 60, idleFps: 30, petDpr: 2, petAA: true, petShadows: true, petFps: 60, gameDpr: 2, gameFps: 60, bloom: true, tilt: true, anim: true },
  normal: { dpr: 1.25, msaa: false, shadows: false, blur: 1, fps: 30, idleFps: 15, petDpr: 1.5, petAA: false, petShadows: true, petFps: 30, gameDpr: 1.5, gameFps: 60, bloom: true, tilt: true, anim: true },
  eco: { dpr: 1, msaa: false, shadows: false, blur: 1, fps: 24, idleFps: 10, petDpr: 1.25, petAA: false, petShadows: false, petFps: 30, gameDpr: 1, gameFps: 30, bloom: false, tilt: false, anim: false }
};

export function profile(q) { return P[q] || P.normal; }

/* Який рівень вмикати, коли людина нічого не вибирала.
   Дотиковий екран (телефон/планшет) → eco: тихо, холодно, економить батарею.
   Комп'ютер → high. Користувач завжди може змінити в «Налаштуваннях». */
export function defaultQuality() {
  try {
    const coarse = window.matchMedia('(pointer:coarse)').matches;
    const saver = navigator.connection && navigator.connection.saveData;
    const calm = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (coarse || saver || calm) return 'eco';
  } catch (_) { }
  return 'high';
}

/* Крок вниз, коли пристрій не тягне: high → normal → eco → off */
export function lower(q) { return q === 'high' ? 'normal' : q === 'normal' ? 'eco' : 'off'; }

/* Обмежувач кадрів. Повертає true, коли кадр треба малювати.
   Працює за часом, тож однаково на 60, 90 і 120 Гц екранах. */
export function limiter(getFps) {
  let last = 0;
  return function (now) {
    const f = getFps();
    if (!f || f >= 60) { last = now; return true; }
    if (now - last >= 1000 / f - 2) { last = now; return true; }
    return false;
  };
}

/* Скільки було «втраченого» часу між кадрами: для автоматичного зниження якості */
export function slowMeter(opts) {
  const o = Object.assign({ warm: 60, bad: 45, ratio: 2.2, minGap: 70 }, opts || {});
  let n = 0, bad = 0, last = 0, fired = false;
  return {
    reset() { last = 0; bad = Math.max(0, bad - 10); },
    /** now — час кадру (мс), want — бажаний інтервал (мс). true = пристрій не справляється */
    tick(now, want) {
      if (fired) return false;
      const gap = last ? now - last : 0; last = now;
      if (++n < o.warm || !gap) return false;               // перші кадри: компіляція шейдерів, не рахуємо
      if (gap > Math.max(o.minGap, want * o.ratio)) bad += 2; else if (bad > 0) bad -= 1;
      if (bad >= o.bad) { fired = true; return true; }
      return false;
    }
  };
}
