/* ============================================================
   «Знайди ласощі» — гра з чашками для улюбленця (усі види).
   Раунди чергуються:
   • ТИ шукаєш: ласощі ховаються під чашку, чашки перемішуються
     (чим вищий рівень — тим більше обмінів і швидше), торкаєшся чашки.
   • ВІН шукає: ти ховаєш ласощі й перемішуєш чашки пальцем
     (перетягни чашку на іншу або торкнись двох по черзі), а тварина
     відвертається, а потім шукає носом. Нюх тренується з кожним раундом.
   ============================================================ */
import * as THREE from '../lib/three.module.js';

const V = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
const Z = 0.62, UP = 0.3;
const COLORS = [0xe4472f, 0x4867ee, 0x2fa65a, 0xf08a1c];

export function treatMesh() {
  const g = new THREE.Group();
  const dough = new THREE.MeshStandardMaterial({ color: 0xc98a3c, roughness: 0.85 }), choc = new THREE.MeshStandardMaterial({ color: 0x4a2a0c, roughness: 0.6 });
  const c = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.058, 0.022, 20), dough); c.position.y = 0.011; c.castShadow = true; g.add(c);
  for (let i = 0; i < 5; i++) { const a = i * 1.3, r = 0.03 * ((i % 2) + 0.4); const ch = new THREE.Mesh(new THREE.SphereGeometry(0.008, 6, 4), choc); ch.position.set(Math.cos(a) * r, 0.023, Math.sin(a) * r); g.add(ch); }
  return g;
}
function cupMesh(color) {
  const g = new THREE.Group();
  const mat = new THREE.MeshPhysicalMaterial({ color, roughness: 0.32, clearcoat: 0.9, clearcoatRoughness: 0.2, side: THREE.DoubleSide });
  const white = new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.3, clearcoat: 0.6 });
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.125, 0.22, 36, 1, true), mat); body.position.y = 0.11; g.add(body);
  const top = new THREE.Mesh(new THREE.CircleGeometry(0.085, 36), mat); top.rotation.x = -Math.PI / 2; top.position.y = 0.22; g.add(top);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.124, 0.011, 8, 36), mat); rim.rotation.x = Math.PI / 2; rim.position.y = 0.006; g.add(rim);
  const band = new THREE.Mesh(new THREE.TorusGeometry(0.106, 0.008, 6, 36), white); band.rotation.x = Math.PI / 2; band.position.y = 0.075; g.add(band);
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.028, 14, 10), white); knob.position.y = 0.235; g.add(knob);
  g.traverse((m) => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
  const hit = new THREE.Mesh(new THREE.CylinderGeometry(0.19, 0.19, 0.46, 10), new THREE.MeshBasicMaterial({ visible: false })); hit.position.y = 0.2; g.add(hit); g.userData.hit = hit;
  return g;
}
const ease = (k) => (k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2);

export class Cups {
  constructor(st) {
    this.st = st; this.g = new THREE.Group(); st.world.add(this.g);
    this.treat = treatMesh(); this.g.add(this.treat); this.treat.visible = false;
    this.cups = []; this.order = []; this.timers = []; this.anims = [];
    this.level = Math.max(1, Math.round(st.skills.cups || 1)); this.turn = 'you'; this.phase = 'off';
  }
  get n() { return this.level >= 5 ? 4 : 3; }
  slotX(i) { const n = this.order.length || this.n, gap = n === 4 ? 0.4 : 0.48; return (i - (n - 1) / 2) * gap; }
  hint(k, n) { if (this.st.onHint) this.st.onHint(k, n); }
  wait(t, fn) { this.timers.push({ t, fn }); }
  anim(dur, step, done) { this.anims.push({ t: 0, dur, step, done }); }
  build() {
    this.cups.forEach((c) => this.g.remove(c)); this.cups = []; this.order = [];
    for (let i = 0; i < this.n; i++) { const c = cupMesh(COLORS[i]); c.userData.i = i; this.cups.push(c); this.order.push(i); this.g.add(c); }
    this.order.forEach((ci, s) => this.cups[ci].position.set(this.slotX(s), 0, Z));
  }
  start() {
    this.g.visible = true; this.build(); this.st.game = this;
    const st = this.st; st._stop();
    st._goto(st.world.localToWorld(V(0, 0, -0.2)), false, () => { st._faceCam = true; st.play('sit'); st.state = 'game'; });
    this.wait(1.2, () => this.round());
  }
  stop() { this.timers = []; this.anims = []; this.g.parent && this.g.parent.remove(this.g); this.st.game = null; this.st.lookAt = null; if (this.st.state === 'game') { this.st.state = 'idle'; this.st.play('idle'); } this.hint(null); }
  setVisible(v) { this.g.visible = v; }
  // підняти / опустити чашку
  lift(c, to, dur = 0.28) { const y0 = c.position.y; this.anim(dur, (k) => { c.position.y = y0 + (to - y0) * ease(k); }); }
  liftAll(to) { this.cups.forEach((c) => this.lift(c, to)); }
  treatAt(slot, y = 0) { this.treat.visible = true; this.treat.position.set(this.slotX(slot), y, Z); this.treat.scale.setScalar(1); }
  swap(s1, s2, dur, done) {
    const a = this.cups[this.order[s1]], b = this.cups[this.order[s2]], xa = a.position.x, xb = b.position.x;
    [this.order[s1], this.order[s2]] = [this.order[s2], this.order[s1]];
    this.st._s('shuffle');
    this.anim(dur, (k) => { const e = ease(k), arc = Math.sin(k * Math.PI) * 0.2; a.position.x = xa + (xb - xa) * e; b.position.x = xb + (xa - xb) * e; a.position.z = Z + arc; b.position.z = Z - arc; }, done);
  }
  shuffle(k, done) {
    const dur = Math.max(0.24, 0.62 - this.level * 0.05);
    const step = (left) => {
      if (!left) return done();
      const n = this.order.length; let s1 = (Math.random() * n) | 0, s2 = (s1 + 1 + ((Math.random() * (n - 1)) | 0)) % n;
      this.swap(s1, s2, dur, () => this.wait(0.06, () => step(left - 1)));
    };
    step(k);
  }
  // тварина підходить до чашки (стає позаду неї), нюхає, торкається лапою
  petTo(slot, cb) {
    const st = this.st, x = this.slotX(slot), behind = Z - 0.18 - (st.len || 1) * 0.5;
    st._goto(st.world.localToWorld(V(x, 0, behind)), false, () => { st._faceLocal(V(x, 0, Z)); st.state = 'game'; cb && cb(); });
  }
  sniff(slot, cb) { const st = this.st; this.petTo(slot, () => { st.play('sniff'); st.state = 'game'; st._s('sniff'); this.wait(0.85, cb); }); }
  eat(slot, cb) {
    const st = this.st;
    this.petTo(slot, () => {
      st.play('eat'); st._s('crunch'); this.wait(0.35, () => st._s('crunch')); this.wait(0.7, () => st._s('crunch'));
      this.anim(1.0, (k) => { this.treat.scale.setScalar(Math.max(0.01, 1 - k)); }, () => { this.treat.visible = false; });
      this.wait(1.1, () => { st._need('joy', 8); st._need('food', 3); st._v('happy', 0); if (st.onHappy) st.onHappy('play'); st.play('sit'); st.state = 'game'; cb && cb(); });
    });
  }
  home(cb) { const st = this.st; st._goto(st.world.localToWorld(V(0, 0, -0.2)), false, () => { st._faceCam = true; st.play('sit'); st.state = 'game'; cb && cb(); }); }
  next() {
    this.wait(0.9, () => {
      this.liftAll(0); this.treat.visible = false;
      this.turn = this.turn === 'you' ? 'pet' : 'you';
      this.wait(0.4, () => this.home(() => { if (this.order.length !== this.n) this.build(); this.round(); }));
    });
  }
  round() { this.sel = null; this.turn === 'you' ? this.roundYou() : this.roundPet(); }

  /* ----- ти шукаєш ----- */
  roundYou() {
    this.phase = 'show'; this.hint('cups_watch');
    const s = (Math.random() * this.order.length) | 0; this.treatCup = this.order[s];
    this.liftAll(UP); this.st.lookAt = V(this.slotX(s), 0, Z);
    this.wait(0.3, () => { this.treatAt(s, 0.5); this.st._s('catchIt', 0.4); const t = this.treat; this.anim(0.35, (k) => { t.position.y = 0.5 * (1 - k * k); }); });
    this.wait(1.6, () => {
      this.liftAll(0); this.st._s('cup');
      this.wait(0.35, () => { this.treat.visible = false; this.phase = 'shuffle'; this.hint('cups_shuffle'); this.st.lookAt = V(0, 0.1, Z); this.shuffle(2 + this.level, () => { this.phase = 'guess'; this.hint('cups_guess'); }); });
    });
  }
  /* ----- він шукає ----- */
  roundPet() {
    this.phase = 'hide'; this.hint('cups_hide');
    this.treatAt(0, 0.55); this.treat.position.x = 0; this.st.lookAt = this.treat.position;
  }
  turnAway() { const st = this.st; st._faceLocal(V(st.actor.position.x, 0, -5)); st.play('sit'); st.state = 'game'; st.lookAt = null; if (st.onSay) st.onSay('cups_eyes'); }
  seek() {
    this.phase = 'seek'; this.hint('cups_seek');
    const st = this.st, nose = st.skills.nose || 0, right = this.order.indexOf(this.treatCup), n = this.order.length;
    const ok = Math.random() < Math.min(0.95, 0.5 + nose * 0.09);
    let pick = right; if (!ok) { pick = (right + 1 + ((Math.random() * (n - 1)) | 0)) % n; }
    const path = []; const start = Math.random() < 0.5 ? 0 : n - 1, dir = start === 0 ? 1 : -1;
    for (let s = start; s >= 0 && s < n; s += dir) { path.push(s); if (s === pick) break; }
    st._faceCam = true;
    const go = (i) => {
      const s = path[i];
      this.sniff(s, () => {
        if (s !== pick) return go(i + 1);
        st.play('paw', { once: !st.proc, dur: st.proc ? 0.6 : 0, then: () => { st.play('sit'); st.state = 'game'; } });
        this.wait(0.45, () => {
          const c = this.cups[this.order[s]]; this.lift(c, UP); st._s('cup');
          if (s === right) {
            this.treatAt(s); st.skills.nose = Math.min(5, nose + 0.35); if (st.onTrain) st.onTrain(st.skills);
            this.hint('cups_found'); this.wait(0.4, () => this.eat(s, () => this.next()));
          } else { this.hint('cups_wrong'); st._v('no', 0); this.phase = 'show-me'; }
        });
      });
    };
    go(0);
  }

  /* ----- дотики (повертають true, якщо дотик для гри) ----- */
  _cupAt(e) { const h = this.st._hit(e, this.cups.map((c) => c.userData.hit)); return h ? h.object.parent : null; }
  down(e) {
    const c = this._cupAt(e); if (!c) return false;
    this.dn = { c, x0: c.position.x, moved: false };
    return true;
  }
  move(e) {
    if (!this.dn || this.phase !== 'mix') return;
    const p = this.st._floor(e); if (!p) return; const lp = this.st.world.worldToLocal(p);
    const c = this.dn.c; this.dn.moved = true; c.position.x = Math.max(this.slotX(0) - 0.1, Math.min(this.slotX(this.order.length - 1) + 0.1, lp.x)); c.position.y = 0.07;
  }
  up(e, moved) {
    const dn = this.dn; this.dn = null; if (!dn) return;
    const c = dn.c, slot = this.order.indexOf(c.userData.i);
    if (this.phase === 'mix' && dn.moved) {
      // перетягнув: на яке місце відпустив — з тією чашкою й міняємо
      let best = slot, bd = 9; this.order.forEach((_, s) => { const d = Math.abs(this.slotX(s) - c.position.x); if (d < bd) { bd = d; best = s; } });
      c.position.y = 0;
      if (best !== slot) { c.position.x = this.slotX(slot); this.mixSwap(slot, best); } else this.anim(0.15, (k) => { c.position.x = c.position.x + (this.slotX(slot) - c.position.x) * k; });
      return;
    }
    if (moved) return;
    this.tap(c, slot);
  }
  mixSwap(a, b) { this.sel = null; this.cups.forEach((c) => { c.position.y = 0; }); this.swaps++; this.swap(a, b, 0.32, () => { const left = Math.max(0, 3 - this.swaps); if (left) this.hint('cups_mix', left); else { this.phase = 'wait'; this.hint('cups_ready'); this.wait(0.9, () => this.seek()); } }); }
  tap(c, slot) {
    const st = this.st;
    if (this.phase === 'guess') {
      this.phase = 'reveal'; this.lift(c, UP); st._s('cup');
      const right = this.order.indexOf(this.treatCup);
      if (c.userData.i === this.treatCup) {
        this.treatAt(slot); this.level = Math.min(8, this.level + 1); st.skills.cups = this.level; if (st.onTrain) st.onTrain(st.skills);
        this.hint('cups_yes', this.level); st._s('ok');
        this.wait(0.5, () => this.eat(slot, () => this.next()));
      } else {
        this.hint('cups_no');
        this.wait(0.6, () => this.sniff(right, () => { const rc = this.cups[this.treatCup]; this.lift(rc, UP); st._s('cup'); this.treatAt(right); this.wait(0.4, () => this.eat(right, () => this.next())); }));
      }
    } else if (this.phase === 'hide') {
      // ховаєш ласощі під обрану чашку
      this.phase = 'hiding'; this.treatCup = c.userData.i; this.lift(c, UP); st._s('cup');
      const t = this.treat, x0 = t.position.x, x1 = this.slotX(slot);
      this.anim(0.45, (k) => { t.position.x = x0 + (x1 - x0) * ease(k); t.position.y = 0.55 * (1 - ease(k)); t.position.z = Z; });
      this.wait(0.7, () => { this.lift(c, 0); st._s('cup'); this.wait(0.3, () => { this.treat.visible = false; this.phase = 'mix'; this.swaps = 0; this.hint('cups_mix', 3); this.turnAway(); }); });
    } else if (this.phase === 'mix') {
      // або торкнись двох чашок по черзі
      if (this.sel == null) { this.sel = slot; this.lift(c, 0.06, 0.12); st._s('tap'); }
      else if (this.sel === slot) { this.sel = null; this.lift(c, 0, 0.12); }
      else this.mixSwap(this.sel, slot);
    } else if (this.phase === 'show-me') {
      this.lift(c, UP); st._s('cup');
      if (c.userData.i === this.treatCup) { this.phase = 'reveal'; this.treatAt(slot); this.hint('cups_thanks'); this.wait(0.4, () => this.eat(slot, () => this.next())); }
    }
  }
  update(dt) {
    for (let i = this.timers.length - 1; i >= 0; i--) { const t = this.timers[i]; t.t -= dt; if (t.t <= 0) { this.timers.splice(i, 1); t.fn(); } }
    for (let i = this.anims.length - 1; i >= 0; i--) { const a = this.anims[i]; a.t += dt; const k = Math.min(1, a.t / a.dur); a.step(k); if (k >= 1) { this.anims.splice(i, 1); if (a.done) a.done(); } }
    if (this.phase === 'hide' && this.treat.visible) { this.treat.rotation.y += dt * 2; this.treat.position.y = 0.55 + Math.sin(performance.now() / 300) * 0.03; }
  }
}
