/* ============================================================
   СЦЕНА І СКЛО.
   1) 3D-нутрощі приставки: плата, чипи, шестерні, конденсатори,
      світлодіоди — справжні матеріали й відбиття.
   2) Скло малює ЦЕЙ рушій, а не браузер: кожна панель з
      data-glass стає лінзою — заломлення по краях, розмиття,
      хроматична аберація, відблиск. Тому однаково на iPhone,
      Android і комп'ютері.
   3) «Корпус»: камера наближається, видно ребра деталей, доріжки
      світяться, по платі біжить справжній код сервісу, а кожна
      дія посилає імпульс до свого модуля.
   ============================================================ */
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const MAXG = 24;

export function createStage(canvas, opt) {
  opt = opt || {};
  let quality = opt.quality || 'high';
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: false, powerPreference: 'high-performance' });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x06080b);
  scene.fog = new THREE.Fog(0x06080b, 14, 30);
  const pmrem = new THREE.PMREMGenerator(renderer);
  const env = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environment = env;
  scene.environmentIntensity = 0.55;

  const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 80);

  /* ---------- світло ---------- */
  const key = new THREE.DirectionalLight(0xfff1dc, 2.2);
  key.position.set(-6, 12, 4);
  key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  Object.assign(key.shadow.camera, { left: -9, right: 9, top: 9, bottom: -9, near: 1, far: 30 });
  key.shadow.bias = -0.0004;
  key.shadow.radius = 4;
  scene.add(key);
  const amber = new THREE.PointLight(0xffa64a, 18, 14, 2); amber.position.set(-4, 2.2, 3); scene.add(amber);
  const cyan = new THREE.PointLight(0x5fd8ff, 22, 16, 2); cyan.position.set(5, 2.6, -3); scene.add(cyan);
  scene.add(new THREE.HemisphereLight(0x9fb8d8, 0x0a0806, 0.25));

  /* ---------- текстура плати (малюється кодом) ---------- */
  const TS = 2048, W = 20; // текстура 2048 px на 20 одиниць світу
  const w2t = (x) => (x / W + 0.5) * TS;
  const pcb = document.createElement('canvas'); pcb.width = pcb.height = TS;
  const metal = document.createElement('canvas'); metal.width = metal.height = TS;
  const glow = document.createElement('canvas'); glow.width = glow.height = TS;
  const pc = pcb.getContext('2d'), mc = metal.getContext('2d'), gc = glow.getContext('2d');
  pc.fillStyle = '#0c1613'; pc.fillRect(0, 0, TS, TS);
  /* легкий шум склотекстоліту */
  for (let i = 0; i < 26000; i++) {
    pc.fillStyle = Math.random() < 0.5 ? 'rgba(255,255,255,0.018)' : 'rgba(0,0,0,0.05)';
    pc.fillRect(Math.random() * TS, Math.random() * TS, 2, 2);
  }
  mc.fillStyle = '#000'; mc.fillRect(0, 0, TS, TS);
  gc.fillStyle = '#000'; gc.fillRect(0, 0, TS, TS);

  const MODS = {
    core: { x: 0, z: 0.6, w: 2.6, d: 2.6, h: 0.32 },
    ai: { x: 1.9, z: -3.1, w: 1.9, d: 1.25, h: 0.26 },
    sand1: { x: -2.6, z: -2.6, w: 1.1, d: 1.1, h: 0.22 },
    sand2: { x: -2.6, z: -0.7, w: 1.1, d: 1.1, h: 0.22 },
    sand3: { x: -2.6, z: 1.2, w: 1.1, d: 1.1, h: 0.22 },
    mem: { x: 2.75, z: 0.55, w: 0.85, d: 2.5, h: 0.2 },
    net: { x: 0.0, z: 3.7, w: 1.9, d: 0.95, h: 0.22 },
    pet: { x: -0.4, z: -3.2, w: 1.2, d: 0.9, h: 0.2 }
  };
  const busses = {}; // модуль → масив доріжок (масиви Vector3)
  function trace(pts, mod, width) {
    const path = pts.map(([x, z]) => [w2t(x), w2t(z)]);
    const draw = (ctx, col, lw) => {
      ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.beginPath(); path.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)); ctx.stroke();
    };
    const lw = width || 5;
    draw(pc, '#b5773e', lw); draw(mc, '#ffffff', lw); draw(gc, '#ffffff', lw * 0.7);
    for (const [x, y] of [path[0], path[path.length - 1]]) {
      pc.fillStyle = '#d9a955'; pc.beginPath(); pc.arc(x, y, lw * 1.5, 0, Math.PI * 2); pc.fill();
      pc.fillStyle = '#0c1613'; pc.beginPath(); pc.arc(x, y, lw * 0.55, 0, Math.PI * 2); pc.fill();
      mc.fillStyle = '#fff'; mc.beginPath(); mc.arc(x, y, lw * 1.5, 0, Math.PI * 2); mc.fill();
    }
    if (mod) (busses[mod] = busses[mod] || []).push(pts.map(([x, z]) => new THREE.Vector3(x, 0.012, z)));
  }
  /* маршрути: від країв плати до модулів (по них біжать імпульси) */
  const R = (a, b) => a + Math.random() * (b - a);
  function routeTo(mod, from, n) {
    const m = MODS[mod];
    for (let k = 0; k < n; k++) {
      const off = (k - (n - 1) / 2) * 0.16;
      const [fx, fz] = from;
      const tx = m.x + (fx < m.x - m.w / 2 ? -m.w / 2 : fx > m.x + m.w / 2 ? m.w / 2 : off);
      const tz = m.z + (fz < m.z - m.d / 2 ? -m.d / 2 : fz > m.z + m.d / 2 ? m.d / 2 : off);
      const midx = (fx + tx) / 2 + off;
      trace([[fx + off, fz + off], [midx, fz + off], [midx + (tz - fz) * 0.15, tz], [tx, tz]], mod, 4);
    }
  }
  routeTo('core', [-9, 0.2], 3); routeTo('core', [9, 1.0], 3); routeTo('core', [0.2, -9], 2);
  routeTo('ai', [9, -3.5], 3); routeTo('ai', [3.6, -9], 2);
  routeTo('sand1', [-9, -2.6], 2); routeTo('sand2', [-9, -0.7], 2); routeTo('sand3', [-9, 1.3], 2);
  routeTo('mem', [9, 0.6], 3); routeTo('net', [0.5, 9], 3); routeTo('net', [-6, 9], 2); routeTo('pet', [-1.2, -9], 2);
  /* шини між модулями */
  const link = (a, b, n) => { const A = MODS[a], B = MODS[b]; for (let k = 0; k < n; k++) { const o = (k - (n - 1) / 2) * 0.14; trace([[A.x + o, A.z], [A.x + o, (A.z + B.z) / 2 + o], [B.x + o, (A.z + B.z) / 2 + o], [B.x + o, B.z]], null, 3); } };
  link('core', 'ai', 4); link('core', 'mem', 5); link('core', 'net', 4); link('core', 'sand2', 4); link('sand1', 'sand2', 2); link('sand2', 'sand3', 2); link('core', 'pet', 2);
  /* дрібні доріжки й переходи */
  for (let i = 0; i < 160; i++) {
    const x = R(-9.5, 9.5), z = R(-9.5, 9.5);
    const inside = Object.values(MODS).some(m => Math.abs(x - m.x) < m.w / 2 + 0.3 && Math.abs(z - m.z) < m.d / 2 + 0.3);
    if (inside) continue;
    const L = R(0.4, 1.6), dir = Math.floor(R(0, 4));
    const pts = [[x, z]];
    const d = [[1, 0], [0, 1], [1, 1], [1, -1]][dir];
    pts.push([x + d[0] * L, z + d[1] * L]);
    if (Math.random() < 0.6) pts.push([x + d[0] * L + R(0.3, 1.2), z + d[1] * L]);
    trace(pts, null, 2.5);
  }
  for (let i = 0; i < 260; i++) {
    const x = w2t(R(-9.8, 9.8)), y = w2t(R(-9.8, 9.8));
    pc.fillStyle = '#c8954a'; pc.beginPath(); pc.arc(x, y, 4, 0, Math.PI * 2); pc.fill();
    pc.fillStyle = '#081210'; pc.beginPath(); pc.arc(x, y, 1.6, 0, Math.PI * 2); pc.fill();
    mc.fillStyle = '#fff'; mc.beginPath(); mc.arc(x, y, 4, 0, Math.PI * 2); mc.fill();
  }
  /* шовкографія */
  pc.fillStyle = 'rgba(235,235,225,0.72)';
  pc.font = '600 22px "JetBrains Mono", monospace';
  pc.fillText('PRISTAVKA · CONSOLE rev.1', w2t(-2.2), w2t(5.3));
  pc.font = '500 22px "JetBrains Mono", monospace';
  [['CORE', 'core'], ['AI', 'ai'], ['SBX-1', 'sand1'], ['SBX-2', 'sand2'], ['SBX-3', 'sand3'], ['MEM', 'mem'], ['NET', 'net'], ['PET', 'pet']].forEach(([t, m]) => {
    const M = MODS[m]; pc.fillText(t, w2t(M.x - M.w / 2), w2t(M.z - M.d / 2 - 0.12));
    pc.strokeStyle = 'rgba(235,235,225,0.5)'; pc.lineWidth = 2;
    pc.strokeRect(w2t(M.x - M.w / 2 - 0.08), w2t(M.z - M.d / 2 - 0.08), (M.w + 0.16) / W * TS, (M.d + 0.16) / W * TS);
  });

  const pcbTex = new THREE.CanvasTexture(pcb); pcbTex.colorSpace = THREE.SRGBColorSpace; pcbTex.anisotropy = 8;
  const metalTex = new THREE.CanvasTexture(metal);
  const glowTex = new THREE.CanvasTexture(glow);
  const boardMat = new THREE.MeshPhysicalMaterial({
    map: pcbTex, metalnessMap: metalTex, metalness: 1, roughness: 0.5, roughnessMap: null,
    clearcoat: 0.7, clearcoatRoughness: 0.25, emissiveMap: glowTex, emissive: new THREE.Color(0x58d8ff), emissiveIntensity: 0
  });
  const board = new THREE.Mesh(new THREE.BoxGeometry(W, 0.16, W), boardMat);
  board.position.y = -0.08; board.receiveShadow = true;
  scene.add(board);

  /* ---------- деталі ---------- */
  const xrayGroup = new THREE.Group(); scene.add(xrayGroup);
  const edgeMat = new THREE.LineBasicMaterial({ color: 0x7fe3ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false });
  function addEdges(mesh) {
    const e = new THREE.LineSegments(new THREE.EdgesGeometry(mesh.geometry, 25), edgeMat);
    e.position.copy(mesh.position); e.rotation.copy(mesh.rotation); e.scale.copy(mesh.scale);
    xrayGroup.add(e);
  }
  function labelTex(lines, w, h, opts) {
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const x = c.getContext('2d');
    x.fillStyle = opts && opts.bg || '#121315'; x.fillRect(0, 0, w, h);
    x.fillStyle = 'rgba(255,255,255,0.03)';
    for (let i = 0; i < 1400; i++) x.fillRect(Math.random() * w, Math.random() * h, 1, 1);
    x.fillStyle = opts && opts.ink || 'rgba(230,230,225,0.78)';
    x.textBaseline = 'top';
    lines.forEach((l, i) => { x.font = l[1]; x.fillText(l[0], l[2] || 18, l[3] != null ? l[3] : 18 + i * 34); });
    x.beginPath(); x.arc(22, h - 22, 7, 0, Math.PI * 2); x.fillStyle = 'rgba(255,255,255,0.18)'; x.fill();
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
  }
  const chipMeshes = {};
  const plastic = (map) => new THREE.MeshPhysicalMaterial({ color: 0xffffff, map, roughness: 0.42, metalness: 0, clearcoat: 0.35, clearcoatRoughness: 0.4 });
  const sidePlastic = new THREE.MeshPhysicalMaterial({ color: 0x141518, roughness: 0.5, clearcoat: 0.2 });
  const pinMat = new THREE.MeshStandardMaterial({ color: 0xd8d8d2, metalness: 1, roughness: 0.28 });
  const goldMat = new THREE.MeshStandardMaterial({ color: 0xe0b45a, metalness: 1, roughness: 0.25 });
  function chip(name, title, sub) {
    const m = MODS[name];
    const top = labelTex([[title, '700 46px "JetBrains Mono", monospace', 26, 30], [sub, '500 24px "JetBrains Mono", monospace', 26, 92]], 512, Math.round(512 * m.d / m.w));
    const mats = [sidePlastic, sidePlastic, plastic(top), sidePlastic, sidePlastic, sidePlastic];
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(m.w, m.h, m.d), mats);
    mesh.position.set(m.x, m.h / 2 + 0.02, m.z); mesh.castShadow = true; mesh.receiveShadow = true;
    scene.add(mesh); addEdges(mesh); chipMeshes[name] = mesh;
    /* виводи по периметру */
    const count = Math.max(4, Math.round(m.w / 0.16)), countD = Math.max(4, Math.round(m.d / 0.16));
    const pins = new THREE.InstancedMesh(new THREE.BoxGeometry(0.07, 0.04, 0.16), pinMat, count * 2 + countD * 2);
    const tmp = new THREE.Object3D(); let k = 0;
    for (let i = 0; i < count; i++) {
      const x = m.x - m.w / 2 + (i + 0.5) * m.w / count;
      for (const s of [-1, 1]) { tmp.position.set(x, 0.03, m.z + s * (m.d / 2 + 0.06)); tmp.rotation.set(0, 0, 0); tmp.updateMatrix(); pins.setMatrixAt(k++, tmp.matrix); }
    }
    for (let i = 0; i < countD; i++) {
      const z = m.z - m.d / 2 + (i + 0.5) * m.d / countD;
      for (const s of [-1, 1]) { tmp.position.set(m.x + s * (m.w / 2 + 0.06), 0.03, z); tmp.rotation.set(0, Math.PI / 2, 0); tmp.updateMatrix(); pins.setMatrixAt(k++, tmp.matrix); }
    }
    pins.castShadow = true; scene.add(pins);
  }
  chip('core', 'PRISTAVKA', 'CORE · ядро');
  chip('ai', 'AI-MOD', 'ключі · черга');
  chip('sand1', 'SBX-1', 'пісочниця');
  chip('sand2', 'SBX-2', 'пісочниця');
  chip('sand3', 'SBX-3', 'пісочниця');
  chip('mem', 'MEM', 'стан');
  chip('net', 'NET', 'кімнати · бот');
  chip('pet', 'PET', 'улюбленець');
  /* металева кришка-радіатор на ядрі */
  const lid = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.06, 1.5), new THREE.MeshPhysicalMaterial({ color: 0xc9ccd0, metalness: 1, roughness: 0.22, clearcoat: 0.4 }));
  lid.position.set(MODS.core.x + 0.35, MODS.core.h + 0.05, MODS.core.z + 0.35); lid.castShadow = true; scene.add(lid); addEdges(lid);

  /* конденсатори */
  const capTop = (() => {
    const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d');
    const g = x.createRadialGradient(64, 64, 4, 64, 64, 64); g.addColorStop(0, '#e6e8ea'); g.addColorStop(1, '#9ea3a8');
    x.fillStyle = g; x.fillRect(0, 0, 128, 128); x.strokeStyle = '#6c7076'; x.lineWidth = 6;
    x.beginPath(); x.moveTo(30, 64); x.lineTo(98, 64); x.moveTo(64, 30); x.lineTo(64, 98); x.stroke();
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
  })();
  const capSide = new THREE.MeshPhysicalMaterial({ color: 0x1b3150, roughness: 0.35, clearcoat: 0.8, clearcoatRoughness: 0.2 });
  const capT = new THREE.MeshStandardMaterial({ map: capTop, metalness: 0.9, roughness: 0.35 });
  [[-1.0, -2.0, 0.26, 0.62], [1.05, -1.65, 0.22, 0.5], [-1.0, 2.6, 0.3, 0.7], [1.7, 2.4, 0.24, 0.55], [4.1, -1.2, 0.34, 0.85], [-4.2, 3.4, 0.3, 0.75], [4.4, 2.8, 0.26, 0.6], [-4.0, -3.9, 0.24, 0.5]].forEach(([x, z, r, h]) => {
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, 40), [capSide, capT, capT]);
    cap.position.set(x, h / 2, z); cap.castShadow = true; scene.add(cap); addEdges(cap);
  });
  /* дрібні SMD-компоненти */
  const smd = new THREE.InstancedMesh(new THREE.BoxGeometry(0.16, 0.06, 0.08), new THREE.MeshStandardMaterial({ color: 0x2b2018, roughness: 0.6 }), 90);
  { const t = new THREE.Object3D(); let k = 0; while (k < 90) { const x = R(-6, 6), z = R(-5.5, 5.5); if (Object.values(MODS).some(m => Math.abs(x - m.x) < m.w / 2 + 0.25 && Math.abs(z - m.z) < m.d / 2 + 0.25)) continue; t.position.set(x, 0.03, z); t.rotation.set(0, Math.random() < 0.5 ? 0 : Math.PI / 2, 0); t.updateMatrix(); smd.setMatrixAt(k++, t.matrix); } }
  smd.castShadow = true; scene.add(smd);

  /* шестерні — механізм, як у прозорому годиннику */
  function gearShape(n, ro, ri, hole) {
    const s = new THREE.Shape(), step = Math.PI * 2 / n;
    for (let i = 0; i < n; i++) {
      const a = i * step;
      const p = [[ri, a], [ro, a + step * 0.18], [ro, a + step * 0.44], [ri, a + step * 0.62]];
      p.forEach(([r, b], j) => (i === 0 && j === 0) ? s.moveTo(r * Math.cos(b), r * Math.sin(b)) : s.lineTo(r * Math.cos(b), r * Math.sin(b)));
    }
    s.closePath();
    const h = new THREE.Path(); h.absarc(0, 0, hole, 0, Math.PI * 2, true); s.holes.push(h);
    for (let k = 0; k < 5; k++) { const a = k * Math.PI * 2 / 5, rr = (ri + hole) / 2; const w = new THREE.Path(); w.absarc(rr * Math.cos(a), rr * Math.sin(a), (ri - hole) * 0.28, 0, Math.PI * 2, true); s.holes.push(w); }
    return s;
  }
  const brass = new THREE.MeshPhysicalMaterial({ color: 0xd9b26a, metalness: 1, roughness: 0.24, clearcoat: 0.3 });
  const steel = new THREE.MeshPhysicalMaterial({ color: 0xb8c0c8, metalness: 1, roughness: 0.2 });
  const gears = [];
  function gear(n, ro, x, z, y, mat, speed) {
    const g = new THREE.Mesh(new THREE.ExtrudeGeometry(gearShape(n, ro, ro * 0.86, ro * 0.18), { depth: 0.12, bevelEnabled: true, bevelThickness: 0.02, bevelSize: 0.02, bevelSegments: 2, curveSegments: 8 }), mat);
    g.rotation.x = -Math.PI / 2; g.position.set(x, y, z); g.castShadow = true; g.receiveShadow = true;
    scene.add(g); gears.push({ g, speed }); addEdges(g);
    const axle = new THREE.Mesh(new THREE.CylinderGeometry(ro * 0.12, ro * 0.12, y + 0.3, 24), steel); axle.position.set(x, (y + 0.3) / 2, z); axle.castShadow = true; scene.add(axle);
    return g;
  }
  gear(24, 1.25, 5.4, -3.9, 0.55, brass, 0.18);
  gear(14, 0.74, 6.95, -2.3, 0.55, steel, -0.18 * 24 / 14);
  gear(12, 0.62, 4.6, -1.95, 0.75, brass, -0.18 * 24 / 12);
  gear(18, 0.95, -5.4, 4.2, 0.45, steel, 0.12);
  gear(10, 0.55, -4.0, 5.2, 0.45, brass, -0.12 * 18 / 10);

  /* скляний картридж у слоті */
  const slot = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.35, 2.6), new THREE.MeshPhysicalMaterial({ color: 0x1a1b1e, roughness: 0.45 }));
  slot.position.set(-4.9, 0.17, -0.7); slot.castShadow = true; scene.add(slot); addEdges(slot);
  const cart = new THREE.Mesh(new THREE.BoxGeometry(0.22, 1.7, 2.3), new THREE.MeshPhysicalMaterial({ color: 0xbfe9ff, metalness: 0, roughness: 0.06, transmission: 0, transparent: true, opacity: 0.28, clearcoat: 1, clearcoatRoughness: 0.05, ior: 1.5 }));
  cart.position.set(-4.9, 1.15, -0.7); scene.add(cart); addEdges(cart);
  const cartPcb = new THREE.Mesh(new THREE.BoxGeometry(0.04, 1.3, 1.9), new THREE.MeshPhysicalMaterial({ map: pcbTex, metalness: 0.6, roughness: 0.4 }));
  cartPcb.position.set(-4.9, 1.05, -0.7); scene.add(cartPcb);
  const cartPins = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.1, 2.1), goldMat); cartPins.position.set(-4.9, 0.32, -0.7); scene.add(cartPins);

  /* кабелі */
  const rubber = new THREE.MeshPhysicalMaterial({ color: 0x111214, roughness: 0.62, clearcoat: 0.2 });
  [[[-10, 0.2, -6], [-7, 0.6, -5.4], [-5.6, 0.4, -4.4], [-4.9, 0.25, -2.2]], [[10, 0.2, 5], [7.5, 0.7, 4.2], [5.2, 0.45, 3.6], [3.6, 0.2, 3.0]], [[2, 0.2, 10], [1.4, 0.8, 7.4], [0.6, 0.5, 5.4], [0.2, 0.2, 4.3]]].forEach(pts => {
    const curve = new THREE.CatmullRomCurve3(pts.map(p => new THREE.Vector3(...p)));
    const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 64, 0.11, 14, false), rubber); tube.castShadow = true; scene.add(tube);
  });

  /* світлодіоди з ореолом */
  const glowSprite = (() => {
    const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d');
    const g = x.createRadialGradient(64, 64, 0, 64, 64, 64); g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.25, 'rgba(255,255,255,0.55)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = g; x.fillRect(0, 0, 128, 128); return new THREE.CanvasTexture(c);
  })();
  const leds = [];
  function led(x, z, color, phase) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.07, 0.08), new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 2 }));
    m.position.set(x, 0.04, z); scene.add(m);
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowSprite, color, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false }));
    s.position.set(x, 0.12, z); s.scale.set(0.9, 0.9, 1); scene.add(s);
    leds.push({ m, s, phase });
  }
  led(-1.6, -0.9, 0xffb547, 0); led(1.5, 2.15, 0x7fe3ff, 1.3); led(3.0, -2.2, 0x7fe3ff, 2.1); led(-3.4, -3.3, 0xffb547, 0.6);
  led(-3.4, 1.9, 0x7fe3ff, 2.9); led(0.9, 4.4, 0xffb547, 1.7); led(3.5, 2.05, 0xffb547, 0.9);

  /* ---------- «Корпус»: дощ із коду ---------- */
  const rainC = document.createElement('canvas'); rainC.width = 1024; rainC.height = 1024;
  const rx = rainC.getContext('2d');
  rx.fillStyle = '#000'; rx.fillRect(0, 0, 1024, 1024);
  const rainTex = new THREE.CanvasTexture(rainC);
  const rainMat = new THREE.MeshBasicMaterial({ map: rainTex, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, color: 0x8ff0ff });
  const rain = new THREE.Mesh(new THREE.PlaneGeometry(16, 16), rainMat);
  rain.rotation.x = -Math.PI / 2; rain.position.y = 1.0; scene.add(rain);
  let codeText = '/* PRISTAVKA */';
  const FS = 12, CW = 11, COLS = Math.floor(1024 / CW);
  const drops = Array.from({ length: COLS }, () => ({ y: Math.random() * -60, sp: 0.25 + Math.random() * 0.55, i: Math.floor(Math.random() * 5000) }));
  let hiCode = null, hiUntil = 0;
  function drawRain(dt, t) {
    rx.fillStyle = 'rgba(0,0,0,0.13)'; rx.fillRect(0, 0, 1024, 1024);
    rx.font = '600 ' + FS + 'px "JetBrains Mono", monospace';
    for (let c = 0; c < COLS; c++) {
      const d = drops[c];
      d.y += d.sp * dt * 60 * 0.9;
      const y = Math.floor(d.y);
      if (y >= 0 && y * FS < 1024) {
        const ch = codeText[(d.i + y) % codeText.length] || ' ';
        rx.fillStyle = 'rgba(225,255,255,1)'; rx.fillText(ch, c * CW + 2, y * FS);
        const ch2 = codeText[(d.i + y + 7) % codeText.length] || ' ';
        rx.fillStyle = 'rgba(120,230,255,0.55)'; rx.fillText(ch2, c * CW + 2, (y - 1) * FS);
      }
      if (y * FS > 1024 + Math.random() * 600) { d.y = Math.random() * -30; d.i = Math.floor(Math.random() * codeText.length); }
    }
    if (hiCode && t < hiUntil) {
      const a = Math.min(1, (hiUntil - t) / 0.8);
      const n = Math.min(hiCode.length, 16);
      rx.fillStyle = 'rgba(0,0,0,' + (0.7 * a) + ')'; rx.fillRect(330, 400, 380, 15 * n + 22);
      rx.font = '600 12px "JetBrains Mono", monospace';
      hiCode.slice(0, 16).forEach((l, i) => { rx.fillStyle = 'rgba(255,214,150,' + a + ')'; rx.fillText(l.replace(/^\s+/, m => m.slice(0, 6)).slice(0, 52), 340, 418 + i * 15); });
    }
    rainTex.needsUpdate = true;
  }

  /* мітки модулів (у 3D, тому їх теж заломлює скло) */
  const labels = [];
  function makeLabel(text) {
    const c = document.createElement('canvas'); c.width = 512; c.height = 96; const x = c.getContext('2d');
    x.clearRect(0, 0, 512, 96);
    x.fillStyle = 'rgba(6,26,34,0.85)'; x.strokeStyle = 'rgba(127,227,255,0.9)'; x.lineWidth = 3;
    const r = 40; x.beginPath(); x.roundRect(4, 8, 504, 80, r); x.fill(); x.stroke();
    x.fillStyle = '#bff4ff'; x.font = '600 38px "JetBrains Mono", monospace'; x.textBaseline = 'middle'; x.textAlign = 'center';
    x.fillText(text, 256, 49);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
  }
  function setLabels(map) {
    labels.forEach(l => { scene.remove(l); l.material.map.dispose(); });
    labels.length = 0;
    Object.entries(map).forEach(([mod, text]) => {
      const M = MODS[mod]; if (!M) return;
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: makeLabel(text), transparent: true, opacity: 0, depthTest: false }));
      s.position.set(M.x, 1.25, M.z); s.scale.set(1.5, 0.28, 1); s.renderOrder = 10;
      scene.add(s); labels.push(s);
    });
  }

  /* імпульси по доріжках */
  const pulses = [];
  const pulseMat = (color) => new THREE.SpriteMaterial({ map: glowSprite, color, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false });
  function pulse(mod, color) {
    const list = busses[mod] || busses.core;
    for (let k = 0; k < 2; k++) {
      const path = list[Math.floor(Math.random() * list.length)];
      const s = new THREE.Sprite(pulseMat(color || 0x9ff3ff)); s.scale.set(0.7, 0.7, 1);
      scene.add(s);
      const len = path.reduce((a, p, i) => i ? a + p.distanceTo(path[i - 1]) : 0, 0);
      pulses.push({ s, path, len, t: -k * 0.15, mod });
    }
  }
  const flash = {};
  function posOn(path, d) {
    for (let i = 1; i < path.length; i++) {
      const l = path[i].distanceTo(path[i - 1]);
      if (d <= l) return path[i - 1].clone().lerp(path[i], d / l);
      d -= l;
    }
    return path[path.length - 1].clone();
  }

  /* ---------- скло: розмиття й лінзи ---------- */
  const fsGeo = new THREE.PlaneGeometry(2, 2);
  const orth = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  const quad = new THREE.Mesh(fsGeo); const postScene = new THREE.Scene(); postScene.add(quad);
  let rtScene, rtA, rtB;
  const blurMat = new THREE.ShaderMaterial({
    uniforms: { tSrc: { value: null }, uDir: { value: new THREE.Vector2() } },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }',
    fragmentShader: `uniform sampler2D tSrc; uniform vec2 uDir; varying vec2 vUv;
      void main(){
        vec3 c = texture2D(tSrc, vUv).rgb * 0.2270270;
        c += texture2D(tSrc, vUv + uDir * 1.3846154).rgb * 0.3162162;
        c += texture2D(tSrc, vUv - uDir * 1.3846154).rgb * 0.3162162;
        c += texture2D(tSrc, vUv + uDir * 3.2307692).rgb * 0.0702703;
        c += texture2D(tSrc, vUv - uDir * 3.2307692).rgb * 0.0702703;
        gl_FragColor = vec4(c, 1.0);
      }`,
    depthTest: false, depthWrite: false
  });
  const rects = Array.from({ length: MAXG }, () => new THREE.Vector4());
  const clips = Array.from({ length: MAXG }, () => new THREE.Vector4(-1e5, -1e5, 2e5, 2e5));
  const tints = Array.from({ length: MAXG }, () => new THREE.Vector4());
  const opts = Array.from({ length: MAXG }, () => new THREE.Vector4());
  const glassMat = new THREE.ShaderMaterial({
    uniforms: {
      tScene: { value: null }, tBlur: { value: null }, uRes: { value: new THREE.Vector2(1, 1) }, uDpr: { value: 1 },
      uCount: { value: 0 }, uRect: { value: rects }, uClip: { value: clips }, uTint: { value: tints }, uOpt: { value: opts },
      uTime: { value: 0 }, uDim: { value: 0.6 }
    },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }',
    fragmentShader: `
      #define MAXG ${MAXG}
      uniform sampler2D tScene; uniform sampler2D tBlur;
      uniform vec2 uRes; uniform float uDpr; uniform int uCount; uniform float uTime; uniform float uDim;
      uniform vec4 uRect[MAXG]; uniform vec4 uClip[MAXG]; uniform vec4 uTint[MAXG]; uniform vec4 uOpt[MAXG];
      varying vec2 vUv;
      float sdRR(vec2 p, vec2 b, float r){ vec2 q = abs(p) - b + r; return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r; }
      void main(){
        vec2 uv = vUv;
        vec2 p = vec2(uv.x * uRes.x, (1.0 - uv.y) * uRes.y);
        vec3 col = texture2D(tScene, uv).rgb;
        vec2 vq = uv - 0.5; float vig = 1.0 - dot(vq, vq) * 1.1;
        col *= uDim * vig;
        float shade = 0.0;
        for (int i = 0; i < MAXG; i++) {
          if (i >= uCount) break;
          vec4 R = uRect[i]; vec4 C = uClip[i];
          if (p.x < C.x || p.y < C.y || p.x > C.x + C.z || p.y > C.y + C.w) continue;
          vec2 hb = R.zw * 0.5; vec2 c = R.xy + hb;
          float rad = min(uOpt[i].z, min(hb.x, hb.y));
          float d = sdRR(p - c, hb, rad);
          float ds = sdRR(p - c - vec2(0.0, 12.0), hb, rad);
          if (d > 0.0) { shade = max(shade, (1.0 - smoothstep(-6.0, 40.0, ds)) * 0.42 * uOpt[i].w); continue; }
          float bevel = clamp(min(hb.x, hb.y) * 0.8, 6.0, 30.0);
          float e = clamp(-d / bevel, 0.0, 1.0);
          float edge = 1.0 - e;
          vec2 g = vec2(sdRR(p - c + vec2(1.0, 0.0), hb, rad) - sdRR(p - c - vec2(1.0, 0.0), hb, rad),
                        sdRR(p - c + vec2(0.0, 1.0), hb, rad) - sdRR(p - c - vec2(0.0, 1.0), hb, rad));
          vec2 n = normalize(g + 1e-5);
          float h = edge * edge * (3.0 - 2.0 * edge);
          vec2 off = -n * h * 34.0 * uOpt[i].x;
          off += (p - c) * -0.035 * uOpt[i].x * e;
          vec2 o = vec2(off.x / uRes.x, -off.y / uRes.y);
          float ca = 0.25 + 0.75 * h;
          vec3 bl;
          bl.r = texture2D(tBlur, uv + o).r;
          bl.g = texture2D(tBlur, uv + o * (1.0 + 0.07 * ca)).g;
          bl.b = texture2D(tBlur, uv + o * (1.0 + 0.14 * ca)).b;
          vec3 sharp = texture2D(tScene, uv + o).rgb;
          vec3 gl = mix(bl, sharp, 0.22 * h);
          float lum = dot(gl, vec3(0.299, 0.587, 0.114));
          gl = mix(vec3(lum), gl, 1.45);
          gl = mix(gl, uTint[i].rgb, uTint[i].a);
          gl *= 1.0 - uOpt[i].y;
          gl += 0.03;
          vec2 L = normalize(vec2(-0.55, -0.85));
          float lit = max(dot(n, L), 0.0);
          float rim = pow(lit, 1.6) * smoothstep(0.45, 1.0, edge);
          float rim2 = pow(max(dot(n, -L), 0.0), 2.0) * smoothstep(0.7, 1.0, edge);
          float sheen = (1.0 - smoothstep(0.0, R.w * 0.55, p.y - R.y)) * 0.05;
          gl += vec3(1.0, 0.98, 0.95) * (rim * 0.7 + rim2 * 0.22 + sheen);
          gl *= 1.0 - 0.22 * smoothstep(0.8, 1.0, edge) * (1.0 - lit);
          float aa = smoothstep(0.5, -1.0, d);
          col = mix(col, gl, aa);
          shade = 0.0;
        }
        col *= 1.0 - shade;
        gl_FragColor = vec4(col, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
    depthTest: false, depthWrite: false, toneMapped: true
  });

  /* ---------- розмір ---------- */
  let W0 = 1, H0 = 1, dpr = 1;
  function resize() {
    W0 = window.innerWidth; H0 = window.innerHeight;
    dpr = Math.min(window.devicePixelRatio || 1, quality === 'high' ? 2 : 1.25);
    renderer.setPixelRatio(dpr);
    renderer.setSize(W0, H0, false);
    camera.aspect = W0 / H0;
    camera.fov = camera.aspect < 0.8 ? 46 : camera.aspect < 1.2 ? 40 : 32;
    const half = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
    base.dist = Math.max(12.5, 3.7 / (half * camera.aspect));
    scene.fog.near = base.dist * 0.95; scene.fog.far = base.dist * 2.4;
    camera.updateProjectionMatrix();
    const pw = Math.floor(W0 * dpr), ph = Math.floor(H0 * dpr);
    rtScene && rtScene.dispose(); rtA && rtA.dispose(); rtB && rtB.dispose();
    rtScene = new THREE.WebGLRenderTarget(pw, ph, { type: THREE.HalfFloatType, samples: quality === 'high' ? 4 : 0 });
    const bw = Math.max(2, Math.floor(pw / 4)), bh = Math.max(2, Math.floor(ph / 4));
    rtA = new THREE.WebGLRenderTarget(bw, bh, { type: THREE.HalfFloatType });
    rtB = new THREE.WebGLRenderTarget(bw, bh, { type: THREE.HalfFloatType });
    glassMat.uniforms.uRes.value.set(W0, H0);
    key.castShadow = quality === 'high';
  }
  const base = { dist: 13 };
  window.addEventListener('resize', resize);
  resize();

  /* ---------- скляні панелі з DOM ---------- */
  const PRESET = {
    '': [0.05, 0.06, 0.09, 0.2, 1.0, 0.0, 1],
    dark: [0.02, 0.03, 0.05, 0.45, 0.8, 0.12, 1],
    deep: [0.01, 0.015, 0.025, 0.66, 0.7, 0.1, 1],
    clear: [1, 1, 1, 0.03, 1.25, 0.0, 0.6],
    amber: [1, 0.66, 0.25, 0.6, 0.9, 0.0, 0.8],
    cyan: [0.45, 0.85, 1, 0.3, 1.0, 0.05, 0.8],
    on: [1, 1, 1, 0.16, 1.1, 0.0, 0.5]
  };
  function collectGlass() {
    const els = document.querySelectorAll('[data-glass]');
    let n = 0;
    for (const el of els) {
      if (n >= MAXG) break;
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2 || r.bottom < 0 || r.top > H0 || r.right < 0 || r.left > W0) continue;
      if (el.offsetParent === null && getComputedStyle(el).position !== 'fixed') continue;
      const cs = el.__gcs || (el.__gcs = getComputedStyle(el));
      const rad = parseFloat(cs.borderTopLeftRadius) || 0;
      const P = PRESET[el.dataset.glass] || PRESET[''];
      rects[n].set(r.left, r.top, r.width, r.height);
      const clipEl = el.closest('[data-clip]');
      if (clipEl) { const c = clipEl.getBoundingClientRect(); clips[n].set(c.left, c.top, c.width, c.height); }
      else clips[n].set(-1e5, -1e5, 2e5, 2e5);
      tints[n].set(P[0], P[1], P[2], P[3]);
      opts[n].set(P[4], P[5], rad, P[6]);
      n++;
    }
    glassMat.uniforms.uCount.value = n;
  }

  /* ---------- стан і цикл ---------- */
  const st = { corpus: 0, corpusTarget: 0, px: 0, py: 0, tx: 0, ty: 0, running: true };
  window.addEventListener('pointermove', (e) => { st.tx = (e.clientX / W0 - 0.5); st.ty = (e.clientY / H0 - 0.5); }, { passive: true });
  const clock = new THREE.Clock();
  const look = new THREE.Vector3();
  function frame() {
    if (!st.running) return;
    requestAnimationFrame(frame);
    const dt = Math.min(clock.getDelta(), 0.05), t = clock.elapsedTime;
    st.corpus += (st.corpusTarget - st.corpus) * Math.min(1, dt * 3.2);
    st.px += (st.tx - st.px) * Math.min(1, dt * 2); st.py += (st.ty - st.py) * Math.min(1, dt * 2);
    const k = st.corpus;
    /* камера: звичайно — спокійний огляд; «Корпус» — ближче й нижче */
    const dist = base.dist * (1 - 0.28 * k);
    const ang = THREE.MathUtils.degToRad(58 - 16 * k) + st.py * 0.05;
    const yaw = Math.sin(t * 0.05) * 0.06 + st.px * 0.12;
    camera.position.set(Math.sin(yaw) * dist * Math.cos(ang), dist * Math.sin(ang), Math.cos(yaw) * dist * Math.cos(ang));
    look.set(st.px * 0.6, 0, 0.3 - k * 0.2);
    camera.lookAt(look);
    gears.forEach(({ g, speed }) => { g.rotation.z += speed * dt * (1 + k * 1.5); });
    leds.forEach(({ m, s, phase }) => { const v = 0.55 + 0.45 * Math.sin(t * 2.2 + phase * 2.0); s.material.opacity = v; m.material.emissiveIntensity = 1 + v * 2; });
    boardMat.emissiveIntensity = k * (0.55 + 0.25 * Math.sin(t * 1.3));
    boardMat.color.setScalar(1 - 0.45 * k);
    edgeMat.opacity = k * 0.85;
    rainMat.opacity = k * 0.8;
    labels.forEach((l, i) => { l.material.opacity = k; l.position.y = 1.25 + Math.sin(t * 1.4 + i) * 0.04; });
    if (k > 0.02) drawRain(dt, t);
    for (let i = pulses.length - 1; i >= 0; i--) {
      const p = pulses[i];
      p.t += dt * 1.25;
      const d = Math.max(0, p.t) * p.len;
      p.s.position.copy(posOn(p.path, Math.min(d, p.len))); p.s.position.y = 0.1;
      p.s.material.opacity = (p.t < 0 ? 0 : 1) * (0.55 + 0.45 * k);
      if (p.t >= 1) { flash[p.mod] = t; scene.remove(p.s); p.s.material.dispose(); pulses.splice(i, 1); }
    }
    Object.entries(chipMeshes).forEach(([m, mesh]) => {
      const f = flash[m] ? Math.max(0, 1 - (t - flash[m]) / 0.9) : 0;
      mesh.material[2].emissive = mesh.material[2].emissive || new THREE.Color();
      mesh.material[2].emissive.setRGB(0.35 * f, 0.85 * f, 1.0 * f);
    });
    /* 1) сцена в текстуру */
    renderer.setRenderTarget(rtScene); renderer.render(scene, camera);
    /* 2) розмиття (двічі для глибини) */
    const bw = rtA.width, bh = rtA.height;
    quad.material = blurMat;
    let src = rtScene.texture;
    for (let it = 0; it < 2; it++) {
      blurMat.uniforms.tSrc.value = src; blurMat.uniforms.uDir.value.set(1.6 / bw, 0); renderer.setRenderTarget(rtA); renderer.render(postScene, orth);
      blurMat.uniforms.tSrc.value = rtA.texture; blurMat.uniforms.uDir.value.set(0, 1.6 / bh); renderer.setRenderTarget(rtB); renderer.render(postScene, orth);
      src = rtB.texture;
    }
    /* 3) скло поверх */
    collectGlass();
    quad.material = glassMat;
    glassMat.uniforms.uDim.value = 0.58 + 0.42 * k;
    glassMat.uniforms.tScene.value = rtScene.texture; glassMat.uniforms.tBlur.value = rtB.texture; glassMat.uniforms.uTime.value = t;
    renderer.setRenderTarget(null); renderer.render(postScene, orth);
  }
  frame();

  return {
    setCorpus(on) { st.corpusTarget = on ? 1 : 0; },
    pulse,
    setCode(text) { if (text && text.length > 200) codeText = text.replace(/\s+/g, ' '); },
    highlight(lines) { hiCode = lines; hiUntil = clock.elapsedTime + 3.2; },
    setLabels,
    setQuality(q) { quality = q; resize(); },
    stop() { st.running = false; },
    start() { if (!st.running) { st.running = true; clock.getDelta(); frame(); } },
    renderer
  };
}
