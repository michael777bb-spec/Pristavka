/* ============================================================
   УЛЮБЛЕНЕЦЬ У 3D — усе руками й за контекстом виду тварини.
   • Гладиш — проводиш пальцем по шерсті (муркоче / виляє).
   • Тап по голові — озирається; по спині — підстрибує.
   • Миски: тап по мисці з їжею — насипаєш корм (котові рибку, собаці
     гранули); тап по мисці з водою — наливаєш. Тварина сама підходить.
   • Іграшки за видом: собаці — м'яч і кістка (кидаєш — приносить),
     котові — лазер (веди пальцем по підлозі) і клубок (штовхни).
   • М'яч летить дугою й відскакує; пес ловить у повітрі. Кістку можна
     відбирати — перетягування. Котові — вудочка з пером. Усім — «Знайди ласощі».
   • Команди жестами на сцені (↑ ↓ ◯ ↔, утримання, подвійний тап) — з тренуванням.
   • Їсть і п'є по-різному: хрумтить кормом, лакає воду (брижі, краплі).
   • Шапки сидять на маківці й рухаються разом із головою.
   • Потреби: їжа, вода, радість, сили. Втомився — лягає спати.
   Коти зроблені кодом (catcrew.js), інші тварини — CC0-моделі.
   ============================================================ */
import * as THREE from '../lib/three.module.js';
import { RoomEnvironment } from '../lib/addons/environments/RoomEnvironment.js';
import { gltf, parse, clip, prep } from './models.js';
import { clone as skClone } from '../lib/addons/utils/SkeletonUtils.js';
import { makeCat } from './catcrew.js';
import { petVoice, careSound } from './voice.js';
import { Cups, treatMesh } from './petcups.js';
import { profile, limiter } from './perf.js';

const V = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
const up = V(0, 1, 0);
export const HATS = ['none', 'crown', 'wreath', 'party', 'beanie', 'visor', 'bow'];
// r — радіус основи моделі шапки; k — її радіус у частках ширини голови; sink — наскільки натягнути вниз; tilt/roll — нахил
const HAT_FIT = {
  crown: { r: 0.42, k: 0.27, sink: 0.03, tilt: -0.08 }, wreath: { r: 0.44, k: 0.42, sink: 0.12, tilt: -0.22 },
  party: { r: 0.42, k: 0.17, sink: 0, roll: 0.28, side: 0.1 }, beanie: { r: 0.5, k: 0.43, sink: 0.2, tilt: -0.12 },
  visor: { r: 0.5, k: 0.41, sink: 0.17, tilt: -0.1 }, bow: { r: 0.42, k: 0.2, sink: -0.02, side: 0.22, roll: -0.35 }
};
export const COMMANDS = ['sit', 'lie', 'paw', 'jump', 'spin', 'voice'];
const SPECIES = { cat: /^proc:cat/, dog: /shiba|husky|pug/, fox: /fox/, wolf: /wolf/, frog: /frog/, deer: /deer/, dino: /dino/, dragon: /dragon/, trike: /triceratops/ };
export function speciesOf(url) { for (const [k, re] of Object.entries(SPECIES)) if (re.test(url || '')) return k; return 'dog'; }
export function toysFor(sp) { return sp === 'cat' ? ['wand', 'laser', 'yarn', 'cups'] : sp === 'frog' ? ['fly', 'ball', 'cups'] : ['dog', 'fox', 'wolf'].includes(sp) ? ['ball', 'bone', 'cups'] : ['ball', 'cups']; }

function stripes(c1, c2, n = 6) { const cv = document.createElement('canvas'); cv.width = 64; cv.height = 64; const g = cv.getContext('2d'); for (let i = 0; i < n; i++) { g.fillStyle = i % 2 ? c2 : c1; g.fillRect(0, i * 64 / n, 64, 64 / n + 1); } const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t; }
const std = (c, r = 0.6, m = 0) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m });
function makeHat(kind) {
  // усі шапки змодельовані з основою на y = 0 і радіусом основи r із HAT_FIT
  const g = new THREE.Group();
  if (kind === 'party') {
    const cone = new THREE.Mesh(new THREE.ConeGeometry(0.42, 1.1, 40, 1, true), new THREE.MeshPhysicalMaterial({ map: stripes('#ff6b8a', '#ffd36b', 8), roughness: 0.45, clearcoat: 0.4, side: THREE.DoubleSide })); cone.position.y = 0.55; g.add(cone);
    const pom = new THREE.Mesh(new THREE.IcosahedronGeometry(0.14, 2), std('#ffffff', 1)); pom.position.y = 1.12; g.add(pom);
    const trim = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.05, 8, 40), std('#ffffff', 1)); trim.rotation.x = Math.PI / 2; g.add(trim);
  } else if (kind === 'beanie') {
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.5, 40, 20, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ map: stripes('#4aa3ff', '#2d6fd1', 10), roughness: 0.95 })); cap.scale.y = 0.95; g.add(cap);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.49, 0.1, 14, 48), std('#2d6fd1', 0.95)); rim.rotation.x = Math.PI / 2; rim.position.y = 0.05; g.add(rim);
    const pom = new THREE.Mesh(new THREE.IcosahedronGeometry(0.17, 2), std('#ffffff', 1)); pom.position.y = 0.52; g.add(pom);
  } else if (kind === 'crown') {
    const gold = new THREE.MeshPhysicalMaterial({ color: '#ffcc4d', roughness: 0.22, metalness: 1, clearcoat: 0.6 });
    const band = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.4, 0.2, 48, 1, true), gold); band.position.y = 0.1; band.material.side = THREE.DoubleSide; g.add(band);
    for (let i = 0; i < 7; i++) { const a = (i / 7) * Math.PI * 2; const sp = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.26, 12), gold); sp.position.set(Math.cos(a) * 0.4, 0.31, Math.sin(a) * 0.4); g.add(sp); const ball = new THREE.Mesh(new THREE.SphereGeometry(0.035, 10, 8), gold); ball.position.set(Math.cos(a) * 0.4, 0.45, Math.sin(a) * 0.4); g.add(ball); const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.045), new THREE.MeshPhysicalMaterial({ color: i % 2 ? '#e8336b' : '#36aee0', roughness: 0.05, transmission: 0.4, thickness: 0.1 })); gem.position.set(Math.cos(a + 0.45) * 0.425, 0.1, Math.sin(a + 0.45) * 0.425); g.add(gem); }
  } else if (kind === 'wreath') {
    // український вінок: квіти по колу, листя і стрічки ззаду
    const cols = ['#e4472f', '#ffd23f', '#8655f0', '#ff7fb0', '#36aee0', '#ffffff'];
    const leaf = std('#3c9a4a', 0.6);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.44, 0.04, 8, 48), leaf); ring.rotation.x = Math.PI / 2; ring.position.y = 0.04; g.add(ring);
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2, front = Math.cos(a - Math.PI / 2) > 0 ? 1.25 : 0.95; const f = new THREE.Group(); f.position.set(Math.cos(a) * 0.44, 0.08, Math.sin(a) * 0.44); f.lookAt(Math.cos(a) * 2, 0.6, Math.sin(a) * 2); f.scale.setScalar(front * (i % 3 === 0 ? 1.25 : 1)); g.add(f);
      const c = std(cols[i % cols.length], 0.55);
      for (let k = 0; k < 5; k++) { const pa = (k / 5) * Math.PI * 2; const pt = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), c); pt.scale.set(1, 1, 0.45); pt.position.set(Math.cos(pa) * 0.05, Math.sin(pa) * 0.05, 0); f.add(pt); }
      const ctr = new THREE.Mesh(new THREE.SphereGeometry(0.03, 10, 8), std('#ffb000', 0.5)); ctr.position.z = 0.02; f.add(ctr);
      const lf = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), leaf); lf.scale.set(0.45, 1.2, 0.2); lf.position.set(Math.cos(a + 0.26) * 0.45, 0.04, Math.sin(a + 0.26) * 0.45); lf.rotation.z = 1.2; g.add(lf);
    }
    ['#e4472f', '#ffd23f', '#36aee0', '#3c9a4a'].forEach((col, i) => { const r = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.62, 0.008), std(col, 0.5)); r.position.set(-0.09 + i * 0.06, -0.26, -0.44); r.rotation.x = 0.25; g.add(r); });
  } else if (kind === 'visor') {
    const blue = std('#2d5fd8', 0.7);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.5, 40, 20, 0, Math.PI * 2, 0, Math.PI / 2), blue); cap.scale.y = 0.78; g.add(cap);
    const vis = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.03, 40, 1, false, -Math.PI / 2, Math.PI), std('#ffd23f', 0.6)); vis.scale.set(1, 1, 1.05); vis.position.set(0, 0.04, 0.28); vis.rotation.x = 0.12; g.add(vis);
    const btn = new THREE.Mesh(new THREE.SphereGeometry(0.05, 12, 8), std('#ffd23f', 0.6)); btn.position.y = 0.39; g.add(btn);
    const patch = new THREE.Mesh(new THREE.CircleGeometry(0.12, 24), std('#ffffff', 0.6)); patch.position.set(0, 0.2, 0.455); patch.rotation.x = -0.45; g.add(patch);
  } else if (kind === 'bow') {
    const pink = new THREE.MeshPhysicalMaterial({ color: '#ff7fb0', roughness: 0.35, sheen: 1, sheenColor: new THREE.Color('#ffd0e4') });
    for (const sx of [-1, 1]) { const l = new THREE.Mesh(new THREE.SphereGeometry(0.22, 20, 14), pink); l.scale.set(1, 0.7, 0.35); l.position.set(sx * 0.2, 0.12, 0); l.rotation.z = sx * 0.35; g.add(l); const tail = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.26, 0.02), pink); tail.position.set(sx * 0.08, -0.02, 0); tail.rotation.z = sx * 0.4; g.add(tail); }
    const c = new THREE.Mesh(new THREE.SphereGeometry(0.09, 16, 12), pink); c.position.y = 0.12; c.scale.set(1, 1, 0.7); g.add(c);
  }
  g.traverse((m) => { if (m.isMesh) m.castShadow = true; });
  return g;
}
function toyMesh(kind) {
  const g = new THREE.Group();
  if (kind === 'ball') { const cv = document.createElement('canvas'); cv.width = 256; cv.height = 128; const x = cv.getContext('2d'); x.fillStyle = '#d7f24a'; x.fillRect(0, 0, 256, 128); x.strokeStyle = '#fff'; x.lineWidth = 7; x.beginPath(); for (let i = 0; i <= 256; i += 4) { const y = 64 + Math.sin(i / 256 * Math.PI * 4) * 34; i ? x.lineTo(i, y) : x.moveTo(i, y); } x.stroke(); const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; const m = new THREE.Mesh(new THREE.SphereGeometry(0.12, 32, 20), new THREE.MeshStandardMaterial({ map: t, roughness: 0.85 })); m.position.y = 0.12; g.add(m); g.userData.r = 0.12; }
  else if (kind === 'bone') { const m = std(0xf4ead6, 0.6); const shaft = new THREE.Mesh(new THREE.CapsuleGeometry(0.04, 0.26, 6, 12), m); shaft.rotation.z = Math.PI / 2; shaft.position.y = 0.06; g.add(shaft); for (const sx of [-1, 1]) for (const sz of [-1, 1]) { const k = new THREE.Mesh(new THREE.SphereGeometry(0.055, 14, 10), m); k.position.set(sx * 0.17, 0.06, sz * 0.04); g.add(k); } g.userData.r = 0.06; }
  else if (kind === 'yarn') { const m = new THREE.MeshStandardMaterial({ color: 0xe0457b, roughness: 0.95 }); const b = new THREE.Mesh(new THREE.SphereGeometry(0.11, 24, 16), m); b.position.y = 0.11; g.add(b); for (let i = 0; i < 5; i++) { const r = new THREE.Mesh(new THREE.TorusGeometry(0.112, 0.008, 6, 40), m); r.rotation.set(Math.random() * 3, Math.random() * 3, 0); r.position.y = 0.11; g.add(r); } const th = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.006, 4, 24, 2), m); th.position.set(0.15, 0.01, 0); th.rotation.x = Math.PI / 2; g.add(th); g.userData.r = 0.11; }
  else if (kind === 'wand') {
    // перо на нитці; нитка йде вгору за кадр, до «вудочки» в руці
    const fm = (c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.8, side: THREE.DoubleSide });
    for (let i = 0; i < 3; i++) { const f = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.2, 8), fm(['#ff7fb0', '#8655f0', '#ffd23f'][i])); f.scale.set(1, 1, 0.35); f.position.set((i - 1) * 0.03, -0.1, 0); f.rotation.z = (i - 1) * 0.35 + Math.PI; g.add(f); }
    const bead = new THREE.Mesh(new THREE.SphereGeometry(0.022, 10, 8), std('#ffffff', 0.4)); g.add(bead);
    const str = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.003, 3, 4), new THREE.MeshBasicMaterial({ color: 0xf2efe6 })); str.position.y = 1.5; g.add(str);
  }
  else if (kind === 'fly') { const body = new THREE.Mesh(new THREE.SphereGeometry(0.04, 10, 8), std(0x222222, 0.4)); g.add(body); for (const sx of [-1, 1]) { const w = new THREE.Mesh(new THREE.CircleGeometry(0.05, 12), new THREE.MeshBasicMaterial({ color: 0xcfefff, transparent: true, opacity: 0.6, side: THREE.DoubleSide })); w.position.set(sx * 0.04, 0.02, 0); w.rotation.set(-1.2, 0, sx * 0.5); w.name = 'wing'; g.add(w); } g.position.y = 0.5; g.userData.r = 0.04; }
  g.traverse((m) => { if (m.isMesh) m.castShadow = true; });
  return g;
}
function bowl(color, inner) {
  const g = new THREE.Group();
  const outer = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.16, 0.1, 32, 1, true), new THREE.MeshPhysicalMaterial({ color, roughness: 0.25, clearcoat: 1, side: THREE.DoubleSide })); outer.position.y = 0.05; g.add(outer);
  const bot = new THREE.Mesh(new THREE.CircleGeometry(0.16, 32), new THREE.MeshPhysicalMaterial({ color, roughness: 0.3 })); bot.rotation.x = -Math.PI / 2; bot.position.y = 0.005; g.add(bot);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.015, 8, 40), new THREE.MeshPhysicalMaterial({ color, roughness: 0.2, clearcoat: 1 })); rim.rotation.x = Math.PI / 2; rim.position.y = 0.1; g.add(rim);
  const fill = new THREE.Mesh(new THREE.CircleGeometry(0.185, 32), inner); fill.rotation.x = -Math.PI / 2; fill.position.y = 0.02; g.add(fill);
  g.userData.fill = fill;
  const hit = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.4, 10), new THREE.MeshBasicMaterial({ visible: false })); hit.position.y = 0.15; g.add(hit); g.userData.hit = hit;
  g.traverse((m) => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
  return g;
}

export class PetStage {
  constructor(quality) {
    this.PF = profile(quality || 'high');
    this.canvas = document.createElement('canvas'); this.canvas.className = 'pet-canvas'; this.canvas.setAttribute('aria-hidden', 'true');
    // згладжування країв на телефонах зайве (високий dpr) і дорого — лише в «Високій» якості
    const R = this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: this.PF.petAA, alpha: true });
    R.outputColorSpace = THREE.SRGBColorSpace; R.toneMapping = THREE.ACESFilmicToneMapping; R.shadowMap.enabled = true; R.shadowMap.type = THREE.PCFShadowMap;
    this.scene = new THREE.Scene();
    // світло-оточення потребує half-float текстур; без них (старі Android) — просте запасне світло
    if (R.extensions.has('EXT_color_buffer_float') || R.extensions.has('EXT_color_buffer_half_float')) { const pm = new THREE.PMREMGenerator(R); this.scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture; this.scene.environmentIntensity = 0.55; pm.dispose(); }
    else this.scene.add(new THREE.HemisphereLight(0xffffff, 0x3a4250, 1.2));
    this.camera = new THREE.PerspectiveCamera(30, 1, 0.05, 60);
    const key = this.keyLight = new THREE.DirectionalLight(0xfff0dc, 2.6); key.position.set(-2.5, 5, 3.5); key.castShadow = this.PF.petShadows; key.shadow.mapSize.set(this.PF.petDpr > 1.3 ? 1024 : 512, this.PF.petDpr > 1.3 ? 1024 : 512); Object.assign(key.shadow.camera, { left: -3, right: 3, top: 3, bottom: -3, near: 0.5, far: 15 }); key.shadow.bias = -0.0005; this.scene.add(key);
    const rim = new THREE.DirectionalLight(0x8fdcff, 1.3); rim.position.set(3, 2, -3); this.scene.add(rim);
    this.world = new THREE.Group(); this.scene.add(this.world);
    const ground = new THREE.Mesh(new THREE.CircleGeometry(3.2, 64), new THREE.ShadowMaterial({ opacity: 0.36 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; this.world.add(ground);
    const ringTex = (() => { const cv = document.createElement('canvas'); cv.width = cv.height = 256; const g = cv.getContext('2d'); const gr = g.createRadialGradient(128, 128, 60, 128, 128, 128); gr.addColorStop(0, 'rgba(255,255,255,0.10)'); gr.addColorStop(0.92, 'rgba(255,255,255,0.05)'); gr.addColorStop(0.97, 'rgba(255,255,255,0.22)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, 256, 256); return new THREE.CanvasTexture(cv); })();
    this.rug = new THREE.Mesh(new THREE.CircleGeometry(1.65, 64), new THREE.MeshBasicMaterial({ map: ringTex, transparent: true, depthWrite: false })); this.rug.rotation.x = -Math.PI / 2; this.rug.position.y = 0.002; this.world.add(this.rug);
    this.actor = new THREE.Group(); this.world.add(this.actor);
    this.body = new THREE.Group(); this.actor.add(this.body);
    this.proxy = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshBasicMaterial({ visible: false })); this.actor.add(this.proxy);
    // миски
    this.foodBowl = bowl(0xd9573f, new THREE.MeshStandardMaterial({ color: 0x8a5a2a, roughness: 0.9 }));
    this.waterBowl = bowl(0x3f7fd9, new THREE.MeshPhysicalMaterial({ color: 0x6fc3ff, roughness: 0.05, transmission: 0.3, transparent: true, opacity: 0.85 }));
    // миски спереду зліва: тварина підходить з-за миски й їсть обличчям до тебе
    this.foodBowl.position.set(-1.22, 0, 0.18); this.waterBowl.position.set(-0.92, 0, 0.78);
    this.world.add(this.foodBowl, this.waterBowl);
    this.bowls = { food: 0.6, water: 0.8 };
    this.kibble = new THREE.Group(); this.foodBowl.add(this.kibble);
    // лазерна крапка
    this.dot = new THREE.Mesh(new THREE.CircleGeometry(0.035, 16), new THREE.MeshBasicMaterial({ color: new THREE.Color(4, 0.2, 0.2) })); this.dot.rotation.x = -Math.PI / 2; this.dot.position.y = 0.01; this.dot.visible = false; this.world.add(this.dot);
    this.dotGlow = new THREE.PointLight(0xff2020, 0, 0.8); this.dot.add(this.dotGlow);
    this.toy = null; this.toyKind = null; this.toyV = V(); this.toyHeld = false; this.cups = null; this.game = null; this.lookAt = null; this.gestures = false;
    // ефекти мисок
    this.shown = { food: 0.6, water: 0.8 }; this.fx = []; this._pour = 0;
    this._ringGeo = new THREE.RingGeometry(0.018, 0.026, 28); this._dropGeo = new THREE.SphereGeometry(0.011, 8, 6); this._crumbGeo = new THREE.DodecahedronGeometry(0.011);
    this._dropMat = new THREE.MeshStandardMaterial({ color: 0x9fd8ff, roughness: 0.1, transparent: true, opacity: 0.85 });
    this.stream = new THREE.Mesh(new THREE.CylinderGeometry(0.011, 0.016, 0.56, 10, 1, true), new THREE.MeshStandardMaterial({ color: 0x8fd0ff, roughness: 0.05, transparent: true, opacity: 0.7 })); this.stream.visible = false; this.world.add(this.stream);
    // слід жесту поверх сцени
    this.trail = document.createElement('canvas'); this.trail.className = 'pet-trail'; this.trail.setAttribute('aria-hidden', 'true');
    this.onHint = this.onGesture = null;
    this.hatKind = 'none'; this.hat = null; this.mode = 'mini'; this.sp = 'dog';
    this.state = 'idle'; this.target = null; this.onArrive = null; this.busy = 0;
    this.needs = { food: 75, water: 75, joy: 70, energy: 85 };
    this.skills = {}; this.awaitReward = 0;
    this.stroke = 0; this.lastAct = performance.now(); this.nextWander = 8;
    this.look = new THREE.Vector2(); this.lookW = 0;
    this.cache = {};
    this.onState = this.onTap = this.onHappy = this.onNeeds = this.onSound = this.onSay = this.onTrain = null;
    this._ro = new ResizeObserver(() => this.resize());
    this.ray = new THREE.Raycaster();
    this._t0 = performance.now();
    this._lim = limiter(() => (this.mode === 'full' ? this.PF.petFps : Math.min(this.PF.petFps, 30)));
    this._bindInput(); this._loop();
  }

  /* ---------- розміщення ---------- */
  mount(el, mode) {
    if (!el) return;
    if (this.canvas.parentNode !== el) {
      el.appendChild(this.canvas); el.appendChild(this.trail); this._ro.disconnect(); this._ro.observe(el);
      // не малюємо, поки улюбленця не видно (прихований блок, під листом тощо)
      try { if (window.IntersectionObserver) { this._vis = true; this._io = this._io || new IntersectionObserver((es) => { this._vis = es[es.length - 1].isIntersecting; }); this._io.disconnect(); this._io.observe(el); } } catch (_) { }
    }
    this.setMode(mode || 'mini'); this.resize();
  }
  /* зміна якості «на льоту»: роздільність і тіні; згладжування (antialias) задається лише при створенні */
  setQuality(q) {
    this.PF = profile(q);
    if (this.keyLight) this.keyLight.castShadow = this.PF.petShadows;
    this.resize();
  }
  setMode(m) {
    this.mode = m; const full = m === 'full';
    if (this.keyLight) this.keyLight.castShadow = this.PF.petShadows && (full || this.PF.petAA); // у малому кутку тінь не видно — не рахуємо її
    this.rug.visible = this.foodBowl.visible = this.waterBowl.visible = full;
    if (this.toy) this.toy.visible = full || this.toyHeld;
    if (this.cups) { this.cups.setVisible(full); if (full && !this.game) this.cups.start(); }
    if (!full) { this.gestures = false; this.lookAt = null; }
    if (!full) { this._stop(); this.actor.position.set(0, 0, 0); this.actor.rotation.y = 0.5; this.world.rotation.y = 0; this.dot.visible = false; }
    else if (this._lastMode !== 'full') this.actor.rotation.y = 0.35;
    this._lastMode = m; this._frame();
  }
  resize() { const p = this.canvas.parentNode; if (!p) return; const w = Math.max(40, p.clientWidth), h = Math.max(40, p.clientHeight); this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, this.PF.petDpr)); this.renderer.setSize(w, h, false); this._w = w; this._h = h; this.camera.aspect = w / h; this._frame(); }
  _frame() {
    const s = this.size || 1, wide = this.wide || s;
    const tan = Math.tan(THREE.MathUtils.degToRad(this.camera.fov) / 2), asp = this.camera.aspect;
    if (this.mode === 'full') {
      // килимок — посередині ВІДКРИТОЇ частини сцени: між показниками зверху та панеллю знизу
      const H = this._h || 400, Wd = this._w || 300, host = this.canvas.closest('.pet-stage');
      const dock = host && host.querySelector('.pet-dock') ? host.querySelector('.pet-dock').offsetHeight + 14 : 0, top = host ? 44 : 0;
      const visH = Math.max(120, H - dock - top), tanV = tan * visH / H;
      const R = 1.65, el = 0.66; const dist = Math.max((R * (asp < 0.9 ? 0.98 : 1.08)) / (tan * asp), (R * 0.62 + s * 0.62) / tanV);
      this.camera.position.set(0, Math.sin(el) * dist + s * 0.2, Math.cos(el) * dist); this.camera.lookAt(0, s * 0.22, 0);
      this.camera.setViewOffset(Wd, H, 0, (dock - top) / 2, Wd, H);
    } else { this.camera.clearViewOffset(); const dist = Math.max((s * 1.35 / 2) / tan, (wide * 1.2 / 2) / (tan * asp)); this.camera.position.set(0, s * 0.55 + dist * 0.2, dist); this.camera.lookAt(0, s * 0.45, 0); }
    this.camera.updateProjectionMatrix();
  }

  /* ---------- модель ---------- */
  async load(url, breed, tint) {
    this.loading = true; if (this.onState) this.onState('loading');
    try {
      this.sp = typeof url === 'string' ? speciesOf(url) : 'dog';
      if (typeof url === 'string' && url.startsWith('proc:cat')) this._useCat(url.split(':')[2] || 'grey');
      else { const g = url instanceof ArrayBuffer ? await parse(url) : this.cache[url] || await gltf(url); this._use(g, tint); }
      this.breed = breed; this._fillKibble();
      if (this.onState) this.onState('ready');
    } catch (e) { console.error(e); if (this.onState) this.onState('error', e); }
    this.loading = false;
  }
  async loadFile(file, breed) {
    const key = 'file:' + file.name + ':' + file.size; const buf = await file.arrayBuffer();
    this.loading = true; if (this.onState) this.onState('loading');
    try { const g = await parse(buf); this.cache[key] = g; this.sp = 'dog'; this._use(g); this.breed = breed; if (this.onState) this.onState('ready'); } catch (e) { if (this.onState) this.onState('error', e); }
    this.loading = false; return key;
  }
  _measure(model) {
    model.updateMatrixWorld(true);
    const b = new THREE.Box3().setFromObject(model); const c = b.getCenter(V());
    model.position.x -= c.x; model.position.z -= c.z; model.position.y -= b.min.y;
    const sz = b.getSize(V()); this.size = sz.y; this.wide = Math.max(sz.x, sz.z) * 0.85; this.len = Math.max(sz.x, sz.z);
    this.proxy.scale.set(sz.x * 1.05, sz.y * 1.05, sz.z * 1.05); this.proxy.position.set(0, sz.y / 2, 0);
  }
  _useCat(coat) {
    this.body.clear(); this.mixer = null; this.acts = null;
    const cat = makeCat({ coat }); cat.scale.setScalar(1.9); this.body.add(cat);
    this.proc = cat.userData.cat; this._measure(cat); this.head = this.proc.head; this._hatAnchor(cat);
    this.state = 'idle'; this.play('idle'); this.setHat(this.hatKind); this._frame();
  }
  _use(g, tint) {
    this.body.clear(); this.proc = null;
    const model = skClone(g.scene); prep(model, { tint });
    model.updateMatrixWorld(true);
    const box = new THREE.Box3().setFromObject(model), size = box.getSize(V());
    model.scale.multiplyScalar(1.1 / Math.max(size.y, size.x * 0.6, size.z * 0.6));
    this.body.add(model); this._measure(model);
    this.mixer = new THREE.AnimationMixer(model);
    const cl = g.animations || [];
    const A = (c2) => c2 ? this.mixer.clipAction(c2) : null;
    // важливо: «Death» містить «eat» — тому шаблони точні
    this.acts = {
      idle: A(clip(cl, /^idle$/i, /flying_idle/i, /^triceratops_idle$/i, /^idle/i) || cl.find((c) => !/death/i.test(c.name))),
      idle2: A(clip(cl, /^idle_2$/i, /^dance$/i)),
      walk: A(clip(cl, /^walk$/i, /walk$/i, /flying_idle/i)),
      run: A(clip(cl, /^gallop$/i, /^run$/i, /_run$/i, /fast_flying/i)),
      eat: A(clip(cl, /^eating$/i, /^idle_eating$/i, /^bite_front$/i, /^headbutt$/i)),
      jump: A(clip(cl, /^jump_toidle$/i, /^jump$/i, /_jump$/i, /^jump_start$/i, /^yes$/i)),
      reactL: A(clip(cl, /hitreact_left/i, /^hitreact$/i, /^headbutt$/i, /^yes$/i)),
      reactR: A(clip(cl, /hitreact_right/i, /^hitreact$/i, /^headbutt$/i, /^yes$/i)),
      low: A(clip(cl, /headlow/i, /^duck$/i)),
      paw: A(clip(cl, /^wave$/i, /^yes$/i, /hitreact_left/i, /^punch$/i)),
      voice: A(clip(cl, /^attack_headbutt$/i, /^attack$/i, /_attack$/i, /^headbutt$/i, /^punch$/i, /^no$/i))
    };
    this.head = null;
    model.traverse((o) => { if (!this.head && o.isBone && /^head$/i.test(o.name)) this.head = o; });
    if (!this.head) model.traverse((o) => { if (!this.head && o.isBone && /head/i.test(o.name) && !/end/i.test(o.name)) this.head = o; });
    this._hatAnchor(model);
    this.cur = null; this.state = 'idle'; this.play('idle'); this.setHat(this.hatKind); this._frame();
  }
  /* логічні стани → анімація (кіт — процедурно, інші — кліпи + поза тіла) */
  play(n, { once = false, speed = 1, then, dur } = {}) {
    clearTimeout(this._playT);
    this.pose = n;
    if (this.proc) {
      const map = { idle2: 'idle', low: 'lie', reactL: 'look', reactR: 'look', voice: 'meow', chew: 'eat', spin: 'walk', fly: 'idle', tug: 'crouch' };
      this.proc.set(map[n] || n);
      if (once || dur) this._playT = setTimeout(() => { if (then) then(); else this._backToIdle(); }, (dur || ({ jump: 0.75, paw: 1.6, voice: 1.0, meow: 1.0, reactL: 0.6, reactR: 0.6, eat: 2.6, drink: 2.4, swat: 0.6 }[n] || 1.2)) * 1000);
      return;
    }
    const anim = n === 'drink' ? (this.acts && this.acts.low ? 'low' : 'eat') : { sit: 'low', lie: 'low', sleep: 'low', chew: 'eat', pounce: 'run', crouch: 'low', purr: 'idle', spin: 'walk', fly: 'idle', sniff: 'low', tug: 'low', swat: 'paw', look: 'idle', beg: 'idle2', groom: 'idle2' }[n] || n;
    const a = (this.acts && (this.acts[anim] || this.acts.idle));
    if (!a) { if (then) setTimeout(then, 800); return; }
    a.timeScale = speed;
    if (!(this.cur === a && !once)) { a.reset(); a.setLoop(once ? THREE.LoopOnce : THREE.LoopRepeat, Infinity); a.clampWhenFinished = once; a.fadeIn(0.25).play(); if (this.cur && this.cur !== a) this.cur.fadeOut(0.25); this.cur = a; }
    if (once) { const f = (e) => { if (e.action === a) { this.mixer.removeEventListener('finished', f); if (then) then(); else this._backToIdle(); } }; this.mixer.addEventListener('finished', f); }
    else if (dur) this._playT = setTimeout(() => { if (then) then(); else this._backToIdle(); }, dur * 1000);
  }
  _backToIdle() { if (['walk', 'run', 'fetch', 'return', 'laser', 'tug', 'offer', 'wand'].includes(this.state)) return; this.state = 'idle'; this.play(this.needs.energy < 15 ? 'sleep' : 'idle'); }

  /* ---------- вбрання: шапка сидить на маківці й рухається разом із головою ----------
     У позі спокою беремо вершини моделі, що належать кістці голови, і шукаємо
     маківку посередині між вухами та ширину голови. Шапку чіпляємо до кістки
     голови з цим зсувом — тоді вона нахиляється й повертається разом із головою. */
  _hatAnchor(model) {
    this.hatAnchor = null; this.hatBone = null;
    const bone = this.head;
    const save = [this.body.rotation.x, this.body.rotation.z, this.body.position.y];
    this.body.rotation.x = this.body.rotation.z = 0; this.body.position.y = 0;
    this.scene.updateMatrixWorld(true);
    const pts = [], v = V(), inv = new THREE.Matrix4().copy(this.body.matrixWorld).invert();
    if (bone && this.proc) {
      const sk = bone.children.find((c) => c.isMesh);
      if (sk) { const pos = sk.geometry.attributes.position; for (let i = 0; i < pos.count; i++) { v.fromBufferAttribute(pos, i).applyMatrix4(sk.matrixWorld).applyMatrix4(inv); pts.push(v.clone()); } }
    } else if (bone) {
      // у цих моделях маківку часто «тримають» кістки вух або верх шиї, а не сама кістка голови,
      // тому беремо всю голову: кістку голови, її нащадків (вуха, щелепа) і найближчу кістку шиї
      // вуха бувають не дітьми голови, а «сестрами» — тому беремо все, що росте з верхньої кістки шиї
      const root = bone.parent && bone.parent.isBone && bone.parent.parent && bone.parent.parent.isBone ? bone.parent : bone;
      const set = new Set(); root.traverse((o) => { if (o.isBone) set.add(o); });
      model.traverse((m) => {
        if (!m.isSkinnedMesh || !m.skeleton) return;
        const g = m.geometry, si = g.attributes.skinIndex, sw = g.attributes.skinWeight; if (!si || !sw) return;
        const own = m.skeleton.bones.map((b) => set.has(b)); if (!own.some(Boolean)) return;
        m.skeleton.update();
        for (let i = 0; i < g.attributes.position.count; i++) {
          let best = -1, bw = 0; for (let j = 0; j < si.itemSize; j++) { const w = sw.getComponent(i, j); if (w > bw) { bw = w; best = si.getComponent(i, j); } }
          if (best < 0 || !own[best]) continue;
          m.getVertexPosition(i, v); v.applyMatrix4(m.matrixWorld).applyMatrix4(inv); pts.push(v.clone());
        }
      });
    }
    if (pts.length >= 12) {
      const pc = (a, q) => a[Math.min(a.length - 1, Math.max(0, Math.round(q * (a.length - 1))))];
      const xs = pts.map((p) => p.x).sort((a, b) => a - b), cx = pc(xs, 0.5), W1 = Math.max(0.05, pc(xs, 0.9) - pc(xs, 0.1));
      // маківка — найвища точка вузької смуги посередині (вуха збоку в неї не потрапляють)
      const strip = pts.filter((p) => Math.abs(p.x - cx) < W1 * 0.18);
      const ys = strip.map((p) => p.y).sort((a, b) => a - b), top = pc(ys, 0.97);
      const band = strip.filter((p) => p.y > top - W1 * 0.15).map((p) => p.z).sort((a, b) => a - b);
      // ширина голови — на висоті маківки (там, де сидить шапка), а не по всій голові
      const H = top - pc(pts.map((p) => p.y).sort((a, b) => a - b), 0.05);
      const xs2 = pts.filter((p) => p.y > top - H * 0.3 && p.y < top + H * 0.3).map((p) => p.x).sort((a, b) => a - b);
      const W = Math.max(W1, xs2.length > 8 ? pc(xs2, 0.97) - pc(xs2, 0.03) : W1);
      const at = new THREE.Matrix4().compose(this.body.localToWorld(V(cx, top, pc(band, 0.5))), this.body.getWorldQuaternion(new THREE.Quaternion()), V(W, W, W));
      this.hatAnchor = new THREE.Matrix4().copy(bone.matrixWorld).invert().multiply(at); this.hatBone = bone; this.headW = W;
    } else {
      // моделі без кістки голови: шапка на тілі, над передньою частиною
      const W = (this.wide || 0.6) * 0.42; this.hatBone = this.body; this.headW = W;
      this.hatAnchor = new THREE.Matrix4().compose(V(0, (this.size || 1) * 0.97, (this.len || 1) * 0.25), new THREE.Quaternion(), V(W, W, W));
    }
    this.body.rotation.x = save[0]; this.body.rotation.z = save[1]; this.body.position.y = save[2];
  }
  setHat(kind) {
    this.hatKind = kind;
    if (this.hat) { if (this.hat.parent) this.hat.parent.remove(this.hat); this.hat = null; }
    if (!kind || kind === 'none' || !this.hatAnchor || !this.hatBone) return;
    const F = HAT_FIT[kind] || HAT_FIT.crown;
    const wrap = new THREE.Group(); wrap.matrixAutoUpdate = false; wrap.matrix.copy(this.hatAnchor); wrap.matrixWorldNeedsUpdate = true;
    const h = makeHat(kind); const s = F.k / F.r;
    h.position.set(F.side || 0, -(F.sink || 0), F.fwd || 0); h.rotation.set(F.tilt || 0, F.yaw || 0, F.roll || 0); h.scale.setScalar(s);
    wrap.add(h); this.hatBone.add(wrap); this.hat = wrap;
    if (this.mode === 'full' && !this.loading) { h.scale.setScalar(s * 0.01); this._hatPop = { h, s, t: 0 }; this._s('wear'); }
  }
  react(kind) { if (kind === 'happy' || kind === 'play') this.play('jump', { once: true }); else if (kind === 'feed') this.play('eat', { once: true }); else this.play('reactL', { once: true }); if (this.onHappy) this.onHappy(kind); }
  setNeeds(n) { Object.assign(this.needs, n); }
  _need(k, d) { this.needs[k] = Math.max(0, Math.min(100, (this.needs[k] ?? 50) + d)); }
  // голос тварини (за видом і ситуацією) і звуки догляду; голос не накладається сам на себе
  _v(what, gap = 0.45) { const n = performance.now(); if (n - (this._vt || 0) < gap * 1000) return; this._vt = n; petVoice(this.sp, what, this.size); }
  _s(kind, arg) { careSound(kind, arg); }
  _pose(n) { if (this.pose !== n) this.play(n); }
  _fwd() { return V(Math.sin(this.actor.rotation.y), 0, Math.cos(this.actor.rotation.y)); }

  /* ---------- миски ---------- */
  _fillKibble() {
    this.kibble.clear();
    const cat = this.sp === 'cat', N = 30;
    const m1 = new THREE.MeshStandardMaterial({ color: cat ? 0xc98a6a : 0x8a5a2a, roughness: 0.8 }), m2 = new THREE.MeshStandardMaterial({ color: cat ? 0xe6b493 : 0xa8743c, roughness: 0.8 });
    const geo = cat ? new THREE.SphereGeometry(0.026, 8, 6) : new THREE.DodecahedronGeometry(0.024);
    // гірка: перші шматочки — на дні, останні — зверху (їх з'їдають першими)
    for (let i = 0; i < N; i++) {
      const q = i / N, a = Math.random() * 6.28, r = 0.145 * (1 - q * 0.7) * Math.sqrt(Math.random());
      const k = new THREE.Mesh(geo, i % 3 ? m1 : m2); k.position.set(Math.cos(a) * r, 0.022 + q * 0.06, Math.sin(a) * r);
      if (cat) k.scale.set(1.4, 0.7, 0.9); k.rotation.set(Math.random() * 3, Math.random() * 3, 0); k.castShadow = true; k.userData.y = k.position.y; this.kibble.add(k);
    }
    if (cat) { const fish = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.12, 8), new THREE.MeshStandardMaterial({ color: 0x9fb8c8, metalness: 0.4, roughness: 0.3 })); fish.rotation.z = Math.PI / 2; fish.position.set(0.03, 0.08, 0); fish.userData.y = 0.08; this.kibble.add(fish); }
    this._bowlLook();
  }
  _bowlLook() {
    const f = this.shown.food, w = this.shown.water, ks = this.kibble.children, vis = Math.round(f * ks.length);
    ks.forEach((k, i) => { k.visible = i < vis; });
    const fb = this.foodBowl.userData.fill; fb.visible = f > 0.02; fb.position.y = 0.012 + Math.min(1, f * 2) * 0.012;
    const wf = this.waterBowl.userData.fill; wf.visible = w > 0.02; wf.position.y = 0.012 + w * 0.072; const s = 0.84 + w * 0.16; wf.scale.set(s, s, 1);
  }
  fillBowl(which) {
    if (this.bowls[which] > 0.95) return;
    const b = which === 'food' ? this.foodBowl : this.waterBowl;
    if (which === 'food') {
      // корм сиплеться згори: нові шматочки падають у миску
      const ks = this.kibble.children, from = Math.round(this.shown.food * ks.length);
      ks.forEach((k, i) => { if (i >= from) { k.userData.fall = 0.35 + (i - from) * 0.022; k.userData.fv = 0; } });
      this.bowls.food = this.shown.food = 1; this._bowlLook(); this._s('kibble');
    } else { this.bowls.water = 1; this._pour = 0.7; this._s('pour'); }
    b.scale.set(1.12, 0.88, 1.12); setTimeout(() => b.scale.set(1, 1, 1), 160);
    if (this.mode === 'full' && !['fetch', 'return', 'eat', 'drink', 'tug', 'offer'].includes(this.state) && !this.cups) setTimeout(() => this._goEat(which), 700);
  }
  _goEat(which) {
    const b = which === 'food' ? this.foodBowl : this.waterBowl;
    const dir = b.position.clone().setY(0).negate().normalize();
    const p = b.position.clone().addScaledVector(dir, (this.len || 1) * 0.5 + 0.12);
    this._goto(this.world.localToWorld(p), false, () => {
      this._faceLocal(b.position);
      this.state = which === 'food' ? 'eat' : 'drink';
      this.meal = { which, t: 0, tick: 0.25, dur: which === 'food' ? 3.4 : 3.0, from: this.bowls[which], eat: Math.min(this.bowls[which], 0.45) };
      this.play(this.state, { speed: which === 'water' ? 1.6 : 1 });
    });
  }
  _meal(dt) {
    const m = this.meal; m.t += dt; m.tick -= dt;
    this.bowls[m.which] = m.from - m.eat * Math.min(1, m.t / m.dur);
    if (m.tick <= 0) {
      if (m.which === 'food') { m.tick = 0.36; this._s('crunch'); this._crumbs(2); }
      else { m.tick = 0.28; this._s('lap'); this._ripple(); if (Math.random() < 0.7) this._drops(2); }
    }
    if (m.t >= m.dur) {
      this.meal = null; this._need(m.which, 90 * m.eat); this._need('joy', 4); this.state = 'idle';
      this.play(this.proc ? 'groom' : 'idle', { dur: this.proc ? 1.6 : 0 }); if (this.onHappy) this.onHappy('feed'); this._v('happy', 0.2);
    }
  }
  /* ---------- маленькі ефекти: брижі, краплі, крихти ---------- */
  _fxAdd(m, o, parent) { (parent || this.world).add(m); this.fx.push(Object.assign({ m, t: 0, life: 1 }, o)); }
  _ripple() {
    const wf = this.waterBowl.userData.fill, r = new THREE.Mesh(this._ringGeo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.6, depthWrite: false }));
    const a = Math.random() * 6.28, rr = Math.random() * 0.05; r.rotation.x = -Math.PI / 2; r.position.set(Math.cos(a) * rr, wf.position.y + 0.003, Math.sin(a) * rr);
    this._fxAdd(r, { kind: 'ripple', life: 0.75 }, this.waterBowl);
  }
  _drops(n) {
    const b = this.waterBowl.position, y0 = this.waterBowl.userData.fill.position.y;
    for (let i = 0; i < n; i++) { const d = new THREE.Mesh(this._dropGeo, this._dropMat); d.position.set(b.x + (Math.random() - 0.5) * 0.1, y0 + 0.02, b.z + (Math.random() - 0.5) * 0.1); this._fxAdd(d, { kind: 'drop', life: 1.2, v: V((Math.random() - 0.5) * 0.6, 0.7 + Math.random() * 0.6, (Math.random() - 0.5) * 0.6), floor: y0 }); }
  }
  _crumbs(n) {
    const b = this.foodBowl.position, toward = this.actor.position.clone().sub(b).setY(0).normalize();
    for (let i = 0; i < n; i++) { const c = new THREE.Mesh(this._crumbGeo, this.kibble.children[0] ? this.kibble.children[0].material : this._dropMat); c.position.set(b.x + toward.x * 0.12, 0.09, b.z + toward.z * 0.12); this._fxAdd(c, { kind: 'crumb', life: 2.2, v: V(toward.x * 0.5 + (Math.random() - 0.5) * 0.5, 0.6 + Math.random() * 0.4, toward.z * 0.5 + (Math.random() - 0.5) * 0.5) }); }
  }
  _fxTick(dt) {
    for (let i = this.fx.length - 1; i >= 0; i--) {
      const f = this.fx[i]; f.t += dt; const k = f.t / f.life, m = f.m;
      if (f.kind === 'ripple') { const s = 0.4 + k * 2.6; m.scale.set(s, s, s); m.material.opacity = 0.6 * (1 - k); }
      else if (f.kind === 'drop' || f.kind === 'crumb' || f.kind === 'treat') {
        if (f.v) { f.v.y -= 6 * dt; m.position.addScaledVector(f.v, dt); const fl = f.floor ?? 0.008; if (m.position.y < fl) { if (f.kind === 'drop') f.t = f.life; else { m.position.y = fl; f.v = null; } } }
        if (f.kind === 'crumb' && k > 0.7) m.scale.setScalar(Math.max(0.01, (1 - k) / 0.3));
      }
      if (f.t >= f.life) { if (m.parent) m.parent.remove(m); if (f.kind === 'ripple') m.material.dispose(); this.fx.splice(i, 1); if (f.done) f.done(); }
    }
  }
  // ласощі летять від тебе просто до рота
  _tossTreat(done) {
    const c = treatMesh(); const from = this.world.worldToLocal(this.camera.position.clone().lerp(this.world.localToWorld(V(0, 0.5, 0)), 0.55)), to = this.world.worldToLocal(this._mouth());
    c.position.copy(from); this.world.add(c); let t = 0;
    this._fxAdd(c, { kind: 'fly', life: 0.45, done: () => { if (done) done(); } });
    const f = this.fx[this.fx.length - 1]; f.tick = (dt) => { t += dt; const k = Math.min(1, t / 0.45); c.position.lerpVectors(from, this.world.worldToLocal(this._mouth()), k); c.position.y += Math.sin(k * Math.PI) * 0.35; c.rotation.x += dt * 9; };
    void to;
  }

  /* ---------- іграшки ---------- */
  setToy(kind) {
    if (this.toy) { if (this.toy.parent) this.toy.parent.remove(this.toy); this.toy = null; }
    if (this.cups) { this.cups.stop(); this.cups = null; }
    if (['offer', 'tug', 'fetch', 'return', 'wand', 'laser'].includes(this.state)) { this._stop(); this.state = 'idle'; this.play('idle'); }
    this.toyKind = kind; this.toyHeld = false; this.dot.visible = false; this.wand = null; this.tug = null; this.lookAt = null;
    if (!kind || kind === 'laser') return;
    if (kind === 'cups') { this.cups = new Cups(this); if (this.mode === 'full') this.cups.start(); return; }
    this.toy = toyMesh(kind); this.toy.visible = this.mode === 'full'; this.world.add(this.toy); this.toyV.set(0, 0, 0);
    if (kind === 'wand') { this.toy.position.set(0.45, 0.6, 0.55); this.wand = { v: V(), held: false, cool: 0, caught: 0, still: 0 }; }
    else this.toy.position.set(0.8, kind === 'fly' ? 0.5 : 0, 0.55);
    const hit = new THREE.Mesh(new THREE.SphereGeometry(kind === 'wand' ? 0.22 : 0.32, 8, 6), new THREE.MeshBasicMaterial({ visible: false })); hit.position.y = kind === 'wand' ? 0 : 0.1; this.toy.add(hit); this.toyHit = hit;
  }
  _dropToy() {
    if (!this.toy) return;
    this.toyHeld = false; this.toy.position.copy(this.actor.position).addScaledVector(this._fwd(), (this.len || 1) * 0.5).setY(0); this.toyV.set(0, 0, 0); this.toy.rotation.set(0, this.toy.rotation.y, 0);
    if (this.state === 'offer') { this.state = 'idle'; this.play('idle'); }
    this._s('catchIt');
  }

  /* ---------- команди й тренування ---------- */
  command(cmd) {
    if (this.loading) return false;
    this._stop(); this.lastAct = performance.now();
    if (this.needs.energy < 10) { this.play('sleep'); if (this.onSay) this.onSay('tired'); this._s('snore'); return false; }
    const sk = this.skills[cmd] || 0, ok = Math.random() < 0.35 + sk * 0.13;
    this._faceLocal(this.world.worldToLocal(this.camera.position.clone()));
    if (!ok) { this.state = 'idle'; this.play(this.proc ? 'look' : 'reactL', { once: !this.proc, dur: this.proc ? 0.9 : 0 }); if (this.onSay) this.onSay('confused'); this._v('no'); return false; }
    this.state = 'cmd';
    const done = () => { this.state = 'idle'; this.awaitReward = 3; this._learn(cmd, 0.2); if (this.onSay) this.onSay('wait'); this.play(cmd === 'lie' ? 'lie' : cmd === 'sit' ? 'sit' : this.proc ? 'beg' : 'idle', { dur: 3, then: () => this._backToIdle() }); };
    if (cmd === 'sit') this.play('sit', { dur: 1.2, then: done });
    else if (cmd === 'lie') this.play('lie', { dur: 1.2, then: done });
    else if (cmd === 'paw') this.play('paw', { once: !this.proc, dur: this.proc ? 1.6 : 0, then: done });
    else if (cmd === 'jump') { this.play('jump', { once: !this.proc, dur: this.proc ? 0.8 : 0, then: done }); setTimeout(() => this._s('catchIt'), 650); }
    else if (cmd === 'spin') { this.spin = 1.1; this.play('walk', { dur: 1.1, then: done }); this._s('shuffle'); }
    else if (cmd === 'voice') { this.play('voice', { once: !this.proc, dur: this.proc ? 1 : 0, then: done }); this._v('hello', 0); }
    this.lastCmd = cmd;
    return true;
  }
  reward() {
    if (this.loading) return;
    this._tossTreat(() => {
      if (this.awaitReward > 0 && this.lastCmd) { this._learn(this.lastCmd, 0.8); this.awaitReward = 0; if (this.onSay) this.onSay('learned'); }
      this._need('joy', 5); this._need('food', 4); this.play('eat', { dur: 1.2 }); this._s('crunch'); setTimeout(() => this._s('crunch'), 330); setTimeout(() => this._v('happy', 0), 900); if (this.onHappy) this.onHappy('feed');
    });
  }
  _learn(cmd, d) { this.skills[cmd] = Math.min(5, (this.skills[cmd] || 0) + d); if (this.onTrain) this.onTrain(this.skills); }

  /* ---------- рух ---------- */
  _goto(p, run, cb) { this.target = p.clone(); this.target.y = 0; this.running = run; this.onArrive = cb; this.state = run ? 'run' : 'walk'; this.play(run ? 'run' : 'walk', { speed: run ? 1.1 : 1 }); }
  _stop() { this.target = null; this.onArrive = null; this.spin = 0; if (['walk', 'run', 'fetch', 'return', 'laser', 'wand'].includes(this.state)) { this.state = 'idle'; this.play('idle'); } }
  _mouth() { const p = V(); if (this.head) this.head.getWorldPosition(p); else this.actor.getWorldPosition(p).add(V(0, this.size * 0.6, 0)); const fwd = V(0, 0, 1).applyQuaternion(this.actor.getWorldQuaternion(new THREE.Quaternion())); return p.addScaledVector(fwd, this.len * 0.12).add(V(0, -this.size * 0.08, 0)); }
  _faceLocal(lp, dt = 1, k = 100) { const d = lp.clone().sub(this.actor.position); if (d.lengthSq() < 1e-4) return; const want = Math.atan2(d.x, d.z); let diff = want - this.actor.rotation.y; diff = Math.atan2(Math.sin(diff), Math.cos(diff)); this.actor.rotation.y += diff * Math.min(1, dt * k); }
  _face(p, dt, k = 6) { this._faceLocal(this.world.worldToLocal(p.clone()), dt, k); }

  /* ---------- дотики ---------- */
  _ndc(e) { const r = this.canvas.getBoundingClientRect(); return new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); }
  _hit(e, objs) { this.ray.setFromCamera(this._ndc(e), this.camera); return this.ray.intersectObjects(objs.filter(Boolean), false)[0] || null; }
  _floor(e, y = 0) { this.ray.setFromCamera(this._ndc(e), this.camera); const p = V(); return this.ray.ray.intersectPlane(new THREE.Plane(up, -y), p) ? p : null; }
  // перо на вудочці рухається у вертикальній площині перед твариною
  _wandTo(e) {
    if (!this.toy || !this.wand) return;
    this.ray.setFromCamera(this._ndc(e), this.camera);
    const n = this.camera.position.clone().setY(0).normalize(), o = this.world.localToWorld(V(0, 0, 0.3)), p = V();
    if (!this.ray.ray.intersectPlane(new THREE.Plane().setFromNormalAndCoplanarPoint(n, o), p)) return;
    const lp = this.world.worldToLocal(p); lp.y = THREE.MathUtils.clamp(lp.y, 0.04, (this.size || 1) * 1.7); const r = Math.hypot(lp.x, lp.z); if (r > 1.45) { lp.x *= 1.45 / r; lp.z *= 1.45 / r; }
    const F = this.toy.position, dtv = Math.max(0.016, (performance.now() - (this.wand.tt || 0)) / 1000); this.wand.tt = performance.now();
    if (this.wand.held) this.wand.v.lerp(lp.clone().sub(F).divideScalar(dtv), 0.5); else this.wand.v.set(0, 0, 0);
    this.wand.held = true; this.wand.still = 0; F.copy(lp); this.wand.caught = 0;
  }
  _tugStart() { this.state = 'tug'; this.tug = { p: 0, t: 0, g: 0.2, f: null }; this.target = null; this.play('tug'); if (this.onSay) this.onSay('tug'); }
  _tugMove(e) {
    const p = this._floor(e); if (!p || !this.tug) return false; const lp = this.world.worldToLocal(p); this.tug.f = lp;
    this.tug.p += Math.min(28, Math.hypot(e.movementX || 0, e.movementY || 0)) * 0.0042;
    if (this.tug.p < 1) return false;
    // перемога: кістка в руці
    this.tug = null; this.toyHeld = false; this.state = 'idle'; this.play('jump', { once: true }); this._need('joy', 12); this._v('happy', 0); if (this.onHappy) this.onHappy('play');
    this.toy.position.set(lp.x, 0.16, lp.z); if (this.onSay) this.onSay('tug_win'); return true;
  }
  _tugEnd() {
    if (!this.tug) return;
    // відпустив — пес переміг і гордо трусить кісткою
    this.tug = null; this.state = 'offer'; this.offerUntil = performance.now() + 1800; this.play('jump', { once: !this.proc, dur: this.proc ? 0.7 : 0, then: () => this.play('idle') }); this._v('happy', 0); this._need('joy', 6);
  }
  _classify(dd) {
    const P = dd.pts, now = performance.now();
    if (!dd.moved) { if (now - (this._tapT || 0) < 340) { this._tapT = 0; this._gesture('voice'); } else this._tapT = now; return; }
    let len = 0, turn = 0, pa = null;
    for (let i = 1; i < P.length; i++) { const dx = P[i].x - P[i - 1].x, dy = P[i].y - P[i - 1].y, l = Math.hypot(dx, dy); if (l < 3) continue; len += l; const a = Math.atan2(dy, dx); if (pa != null) { const da = a - pa; turn += Math.atan2(Math.sin(da), Math.cos(da)); } pa = a; }
    const dx = P[P.length - 1].x - P[0].x, dy = P[P.length - 1].y - P[0].y, disp = Math.hypot(dx, dy);
    if (len < 36) return;
    if (Math.abs(turn) > 4.2 && len > disp * 1.8) { this.spinDir = Math.sign(turn); return this._gesture('spin'); }
    if (Math.abs(dy) > Math.abs(dx) * 1.1) return this._gesture(dy < 0 ? 'jump' : 'lie');
    return this._gesture('paw');
  }
  _gesture(cmd) { const ok = this.command(cmd); if (this.onGesture) this.onGesture(cmd, ok); }
  _trailPush(e) { const r = this.canvas.getBoundingClientRect(); if (!this._tr) this._tr = { p: [], a: 1, live: true }; this._tr.p.push([e.clientX - r.left, e.clientY - r.top]); if (this._tr.p.length > 90) this._tr.p.shift(); }
  _trailDraw(dt) {
    const c = this.trail; if (!c || !this._tr) return;
    const T = this._tr, r = this.canvas.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (c.width !== Math.round(r.width * dpr) || c.height !== Math.round(r.height * dpr)) { c.width = Math.round(r.width * dpr); c.height = Math.round(r.height * dpr); }
    const g = c.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, r.width, r.height);
    if (!T.live) T.a -= dt * 2.2; if (T.a <= 0 || T.p.length < 2) { if (T.a <= 0) { this._tr = null; g.clearRect(0, 0, r.width, r.height); } return; }
    g.lineCap = g.lineJoin = 'round';
    for (const [w, col] of [[14, 'rgba(255,211,107,.18)'], [6, 'rgba(255,227,154,.9)']]) { g.globalAlpha = T.a; g.strokeStyle = col; g.lineWidth = w; g.beginPath(); T.p.forEach(([x, y], i) => i ? g.lineTo(x, y) : g.moveTo(x, y)); g.stroke(); }
    g.globalAlpha = 1;
  }
  _bindInput() {
    let d = null; const cv = this.canvas; cv.style.touchAction = 'none';
    cv.addEventListener('pointerdown', (e) => {
      this.lastAct = performance.now(); const full = this.mode === 'full';
      if (full && this.cups && this.cups.down(e)) { d = { what: 'cups', x: e.clientX, y: e.clientY, moved: false }; try { cv.setPointerCapture(e.pointerId); } catch (_) { } return; }
      let what = 'empty';
      if (full && this.gestures) what = 'gest';
      else if (full && this.toy && this.toyHeld && this.toyKind === 'bone' && ['offer', 'return'].includes(this.state) && this._hit(e, [this.toyHit, this.proxy])) what = 'tug';
      else if (full && this.toy && this.toyKind === 'wand' && this._hit(e, [this.toyHit])) what = 'wand';
      else if (full && this.toy && !this.toyHeld && this.toyKind !== 'wand' && this._hit(e, [this.toyHit])) what = 'toy';
      else if (full && this._hit(e, [this.foodBowl.userData.hit])) what = 'food';
      else if (full && this._hit(e, [this.waterBowl.userData.hit])) what = 'water';
      else if (this._hit(e, [this.proxy])) what = 'pet';
      else if (full && this.toyKind === 'laser') what = 'laser';
      else if (full && this.toyKind === 'wand' && this.toy) what = 'wand';
      // поки гра з чашками сама веде тварину — дотики до неї й мисок не збивають гру
      if (this.cups && ['pet', 'food', 'water'].includes(what) && (this.target || !['guess', 'hide', 'mix', 'show-me'].includes(this.cups.phase))) what = 'empty';
      d = { x: e.clientX, y: e.clientY, t0: performance.now(), what, moved: false, rot: this.world.rotation.y, hist: [], pts: [{ x: e.clientX, y: e.clientY }] };
      if (what === 'pet') { const h = this._hit(e, [this.proxy]); d.hy = h ? this.actor.worldToLocal(h.point.clone()).y / (this.size || 1) : 0; d.hx = h ? h.point.x : 0; }
      if (what === 'laser') { const p = this._floor(e); if (p) { this.dot.visible = true; this.dot.position.copy(this.world.worldToLocal(p)).setY(0.01); this.state = 'laser'; this.play('crouch'); } }
      if (what === 'wand') { this.wand.held = false; this._wandTo(e); }
      if (what === 'tug') this._tugStart();
      if (what === 'gest') { const dd = d; this._tr = null; this._trailPush(e); dd.holdT = setTimeout(() => { if (d === dd && !dd.moved) { dd.fired = true; this._gesture('sit'); } }, 520); }
      try { cv.setPointerCapture(e.pointerId); } catch (_) { }
      if (what === 'toy') { this._stop(); this.toyV.set(0, 0, 0); this.toyDrag = true; }
    });
    cv.addEventListener('pointermove', (e) => {
      const r = cv.getBoundingClientRect(); if (r.width) { this.look.set(((e.clientX - r.left) / r.width - 0.5) * 2, ((e.clientY - r.top) / r.height - 0.5) * 2); this.lookW = 1; }
      if (!d) return;
      const dx = e.clientX - d.x, dy = e.clientY - d.y;
      if (!d.moved && Math.hypot(dx, dy) > 7) d.moved = true;
      if (d.what === 'cups') { this.cups.move(e); return; }
      if (d.what === 'gest') { d.pts.push({ x: e.clientX, y: e.clientY }); this._trailPush(e); return; }
      if (d.what === 'laser') { const p = this._floor(e); if (p) { const lp = this.world.worldToLocal(p); if (lp.length() > 1.6) lp.setLength(1.6); this.dot.position.set(lp.x, 0.01, lp.z); } return; }
      if (d.what === 'wand') { this._wandTo(e); return; }
      if (d.what === 'tug') { if (this._tugMove(e)) { d.what = 'toy'; d.moved = true; d.hist = []; this.toyDrag = true; } return; }
      if (!d.moved) return;
      if (d.what === 'toy') { const p = this._floor(e); if (!p) return; const lp = this.world.worldToLocal(p.clone()); if (lp.length() > 1.55) lp.setLength(1.55); this.toy.position.set(lp.x, this.toyKind === 'fly' ? 0.5 : 0.16, lp.z); d.hist.push({ p: lp.clone().setY(0), t: performance.now() }); if (d.hist.length > 6) d.hist.shift(); }
      else if (d.what === 'pet') {
        if (this._hit(e, [this.proxy])) {
          this.stroke += Math.hypot(e.movementX || 0, e.movementY || 0) || 4; this.strokeDir = Math.sign(dx) || 1;
          if (this.state !== 'stroke') { this._stop(); this.state = 'stroke'; this.play(this.proc ? 'purr' : (this.acts && this.acts.idle2 ? 'idle2' : 'idle')); this._v('pet', 2.1); }
          if (this.stroke > 140) { this.stroke = 0; this._need('joy', 4); if (this.onHappy) this.onHappy('stroke'); this._v('pet', 2.1); if (this.awaitReward > 0) { this._learn(this.lastCmd, 0.5); this.awaitReward = 0; if (this.onSay) this.onSay('learned'); } }
        }
      } else if (this.mode === 'full') { if (!this.cups && this.toyKind !== 'wand') this.world.rotation.y = d.rot + dx * 0.01; }
      else this.actor.rotation.y = d.rot + dx * 0.012;
    });
    const end = (e) => {
      if (!d) return; const dd = d; d = null; this.toyDrag = false;
      if (dd.what === 'cups') { if (this.cups) this.cups.up(e, dd.moved); return; }
      if (dd.what === 'gest') { clearTimeout(dd.holdT); if (this._tr) this._tr.live = false; if (!dd.fired) this._classify(dd); return; }
      if (dd.what === 'wand') { if (this.wand) this.wand.held = false; return; }
      if (dd.what === 'tug') { this._tugEnd(); return; }
      if (dd.what === 'laser') { setTimeout(() => { this.dot.visible = false; if (this.state === 'laser') { this.state = 'idle'; this.play('idle'); } }, 700); return; }
      if (dd.what === 'food' || dd.what === 'water') { if (!dd.moved) this.fillBowl(dd.what); return; }
      if (!dd.moved) {
        if (dd.what === 'pet') { if (dd.hy > 0.62) this.play(dd.hx < 0 ? 'reactL' : 'reactR', { once: true }); else this.play('jump', { once: true }); this._need('joy', 2); if (Math.random() < 0.6) this._v('hello'); if (this.onTap) this.onTap(); }
        else if (dd.what === 'toy' && this.toy) { const fwd = this.toy.position.clone().sub(this.actor.position).setY(0).normalize(); this.toyV.set(fwd.x * 1.6, 1.2, fwd.z * 1.6); this._s('catchIt'); }
        return;
      }
      if (dd.what === 'toy' && this.toy) {
        // кидок: швидкість пальця по підлозі → політ дугою; повільно відпустив — просто поклав
        const h = dd.hist; let sp = 0;
        if (h.length >= 2) { const a = h[0], b = h[h.length - 1]; const t = Math.max(16, b.t - a.t) / 1000; const vel = b.p.clone().sub(a.p).divideScalar(t); if (vel.length() > 5.5) vel.setLength(5.5); sp = vel.length(); this.toyV.set(vel.x, 0, vel.z); }
        if (this.toyKind !== 'fly') this.toyV.y = sp > 0.8 ? Math.min(5.2, 1.4 + sp * 0.7) : 0;
        if (sp > 0.8) this._s('throwIt');
      } else if (dd.what === 'pet' && this.state === 'stroke') { this.state = 'idle'; this.play('idle'); }
    };
    cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end); cv.addEventListener('pointerleave', () => { this.lookW = 0; });
  }

  /* ---------- кадр ---------- */
  _loop() {
    requestAnimationFrame(() => this._loop());
    if (!this.canvas.isConnected || document.hidden || this._vis === false) return;
    const now = performance.now();
    if (!this._lim(now)) return;                 // ліміт кадрів (30 к/с замість 60–120): улюбленцю цього досить
 const dt = Math.min((now - this._t0) / 1000, 0.05); this._t0 = now; const tt = now / 1000;
    const resting = this.state === 'idle' && (this.pose === 'sleep' || this.pose === 'lie');
    this._need('food', -0.035 * dt); this._need('water', -0.045 * dt); this._need('joy', -0.025 * dt);
    this._need('energy', (resting ? 0.6 : this.state === 'idle' ? 0.06 : ['run', 'fetch', 'laser', 'wand', 'tug'].includes(this.state) ? -0.5 : -0.05) * dt);
    if ((this._nt = (this._nt || 0) + dt) > 1) { this._nt = 0; if (this.onNeeds) this.onNeeds(this.needs); }
    this.awaitReward = Math.max(0, this.awaitReward - dt);
    if (this.head && this._hqi && !this.proc) this.head.quaternion.multiply(this._hqi);
    if (this.mixer) this.mixer.update(dt);
    if (this.proc) this.proc.update(dt);
    const full = this.mode === 'full', pos = this.actor.position;
    // поза тіла для моделей без потрібних кліпів
    if (!this.proc) {
      const tgt = { sit: [-0.3, -0.06], lie: [0, -0.22], sleep: [0, -0.22], crouch: [0.1, -0.1], drink: [0.22, -0.04], eat: [0.12, 0], sniff: [0.16, -0.02], tug: [-0.2, -0.05] }[this.pose] || [0, 0];
      this.body.rotation.x += (tgt[0] - this.body.rotation.x) * Math.min(1, dt * 6);
      this.body.position.y += (tgt[1] * (this.size || 1) - this.body.position.y) * Math.min(1, dt * 6);
    }
    if (this.spin > 0) { this.spin -= dt; this.actor.rotation.y += dt * Math.PI * 2 / 1.1 * (this.spinDir || 1); }
    // миски: рівень плавно наздоганяє, корм падає, вода ллється
    const sf = this.shown;
    for (const k of ['food', 'water']) { const want = this.bowls[k]; if (Math.abs(sf[k] - want) > 0.002) { sf[k] += (want - sf[k]) * Math.min(1, dt * (k === 'water' && this._pour > 0 ? 2.2 : 8)); this._bowlLook(); } }
    for (const k of this.kibble.children) if (k.userData.fall > 0) { k.userData.fv += 7 * dt; k.userData.fall = Math.max(0, k.userData.fall - k.userData.fv * dt); k.position.y = k.userData.y + k.userData.fall; }
    if (this._pour > 0) { this._pour -= dt; this.stream.visible = full; const wf = this.waterBowl.userData.fill; this.stream.position.set(this.waterBowl.position.x, 0.38, this.waterBowl.position.z); this.stream.scale.y = 1 + Math.sin(tt * 40) * 0.03; if (Math.random() < dt * 12) this._ripple(); void wf; } else this.stream.visible = false;
    if (this.meal && (this.state === 'eat' || this.state === 'drink')) this._meal(dt); else if (this.meal && this.state !== 'walk') this.meal = null;
    this._fxTick(dt); for (const f of this.fx) if (f.tick) f.tick(dt);
    // м'яч / кістка / клубок / муха: справжній політ дугою, відскоки, тертя
    if (full && this.toy && !this.toyHeld && !this.toyDrag && this.toyKind !== 'wand') {
      const v = this.toyV, fly = this.toyKind === 'fly', T = this.toy.position;
      if (fly) { if (v.lengthSq() < 0.01) T.set(Math.cos(tt * 0.9) * 0.9, 0.45 + Math.sin(tt * 2.3) * 0.12, Math.sin(tt * 1.3) * 0.7); this.toy.children.forEach((c) => { if (c.name === 'wing') c.rotation.y = Math.sin(tt * 60) * 0.6; }); }
      const air = !fly && T.y > 0.001;
      if (v.lengthSq() > 1e-4 || air) {
        if (!fly) v.y -= 12 * dt;
        T.addScaledVector(v, dt);
        if (!fly && T.y <= 0) { T.y = 0; if (v.y < -1.4) { v.y = -v.y * (this.toyKind === 'ball' ? 0.55 : 0.25); v.x *= 0.82; v.z *= 0.82; this._s('bounce', Math.min(1, v.y / 2.5)); } else v.y = 0; if (this.toyKind === 'bone') this.toy.rotation.x *= 0.5; }
        const rr = Math.hypot(T.x, T.z), lim = 1.55;
        if (rr > lim) { const n = V(T.x, 0, T.z).normalize(); const vn = v.x * n.x + v.z * n.z; if (vn > 0) { v.x -= 2 * vn * n.x; v.z -= 2 * vn * n.z; v.x *= 0.7; v.z *= 0.7; this._s('bounce', Math.min(0.6, vn / 4)); } T.x = n.x * lim; T.z = n.z * lim; }
        const hs = Math.hypot(v.x, v.z);
        if (this.toyKind === 'ball' || this.toyKind === 'yarn') { if (hs > 1e-3) { const ax = V(v.z, 0, -v.x).normalize(); this.toy.rotateOnWorldAxis(ax, hs * dt / (this.toy.userData.r || 0.1)); } }
        else if (this.toyKind === 'bone' && T.y > 0.01) this.toy.rotation.x += dt * 10; else this.toy.rotation.y += hs * dt * 3;
        if (!air || fly) { const f = Math.max(0, 1 - (fly ? 0.9 : 1.5) * dt); v.x *= f; v.z *= f; } else { v.x *= 1 - 0.05 * dt; v.z *= 1 - 0.05 * dt; }
        if (!air && !fly && Math.hypot(v.x, v.z) < 0.05 && Math.abs(v.y) < 0.01) v.set(0, 0, 0);
        if ((hs > 0.7 || T.y > 0.3) && !['fetch', 'return', 'eat', 'drink', 'cmd', 'tug', 'offer'].includes(this.state) && this.needs.energy > 8 && !this.cups) { this.state = 'fetch'; this.play('run', { speed: 1.1 }); }
      }
    }
    // вудочка з пером (для котів): перо гойдається; кіт полює за висотою й швидкістю пера
    if (full && this.toyKind === 'wand' && this.toy && this.wand) {
      const W = this.wand, F = this.toy.position;
      if (!W.held) { F.addScaledVector(W.v, dt); W.v.multiplyScalar(Math.max(0, 1 - 3 * dt)); if (W.caught <= 0) F.y = Math.max(0.05, F.y - 0.05 * dt); }
      const sp = W.held ? W.v.length() : W.v.length() * 0.5; if (W.held) W.v.multiplyScalar(Math.max(0, 1 - 6 * dt));
      this.toy.rotation.z = Math.sin(tt * 3) * 0.15 - THREE.MathUtils.clamp(W.v.x * 0.15, -0.6, 0.6); this.toy.rotation.x = THREE.MathUtils.clamp(W.v.z * 0.1, -0.5, 0.5);
      W.cool -= dt;
      if (!this.gestures && !this.target && !['eat', 'drink', 'cmd', 'stroke'].includes(this.state) && this.needs.energy > 6) {
        const dx = F.x - pos.x, dz = F.z - pos.z, d = Math.hypot(dx, dz), h = F.y, reach = (this.len || 1) * 0.55, tall = this.size || 1;
        this.lookAt = F; this.state = 'wand';
        if (W.caught > 0) { W.caught -= dt; F.copy(pos).addScaledVector(this._fwd(), reach * 0.85).setY(0.05); this._pose('pounce'); if (W.caught <= 0) { W.v.set((Math.random() - 0.5) * 2, 0, (Math.random() - 0.5) * 2); F.y = 0.45; this._pose('sit'); } }
        else if (d > reach * 1.35) { this._faceLocal(F, dt, 8); pos.addScaledVector(this._fwd(), Math.min(d - reach, (sp > 1 ? 2.3 : 0.9) * dt)); this._pose(sp > 1 ? 'run' : 'walk'); W.still = 0; }
        else {
          this._faceLocal(F, dt, 6);
          const catchIt = () => { W.caught = 1.3; W.cool = 1; this._need('joy', 7); this._v('play', 0.3); this._s('catchIt'); if (this.onHappy) this.onHappy('play'); };
          if (h > tall * 0.85) { this._pose('look'); W.still = 0; if (sp > 1.1 && h < tall * 1.6 && W.cool <= 0) { W.cool = 1.5; this.play('jump', { dur: 0.7, then: () => { this.pose = ''; } }); this._need('joy', 2); if (Math.random() < 0.4) setTimeout(catchIt, 380); } }
          else if (sp > 0.55) { W.still = 0; if (this.pose !== 'jump') this._pose('swat'); if (W.cool <= 0 && d < reach * 1.1) { W.cool = 0.55; this._need('joy', 1.2); this._s('catchIt', 0.5); if (Math.random() < 0.16) catchIt(); } }
          else { if (this.pose !== 'jump') this._pose('crouch'); W.still += dt; if (W.still > 1.7) { W.still = 0; this.play('pounce', { dur: 0.5 }); pos.addScaledVector(this._fwd(), reach * 0.4); catchIt(); } }
        }
      } else if (this.state === 'wand') this.state = 'idle';
    }
    if (this.cups) { if (full) this.cups.update(dt); }
    if (full && (this.mixer || this.proc)) {
      if (this.state === 'fetch' && this.toy) {
        const bp = this.toy.position, d = Math.hypot(bp.x - pos.x, bp.z - pos.z);
        this._faceLocal(bp, dt, 8);
        const fwd = this._fwd(), reach = (this.len || 1) * 0.45, tall = this.size || 1;
        if (d > reach) pos.addScaledVector(fwd, Math.min(d, 2.2 * dt));
        // ловить у повітрі: м'яч на висоті морди поруч — стрибок і хап
        const inAir = bp.y > 0.15 && bp.y < tall * 1.25 && this.toyV.y < 2.5 && d < reach * 1.4;
        if (inAir && this.toyKind !== 'yarn' && this.toyKind !== 'fly') { this.play('jump', { once: !this.proc, dur: this.proc ? 0.6 : 0 }); this._s('catchIt'); this._need('joy', 6); if (this.onSay) this.onSay('caught'); this._grab(); }
        else if (d <= reach && bp.y < 0.06 && Math.hypot(this.toyV.x, this.toyV.z) < 0.7) {
          this._need('joy', 9); this._need('energy', -3);
          if (this.toyKind === 'yarn' || this.toyKind === 'fly') {
            // кіт б'є лапою клубок; жаба ловить муху — не приносять назад
            this.state = 'idle'; this.play(this.toyKind === 'fly' ? 'jump' : 'pounce', { dur: 0.6, then: () => this._backToIdle() });
            this.toyV.set((Math.random() - 0.5) * 3, this.toyKind === 'yarn' ? 1.2 : 0, (Math.random() - 0.5) * 3); if (this.onHappy) this.onHappy('play'); if (this.toyKind === 'fly') this._v('hello'); else this._s('catchIt');
          } else this._grab();
        }
      }
      if (this.state === 'laser' && this.dot.visible) {
        const dp = this.dot.position, d = Math.hypot(dp.x - pos.x, dp.z - pos.z);
        this._faceLocal(dp, dt, 10);
        const fwd = this._fwd();
        if (d > this.len * 0.35) { pos.addScaledVector(fwd, Math.min(d, 2.4 * dt)); if (this.proc && this.proc.state !== 'run') this.proc.set('run'); else if (!this.proc) this._pose('run'); }
        else { if (this.proc && this.proc.state !== 'pounce') { this.proc.set('pounce'); this._need('joy', 2); } else if (!this.proc) this._pose('crouch'); }
        this.dotGlow.intensity = 1.5;
      }
      if (this.target && ['walk', 'run', 'return'].includes(this.state)) {
        const tl = this.world.worldToLocal(this.target.clone()), d = Math.hypot(tl.x - pos.x, tl.z - pos.z);
        this._face(this.target, dt, 7);
        if (this.state === 'return' && this.pose !== 'walk') this.play('walk');
        if (d > 0.08) pos.addScaledVector(this._fwd(), Math.min(d, (this.running ? 2 : 0.8) * dt));
        else { const cb = this.onArrive; this.target = null; this.onArrive = null; this.state = 'idle'; this.play('idle'); if (cb) cb(); }
      }
      if (this.state === 'tug' && this.tug) {
        const T = this.tug; T.t += dt; T.g -= dt;
        if (T.f) this._faceLocal(T.f, dt, 5);
        pos.addScaledVector(this._fwd(), -Math.sin(T.t * 9) * 0.35 * dt);
        this.actor.rotation.y += Math.sin(T.t * 15) * 0.9 * dt;
        if (T.g <= 0) { T.g = 0.8 + Math.random() * 0.5; this._v('tug', 0.3); }
      }
      if (this.state === 'offer' && now > (this.offerUntil || 0)) this._dropToy();
      if (this._faceCam) { const lp = this.world.worldToLocal(this.camera.position.clone()); this._faceLocal(lp, dt, 4); const want = Math.atan2(lp.x - pos.x, lp.z - pos.z); if (Math.abs(Math.atan2(Math.sin(want - this.actor.rotation.y), Math.cos(want - this.actor.rotation.y))) < 0.05) this._faceCam = false; }
      // самостійне життя: голод, спрага, сон, прогулянка
      if (this.state === 'idle' && !this.cups && this.toyKind !== 'wand' && (now - this.lastAct) / 1000 > this.nextWander) {
        this.lastAct = now; this.nextWander = 7 + Math.random() * 7;
        if (this.needs.food < 35 && this.bowls.food > 0.05) this._goEat('food');
        else if (this.needs.water < 35 && this.bowls.water > 0.05) this._goEat('water');
        else if (this.needs.food < 35 || this.needs.water < 35) { this._faceCam = true; this._v('ask', 3); if (this.onSay) this.onSay(this.needs.food < this.needs.water ? 'hungry' : 'thirsty'); }
        else if (this.needs.energy < 15) this.play('sleep');
        else if (Math.random() < 0.55) { const a = Math.random() * Math.PI * 2, r = 0.3 + Math.random() * 0.9; this._goto(this.world.localToWorld(V(Math.cos(a) * r, 0, Math.sin(a) * r)), false, () => { this._faceCam = true; }); }
        else this.play(this.proc ? (Math.random() < 0.5 ? 'groom' : 'sit') : (this.acts && this.acts.idle2 ? 'idle2' : 'idle'), { dur: 4 });
      }
      if (this.pose === 'sleep' && this.state === 'idle' && (this._zz = (this._zz || 0) + dt) > 4.5) { this._zz = 0; this._s('snore'); }
      if (this.toyHeld && this.toy) { this.toy.position.copy(this.world.worldToLocal(this._mouth())).setY(Math.max(0.02, this.world.worldToLocal(this._mouth()).y - 0.08)); this.toy.rotation.set(0, this.actor.rotation.y, 0); }
      const R = Math.hypot(pos.x, pos.z); if (R > 1.45) { pos.x *= 1.45 / R; pos.z *= 1.45 / R; }
    }
    // погляд: голова стежить за пальцем, пером чи чашками
    const la = this.lookAt;
    if (this.head && !this.proc) {
      let ty = 0, tx = 0;
      if (la && full) { ty = THREE.MathUtils.clamp(Math.atan2(Math.sin(Math.atan2(la.x - pos.x, la.z - pos.z) - this.actor.rotation.y), Math.cos(Math.atan2(la.x - pos.x, la.z - pos.z) - this.actor.rotation.y)), -0.8, 0.8) * 0.7; tx = -THREE.MathUtils.clamp(Math.atan2(la.y - (this.size || 1) * 0.75, Math.max(0.15, Math.hypot(la.x - pos.x, la.z - pos.z))), -0.5, 0.6) * 0.5; }
      else { const k = (this.state === 'idle' || this.state === 'stroke') ? this.lookW : 0; ty = THREE.MathUtils.clamp(this.look.x, -1, 1) * 0.5 * k; tx = THREE.MathUtils.clamp(this.look.y, -1, 1) * 0.25 * k; }
      this._ly = (this._ly || 0) + (ty - (this._ly || 0)) * Math.min(1, dt * 5);
      this._lx = (this._lx || 0) + (tx - (this._lx || 0)) * Math.min(1, dt * 5);
      // накладки на кліп: лакання (дрібно киває), нюхання (водить носом), перетягування (трусить головою)
      const ex = this.state === 'drink' ? Math.sin(tt * 22) * 0.07 : 0, ey = this.state === 'sniff' || this.pose === 'sniff' ? Math.sin(tt * 5) * 0.4 : this.state === 'tug' ? Math.sin(tt * 13) * 0.3 : 0;
      this._hq = new THREE.Quaternion().setFromEuler(new THREE.Euler(this._lx + ex, this._ly + ey, 0)); this._hqi = this._hq.clone().invert();
      this.head.quaternion.multiply(this._hq);
    } else if (this.proc && la && full && ['wand', 'idle', 'game'].includes(this.state) && !['eat', 'drink', 'sleep', 'lie'].includes(this.pose)) {
      const h = this.proc.head, yaw = Math.atan2(la.x - pos.x, la.z - pos.z) - this.actor.rotation.y;
      h.rotation.y += THREE.MathUtils.clamp(Math.atan2(Math.sin(yaw), Math.cos(yaw)), -0.8, 0.8) * 0.8;
      h.rotation.x -= THREE.MathUtils.clamp(Math.atan2(la.y - (this.size || 1) * 0.7, Math.max(0.15, Math.hypot(la.x - pos.x, la.z - pos.z))), -0.6, 0.8) * 0.7;
    }
    if (!this.proc) this.body.rotation.z += ((this.state === 'stroke' ? Math.sin(now / 180) * 0.05 * (this.strokeDir || 1) : 0) - this.body.rotation.z) * Math.min(1, dt * 6);
    if (this._hatPop) { const P = this._hatPop; P.t += dt; const k = Math.min(1, P.t / 0.35), e = 1 + 2.2 * Math.pow(k - 1, 3) + 1.2 * Math.pow(k - 1, 2); P.h.scale.setScalar(P.s * Math.max(0.01, e)); if (k >= 1) { P.h.scale.setScalar(P.s); this._hatPop = null; } }
    if (this.cups && full && Math.abs(this.world.rotation.y) > 0.001) this.world.rotation.y *= Math.max(0, 1 - dt * 5);
    this._trailDraw(dt);
    this.renderer.render(this.scene, this.camera);
  }
  _grab() {
    this.toyHeld = true; this.toyV.set(0, 0, 0); this.state = 'return';
    this._goto(this.world.localToWorld(V(0, 0, 0.2)), false, () => {
      this._faceCam = true;
      if (this.toyKind === 'bone' && !this.proc) { this.state = 'offer'; this.offerUntil = performance.now() + 3800; this.play('idle'); if (this.onSay) this.onSay('tug_offer'); }
      else { this._dropToy(); this.play('jump', { once: !this.proc, dur: this.proc ? 0.7 : 0 }); this._v('happy'); }
      if (this.onHappy) this.onHappy('play');
    });
    this.state = 'return';
  }
}
