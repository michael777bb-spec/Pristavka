# Planetar

Ігрова приставка в браузері для дітей: улюбленець, головоломки, 3D-ігри (Ферма, Іскра, Біт, Історії),
кімнати з друзями, Telegram-бот і ШІ. Українська, English, русский. Працює без інтернету.
Сервер — Cloudflare (безкоштовний тариф).

- **Запустити з планшета, підключити бота й ШІ:** [docs/ІНСТРУКЦІЯ.md](docs/ІНСТРУКЦІЯ.md)
- **Працювати над проєктом зі своїм Claude:** [docs/ЯК-ПРАЦЮВАТИ-З-CLAUDE.md](docs/ЯК-ПРАЦЮВАТИ-З-CLAUDE.md) і [CLAUDE.md](CLAUDE.md)
- Варіант із GitHub (з iPad або ПК): [docs/ВАРІАНТ-GITHUB.md](docs/ВАРІАНТ-GITHUB.md) · Налаштування без перезаливу: [docs/НАЛАШТУВАННЯ.md](docs/НАЛАШТУВАННЯ.md)
- Бот і ШІ — [docs/BOT_AI.md](docs/BOT_AI.md) · Ігри — [docs/GAMES.md](docs/GAMES.md) · Звук — [docs/SOUND.md](docs/SOUND.md)
- Що далі — [docs/ROADMAP.md](docs/ROADMAP.md) · Усі побажання — [docs/WISHES.md](docs/WISHES.md)
- Перевірки — [tools/tests/README.md](tools/tests/README.md)

```
console/   приставка (/play/)        server/   сервер і бот        site/   лендинг
build.mjs  збирання (або tools/build.py)  → public/ і planetar-site.zip (для Cloudflare з планшета)
docs/      інструкції               wrangler.toml   лише для варіанта GitHub
```
