// Pristavka — повний офлайн. Під час встановлення завантажуємо ВСІ файли приставки
// (код, ігри, моделі, шрифти, картинки), тож після першого відкриття з інтернетом
// усе працює й без нього: улюбленець, головоломки, ігри, бот-суперники.
// Без інтернету не працюють лише онлайн-кімнати, рейтинг і ШІ на сервері.
//
// Кожен файл зберігається під ключем «шлях?h=відбиток вмісту». Після оновлення сайту
// докачуються лише змінені файли, а старі прибираються.
const BUILD = '__BUILD__';
const FILES = __MANIFEST__; // { 'js/app.js': 'a1b2c3d4e5', ... } — відносно /play/
const STATIC = 'planetar-files';
const BASE = new URL('./', self.location).pathname; // /play/
const keyOf = (p) => BASE + p + '?h=' + FILES[p];
const SHELL = ['index.html', 'app.css', 'assets/fonts/fonts.css', 'js/app.js', 'js/i18n.js', 'js/kit.js', 'js/icons.js', 'js/pet.js', 'js/voice.js', 'js/petcups.js', 'js/catcrew.js', 'js/models.js', 'js/puzzles.js', 'js/stage.js', 'js/net.js', 'js/ai.js', 'lib/three.module.js', 'lib/three.core.js'];

// хостинг може переадресувати /play/index.html → /play/; переадресовану відповідь браузер
// не прийме для сторінки, тож зберігаємо «чисту» копію
const urlOf = (p) => (p === 'index.html' ? BASE : BASE + p);
async function clean(res) { return res.redirected ? new Response(await res.blob(), { status: res.status, statusText: res.statusText, headers: res.headers }) : res; }
async function grab(c, p) {
  const k = keyOf(p); if (await c.match(k)) return;
  const res = await fetch(urlOf(p), { cache: 'no-cache' }); if (res.ok) await c.put(k, await clean(res));
}
async function pool(list, n, fn) { let i = 0; await Promise.all(Array.from({ length: n }, async () => { while (i < list.length) { const p = list[i++]; try { await fn(p); } catch (_) { } } })); }

self.addEventListener('install', (e) => {
  e.waitUntil((async () => {
    const c = await caches.open(STATIC);
    await pool(SHELL.filter((p) => FILES[p]), 4, (p) => grab(c, p));            // спершу оболонка
    await pool(Object.keys(FILES).filter((p) => !SHELL.includes(p)), 4, (p) => grab(c, p)); // далі все інше
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keep = new Set(Object.keys(FILES).map((p) => new URL(keyOf(p), self.location).href));
    const c = await caches.open(STATIC);
    for (const r of await c.keys()) if (!keep.has(r.url)) await c.delete(r);
    for (const k of await caches.keys()) if (k !== STATIC && k.startsWith('planetar')) await caches.delete(k);
    await self.clients.claim();
    for (const cl of await self.clients.matchAll({ type: 'window' })) cl.postMessage({ t: 'sw-ready', build: BUILD });
  })());
});
self.addEventListener('message', (e) => { if (e.data === 'count') e.source && caches.open(STATIC).then((c) => c.keys()).then((ks) => e.source.postMessage({ t: 'sw-count', have: ks.length, total: Object.keys(FILES).length })); });
self.addEventListener('fetch', (e) => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin || !u.pathname.startsWith(BASE)) return;
  let p = decodeURIComponent(u.pathname.slice(BASE.length));
  if (r.mode === 'navigate' || p === '') p = p && FILES[p] ? p : 'index.html';
  if (!FILES[p]) return; // не наш файл — звичайна мережа
  e.respondWith((async () => {
    const c = await caches.open(STATIC), k = keyOf(p);
    const hit = await c.match(k); if (hit) return hit;
    try { const res = await clean(await fetch(r.mode === 'navigate' ? urlOf(p) : r)); if (res.ok) c.put(k, res.clone()); return res; }
    catch (err) { const any = await caches.match(BASE + p, { ignoreSearch: true }); if (any) return any; throw err; }
  })());
});
