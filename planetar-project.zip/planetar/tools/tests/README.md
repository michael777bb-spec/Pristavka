# Перевірки Pristavka на своєму компʼютері

Потрібно: **Node.js 18+**, **Python 3.10+**, а для перевірок у браузері — Playwright:
```
pip install playwright
python3 -m playwright install chromium
```

## 1. Локальний сервер (без справжнього Telegram і ШІ)
У корені проєкту:
```
npm install
```
Створи файл `.dev.vars` (він уже в `.gitignore`, у GitHub не потрапить):
```
TG_TOKEN=test-token
ADMIN_KEY=test-admin
TG_API=http://127.0.0.1:9911
AI_MOCK=1
```
⚠️ Тут лише **перевірочні** значення. Справжній токен бота й ключі сюди не пиши ніколи.

Запусти (кожне — в окремому вікні терміналу):
```
cd tools/tests && python3 tg_mock.py          # підробний Telegram
npm run build && npx wrangler dev -c wrangler.test.toml --port 8788 --test-scheduled
```
`wrangler.test.toml` — копія `wrangler.toml` без ШІ Cloudflare (для нього треба входити в акаунт).
Приставка: http://localhost:8788/play/

**Варіант планшета (Cloudflare Pages)** — так само `.dev.vars` і `tg_mock.py`, а сервер:
```
node build.mjs && mkdir -p dist && cd dist && unzip -oq ../planetar-site.zip && cd ..
npx wrangler pages dev dist --port 8790 --d1 DB=planetar-db
```
Тоді всі перевірки — з `PRISTAVKA_URL=http://localhost:8790/play/`.

## 2. Перевірки
| Файл | Що перевіряє | Скільки триває |
|---|---|---|
| `bot_test.py` | 30 сценаріїв (обидва варіанти) бота й ШІ: команди, кнопки, привʼязка, улюбленець, безпека, групи, інлайн, виклики, нагадування | ~1 хв |
| `sync_test.py` | один прогрес на двох пристроях: посилання, перенесення, зміни в обидва боки, суперечка | ~1 хв |
| `farm_order_test.py` | Ферма: замовлення дотиком до вантажівки, підказка без товару | ~1 хв |
| `rooms_test.py` | кімнати з опитуванням (варіант планшета): ведучий, місця, старт, ходи, вихід, «мовчун» | ~20 с |
| `smoke_test.py` | усі екрани й ігри відкриваються без помилок; на телефоні й ПК нічого не прокручується | ~5–10 хв |
| `farm_service_test.py` | Ферма справжніми дотиками: болти, відро, каністри, ангар, поїздка в місто | ~10 хв |
| `sound_check.py` | кожен звук: без кліпінгу, чутно на телефоні, не різко | ~2 хв |

Запуск з папки `tools/tests`: `python3 bot_test.py` (поруч має працювати `tg_mock.py`), інші — так само.
Інша адреса сервера: `PRISTAVKA_URL=http://localhost:8788/play/ python3 smoke_test.py`.

Перевірки в браузері повільні: без відеокарти 3D малюється програмно (кадр — до секунди).
Тому в тестах прискорюють час (`d.warp(4)`) і зменшують якість (`d.lowres()`).

## 3. Налагоджувальні гачки
- `?dbg` в адресі приставки → `window.__pet` (улюбленець).
- У кожній грі: `document.querySelector('#cartRoot')._dbg` — стан і дії. Ферма: `S()`, `give(n)`, `stage(n)`, `buy(id)`,
  `hitch(a)`, `drop(id, x, z)`, `call('refuel','tractor')`, `needs(id)`, `att()`, `cityTrip()`, `tripLeft(s)`, `look(x, z, d)`, `pos(kind, a)`.
