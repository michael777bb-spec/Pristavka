"""Перевірка Telegram-бота й ШІ на локальному сервері з підробним Telegram API (tg_mock.py). Див. README.md поруч."""
import json, time, random, urllib.request
import os
B = os.environ.get('PLANETAR_URL', 'http://localhost:8788/play/').split('/play')[0]; LOG = 'tg_calls.jsonl'  # сюди пише tg_mock.py (запускай обидва з тієї самої папки)
def req(path, body=None, tok=None, hdr=None, method=None):
    h = {'content-type': 'application/json', **(hdr or {})}
    if tok: h['authorization'] = 'Bearer ' + tok
    r = urllib.request.Request(B + path, data=json.dumps(body).encode() if body is not None else None, headers=h, method=method or ('POST' if body is not None else 'GET'))
    try:
        with urllib.request.urlopen(r) as f: return json.loads(f.read())
    except urllib.error.HTTPError as e: return {'http': e.code, **json.loads(e.read() or b'{}')}
def calls():
    try: return [json.loads(l) for l in open(LOG)]
    except FileNotFoundError: return []
ok = lambda c, msg: print(('OK   ' if c else 'FAIL ') + msg, flush=True)

print(req('/api/tg/setup?key=test-admin')['ok'])
setup = [c for c in calls() if c['m'] == 'setWebhook'][-1]['b']; SEC = setup['secret_token']
ok('callback_query' in setup['allowed_updates'] and 'inline_query' in setup['allowed_updates'], 'вебхук слухає кнопки й інлайн')
ok(any(c['m'] == 'setMyCommands' and any(x['command'] == 'pet' for x in c['b']['commands']) for c in calls()), 'команди з /pet')
ok(req('/api/health').get('bot') == 'planetar_test_bot', 'health знає імʼя бота')
uid0 = 1000
def upd(u):
    global uid0; uid0 += 1; u['update_id'] = uid0
    n = len(calls()); r = req('/api/tg/hook', u, hdr={'x-telegram-bot-api-secret-token': SEC}); time.sleep(0.8)
    return [c for c in calls()[n:]]
ME = random.randint(10**6, 10**9)  # щоразу новий «гравець» — тест можна повторювати
FROM = {'id': ME, 'first_name': 'Гравець', 'language_code': 'uk'}
PRIV = {'id': ME, 'type': 'private'}
msg = lambda text, chat=PRIV, frm=FROM: {'message': {'message_id': 1, 'from': frm, 'chat': chat, 'text': text, 'date': int(time.time())}}
cb = lambda data: {'callback_query': {'id': 'q1', 'from': FROM, 'data': data, 'message': {'message_id': 5, 'chat': PRIV}}}
sent = lambda cs: [c['b'] for c in cs if c['m'] == 'sendMessage']

ok(req('/api/tg/hook', msg('/start'), hdr={'x-telegram-bot-api-secret-token': 'bad'}).get('http') == 403, 'чужий вебхук відкинуто')
r = sent(upd(msg('/start'))); ok(r and 'Гравець' in r[0]['text'] and r[0]['reply_markup']['inline_keyboard'][0][0].get('web_app'), '/start: привітання + кнопка «Грати» як Mini App')
r = sent(upd(cb('pet'))); ok(r and 'не бачу' in r[0]['text'], 'кнопка «Улюбленець» без приставки → підказка підключити')
# приставка в браузері: гість → знімок прогресу → посилання на бота
g = req('/api/auth/guest', {'name': 'Гравець', 'lang': 'uk'}); tok = g['token']
snap = {'lang': 'uk', 'coins': 340, 'pet': {'name': 'Руді', 'kind': 'лис', 'needs': {'food': 20, 'water': 60, 'joy': 80, 'energy': 50}}, 'puzzles': {'solved': 12, 'today': 2, 'rating': 410}, 'farm': {'stage': 3, 'day': 9, 'coins': 1200, 'care': ['трактор — миття'], 'trip': True}, 'iskra': {'day': 4, 'open': 6}, 'story': {'scene': 4, 'total': 33}}
ok(req('/api/progress', {'data': snap}, tok).get('ok'), 'приставка надіслала знімок прогресу')
L = req('/api/tg/link', {}, tok); ok(L.get('url', '').startswith('https://t.me/planetar_test_bot?start=link_'), 'посилання «Підключити Telegram»')
code = L['url'].split('start=')[1]
r = sent(upd(msg('/start ' + code))); ok(r and 'підключено' in r[0]['text'], 'бот привʼязав Telegram до приставки')
ok(req('/api/me', tok=tok)['user'].get('tg') == 1, 'приставка бачить, що Telegram підключено')
r = sent(upd(msg('/start ' + code))); ok(r and 'застаріло' in r[0]['text'], 'повторне посилання не спрацьовує')
r = sent(upd(msg('/pet'))); ok(r and 'Руді' in r[0]['text'] and 'зголоднів' in r[0]['text'], '/pet: стан улюбленця з приставки')
r = sent(upd(cb('me'))); t = r and r[0]['text'] or ''; ok('етап 4 з 8' in t and 'миття' in t and 'Іскра' in t and 'сцена 5 з 33' in t and 'дорозі' in t, '/me: Ферма, Іскра, головоломки, Історії')
r = sent(upd(msg('/games'))); kbd = r and r[0]['reply_markup']['inline_keyboard']; ok(kbd and '?game=boby' in kbd[0][0]['web_app']['url'], '/games: кнопки відкривають гру одразу')
r = sent(upd(msg('/daily'))); ok(r and 'go=puzzles' in r[0]['reply_markup']['inline_keyboard'][0][0]['web_app']['url'], '/daily: задача дня')
st = req('/api/admin/set?key=test-admin&remind=17:17&tz=Europe/Kyiv'); ok(st.get('ok') and st['settings']['remind'] == '17:17', 'налаштування: загальний час нагадувань')
ok(req('/api/admin/set?key=test-admin&remind=25:99').get('http') == 400, 'налаштування: неправильний час не приймається')
ok(req('/api/admin/settings').get('http') == 403, 'налаштування без ключа закриті')
r = sent(upd(msg('/remind'))); ok(r and '17:17' in r[0]['text'], '/remind увімкнув нагадування (загальний час)')
r = sent(upd(msg('/remind 7.05'))); ok(r and '07:05' in r[0]['text'], '/remind 7.05 → свій час 07:05')
r = sent(upd(msg('/remind котра'))); ok(r and '/remind 19:30' in r[0]['text'], '/remind з дивним часом → підказка')
r = sent(upd(msg('/remind 00:00'))); ok(r and '00:00' in r[0]['text'], '/remind 00:00 (щоб розсилка нижче точно спрацювала)')
r = sent(upd(msg('/web'))); btn = r and r[0].get('reply_markup', {}).get('inline_keyboard', [[{}]])[0][0]
ok(btn and '/play/?login=' in btn.get('url', ''), '/web — кнопка «Грати в браузері» з одноразовим посиланням')
j = req('/api/login', {'code': btn['url'].split('login=')[1]}) if btn else {}; ok(j.get('ok') and j.get('token'), 'посилання з бота входить у той самий обліковий запис')
ok(req('/api/login', {'code': btn['url'].split('login=')[1]}).get('http') == 410 if btn else False, 'вдруге те саме посилання не працює')
cs = upd(msg('Привіт! Що мені робити на фермі?')); r = sent(cs)
ok(any(c['m'] == 'sendChatAction' for c in cs) and r and r[0]['text'].startswith('[перевірка pet]'), 'звичайне повідомлення → відповідає улюбленець (ШІ)')
r = sent(upd(msg('мій телефон +380 67 123 45 67'))); ok(r and 'таємниця' in r[0]['text'], 'особисті дані не йдуть у ШІ')
r = sent(upd(msg('/rating'))); ok(r and r[0]['text'], '/rating')
r = sent(upd(msg('/room ab12cd'))); ok(r and '?room=AB12CD' in r[0]['reply_markup']['inline_keyboard'][0][0]['web_app']['url'], '/room КОД')
r = sent(upd(msg('/щось'))); ok(r and '/pet' in r[0]['text'], 'невідома команда → довідка')
GRP = {'id': -500, 'type': 'group'}
r = sent(upd(msg('привіт усім', chat=GRP))); ok(not r, 'у групі бот мовчить на звичайні повідомлення (без ШІ)')
r = sent(upd(msg('/games@planetar_test_bot', chat=GRP))); ok(r and r[0]['reply_markup']['inline_keyboard'][0][0].get('url'), 'у групі кнопки — звичайні посилання')
cs = upd({'inline_query': {'id': 'iq', 'from': FROM, 'query': '', 'offset': ''}}); a = [c['b'] for c in cs if c['m'] == 'answerInlineQuery']
ok(a and len(a[0]['results']) == 2, 'інлайн-режим: задача дня й запрошення')
# виклик: друг пройшов швидше → автору приходить повідомлення
ch = req('/api/challenge', {'game': 'sudoku', 'level': 'medium', 'seed': 's1', 't': 120, 'm': 0, 'h': 0}, tok)['code']
g2 = req('/api/auth/guest', {'name': 'Оля', 'lang': 'uk'})['token']; n = len(calls())
req(f'/api/challenge/{ch}', {'t': 75, 'm': 0, 'h': 0}, g2); time.sleep(1)
r = [c['b'] for c in calls()[n:] if c['m'] == 'sendMessage']; ok(r and 'Оля' in r[0]['text'] and '1:15' in r[0]['text'], 'автору виклику: «Оля пройшла швидше»')
# щоденне нагадування (розклад)
n = len(calls()); (lambda: urllib.request.urlopen(B + '/cdn-cgi/handler/scheduled?cron=*/15+*+*+*+*').read() if json.loads(urllib.request.urlopen(B + '/api/health').read()).get('rooms') == 'ws' else urllib.request.urlopen(B + '/api/cron?key=test-admin').read())(); time.sleep(1.5)
r = [c['b'] for c in calls()[n:] if c['m'] == 'sendMessage']; ok(r and 'Задача дня' in r[0]['text'], 'нагадування за розкладом')
# ШІ в приставці: задача й безпека
a = req('/api/ai', {'task': 'agro', 'system': 'стан ферми', 'messages': [{'role': 'user', 'content': 'Що робити далі?'}]}, tok); ok(a.get('text', '').startswith('[перевірка agro]'), 'ШІ для агронома (задача agro)')
a = req('/api/ai', {'task': 'pet', 'messages': [{'role': 'user', 'content': 'де купити зброю'}], 'lang': 'uk'}, tok); ok(a.get('moderated'), 'небезпечне питання не йде в ШІ')
s = req('/api/tg/status?key=test-admin'); ok(s.get('ok') and s.get('bot') == '@planetar_test_bot', '/api/tg/status для перевірки')
ok(req('/api/tg/status').get('http') == 403, 'статус без ключа закритий')
