"""Швидка перевірка всієї приставки: кожен екран і кожна гра відкриваються без помилок,
на телефоні (390×760) і ПК (1280×800) нічого не прокручується. Перед релізом — обовʼязково.
Запуск: python3 smoke_test.py  (сервер: npx wrangler dev -c wrangler.test.toml --port 8788)"""
import asyncio, os
from playwright.async_api import async_playwright
BASE = os.environ.get('PLANETAR_URL', 'http://localhost:8788/play/')
ROUTES = ['home', 'games', 'puzzles', 'pet', 'together', 'ai', 'settings']
GAMES = ['boby', 'iskra', 'bit', 'istorii']
async def main():
    bad = 0
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required'])
        for vw, vh in [(390, 760), (1280, 800)]:
            ctx = await b.new_context(viewport={'width': vw, 'height': vh}); pg = await ctx.new_page(); errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            await pg.add_init_script("localStorage.setItem('planetar:quality', JSON.stringify('off'));")
            await pg.goto(BASE); await pg.wait_for_timeout(2500)
            for r in ROUTES:
                await pg.evaluate(f"location.hash='#{r}'"); await pg.wait_for_timeout(900)
                over = await pg.evaluate("document.querySelector('#main').scrollHeight - document.querySelector('#main').clientHeight")
                if over > 4: print(f'FAIL {vw}px: екран {r} прокручується на {over}px'); bad += 1
            for g in GAMES:
                await pg.evaluate("location.hash='#games'"); await pg.wait_for_timeout(600)
                await pg.evaluate(f"document.querySelector('[data-act=openGame][data-arg={g}]').click()")
                try: await pg.wait_for_function("document.querySelector('#cartRoot') && document.querySelector('#cartRoot')._dbg", timeout=60000); print(f'OK   {vw}px: гра {g} відкрилась')
                except Exception: print(f'FAIL {vw}px: гра {g} не відкрилась — {await pg.evaluate("document.querySelector(`#cartRoot`).innerText")}'); bad += 1
                await pg.wait_for_timeout(1500)
                await pg.evaluate("document.querySelector('[data-act=closeGame]') && document.querySelector('[data-act=closeGame]').click()"); await pg.wait_for_timeout(600)
            for e in errs: print(f'FAIL {vw}px: помилка JS — {e[:200]}'); bad += 1
            await ctx.close()
        await b.close()
    print('ПІДСУМОК:', 'усе добре' if not bad else f'{bad} проблем')
asyncio.run(main())
