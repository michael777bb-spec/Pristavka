# Кімнати «з опитуванням» (варіант із планшета, Cloudflare Pages): двоє-троє гравців без браузера.
# Запуск: PLANETAR_URL=http://localhost:8790/play/ python3 rooms_test.py
import json, os, time, urllib.request, urllib.error

BASE = os.environ.get('PLANETAR_URL', 'http://localhost:8788/play/').split('/play')[0]
fails = 0
def ok(c, what):
    global fails
    print(('  ✓ ' if c else '  ✗ ') + what)
    if not c: fails += 1
def req(path, body=None, method=None):
    data = None if body is None else json.dumps(body).encode()
    r = urllib.request.Request(BASE + path, data=data, method=method or ('POST' if body is not None else 'GET'), headers={'content-type': 'application/json'})
    try:
        with urllib.request.urlopen(r) as f: return f.status, json.loads(f.read() or b'{}')
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read() or b'{}')

class P:
    def __init__(s, code, name): s.code, s.name, s.sid, s.after, s.out, s.got = code, name, None, 0, [{'t': 'hello', 'name': name}], []
    def poll(s):
        st, j = req(f'/api/rooms/{s.code}/poll', {'sid': s.sid, 'after': s.after, 'out': s.out}); s.out = []
        if st == 200: s.sid, s.after = j['sid'], j['last']; s.got += j['msgs']
        return st, j
    def last(s, t): return next((m for m in reversed(s.got) if m['t'] == t), None)

st, h = req('/api/health'); ok(st == 200 and h.get('rooms') == 'poll', f"сервер працює в режимі кімнат «poll» ({h.get('rooms')})")
if h.get('rooms') != 'poll': print('Цей сервер має Durable Objects — тест лише для варіанта з планшета.'); raise SystemExit(0)

st, r = req('/api/rooms/new', {'game': 'race', 'max': 2, 'bots': False}); code = r.get('code'); ok(st == 200 and code, 'ведучий створив кімнату ' + str(code))
A = P(code, 'Ведучий'); A.poll()
ok(A.last('you') and A.last('you')['seat'] == 0, 'ведучий отримав місце 0')
lob = A.last('lobby'); ok(lob and lob['host'] == 0 and lob['max'] == 2 and not lob['bots'], 'лобі: ведучий 0, двоє гравців, без ботів')
B = P(code, 'Друг<script>'); B.poll()
ok(B.last('you')['seat'] == 1, 'друг отримав місце 1')
ok(all(p['name'] != 'Друг<script>' for p in B.last('lobby')['players']), 'імʼя очищено від < >')
A.poll(); ok(len(A.last('lobby')['players']) == 2, 'ведучий бачить двох гравців')
st, _ = P(code, 'Третій').poll(); ok(st == 409, 'третій не влазить у кімнату на двох (409)')
st, info = req(f'/api/rooms/{code}/info'); ok(info.get('players') == 2 and info.get('max') == 2, 'інфо про кімнату: 2 з 2')

B.out = [{'t': 'max', 'n': 6}, {'t': 'start', 'data': {'x': 1}}, {'t': 'state', 'data': {'all': 1}}, {'t': 'move', 'data': {'bot': 0, 'p': 0.5}}]; B.poll(); A.poll()
ok(A.last('lobby')['max'] == 2 and not A.last('start'), 'не-ведучий не може міняти кімнату, стартувати чи слати повний стан і ходи ботів')
A.out = [{'t': 'max', 'n': 3}, {'t': 'start', 'data': {'type': 'sudoku', 'level': 1, 'seed': 7}}]; A.poll(); B.poll()
ok(B.last('start') and B.last('start')['data']['seed'] == 7, 'старт дійшов до друга з тим самим завданням')
ok(B.last('lobby')['max'] == 3 and B.last('lobby')['started'], 'ведучий змінив кількість місць до 3, гра почалась')
B.out = [{'t': 'move', 'data': {'p': 0.4}}, {'t': 'emote', 'e': '👍🏻👍🏻'}]; B.poll(); A.poll()
mv = A.last('move'); ok(mv and mv['from'] == 1 and mv['data']['p'] == 0.4 and mv['seq'] > 0, 'хід друга дійшов до ведучого з номером')
ok(A.last('emote') and len(A.last('emote')['e']) <= 4, 'емодзі обрізано до 4 символів')
C = P(code, 'Пізній'); C.poll()
ok(C.last('start') and C.last('start').get('late'), 'той, хто зайшов пізніше, отримав старт «late»')
ok(not C.last('move'), 'новенький не отримує старих ходів')
n0 = len(A.got); A.poll(); A.poll(); ok(not any(m['t'] == 'move' for m in A.got[n0:]), 'повідомлення не повторюються')

st, _ = req(f'/api/rooms/{code}/leave', {'sid': A.sid}); B.poll()
ok(B.last('lobby')['host'] == 1, 'ведучий вийшов — ведучим став друг')
st, j = A.poll(); ok(st == 410, 'вийшовший гравець отримує 410 і зупиняється')
print('  … чекаю 9 с, поки «мовчун» випаде з кімнати'); time.sleep(9); B.poll()
ok([p['seat'] for p in B.last('lobby')['players']] == [1], 'гравець, що мовчить 8 с, випадає з кімнати')
st, j = P('ZZZZ99', 'Хтось').poll(); ok(st == 200 and j['seat'] == 0, 'незнайомий код створює нову кімнату (як і з Durable Objects)')
st, _ = req('/api/cron'); ok(st == 403, 'будильник нагадувань без ключа — 403')
print('\nПомилок:', fails); raise SystemExit(1 if fails else 0)
