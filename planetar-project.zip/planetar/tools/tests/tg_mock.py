# Підробний Telegram Bot API: записує всі виклики бота в tg_calls.jsonl
import json, http.server
class H(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        n = int(self.headers.get('content-length') or 0); body = json.loads(self.rfile.read(n) or b'{}')
        method = self.path.rsplit('/', 1)[-1]
        open('tg_calls.jsonl', 'a').write(json.dumps({'m': method, 'b': body}, ensure_ascii=False) + '\n')
        res = {'getMe': {'id': 1, 'is_bot': True, 'username': 'planetar_test_bot'}, 'getWebhookInfo': {'url': 'http://x/api/tg/hook', 'pending_update_count': 0}}.get(method, True)
        if method == 'sendMessage': res = {'message_id': 1}
        out = json.dumps({'ok': True, 'result': res}).encode()
        self.send_response(200); self.send_header('content-type', 'application/json'); self.send_header('content-length', str(len(out))); self.end_headers(); self.wfile.write(out)
    def log_message(self, *a): pass
http.server.ThreadingHTTPServer(('127.0.0.1', 9911), H).serve_forever()
