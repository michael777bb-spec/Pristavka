"""Ферма: обслуговування техніки справжніми дотиками (болти, відро, каністри, ангар, поїздка в місто).
Запуск: python3 farm_service_test.py  (сервер: npx wrangler dev -c wrangler.test.toml --port 8788)"""
import asyncio, json, os
from playwright.async_api import async_playwright
D = "document.querySelector('#cartRoot')._dbg"
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required'])
        pg = await (await b.new_context(viewport={'width': 390, 'height': 760})).new_page(); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.add_init_script("localStorage.setItem('planetar:quality', JSON.stringify('off')); localStorage.removeItem('planetar:cart:boby:state3');")
        await pg.goto(os.environ.get('PLANETAR_URL', 'http://localhost:8788/play/') + '#games'); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('[data-act=openGame][data-arg=boby]').click()")
        await pg.wait_for_function("document.querySelector('#cartRoot') && document.querySelector('#cartRoot')._dbg", timeout=60000)
        E = lambda js: pg.evaluate(f"(()=>{{const d={D}, S=d.S(); {js}}})()")
        await E("d.start(); d.lowres(); d.give(20000); d.stage(1);"); await pg.wait_for_timeout(800)
        for sid in ['m_tractor', 'a_cultivator', 'b_fuel', 'b_hangar']: await E(f"d.buy('{sid}')")
        await pg.wait_for_timeout(1500)
        async def pos(kind, a): return await E(f"return d.pos('{kind}', {json.dumps(a)})")
        async def until(cond, n=60, step=700):
            for i in range(n):
                if await E(f"return !!({cond})"): return True
                await pg.wait_for_timeout(step)
            return False
        async def drag(a, b2, rub=0):
            await pg.mouse.move(a['x'], a['y']); await pg.mouse.down(); await pg.wait_for_timeout(120)
            steps = 8
            for i in range(1, steps + 1):
                await pg.mouse.move(a['x'] + (b2['x'] - a['x']) * i / steps, a['y'] + (b2['y'] - a['y']) * i / steps); await pg.wait_for_timeout(60)
            for k in range(rub):
                await pg.mouse.move(b2['x'] + (40 if k % 2 else -40), b2['y'] + (10 if k % 2 else -10)); await pg.wait_for_timeout(70)
            await pg.mouse.up(); await pg.wait_for_timeout(300)
        # 1) поломка: болти мають натискатися пальцем
        await E("S.forceBreak = true; d.warp(4); d.hitch('cultivator')")
        print('hitched', await until("S.m.tractor.att==='cultivator'"), flush=True)
        await E("d.drop('tractor', 11.4, 7.1)")
        print('broken', await until("S.m.tractor.broken", 80), 'att:', await E("return d.att()"), 'needs', await E("return d.needs('tractor')"), flush=True)
        await E("d.warp(1); const v = d.VH.tractor; d.look(v.g.position.x, v.g.position.z, 12)"); await pg.wait_for_timeout(2500)
        await pg.screenshot(path='/tmp/pp/svc_broken.png')
        for k in range(8):
            q = await E("const v = d.VH.tractor; const b = v.bolts.find((x) => !x.userData.fixing); if (!b) return v.bolts.length ? {wait: 1} : null; const _ = 0, w = b.getWorldPosition(b.position.clone()); const s = d.where(w), r = document.querySelector('#cartRoot').getBoundingClientRect(); return { x: s.x + r.left, y: s.y + r.top }")
            if not q: break
            if 'wait' in q: await pg.wait_for_timeout(1500); continue
            await pg.mouse.click(q['x'], q['y']); await pg.wait_for_timeout(1200)
        print('repaired by taps', await E("return !S.m.tractor.broken"), 'bolts left', await E("return d.VH.tractor.bolts.length"), flush=True)
        await E("d.VH.tractor.path = []; d.VH.tractor.job = null; d.go && 0"); await pg.wait_for_timeout(500)
        # 2) бруд: відро, потерти
        await E("d.warp(4); d.drop('tractor', 0.4, 0.6)"); print('to yard', await until("Math.hypot(d.VH.tractor.g.position.x-0.4, d.VH.tractor.g.position.z-0.6) < 0.5", 80), flush=True)
        await E("d.warp(1); S.m.tractor.dirt = 0.95; d.look(-1.0, 1.9, 15)"); await pg.wait_for_timeout(2500)
        print('dirty: needs', await E("return d.needs('tractor')"), 'coach', await E("return d.att()"), flush=True)
        await pg.screenshot(path='/tmp/pp/svc_dirty.png')
        a = await pos('xyz', [-2.4, 0.3, 3.0]); t = await pos('veh', 'tractor')
        await drag(a, t, rub=40)
        print('scrubbed dirt', await E("return +S.m.tractor.dirt.toFixed(2)"), 'wash cnt', await E("return S.cnt.wash||0"), flush=True)
        # 3) пальне скінчилось: каністра
        await E("S.m.tractor.fuel = 0"); await pg.wait_for_timeout(600)
        print('dry coach', await E("return d.att()"), flush=True)
        a = await pos('xyz', [-0.6, 0.3, 3.0]); t = await pos('veh', 'tractor')
        await drag(a, t)
        print('fuel after can', await E("return Math.round(S.m.tractor.fuel)"), flush=True)
        # 4) мастило
        await E("S.m.tractor.oil = 10"); await pg.wait_for_timeout(600)
        print('oil coach', await E("return d.att()"), flush=True)
        a = await pos('xyz', [-1.5, 0.3, 3.0]); t = await pos('veh', 'tractor')
        await drag(a, t)
        print('oil after', await E("return Math.round(S.m.tractor.oil)"), flush=True)
        # 5) знос: в ангар
        await E("S.m.tractor.wear = 92; S.m.tractor.fuel = 40"); await pg.wait_for_timeout(600)
        print('wear coach', await E("return d.att()"), flush=True)
        t = await pos('veh', 'tractor'); hg = await pos('xyz', [2.0, 0, -1.6]); print('hangar on screen', hg, flush=True)
        await drag(t, hg)
        await pg.wait_for_timeout(9000)
        print('wear after hangar', await E("return Math.round(S.m.tractor.wear)"), flush=True)
        # 6) у місто: зерно
        await E("d.stage(2); S.m.truck.load = 5; S.m.truck.crop = 'wheat'; S.m.truck.fuel = 60; d.warp(4); d.drop('truck', 5.5, 12.5)")
        print('truck near', await until("Math.hypot(d.VH.truck.g.position.x-5.5, d.VH.truck.g.position.z-12.5) < 0.6", 80), flush=True)
        await E("d.warp(1); d.look(6.5, 13.2, 13)"); await pg.wait_for_timeout(2500)
        c0 = await E("return Math.round(S.coins)")
        t = await pos('veh', 'truck'); cy = await pos('xyz', [7.9, 0, 14.6])
        print('truck', t, 'city', cy, flush=True)
        await drag(t, cy)
        print('trip', await until("S.trip", 60), await E("return JSON.stringify(S.trip)"), flush=True)
        await E("d.tripLeft(0.3)")
        print('back', await until("!S.trip && !S.m.truck.load", 40), 'earned', await E(f"return Math.round(S.coins) - {c0}"), flush=True)
        await pg.screenshot(path='/tmp/pp/svc_city.png')
        # 7) продукція в місто
        await E("S.goods.oil = 400; d.loadGoods('oil')"); print('goods', await E("return JSON.stringify(S.m.truck.goods)"), flush=True)
        await pg.wait_for_timeout(4000)
        await E("d.cityTrip()"); print('trip2', await until("S.trip", 60), flush=True); await E("d.tripLeft(0.2)")
        print('back2', await until("!S.trip && !S.m.truck.goods", 40), flush=True)
        print('errors', errs[:5])
        await b.close()
asyncio.run(main())
