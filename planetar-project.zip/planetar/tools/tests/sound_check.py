"""Перевірка звуку Planetar без динаміка.

Кожен звук і кожна петля рендеряться в OfflineAudioContext у Chromium (через js/sound.js,
разом із головним міксом: компресор, обмежувач), а тут міряються:
  peak    — пік, dBFS (має бути < -1: без кліпінгу)
  band    — гучність у «телефонній» смузі 300 Гц–5 кГц, dBFS (RMS активної частини)
  low     — частка енергії нижче 250 Гц (динамік телефона її не грає) — для разових звуків < 35 %
  harsh   — частка енергії 4–6 кГц (найбільш різка смуга на телефонах) — < 30 %
  dur     — тривалість до затухання нижче -50 dB
Запуск: python3 sound_check.py [--wav DIR]  (сервер: npx wrangler dev -c wrangler.test.toml --port 8788)
"""
import asyncio, json, sys, wave, os
import numpy as np
from playwright.async_api import async_playwright

SR = 44100
LOOPS = [
    ('engine idle', 'engine', {'size': 'tractor', 'rpm': 0, 'load': 0, 'vol': 1}),
    ('engine work', 'engine', {'size': 'tractor', 'rpm': 0.8, 'load': 1, 'vol': 1}),
    ('combine', 'engine', {'size': 'combine', 'rpm': 0.7, 'load': 0.8, 'vol': 1}),
    ('truck', 'engine', {'size': 'truck', 'rpm': 0.6, 'load': 0.3, 'vol': 1}),
    ('jeep', 'engine', {'size': 'jeep', 'rpm': 0.6, 'load': 0.3, 'vol': 1}),
    ('grain', 'grain', {'vol': 1}), ('spray', 'spray', {'vol': 1}), ('water', 'water', {'vol': 1}),
    ('hum', 'hum', {'vol': 1, 'rattle': 11}), ('rumble', 'rumble', {'vol': 1}),
    ('wind', 'wind', {'vol': 1, 'strength': 0.6}), ('rain', 'rain', {'vol': 1, 'intensity': 0.8}),
    ('birds', 'birds', {'vol': 1}), ('crickets', 'crickets', {'vol': 1, 'frogs': True}),
    ('city', 'city', {'vol': 1}), ('room', 'room', {'vol': 1, 'clock': True}), ('pad', 'pad', {'vol': 1}), ('pad tense', 'pad', {'vol': 1, 'tense': True}),
]

def spectrum_parts(x):
    X = np.abs(np.fft.rfft(x * np.hanning(len(x)))) ** 2
    f = np.fft.rfftfreq(len(x), 1 / SR)
    tot = X.sum() + 1e-20
    return (X[f < 250].sum() / tot, X[(f >= 4000) & (f < 6000)].sum() / tot,
            X[(f >= 300) & (f < 5000)].sum() / tot, (X * f).sum() / tot)

def analyse(L, Rr):
    x = (np.array(L) + np.array(Rr)) / 2
    pk = 20 * np.log10(max(np.abs(L).max(), np.abs(Rr).max()) + 1e-12)
    env = np.convolve(np.abs(x), np.ones(441) / 441, mode='same')
    act = env > env.max() * 10 ** (-50 / 20) if env.max() > 0 else np.zeros_like(env, bool)
    if not act.any(): return dict(peak=-200, band=-200, low=0, harsh=0, dur=0, cent=0)
    idx = np.where(act)[0]; seg = x[idx[0]:idx[-1] + 1]
    low, harsh, bandf, cent = spectrum_parts(seg)
    rms = np.sqrt(np.mean(seg ** 2) * bandf + 1e-20)
    return dict(peak=round(pk, 1), band=round(20 * np.log10(rms), 1), low=round(low * 100), harsh=round(harsh * 100), dur=round((idx[-1] - idx[0]) / SR, 2), cent=int(cent))

def save_wav(path, L, Rr):
    d = np.clip(np.stack([L, Rr], 1), -1, 1); d = (d * 32767).astype('<i2')
    with wave.open(path, 'wb') as w: w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(d.tobytes())

async def main():
    wav = sys.argv[sys.argv.index('--wav') + 1] if '--wav' in sys.argv else None
    if wav: os.makedirs(wav, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        base = os.environ.get('PLANETAR_URL', 'http://localhost:8788/play/')
        await pg.goto(base + 'js/sound.js')
        names = await pg.evaluate("import(location.href).then(m => m.SOUNDS)")
        rows = []
        for n in names:
            L, Rr = await pg.evaluate("(n) => import(location.href).then(m => m.renderOffline(({ sfx }) => sfx(n), 3))", n)
            rows.append(('one', n, analyse(L, Rr)));
            if wav: save_wav(f'{wav}/{n}.wav', L, Rr)
        for label, kind, o in LOOPS:
            L, Rr = await pg.evaluate("([k, o]) => import(location.href).then(m => m.renderOffline(({ loop }) => { const h = loop(k, o); for (let i = 0; i < 60; i++) h.tick(0.05); }, 3))", [kind, o])
            rows.append(('loop', label, analyse(L, Rr)))
            if wav: save_wav(f'{wav}/loop_{label.replace(" ", "_")}.wav', L, Rr)
        await b.close()
    bad = []
    print(f"{'тип':5} {'звук':14} {'пік':>6} {'смуга':>6} {'<250':>5} {'4-6k':>5} {'трив':>5} {'центр':>6}")
    for typ, n, r in rows:
        flag = []
        if r['peak'] > -1: flag.append('кліп')
        if r['band'] < -60: flag.append('тихо')
        if typ == 'one' and r['low'] > 35: flag.append('бас')
        if r['harsh'] > 30: flag.append('різко')
        if flag: bad.append((n, flag))
        print(f"{typ:5} {n:14} {r['peak']:6} {r['band']:6} {r['low']:5} {r['harsh']:5} {r['dur']:5} {r['cent']:6} {' '.join(flag)}")
    ui = [r['band'] for t, n, r in rows if t == 'one' and n in ('tap', 'pop', 'ok', 'bad', 'place', 'pencil', 'page', 'choose', 'toggle')]
    print('ui band spread', round(max(ui) - min(ui), 1))
    print('errors', errs[:3])
    print('ПРОБЛЕМИ:', bad if bad else 'немає')

asyncio.run(main())
