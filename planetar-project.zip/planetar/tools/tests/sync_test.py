# Один прогрес на всіх пристроях: вхід за одноразовим посиланням, перенесення прогресу, зміни в обидва боки, суперечка.
# Запуск: PLANETAR_URL=http://localhost:8788/play/ python3 sync_test.py  (потрібен сервер з базою). Посилання з бота (/web) — у bot_test.py
import asyncio, json, os, re, urllib.request
from playwright.async_api import async_playwright
U = os.environ.get('PLANETAR_URL', 'http://localhost:8788/play/'); BASE = U.split('/play')[0]
fails = 0
def ok(c, what):
    global fails
    print(('  ✓ ' if c else '  ✗ ') + what, flush=True)
    if not c: fails += 1

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader'])
        async def device():
            c = await b.new_context(viewport={'width': 390, 'height': 760}); pg = await c.new_page(); errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            await c.add_init_script("localStorage.setItem('planetar_seen','1')")
            return pg, errs
        async def LS(pg, k):  # сторінка може саме перезавантажуватись після отримання прогресу — пробуємо ще раз
            for i in range(20):
                try: return await pg.evaluate(f"localStorage.getItem('planetar:{k}')")
                except Exception: await pg.wait_for_timeout(500)
        async def until(pg, k, v, n=30):
            for i in range(n):
                if await LS(pg, k) == v: return True
                await pg.wait_for_timeout(500)
            return False
        # «згорнули застосунок»: так приставка віддає зміни
        sync = lambda pg: pg.evaluate("Object.defineProperty(document,'hidden',{value:true,configurable:true}); document.dispatchEvent(new Event('visibilitychange')); setTimeout(()=>{ delete document.hidden; }, 3000)")
        A, ea = await device()
        await A.goto(U); await A.wait_for_timeout(5000)
        # A грає: прогрес ферми й монети
        await A.evaluate("localStorage.setItem('planetar:cart:boby:state3', JSON.stringify({stage:5, coins:777})); localStorage.setItem('planetar:coins', '123'); localStorage.setItem('planetar:quality', '\"low\"')")
        await A.reload(); await A.wait_for_timeout(5000)
        tokA = await LS(A, 'token')
        j = await A.evaluate("fetch('/api/save',{headers:{authorization:'Bearer '+JSON.parse(localStorage.getItem('planetar:token'))}}).then(r=>r.json())")
        ok(j.get('data') and 'cart:boby:state3' in j['data'], 'прогрес пристрою A піднявся на сервер')
        ok('quality' not in (j.get('data') or ''), 'налаштування пристрою (якість графіки) лишились на пристрої')
        link = await A.evaluate("fetch('/api/login/new',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+JSON.parse(localStorage.getItem('planetar:token'))},body:'{}'}).then(r=>r.json())")
        ok(link.get('ok') and '?login=' in link.get('url', ''), 'посилання для іншого пристрою: ' + link.get('url', '?')[-30:])
        # B — новий пристрій відкриває посилання
        B, eb = await device()
        await B.goto(link['url']); await until(B, 'coins', '123'); await B.wait_for_timeout(3000)
        ok(json.loads(await LS(B, 'cart:boby:state3') or '{}').get('coins') == 777, 'на пристрої B той самий прогрес Ферми')
        ok(await LS(B, 'coins') == '123', 'і ті самі монети')
        ok('login=' not in B.url, 'код зник з адреси')
        await B.wait_for_load_state(); me = await B.evaluate("fetch('/api/me',{headers:{authorization:'Bearer '+JSON.parse(localStorage.getItem('planetar:token'))}}).then(r=>r.json())")
        meA = await A.evaluate("fetch('/api/me',{headers:{authorization:'Bearer '+JSON.parse(localStorage.getItem('planetar:token'))}}).then(r=>r.json())")
        ok(me['user']['id'] == meA['user']['id'], 'обидва пристрої — один обліковий запис')
        r = urllib.request.Request(BASE + '/api/login', data=json.dumps({'code': link['url'].split('login=')[1]}).encode(), headers={'content-type': 'application/json'}, method='POST')
        try: urllib.request.urlopen(r); second = 200
        except urllib.error.HTTPError as e: second = e.code
        ok(second == 200, 'посилання працює й удруге (спершу в Telegram, потім у Safari)')
        # B грає далі → A бачить
        await B.evaluate("localStorage.setItem('planetar:coins', '200')"); await sync(B); await B.wait_for_timeout(2500)
        await A.reload(); await until(A, 'coins', '200'); await A.wait_for_timeout(2000)
        ok(await LS(A, 'coins') == '200', 'зміни з B прийшли на A (A нічого не міняв)')
        # суперечка: обидва змінили — питаємо; погодились → беремо з хмари
        await A.evaluate("localStorage.setItem('planetar:coins', '300')"); await sync(A); await A.wait_for_timeout(2500)
        await B.evaluate("localStorage.setItem('planetar:coins', '999')")
        asked = []
        B.on('dialog', lambda d: (asked.append(d.message), asyncio.ensure_future(d.accept())))
        await B.reload(); await until(B, 'coins', '300'); await B.wait_for_timeout(2000)
        ok(asked and 'прогрес' in asked[0], 'при суперечці пристрій питає, що лишити')
        ok(await LS(B, 'coins') == '300', 'погодились — узяли прогрес з іншого пристрою')
        ok(not ea and not eb, 'без помилок на сторінках ' + str((ea + eb)[:2]))
        await b.close()
    print('\nПомилок:', fails); raise SystemExit(1 if fails else 0)
asyncio.run(main())
