# Ферма, замовлення: дотик до вантажівки замовлення віддає товар зі складу (навіть коли позаду табличка ділянки),
# без товару — підказка, де його зробити. Запуск: PLANETAR_URL=http://localhost:8788/play/ python3 farm_order_test.py
# Ферма: продукцію, яку тягнуть на вантажівку замовлення, отримує замовлення, навіть коли своя вантажівка стоїть поруч
import asyncio, json, os
from playwright.async_api import async_playwright
D = "document.querySelector('#cartRoot')._dbg"
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader'])
        pg = await (await b.new_context(viewport={'width': 390, 'height': 760})).new_page(); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.add_init_script("localStorage.setItem('planetar_seen','1');localStorage.setItem('planetar:quality', JSON.stringify('off')); localStorage.removeItem('planetar:cart:boby:state3');")
        await pg.goto(os.environ.get('PLANETAR_URL', 'http://localhost:8800/play/') + '?game=boby')
        await pg.wait_for_function(f"{D}", timeout=60000)
        E = lambda js: pg.evaluate(f"(()=>{{const d={D}, S=d.S(); {js}}})()")
        await E("d.start(); d.lowres(); d.give(50000); d.stage(5);"); await pg.wait_for_timeout(800)
        for sid in ['m_truck', 'b_barn', 'b_oilmill']: await E(f"d.buy('{sid}')")
        await pg.wait_for_timeout(1500)
        await E("d.start()"); await pg.wait_for_timeout(1500)
        print('splash still there:', await pg.evaluate("!!document.querySelector('#fSplash')"))
        print('built:', await E("return Object.keys(S.b).filter(k=>S.b[k]).join(',') + ' | veh: ' + Object.keys(d.VH).join(',')"))
        await E("S.goods.oil = 600; d.order('oil', 500);")
        await pg.wait_for_timeout(500)
        # своя вантажівка впритул до вантажівки замовлення
        await E("d.VH.truck.g.position.set(-4.7, 0, -2.0)"); await pg.wait_for_timeout(2500)
        print('truck at', await E("return d.veh('truck').p"), '| order truck exists', await E("return !!S.order"))
        await E("d.look(-7, -6.5, 20)"); await pg.wait_for_timeout(2500)
        async def drag(a, b2):
            await pg.mouse.move(a['x'], a['y']); await pg.mouse.down(); await pg.wait_for_timeout(150)
            for i in range(1, 11): await pg.mouse.move(a['x'] + (b2['x'] - a['x']) * i / 10, a['y'] + (b2['y'] - a['y']) * i / 10); await pg.wait_for_timeout(50)
            await pg.mouse.up(); await pg.wait_for_timeout(700)
        g, o, t = await E("return d.scr('good','oil')"), await E("return d.scr('order')"), await E("return d.scr('truck')")
        print('screen: pallet', g, 'order', o, 'truck', t)
        await pg.screenshot(path='/tmp/pp/order_before.png')
        await drag(g, o)  # перетягування (може не дістати — завод далеко)
        print('drag got:', await E("return S.order && S.order.got"))
        await E("d.look(-3.0, -5.4, 12)"); await pg.wait_for_timeout(2500)
        o = await E("return d.scr('order')"); print('order on screen:', o)
        await pg.screenshot(path='/tmp/pp/order_tap.png')
        print('pick at tap:', await E(f"return d.pickAt({o['x']}, {o['y']})"), '| carry/started:', await E("return d.carry()"))
        await pg.mouse.click(o['x'], o['y']); await pg.wait_for_timeout(800)
        await pg.evaluate("window.__taps=0; const r=document.querySelector('#cartRoot'); r.addEventListener('pointerup', ()=>window.__taps++, true)")
        await pg.mouse.click(o['x'], o['y']); await pg.wait_for_timeout(800)
        print('pointerups seen:', await pg.evaluate("window.__taps"), '| elem at point:', await pg.evaluate(f"(e=>e.tagName+'.'+e.className)(document.elementFromPoint({o['x']},{o['y']}))"))
        r = await E("return { got: S.order && S.order.got, oil: S.goods.oil, coins: S.coins }")
        print('after tap on order truck:', r)
        await E("d.call('deliverGood','oil')"); await pg.wait_for_timeout(300)
        print('direct deliverGood got:', await E("return S.order && S.order.got"))
        print('ORDER DELIVERED' if (r['got'] is None or r['got'] >= 500) else 'NOT DELIVERED', '| errors', errs[:3])
        # порожній склад: дотик показує підказку, де зробити
        await pg.wait_for_timeout(4000); await E("S.goods.oil = 0; d.order('oil', 300)"); await pg.wait_for_timeout(600)
        o = await E("return d.scr('order')"); await pg.mouse.click(o['x'], o['y']); await pg.wait_for_timeout(600)
        print('hint:', await pg.evaluate("[...document.querySelectorAll('.gsub')].map(e=>e.textContent).pop()"))
        await b.close()
asyncio.run(main())
