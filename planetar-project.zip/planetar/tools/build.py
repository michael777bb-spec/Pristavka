# Pristavka: те саме, що build.mjs, але на Python (якщо поруч немає Node.js). Запуск з кореня проєкту: python3 tools/build.py
# Робить public/ (site/ + console/ → /play/ + офлайн-перелік sw.js) і planetar-site.zip для Cloudflare Pages з планшета.
import hashlib, json, os, re, shutil, sys, zipfile, datetime
if not (os.path.isdir('console') and os.path.isdir('site')): sys.exit('Pristavka: запускай з кореня проєкту (де папки console/ і site/)')
OUT, PLAY = 'public', os.path.join('public', 'play')
shutil.rmtree(OUT, ignore_errors=True)
def walk(d): return sorted(os.path.join(r, f) for r, _, fs in os.walk(d) for f in fs)
def copy(src, dst, skip=lambda rel: False):
    n = 0
    for f in walk(src):
        rel = os.path.relpath(f, src).replace('\\', '/')
        if skip(rel): continue
        os.makedirs(os.path.dirname(os.path.join(dst, rel)), exist_ok=True); shutil.copy2(f, os.path.join(dst, rel)); n += 1
    return n
a = copy('site', OUT)
b = copy('console', PLAY, lambda rel: rel.endswith('.md') or rel == 'sw.js' or rel.startswith('_'))
files = {}
for f in walk(PLAY):
    rel = os.path.relpath(f, PLAY).replace('\\', '/')
    if rel == 'sw.js' or (rel.endswith('.txt') and 'LICENSE' not in rel): continue
    files[rel] = hashlib.sha1(open(f, 'rb').read()).hexdigest()[:10]
build = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
man = json.dumps(dict(sorted(files.items())), separators=(',', ':'), ensure_ascii=False)
open(os.path.join(PLAY, 'sw.js'), 'w', encoding='utf-8').write(open('tools/sw-template.js', encoding='utf-8').read().replace('__BUILD__', build, 1).replace('__MANIFEST__', man, 1))
print(f'Pristavka: сайт {a} файлів, приставка {b} файлів, офлайн {len(files)} файлів, збірка {build}')
worker = re.sub(r"^export \{ Room \} from '\./room\.js';\s*$", '// (на Pages кімнати без Durable Objects — див. roomPoll)', open('server/worker.js', encoding='utf-8').read(), flags=re.M)
if re.search(r"from '\./", worker): sys.exit('Pristavka: server/worker.js імпортує інші файли — для архіву планшета сервер має бути одним файлом')
routes = {'version': 1, 'include': ['/', '/en/', '/ru/', '/index.html', '/api/*', '/robots.txt', '/sitemap.xml'], 'exclude': []}
entries = [os.path.relpath(f, OUT).replace('\\', '/') for f in walk(OUT)]
if len(entries) + 2 > 1000: sys.exit(f'Pristavka: для завантаження з планшета ліміт 1000 файлів (зараз {len(entries) + 2})')
with zipfile.ZipFile('planetar-site.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for rel in sorted(entries): z.write(os.path.join(OUT, rel), rel)
    z.writestr('_worker.js', worker); z.writestr('_routes.json', json.dumps(routes, indent=1))
print(f'Pristavka: planetar-site.zip — {len(entries) + 2} файлів, {os.path.getsize("planetar-site.zip") / 1e6:.1f} МБ (для Cloudflare Pages з планшета)')
