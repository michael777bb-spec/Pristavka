// Pristavka: збирає сайт перед викладанням. Жодних бібліотек не треба — лише Node.js.
//   site/     — лендинг, значки, 404           → public/
//   console/  — приставка (улюбленець, ігри)   → public/play/
//   tools/sw-template.js → public/play/sw.js   — офлайн: перелік усіх файлів із відбитками вмісту
// Плюс готовий архів для завантаження з планшета (Cloudflare Pages → «Create deployment»):
//   planetar-site.zip = public/ + _worker.js (сервер одним файлом) + _routes.json
// Варіант GitHub: Cloudflare сам запускає `node build.mjs` і бере public/ + server/worker.js.
import { readFileSync, writeFileSync, mkdirSync, rmSync, existsSync, readdirSync, statSync, copyFileSync } from 'node:fs';
import { deflateRawSync } from 'node:zlib';
import { join, relative, dirname } from 'node:path';
import { createHash } from 'node:crypto';

const OUT = 'public', PLAY = join(OUT, 'play');
if (!existsSync('console') || !existsSync('site')) { console.error('Pristavka: немає папок console/ і site/ — чи всі файли завантажено в GitHub?'); process.exit(1); }
rmSync(OUT, { recursive: true, force: true });

function walk(dir) { const out = []; for (const n of readdirSync(dir)) { const p = join(dir, n); if (statSync(p).isDirectory()) out.push(...walk(p)); else out.push(p); } return out; }
function copyTree(from, to, skip = () => false) { let n = 0; for (const f of walk(from)) { const rel = relative(from, f); if (skip(rel)) continue; const dest = join(to, rel); mkdirSync(dirname(dest), { recursive: true }); copyFileSync(f, dest); n++; } return n; }

const a = copyTree('site', OUT);
const b = copyTree('console', PLAY, (rel) => rel.endsWith('.md') || rel === 'sw.js' || rel.startsWith('_'));

// офлайн-перелік: кожен файл приставки з відбитком вмісту → після оновлення докачуються лише змінені
const files = {};
for (const f of walk(PLAY)) {
  const rel = relative(PLAY, f).split('\\').join('/');
  if (rel === 'sw.js' || (rel.endsWith('.txt') && !rel.includes('LICENSE'))) continue;
  files[rel] = createHash('sha1').update(readFileSync(f)).digest('hex').slice(0, 10);
}
const build = new Date().toISOString().replace(/\D/g, '').slice(0, 14);
const sorted = Object.fromEntries(Object.keys(files).sort().map((k) => [k, files[k]]));
writeFileSync(join(PLAY, 'sw.js'), readFileSync('tools/sw-template.js', 'utf8').replace('__BUILD__', build).replace('__MANIFEST__', JSON.stringify(sorted)));
const mb = Object.keys(files).reduce((s, k) => s + statSync(join(PLAY, k)).size, 0) / 1e6;
console.log(`Pristavka: сайт ${a} файлів, приставка ${b} файлів, офлайн ${Object.keys(files).length} файлів (${mb.toFixed(1)} МБ), збірка ${build}`);

// ---------- перевірка синтаксису: зламаний файл не потрапить на сайт ----------
{
  const { spawnSync } = await import('node:child_process'); const os = await import('node:os');
  const files = [...walk('console/js').filter((f) => f.endsWith('.js')), 'server/worker.js'];
  const bad = [];
  for (const f of files) {
    const tmp = join(os.tmpdir(), 'planetar-check.mjs'); writeFileSync(tmp, readFileSync(f));
    const r = spawnSync(process.execPath, ['--check', tmp], { encoding: 'utf8' });
    if (r.status !== 0) bad.push(`${f}: ${(r.stderr.split('\n').find((l) => /Error/.test(l)) || '').trim()} (рядок ${(r.stderr.match(/:(\d+)\n/) || [])[1] || '?'})`);
  }
  if (bad.length) { console.error('Pristavka: помилка в коді — сайт не зібрано:\n  ' + bad.join('\n  ')); process.exit(1); }
  console.log(`Pristavka: синтаксис ${files.length} файлів — без помилок`);
}

// ---------- сумісність зі старими телефонами ----------
// Те, що раніше лишало білий екран на iPhone SE (iOS < 16.4) і старих Android (Chrome < 94):
//   • `static { }` у класах (three.js нових версій) — браузер не розбирає файл взагалі;
//   • importmap / «голі» імпорти 'three' — не працюють у тих самих браузерах.
// Тому three.js у console/lib/ — оброблений (esbuild --target=es2019, див. console/lib/README.txt), а імпорти — відносні.
{
  const bad = [];
  for (const f of [...walk('console/js'), ...walk('console/lib')].filter((x) => x.endsWith('.js'))) {
    const src = readFileSync(f, 'utf8');
    if (/\bstatic\s*\{/.test(src)) bad.push(`${f}: «static { }» — старі iPhone/Android не розберуть (обробити esbuild --target=es2019)`);
    if (src.split('\n').some((l) => !/^\s*(\*|\/\/|\/\*)/.test(l) && /\bfrom\s*['"]three(\/[^'"]*)?['"]/.test(l))) bad.push(`${f}: імпорт 'three' без шляху — потрібен відносний (../lib/three.module.js)`);
  }
  if (/importmap/.test(readFileSync('console/index.html', 'utf8'))) bad.push('console/index.html: importmap — не працює на iOS < 16.4 (використовуй відносні імпорти)');
  if (bad.length) { console.error('Pristavka: код не піде на старих телефонах — сайт не зібрано:\n  ' + bad.join('\n  ')); process.exit(1); }
  console.log('Pristavka: сумісність зі старими телефонами — без зауважень');
}

// ---------- архів для планшета (Cloudflare Pages, завантаження файлом) ----------
// Сервер — один файл _worker.js (на Pages немає Durable Objects, тож кімнати працюють через опитування — це вже в worker.js).
const worker = readFileSync('server/worker.js', 'utf8').replace(/^export \{ Room \} from '\.\/room\.js';\s*$/m, '// (на Pages кімнати без Durable Objects — див. roomPoll)');
if (/from '\.\//.test(worker)) { console.error('Pristavka: server/worker.js імпортує інші файли — для архіву планшета сервер має бути одним файлом'); process.exit(1); }
const routes = { version: 1, include: ['/', '/en/', '/ru/', '/index.html', '/api/*', '/robots.txt', '/sitemap.xml'], exclude: [] };
const CRC = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c; });
const crc32 = (b) => { let c = -1; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; };
function zip(entries) { // [[імʼя, Buffer]] → Buffer (звичайний .zip, файли в корені)
  const parts = [], dir = []; let off = 0;
  for (const [name, data] of entries) {
    const nm = Buffer.from(name, 'utf8'), z = deflateRawSync(data, { level: 9 }), crc = crc32(data);
    const h = Buffer.alloc(30); h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(8, 8); h.writeUInt32LE(0x00210000, 10);
    h.writeUInt32LE(crc, 14); h.writeUInt32LE(z.length, 18); h.writeUInt32LE(data.length, 22); h.writeUInt16LE(nm.length, 26);
    const d = Buffer.alloc(46); d.writeUInt32LE(0x02014b50, 0); d.writeUInt16LE(20, 4); d.writeUInt16LE(20, 6); d.writeUInt16LE(0x0800, 8); d.writeUInt16LE(8, 10); d.writeUInt32LE(0x00210000, 12);
    d.writeUInt32LE(crc, 16); d.writeUInt32LE(z.length, 20); d.writeUInt32LE(data.length, 24); d.writeUInt16LE(nm.length, 28); d.writeUInt32LE(off, 42);
    parts.push(h, nm, z); dir.push(d, nm); off += 30 + nm.length + z.length;
  }
  const cd = Buffer.concat(dir), e = Buffer.alloc(22); e.writeUInt32LE(0x06054b50, 0); e.writeUInt16LE(entries.length, 8); e.writeUInt16LE(entries.length, 10); e.writeUInt32LE(cd.length, 12); e.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cd, e]);
}
const entries = walk(OUT).sort().map((f) => [relative(OUT, f).split('\\').join('/'), readFileSync(f)]);
entries.push(['_worker.js', Buffer.from(worker)], ['_routes.json', Buffer.from(JSON.stringify(routes, null, 1))]);
const big = entries.filter(([, d]) => d.length > 25 * 1024 * 1024);
if (entries.length > 1000 || big.length) { console.error(`Pristavka: для завантаження з планшета ліміт 1000 файлів і 25 МБ на файл (зараз ${entries.length} файлів${big.length ? ', завеликі: ' + big.map((x) => x[0]).join(', ') : ''})`); process.exit(1); }
writeFileSync('planetar-site.zip', zip(entries));
console.log(`Pristavka: planetar-site.zip — ${entries.length} файлів, ${(statSync('planetar-site.zip').size / 1e6).toFixed(1)} МБ (для Cloudflare Pages з планшета)`);
